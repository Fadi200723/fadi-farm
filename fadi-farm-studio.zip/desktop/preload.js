/* جسر آمن بين التطبيق والحاسوب: قراءة التنزيلات الجديدة (لالتقاط ملفات Google Vids وFlow) وفتح الروابط */
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('fadiDesktop', {
  recent: (kind, since) => ipcRenderer.invoke('dl-recent', kind, since),
  read: p => ipcRenderer.invoke('dl-read', p),
  open: url => ipcRenderer.invoke('open-url', url),
  setIcon: (bytes, name) => ipcRenderer.invoke('set-app-icon', bytes, name),
  bioAvailable: () => ipcRenderer.invoke('bio-available'),
  bioAuth: msg => ipcRenderer.invoke('bio-auth', msg),
  req: o => ipcRenderer.invoke('http-req', o),
  bin: url => ipcRenderer.invoke('http-bin', url),
  get: (url, headers) => ipcRenderer.invoke('http-get', url, headers),
});
