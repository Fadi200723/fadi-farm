/* جسر آمن بين التطبيق والحاسوب: قراءة التنزيلات الجديدة (لالتقاط ملفات Google Vids وFlow) وفتح الروابط */
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('fadiDesktop', {
  recent: (kind, since) => ipcRenderer.invoke('dl-recent', kind, since),
  read: p => ipcRenderer.invoke('dl-read', p),
  open: url => ipcRenderer.invoke('open-url', url),
});
