/* Fadi — نسخة الحاسوب (Windows): نفس التطبيق داخل نافذة مستقلة، بدون قيود المتصفح على المصادر */
const { app, BrowserWindow, shell, session, Menu, ipcMain, net, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');

// الاسم الجديد Swift: نُبقي مجلد البيانات القديم (Fadi) حتى لا تضيع المفاتيح والمشاريع
app.setPath('userData', path.join(app.getPath('appData'), 'Fadi'));
// نسخة واحدة فقط من التطبيق
if (!app.requestSingleInstanceLock()) app.quit();

/* مجلد التنزيلات: يلتقط التطبيق ملفات Google Vids وFlow الجديدة تلقائياً */
const EXT = { video: ['.mp4', '.webm', '.mov', '.m4a', '.mp3', '.wav', '.ogg'], image: ['.png', '.jpg', '.jpeg', '.webp'] };
const MIME = { '.mp4': 'video/mp4', '.webm': 'video/webm', '.mov': 'video/quicktime', '.m4a': 'audio/mp4', '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.ogg': 'audio/ogg', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp' };
ipcMain.handle('dl-recent', async (e, kind, since) => {
  const dir = app.getPath('downloads'), ok = kind === 'image' ? EXT.image : kind === 'video' ? EXT.video : [...EXT.video, ...EXT.image];
  const out = [];
  for (const name of await fs.promises.readdir(dir).catch(() => [])) {
    const ext = path.extname(name).toLowerCase(); if (!ok.includes(ext)) continue;
    const p = path.join(dir, name); const st = await fs.promises.stat(p).catch(() => null); if (!st || !st.isFile()) continue;
    if (st.mtimeMs / 1000 < since || Date.now() - st.mtimeMs < 1500) continue;      // جديد ومكتمل التنزيل
    out.push({ uri: p, name, size: st.size, date: Math.floor(st.mtimeMs / 1000), mime: MIME[ext] || '' });
  }
  return out.sort((a, b) => b.date - a.date).slice(0, 8);
});
ipcMain.handle('dl-read', async (e, p) => {
  const dir = path.resolve(app.getPath('downloads'));
  if (!path.resolve(p).startsWith(dir)) throw new Error('غير مسموح');
  return new Uint8Array(await fs.promises.readFile(p));
});
ipcMain.handle('open-url', (e, url) => { if (/^https?:/.test(url)) shell.openExternal(url); });
/* طلب GET من جهة الحاسوب (بدون قيود المتصفح CORS) لمصادر الصور التي تمنع الاتصال من المتصفح */
/* تنزيل ملف (صورة/فيديو) يمنع المتصفح تنزيله مباشرة */
ipcMain.handle('http-bin', async (e, url) => {
  if (!/^https:\/\//.test(url)) return null;
  try {
    const ac = new AbortController(), t = setTimeout(() => ac.abort(), 120000);
    const r = await net.fetch(url, { signal: ac.signal }); if (!r.ok) { clearTimeout(t); return null; }
    const b = new Uint8Array(await r.arrayBuffer()); clearTimeout(t);
    return b.length > 150e6 ? null : { bytes: b, type: r.headers.get('content-type') || '' };
  } catch { return null; }
});
/* طلب كامل (POST/GET) من جهة البرنامج: صوت ChatGPT وغيره بدون قيود المتصفح */
ipcMain.handle('http-req', async (e, o) => {
  if (!o || !/^https:\/\//.test(o.url)) return { status: 0, data: '' };
  try {
    const ac = new AbortController(), t = setTimeout(() => ac.abort(), o.timeout || 120000);
    const r = await net.fetch(o.url, { method: o.method || 'GET', headers: o.headers || {}, body: o.body == null ? undefined : o.body, signal: ac.signal });
    const buf = Buffer.from(await r.arrayBuffer()); clearTimeout(t);
    return { status: r.status, data: o.binary && r.ok ? buf.toString('base64') : buf.toString('utf8'), retryAfter: parseFloat(r.headers.get('retry-after')) || 0 };
  } catch (err) { return { status: 0, data: String(err && err.message || err) }; }
});
ipcMain.handle('http-get', async (e, url, headers) => {
  if (!/^https:\/\//.test(url)) return { status: 0, data: '' };
  try {
    const ac = new AbortController(), t = setTimeout(() => ac.abort(), 15000);
    const r = await net.fetch(url, { headers: headers || {}, signal: ac.signal });
    const data = await r.text(); clearTimeout(t);
    return { status: r.status, data: data.slice(0, 8e6) };
  } catch (err) { return { status: 0, data: String(err && err.message || err) }; }
});

/* أيقونة واسم التطبيق على سطح المكتب وقائمة ابدأ وشريط المهام (صورة من اختيارك) */
const ICON_PNG = () => path.join(app.getPath('userData'), 'custom-icon.png');
// ويندوز يحفظ الأيقونات حسب اسم الملف، فنكتب ملف ICO باسم جديد في كل تغيير حتى تتحدث فوراً
const icoDir = () => path.join(app.getPath('userData'), 'icons');
function pngToIco(png) {        // ملف ICO يحتوي صورة PNG بحجم 256 (مدعوم في ويندوز 7 وما بعده)
  const h = Buffer.alloc(22);
  h.writeUInt16LE(0, 0); h.writeUInt16LE(1, 2); h.writeUInt16LE(1, 4);
  h.writeUInt8(0, 6); h.writeUInt8(0, 7); h.writeUInt8(0, 8); h.writeUInt8(0, 9);
  h.writeUInt16LE(1, 10); h.writeUInt16LE(32, 12); h.writeUInt32LE(png.length, 14); h.writeUInt32LE(22, 18);
  return Buffer.concat([h, png]);
}
function shortcutDirs() {
  const dirs = [app.getPath('desktop')];
  try { dirs.push(path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs')); } catch {}
  return dirs;
}
ipcMain.handle('set-app-icon', async (e, bytes, name) => {
  if (process.platform !== 'win32') return { ok: false, reason: 'windows-only' };
  const png = Buffer.from(bytes);
  await fs.promises.mkdir(icoDir(), { recursive: true });
  for (const f of await fs.promises.readdir(icoDir()).catch(() => [])) await fs.promises.unlink(path.join(icoDir(), f)).catch(() => {});
  const ICO = path.join(icoDir(), `fadi-${Date.now()}.ico`);
  await fs.promises.writeFile(ICON_PNG(), png); await fs.promises.writeFile(ICO, pngToIco(png));
  const img = nativeImage.createFromPath(ICON_PNG());
  BrowserWindow.getAllWindows().forEach(w => w.setIcon(img));
  const label = String(name || 'Fadi').replace(/[\\/:*?"<>|]/g, '').trim() || 'Fadi';
  let n = 0;
  for (const dir of shortcutDirs()) {
    const files = await fs.promises.readdir(dir).catch(() => []);
    let found = false;
    for (const f of files.filter(x => x.toLowerCase().endsWith('.lnk'))) {
      const p = path.join(dir, f);
      try {
        const l = shell.readShortcutLink(p);
        if (path.resolve(l.target).toLowerCase() !== path.resolve(process.execPath).toLowerCase()) continue;
        found = true;
        const np = path.join(dir, label + '.lnk');
        shell.writeShortcutLink(np, 'create', { ...l, target: process.execPath, icon: ICO, iconIndex: 0, description: label });
        if (np.toLowerCase() !== p.toLowerCase()) await fs.promises.unlink(p).catch(() => {});
        n++;
      } catch {}
    }
    if (!found && dir === app.getPath('desktop')) { try { shell.writeShortcutLink(path.join(dir, label + '.lnk'), 'create', { target: process.execPath, icon: ICO, iconIndex: 0, description: label }); n++; } catch {} }
  }
  // تحديث ذاكرة أيقونات ويندوز حتى تظهر الأيقونة الجديدة على سطح المكتب
  try { require('child_process').execFile('ie4uinit.exe', ['-show'], () => {}); } catch {}
  return { ok: true, shortcuts: n };
});

/* Windows Hello (البصمة / الوجه / رمز PIN) لقفل القنوات — عبر PowerShell وواجهة ويندوز الرسمية */
const HELLO_PS = [
  "$ErrorActionPreference='Stop'",
  "Add-Type -AssemblyName System.Runtime.WindowsRuntime",
  "$null=[Windows.Security.Credentials.UI.UserConsentVerifier,Windows.Security.Credentials.UI,ContentType=WindowsRuntime]",
  "$m=([System.WindowsRuntimeSystemExtensions].GetMethods()|Where-Object{$_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation" + "`" + "1'})[0]",
  "function Wait-Op($op,$t){$task=$m.MakeGenericMethod($t).Invoke($null,@($op));$task.Wait(-1)|Out-Null;$task.Result}",
  "if($env:FADI_HELLO -eq 'check'){Wait-Op ([Windows.Security.Credentials.UI.UserConsentVerifier]::CheckAvailabilityAsync()) ([Windows.Security.Credentials.UI.UserConsentVerifierAvailability])} else {Wait-Op ([Windows.Security.Credentials.UI.UserConsentVerifier]::RequestVerificationAsync($env:FADI_HELLO_MSG)) ([Windows.Security.Credentials.UI.UserConsentVerificationResult])}",
].join('\n');
function hello(mode, msg) {
  return new Promise(res => {
    if (process.platform !== 'win32') return res('');
    require('child_process').execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', HELLO_PS],
      { env: { ...process.env, FADI_HELLO: mode, FADI_HELLO_MSG: String(msg || 'Fadi').slice(0, 120) }, windowsHide: true, timeout: 120000 },
      (err, out) => res(String(out || '').trim()));
  });
}
ipcMain.handle('bio-available', async () => (await hello('check')) === 'Available');
ipcMain.handle('bio-auth', async (e, msg) => /^Verified/m.test(await hello('verify', msg)));

function create() {
  const win = new BrowserWindow({
    width: 1280, height: 880, minWidth: 380, minHeight: 600,
    title: 'Swift', backgroundColor: '#05070d', autoHideMenuBar: true,
    icon: fs.existsSync(ICON_PNG()) ? ICON_PNG() : path.join(__dirname, 'web', 'icons', 'icon-512.png'),
    webPreferences: { webSecurity: false, contextIsolation: true, backgroundThrottling: false, preload: path.join(__dirname, 'preload.js') },
  });
  // الروابط الخارجية (Google Vids، Flow، المصادر) تفتح في المتصفح
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  // قائمة الزر الأيمن للفأرة: نسخ / لصق / قص / تحديد الكل
  win.webContents.on('context-menu', (e, p) => {
    const t = [];
    if (p.isEditable) t.push({ role: 'cut', label: 'قص' }, { role: 'copy', label: 'نسخ' }, { role: 'paste', label: 'لصق' }, { type: 'separator' }, { role: 'selectAll', label: 'تحديد الكل' });
    else if (p.selectionText) t.push({ role: 'copy', label: 'نسخ' });
    if (t.length) Menu.buildFromTemplate(t).popup({ window: win });
  });
  win.loadFile(path.join(__dirname, 'web', 'index.html'));
}

app.whenReady().then(() => {
  // قائمة مخفية تحفظ اختصارات Ctrl+C / Ctrl+V / Ctrl+X / Ctrl+A
  Menu.setApplicationMenu(Menu.buildFromTemplate([{ label: 'تحرير', submenu: [{ role: 'undo' }, { role: 'redo' }, { type: 'separator' }, { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }] }, { label: 'عرض', submenu: [{ role: 'reload' }, { role: 'togglefullscreen' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { role: 'resetZoom' }] }]));
  // حفظ الفيديو والصور: يسأل أين تحفظ الملف
  session.defaultSession.on('will-download', (e, item) => { item.setSaveDialogOptions({ title: 'حفظ الملف' }); });
  create();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) create(); });
});
app.on('second-instance', () => { const w = BrowserWindow.getAllWindows()[0]; if (w) { if (w.isMinimized()) w.restore(); w.focus(); } });
app.on('window-all-closed', () => app.quit());
