/* Fadi — نسخة الحاسوب (Windows): نفس التطبيق داخل نافذة مستقلة، بدون قيود المتصفح على المصادر */
const { app, BrowserWindow, shell, session, Menu } = require('electron');
const path = require('path');

function create() {
  const win = new BrowserWindow({
    width: 1280, height: 880, minWidth: 380, minHeight: 600,
    title: 'Fadi', backgroundColor: '#05070d', autoHideMenuBar: true,
    icon: path.join(__dirname, 'web', 'icons', 'icon-512.png'),
    webPreferences: { webSecurity: false, contextIsolation: true, backgroundThrottling: false },
  });
  // الروابط الخارجية (Google Vids، Flow، المصادر) تفتح في المتصفح
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  // قائمة الزر الأيمن للفأرة: نسخ / لصق / قص / تحديد الكل
  win.webContents.on('context-menu', (e, p) => {
    const t = [];
    if (p.isEditable) t.push({ role: 'cut', label: 'قص' }, { role: 'copy', label: 'نسخ' }, { role: 'paste', label: 'لصق' }, { type: 'separator' }, { role: 'selectAll', label: 'تحديد الكل' });
    else if (p.selectionText) t.push({ role: 'copy', label: 'نسخ' });
    if (t.length) Menu.buildFromTemplate(t).popup({ window: win });
  });
  win.loadFile(path.join(__dirname, 'web', 'index.html'));
}

app.whenReady().then(() => {
  // قائمة مخفية تحفظ اختصارات Ctrl+C / Ctrl+V / Ctrl+X / Ctrl+A
  Menu.setApplicationMenu(Menu.buildFromTemplate([{ label: 'تحرير', submenu: [{ role: 'undo' }, { role: 'redo' }, { type: 'separator' }, { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }] }, { label: 'عرض', submenu: [{ role: 'reload' }, { role: 'togglefullscreen' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { role: 'resetZoom' }] }]));
  // حفظ الفيديو والصور: يسأل أين تحفظ الملف
  session.defaultSession.on('will-download', (e, item) => { item.setSaveDialogOptions({ title: 'حفظ الملف' }); });
  create();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) create(); });
});
app.on('window-all-closed', () => app.quit());
