/* Fadi — نسخة الحاسوب (Windows): نفس التطبيق داخل نافذة مستقلة، بدون قيود المتصفح على المصادر */
const { app, BrowserWindow, shell, session, Menu, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');

// نسخة واحدة فقط من التطبيق
if (!app.requestSingleInstanceLock()) app.quit();

/* مجلد التنزيلات: يلتقط التطبيق ملفات Google Vids وFlow الجديدة تلقائياً */
const EXT = { video: ['.mp4', '.webm', '.mov', '.m4a', '.mp3', '.wav', '.ogg'], image: ['.png', '.jpg', '.jpeg', '.webp'] };
const MIME = { '.mp4': 'video/mp4', '.webm': 'video/webm', '.mov': 'video/quicktime', '.m4a': 'audio/mp4', '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.ogg': 'audio/ogg', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp' };
ipcMain.handle('dl-recent', async (e, kind, since) => {
  const dir = app.getPath('downloads'), ok = kind === 'image' ? EXT.image : kind === 'video' ? EXT.video : [...EXT.video, ...EXT.image];
  const out = [];
  for (const name of await fs.promises.readdir(dir).catch(() => [])) {
    const ext = path.extname(name).toLowerCase(); if (!ok.includes(ext)) continue;
    const p = path.join(dir, name); const st = await fs.promises.stat(p).catch(() => null); if (!st || !st.isFile()) continue;
    if (st.mtimeMs / 1000 < since || Date.now() - st.mtimeMs < 1500) continue;      // جديد ومكتمل التنزيل
    out.push({ uri: p, name, size: st.size, date: Math.floor(st.mtimeMs / 1000), mime: MIME[ext] || '' });
  }
  return out.sort((a, b) => b.date - a.date).slice(0, 8);
});
ipcMain.handle('dl-read', async (e, p) => {
  const dir = path.resolve(app.getPath('downloads'));
  if (!path.resolve(p).startsWith(dir)) throw new Error('غير مسموح');
  return new Uint8Array(await fs.promises.readFile(p));
});
ipcMain.handle('open-url', (e, url) => { if (/^https?:/.test(url)) shell.openExternal(url); });

function create() {
  const win = new BrowserWindow({
    width: 1280, height: 880, minWidth: 380, minHeight: 600,
    title: 'Fadi', backgroundColor: '#05070d', autoHideMenuBar: true,
    icon: path.join(__dirname, 'web', 'icons', 'icon-512.png'),
    webPreferences: { webSecurity: false, contextIsolation: true, backgroundThrottling: false, preload: path.join(__dirname, 'preload.js') },
  });
  // الروابط الخارجية (Google Vids، Flow، المصادر) تفتح في المتصفح
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  // قائمة الزر الأيمن للفأرة: نسخ / لصق / قص / تحديد الكل
  win.webContents.on('context-menu', (e, p) => {
    const t = [];
    if (p.isEditable) t.push({ role: 'cut', label: 'قص' }, { role: 'copy', label: 'نسخ' }, { role: 'paste', label: 'لصق' }, { type: 'separator' }, { role: 'selectAll', label: 'تحديد الكل' });
    else if (p.selectionText) t.push({ role: 'copy', label: 'نسخ' });
    if (t.length) Menu.buildFromTemplate(t).popup({ window: win });
  });
  win.loadFile(path.join(__dirname, 'web', 'index.html'));
}

app.whenReady().then(() => {
  // قائمة مخفية تحفظ اختصارات Ctrl+C / Ctrl+V / Ctrl+X / Ctrl+A
  Menu.setApplicationMenu(Menu.buildFromTemplate([{ label: 'تحرير', submenu: [{ role: 'undo' }, { role: 'redo' }, { type: 'separator' }, { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }] }, { label: 'عرض', submenu: [{ role: 'reload' }, { role: 'togglefullscreen' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { role: 'resetZoom' }] }]));
  // حفظ الفيديو والصور: يسأل أين تحفظ الملف
  session.defaultSession.on('will-download', (e, item) => { item.setSaveDialogOptions({ title: 'حفظ الملف' }); });
  create();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) create(); });
});
app.on('second-instance', () => { const w = BrowserWindow.getAllWindows()[0]; if (w) { if (w.isMinimized()) w.restore(); w.focus(); } });
app.on('window-all-closed', () => app.quit());
