/* Fadi — نسخة الحاسوب (Windows): نفس التطبيق داخل نافذة مستقلة، بدون قيود المتصفح على المصادر */
const { app, BrowserWindow, shell, session } = require('electron');
const path = require('path');

function create() {
  const win = new BrowserWindow({
    width: 1280, height: 880, minWidth: 380, minHeight: 600,
    title: 'Fadi', backgroundColor: '#05070d', autoHideMenuBar: true,
    icon: path.join(__dirname, 'web', 'icons', 'icon-512.png'),
    webPreferences: { webSecurity: false, contextIsolation: true, backgroundThrottling: false },
  });
  // الروابط الخارجية (Google Vids، Flow، المصادر) تفتح في المتصفح
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.loadFile(path.join(__dirname, 'web', 'index.html'));
}

app.whenReady().then(() => {
  // حفظ الفيديو والصور: يسأل أين تحفظ الملف
  session.defaultSession.on('will-download', (e, item) => { item.setSaveDialogOptions({ title: 'حفظ الملف' }); });
  create();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) create(); });
});
app.on('window-all-closed', () => app.quit());
