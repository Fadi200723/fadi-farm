# Fadi Farm Studio

تطبيق أندرويد يحوّل التعليق الصوتي إلى فيديو: تفريغ بـ Gemini، مشاهد بتوقيت، وسائط من Pexels وPixabay وWikimedia وNASA وInternet Archive وOpenverse وUnsplash، وتصدير MP4.

## رابط تحميل التطبيق
بعد أول بناء ناجح يكون الرابط المباشر:

https://github.com/اسم-حسابك/fadi-farm/releases/latest/download/FadiFarm.apk

- `web/` واجهة التطبيق.
- `android-build/` الأيقونة الدائرية، شاشة البداية، مفتاح التوقيع، وسكربت البناء.
- `.github/workflows/build.yml` يبني APK تلقائياً مع كل تعديل وينشره على نفس الرابط.

احتفظ بملف `android-build/release.keystore` كما هو: بدونه لن يقبل الهاتف التحديثات فوق النسخة المثبتة.
