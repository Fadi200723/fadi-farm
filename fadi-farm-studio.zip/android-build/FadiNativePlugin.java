package com.fadifarm.studio;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentUris;
import android.content.Context;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** حفظ الملفات في معرض الهاتف (MediaStore) واختيار الصور والفيديو من المعرض. */
@CapacitorPlugin(
    name = "FadiNative",
    permissions = {
        @Permission(alias = "media", strings = { Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_IMAGES }),
        @Permission(alias = "storage", strings = { Manifest.permission.READ_EXTERNAL_STORAGE })
    }
)
public class FadiNativePlugin extends Plugin {

    private File part(String id) {
        String safe = id == null ? "x" : id.replaceAll("[^a-zA-Z0-9_-]", "");
        return new File(getContext().getCacheDir(), "out-" + safe + ".part");
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[256 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        out.flush();
    }

    @PluginMethod
    public void begin(PluginCall call) {
        File f = part(call.getString("id"));
        try {
            if (f.exists()) f.delete();
            if (!f.createNewFile()) throw new IOException("cannot create temp file");
            call.resolve();
        } catch (Exception e) {
            call.reject("begin: " + e.getMessage());
        }
    }

    @PluginMethod
    public void append(PluginCall call) {
        File f = part(call.getString("id"));
        String data = call.getString("data", "");
        try (FileOutputStream os = new FileOutputStream(f, true)) {
            os.write(Base64.decode(data, Base64.DEFAULT));
            os.flush();
            JSObject r = new JSObject();
            r.put("size", f.length());
            call.resolve(r);
        } catch (Exception e) {
            call.reject("append: " + e.getMessage());
        }
    }

    @PluginMethod
    public void finish(PluginCall call) {
        File src = part(call.getString("id"));
        String name = call.getString("name", "fadi-farm.mp4");
        String mime = call.getString("mime", "video/mp4");
        boolean isVideo = mime.startsWith("video");
        boolean isImage = mime.startsWith("image");
        String dirName = isVideo ? Environment.DIRECTORY_MOVIES : isImage ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS;
        try {
            long size = src.length();
            Uri uri;
            ContentResolver cr = getContext().getContentResolver();
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, dirName + "/FadiFarm");
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri collection = isVideo ? MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                        : isImage ? MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                        : MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                uri = cr.insert(collection, v);
                if (uri == null) throw new IOException("MediaStore insert failed");
                try (InputStream in = new FileInputStream(src); OutputStream out = cr.openOutputStream(uri)) {
                    if (out == null) throw new IOException("cannot open output");
                    copy(in, out);
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                cr.update(uri, done, null, null);
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(dirName), "FadiFarm");
                if (!dir.exists()) dir.mkdirs();
                File dst = new File(dir, name);
                try (InputStream in = new FileInputStream(src); OutputStream out = new FileOutputStream(dst)) {
                    copy(in, out);
                }
                MediaScannerConnection.scanFile(getContext(), new String[] { dst.getAbsolutePath() }, new String[] { mime }, null);
                uri = Uri.fromFile(dst);
            }
            src.delete();
            JSObject r = new JSObject();
            r.put("uri", uri.toString());
            r.put("size", size);
            r.put("folder", dirName + "/FadiFarm");
            call.resolve(r);
        } catch (Exception e) {
            call.reject("save: " + e.getMessage());
        }
    }

    @PluginMethod
    public void share(PluginCall call) {
        try {
            Uri uri = Uri.parse(call.getString("uri"));
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(call.getString("mime", "*/*"));
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(send, call.getString("title", "Fadi Farm"));
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            getActivity().startActivity(chooser);
            call.resolve();
        } catch (Exception e) {
            call.reject("share: " + e.getMessage());
        }
    }

    /** يفتح معرض الصور/الفيديو مباشرة (وليس Google Photos أو مدير الملفات). */
    @PluginMethod
    public void pick(PluginCall call) {
        boolean video = "video".equals(call.getString("kind", "image"));
        Uri collection = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        Intent i = new Intent(Intent.ACTION_PICK);
        i.setDataAndType(collection, video ? "video/*" : "image/*");
        try {
            startActivityForResult(call, i, "pickDone");
        } catch (Exception e) {
            Intent g = new Intent(Intent.ACTION_GET_CONTENT);
            g.setType(video ? "video/*" : "image/*");
            g.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(call, g, "pickDone");
        }
    }

    @ActivityCallback
    private void pickDone(PluginCall call, ActivityResult result) {
        if (call == null) return;
        Intent data = result.getData();
        if (result.getResultCode() != Activity.RESULT_OK || data == null || data.getData() == null) {
            call.reject("cancelled", "CANCELLED");
            return;
        }
        Uri uri = data.getData();
        try {
            call.resolve(copyToCache(uri));
        } catch (Exception e) {
            call.reject("pick: " + e.getMessage());
        }
    }

    private JSObject copyToCache(Uri uri) throws IOException {
        {
            ContentResolver cr = getContext().getContentResolver();
            String mime = cr.getType(uri);
            if (mime == null) mime = "application/octet-stream";
            String name = "media";
            try (Cursor c = cr.query(uri, new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    String n = c.getString(0);
                    if (n != null) name = n;
                }
            } catch (Exception ignored) { }
            File dir = new File(getContext().getCacheDir(), "picked");
            if (!dir.exists()) dir.mkdirs();
            File[] old = dir.listFiles();
            if (old != null) for (File f : old) f.delete();
            File dst = new File(dir, System.currentTimeMillis() + "-" + name.replaceAll("[^\\w.\\-]", "_"));
            try (InputStream in = cr.openInputStream(uri); OutputStream out = new FileOutputStream(dst)) {
                if (in == null) throw new IOException("cannot read");
                copy(in, out);
            }
            JSObject r = new JSObject();
            r.put("path", dst.getAbsolutePath());
            r.put("name", name);
            r.put("mime", mime);
            r.put("size", dst.length());
            return r;
        }
    }

    /* ---------- التقاط الملفات المنزّلة تلقائياً (من Google Vids و Google Flow) ---------- */

    private String mediaAlias() { return Build.VERSION.SDK_INT >= 33 ? "media" : "storage"; }

    @PluginMethod
    public void recent(PluginCall call) {
        if (getPermissionState(mediaAlias()) != PermissionState.GRANTED) {
            requestPermissionForAlias(mediaAlias(), call, "recentPerm");
            return;
        }
        doRecent(call);
    }

    @PermissionCallback
    private void recentPerm(PluginCall call) {
        if (getPermissionState(mediaAlias()) == PermissionState.GRANTED) doRecent(call);
        else call.reject("permission denied", "DENIED");
    }

    private void doRecent(PluginCall call) {
        String kind = call.getString("kind", "video");
        Double sd = call.getDouble("since", 0.0);
        long since = sd == null ? 0L : sd.longValue();
        Integer li = call.getInt("limit", 10);
        int limit = li == null ? 10 : li;
        JSArray items = new JSArray();
        try {
            if (!"image".equals(kind)) query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, since, limit, items);
            if (!"video".equals(kind)) query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, since, limit, items);
            JSObject r = new JSObject();
            r.put("items", items);
            call.resolve(r);
        } catch (Exception e) {
            call.reject("recent: " + e.getMessage());
        }
    }

    private void query(Uri collection, long since, int limit, JSArray out) {
        ContentResolver cr = getContext().getContentResolver();
        String[] cols = Build.VERSION.SDK_INT >= 29
            ? new String[] { MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_ADDED, MediaStore.MediaColumns.RELATIVE_PATH }
            : new String[] { MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_ADDED };
        String sel = MediaStore.MediaColumns.DATE_ADDED + " >= ?";
        String[] args = new String[] { String.valueOf(since) };
        try (Cursor c = cr.query(collection, cols, sel, args, MediaStore.MediaColumns.DATE_ADDED + " DESC")) {
            if (c == null) return;
            int n = 0;
            while (c.moveToNext() && n < limit) {
                String rel = cols.length > 5 ? c.getString(5) : "";
                if (rel != null && rel.contains("FadiFarm")) continue;   // تجاهل ملفات التطبيق نفسه
                long id = c.getLong(0);
                JSObject o = new JSObject();
                o.put("uri", ContentUris.withAppendedId(collection, id).toString());
                o.put("name", c.getString(1));
                o.put("mime", c.getString(2));
                o.put("size", c.getLong(3));
                o.put("date", c.getLong(4));
                out.put(o);
                n++;
            }
        }
    }

    @PluginMethod
    public void importUri(PluginCall call) {
        try {
            call.resolve(copyToCache(Uri.parse(call.getString("uri"))));
        } catch (Exception e) {
            call.reject("import: " + e.getMessage());
        }
    }

    @PluginMethod
    public void copyText(PluginCall call) {
        try {
            ClipboardManager cm = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Fadi Farm", call.getString("text", "")));
            call.resolve();
        } catch (Exception e) {
            call.reject("copy: " + e.getMessage());
        }
    }

    @PluginMethod
    public void open(PluginCall call) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(call.getString("url")));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (call.getBoolean("newTab", false)) {
                // تبويب جديد في كل مرة بدل الرجوع للصفحة السابقة
                i.putExtra("create_new_tab", true);
                i.putExtra(android.provider.Browser.EXTRA_APPLICATION_ID, "fadifarm" + System.currentTimeMillis());
            }
            getActivity().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("open: " + e.getMessage());
        }
    }

    /** جلب نص من الإنترنت (RSS/JSON) بدون قيود CORS — لمصادر الترندات */
    @PluginMethod
    public void fetchText(PluginCall call) {
        final String url = call.getString("url");
        if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) { call.reject("bad url"); return; }
        new Thread(() -> {
            java.net.HttpURLConnection c = null;
            try {
                c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
                c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setInstanceFollowRedirects(true);
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Mobile Safari/537.36");
                c.setRequestProperty("Accept-Language", "ar,en;q=0.8");
                if (url.contains("youtube.com")) c.setRequestProperty("Cookie", "SOCS=CAI; CONSENT=YES+cb");
                JSObject hd = call.getObject("headers");
                if (hd != null) { java.util.Iterator<String> it = hd.keys(); while (it.hasNext()) { String k = it.next(); c.setRequestProperty(k, hd.getString(k)); } }
                int code = c.getResponseCode();
                InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                if (in != null) { byte[] b = new byte[64 * 1024]; int n; while ((n = in.read(b)) > 0 && bo.size() < 4 * 1024 * 1024) bo.write(b, 0, n); in.close(); }
                JSObject r = new JSObject();
                r.put("status", code);
                r.put("data", new String(bo.toByteArray(), "UTF-8"));
                call.resolve(r);
            } catch (Exception e) {
                call.reject("fetch: " + e.getMessage());
            } finally { if (c != null) c.disconnect(); }
        }).start();
    }

    /** طلب HTTP عام (POST/GET) بدون قيود CORS — لمزوّدي الذكاء الاصطناعي والصوت.
        responseType: "text" (افتراضي) أو "base64" للملفات الصوتية */
    @PluginMethod
    public void httpRequest(PluginCall call) {
        final String url = call.getString("url");
        final String method = call.getString("method", "GET");
        final String body = call.getString("body");
        final String rtype = call.getString("responseType", "text");
        final JSObject hd = call.getObject("headers");
        final int timeout = call.getInt("timeout", 120000);
        if (url == null || !url.startsWith("https://")) { call.reject("bad url"); return; }
        new Thread(() -> {
            java.net.HttpURLConnection c = null;
            try {
                c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
                c.setConnectTimeout(20000); c.setReadTimeout(timeout); c.setRequestMethod(method);
                if (hd != null) { java.util.Iterator<String> it = hd.keys(); while (it.hasNext()) { String k = it.next(); c.setRequestProperty(k, hd.getString(k)); } }
                if (body != null) {
                    c.setDoOutput(true);
                    byte[] b = body.getBytes("UTF-8");
                    c.setFixedLengthStreamingMode(b.length);
                    OutputStream os = c.getOutputStream(); os.write(b); os.close();
                }
                int code = c.getResponseCode();
                InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                if (in != null) { byte[] buf = new byte[64 * 1024]; int n; while ((n = in.read(buf)) > 0) bo.write(buf, 0, n); in.close(); }
                JSObject r = new JSObject();
                r.put("status", code);
                String retry = c.getHeaderField("retry-after"); if (retry != null) r.put("retryAfter", retry);
                if ("base64".equals(rtype) && code < 400) r.put("data", Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP));
                else r.put("data", new String(bo.toByteArray(), "UTF-8"));
                call.resolve(r);
            } catch (Exception e) {
                call.reject("http: " + e.getMessage());
            } finally { if (c != null) c.disconnect(); }
        }).start();
    }
}
