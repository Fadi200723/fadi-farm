package com.fadifarm.studio;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** حفظ الملفات في معرض الهاتف (MediaStore) واختيار الصور والفيديو من المعرض. */
@CapacitorPlugin(name = "FadiNative")
public class FadiNativePlugin extends Plugin {

    private File part(String id) {
        String safe = id == null ? "x" : id.replaceAll("[^a-zA-Z0-9_-]", "");
        return new File(getContext().getCacheDir(), "out-" + safe + ".part");
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[256 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        out.flush();
    }

    @PluginMethod
    public void begin(PluginCall call) {
        File f = part(call.getString("id"));
        try {
            if (f.exists()) f.delete();
            if (!f.createNewFile()) throw new IOException("cannot create temp file");
            call.resolve();
        } catch (Exception e) {
            call.reject("begin: " + e.getMessage());
        }
    }

    @PluginMethod
    public void append(PluginCall call) {
        File f = part(call.getString("id"));
        String data = call.getString("data", "");
        try (FileOutputStream os = new FileOutputStream(f, true)) {
            os.write(Base64.decode(data, Base64.DEFAULT));
            os.flush();
            JSObject r = new JSObject();
            r.put("size", f.length());
            call.resolve(r);
        } catch (Exception e) {
            call.reject("append: " + e.getMessage());
        }
    }

    @PluginMethod
    public void finish(PluginCall call) {
        File src = part(call.getString("id"));
        String name = call.getString("name", "fadi-farm.mp4");
        String mime = call.getString("mime", "video/mp4");
        boolean isVideo = mime.startsWith("video");
        boolean isImage = mime.startsWith("image");
        String dirName = isVideo ? Environment.DIRECTORY_MOVIES : isImage ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS;
        try {
            long size = src.length();
            Uri uri;
            ContentResolver cr = getContext().getContentResolver();
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, dirName + "/FadiFarm");
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri collection = isVideo ? MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                        : isImage ? MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                        : MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                uri = cr.insert(collection, v);
                if (uri == null) throw new IOException("MediaStore insert failed");
                try (InputStream in = new FileInputStream(src); OutputStream out = cr.openOutputStream(uri)) {
                    if (out == null) throw new IOException("cannot open output");
                    copy(in, out);
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                cr.update(uri, done, null, null);
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(dirName), "FadiFarm");
                if (!dir.exists()) dir.mkdirs();
                File dst = new File(dir, name);
                try (InputStream in = new FileInputStream(src); OutputStream out = new FileOutputStream(dst)) {
                    copy(in, out);
                }
                MediaScannerConnection.scanFile(getContext(), new String[] { dst.getAbsolutePath() }, new String[] { mime }, null);
                uri = Uri.fromFile(dst);
            }
            src.delete();
            JSObject r = new JSObject();
            r.put("uri", uri.toString());
            r.put("size", size);
            r.put("folder", dirName + "/FadiFarm");
            call.resolve(r);
        } catch (Exception e) {
            call.reject("save: " + e.getMessage());
        }
    }

    @PluginMethod
    public void share(PluginCall call) {
        try {
            Uri uri = Uri.parse(call.getString("uri"));
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(call.getString("mime", "*/*"));
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(send, call.getString("title", "Fadi Farm"));
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            getActivity().startActivity(chooser);
            call.resolve();
        } catch (Exception e) {
            call.reject("share: " + e.getMessage());
        }
    }

    /** يفتح معرض الصور/الفيديو مباشرة (وليس Google Photos أو مدير الملفات). */
    @PluginMethod
    public void pick(PluginCall call) {
        boolean video = "video".equals(call.getString("kind", "image"));
        Uri collection = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        Intent i = new Intent(Intent.ACTION_PICK);
        i.setDataAndType(collection, video ? "video/*" : "image/*");
        try {
            startActivityForResult(call, i, "pickDone");
        } catch (Exception e) {
            Intent g = new Intent(Intent.ACTION_GET_CONTENT);
            g.setType(video ? "video/*" : "image/*");
            g.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(call, g, "pickDone");
        }
    }

    @ActivityCallback
    private void pickDone(PluginCall call, ActivityResult result) {
        if (call == null) return;
        Intent data = result.getData();
        if (result.getResultCode() != Activity.RESULT_OK || data == null || data.getData() == null) {
            call.reject("cancelled", "CANCELLED");
            return;
        }
        Uri uri = data.getData();
        try {
            ContentResolver cr = getContext().getContentResolver();
            String mime = cr.getType(uri);
            if (mime == null) mime = "application/octet-stream";
            String name = "media";
            try (Cursor c = cr.query(uri, new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    String n = c.getString(0);
                    if (n != null) name = n;
                }
            } catch (Exception ignored) { }
            File dir = new File(getContext().getCacheDir(), "picked");
            if (!dir.exists()) dir.mkdirs();
            File[] old = dir.listFiles();
            if (old != null) for (File f : old) f.delete();
            File dst = new File(dir, System.currentTimeMillis() + "-" + name.replaceAll("[^\\w.\\-]", "_"));
            try (InputStream in = cr.openInputStream(uri); OutputStream out = new FileOutputStream(dst)) {
                if (in == null) throw new IOException("cannot read");
                copy(in, out);
            }
            JSObject r = new JSObject();
            r.put("path", dst.getAbsolutePath());
            r.put("name", name);
            r.put("mime", mime);
            r.put("size", dst.length());
            call.resolve(r);
        } catch (Exception e) {
            call.reject("pick: " + e.getMessage());
        }
    }
}
