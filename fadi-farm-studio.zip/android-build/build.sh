#!/usr/bin/env bash
# يبني ملف APK لتطبيق Fadi Farm من مجلد web باستخدام Capacitor. يعمل داخل GitHub Actions.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_NO="${GITHUB_RUN_NUMBER:-1}"
W="$RUNNER_TEMP/cap"; rm -rf "$W"; mkdir -p "$W"; cd "$W"

cp -r "$ROOT/web" www
cat > package.json <<JSON
{ "name": "fadi-farm", "version": "5.21.0", "private": true }
JSON
npm install --no-audit --no-fund @capacitor/core@^6 @capacitor/cli@^6 @capacitor/android@^6 @capacitor/filesystem@^6 @capacitor/share@^6

# مكتبة الجسر بين الواجهة وأندرويد
if [ -f node_modules/@capacitor/core/dist/capacitor.js ]; then
  cp node_modules/@capacitor/core/dist/capacitor.js www/capacitor.js
  sed -i 's#<script src="js/store.js"></script>#<script src="capacitor.js"></script>\n<script src="js/store.js"></script>#' www/index.html
fi

cat > capacitor.config.json <<JSON
{
  "appId": "com.fadifarm.studio",
  "appName": "Swift",
  "webDir": "www",
  "server": { "androidScheme": "https" },
  "android": { "backgroundColor": "#05070d", "allowMixedContent": false }
}
JSON

npx cap add android
npx cap sync android

RES=android/app/src/main/res
python3 -m pip install --quiet --user --break-system-packages pillow || python3 -m pip install --quiet pillow
# الأيقونة الدائرية + شاشة البداية، تُولَّد من صور التطبيق
python3 - "$ROOT" "$RES" <<'PY'
import sys, glob, os
from PIL import Image
root, res = sys.argv[1], sys.argv[2]
rnd = Image.open(root + '/web/icons/icon-512.png').convert('RGBA')
fg = Image.open(root + '/android-build/fg.png').convert('RGBA')
for d, px in {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}.items():
    p = f'{res}/mipmap-{d}'; os.makedirs(p, exist_ok=True)
    r = rnd.resize((px, px), Image.LANCZOS); r.save(p + '/ic_launcher.png'); r.save(p + '/ic_launcher_round.png')
    f = round(px * 108 / 48); fg.resize((f, f), Image.LANCZOS).save(p + '/ic_launcher_foreground.png')
logo = Image.open(root + '/web/icons/icon-512.png').convert('RGBA')
for p in glob.glob(res + '/drawable*/splash.png'):
    w, h = Image.open(p).size
    bg = Image.new('RGB', (w, h), (0, 0, 0))
    lw = int(min(w, h) * 0.45); lh = int(logo.height * lw / logo.width)
    l = logo.resize((lw, lh), Image.LANCZOS)
    bg.paste(l, ((w - lw) // 2, (h - lh) // 2), l); bg.save(p)
PY
# لون خلفية الأيقونة التكيفية (مغطاة بالكامل بالشعار)
sed -i 's/#FFFFFF/#010E3B/I' "$RES/values/ic_launcher_background.xml" 2>/dev/null || true

# إبقاء الشاشة مضاءة داخل التطبيق (مهم أثناء التصدير)
MA=$(find android/app/src/main/java -name MainActivity.java | head -1)
cp "$ROOT/android-build/FadiNativePlugin.java" "$(dirname "$MA")/FadiNativePlugin.java"
cat > "$MA" <<'JAVA'
package com.fadifarm.studio;

import android.os.Bundle;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(FadiNativePlugin.class);
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
}
JAVA
# صلاحية الكتابة للأجهزة القديمة (أندرويد 9 وأقل) فقط
MF=android/app/src/main/AndroidManifest.xml
grep -q WRITE_EXTERNAL_STORAGE "$MF" || sed -i 's#</manifest>#    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />\n</manifest>#' "$MF"
grep -q TTS_SERVICE "$MF" || sed -i 's#</manifest>#    <queries><intent><action android:name="android.intent.action.TTS_SERVICE" /></intent></queries>\n</manifest>#' "$MF"
# البصمة / الوجه: لقفل القنوات
grep -q USE_BIOMETRIC "$MF" || sed -i 's#</manifest>#    <uses-permission android:name="android.permission.USE_BIOMETRIC" />\n</manifest>#' "$MF"
# الكاميرا: للتحقق من وجه صاحب التطبيق قبل تغيير كلمة السر
grep -q android.permission.CAMERA "$MF" || sed -i 's#</manifest>#    <uses-permission android:name="android.permission.CAMERA" />\n    <uses-feature android:name="android.hardware.camera" android:required="false" />\n</manifest>#' "$MF"
grep -q READ_MEDIA_VIDEO "$MF" || sed -i 's#</manifest>#    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />\n    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />\n    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />\n</manifest>#' "$MF"

# رقم الإصدار يزيد مع كل بناء حتى يُحدَّث التطبيق فوق القديم
sed -i -E "s/versionCode [0-9]+/versionCode ${BUILD_NO}/; s/versionName \"[^\"]+\"/versionName \"5.0.${BUILD_NO}\"/" android/app/build.gradle

cd android
chmod +x gradlew
./gradlew --no-daemon assembleRelease

UNSIGNED=$(find app/build/outputs/apk/release -name '*.apk' | head -1)
BT=$(ls -d "$ANDROID_HOME"/build-tools/* | sort -V | tail -1)
"$BT/zipalign" -f -p 4 "$UNSIGNED" "$W/aligned.apk"
"$BT/apksigner" sign --ks "$ROOT/android-build/release.keystore" --ks-pass pass:fadifarm2026 --key-pass pass:fadifarm2026 \
  --ks-key-alias fadifarm --out "$ROOT/FadiFarm.apk" "$W/aligned.apk"
"$BT/apksigner" verify "$ROOT/FadiFarm.apk"
ls -la "$ROOT/FadiFarm.apk"
