/* Fadi — اسم التطبيق وشعاره (محمي بكلمة سر)، وتغيير كلمة السر يحتاج التعرّف على وجه صاحب التطبيق.
   كل شيء يُحفظ على هذا الجهاز فقط: بصمة الوجه أرقام (وليست صورة)، وكلمة السر مشفّرة (SHA-256). */
'use strict';

const AppId = (() => {
  const DEF = { name: 'Fadi', logo: 'icons/icon-192.png', greet: 'فادي' };
  const FACE_LIB = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.15/dist/face-api.js';
  const FACE_MODELS = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.15/model/';
  const get = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
  const put = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { throw new Error('لا توجد مساحة كافية (اختر صورة أصغر)'); } };
  const id = () => ({ ...DEF, ...get('ff.appId', {}) });

  async function hash(p) {
    const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('fadi-app|' + String(p).trim().toLowerCase()));
    return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
  }
  /* كلمة السر: الافتراضية «fadi app»، ويمكن إلغاؤها ('off') أو تغييرها بعد التعرّف على الوجه */
  const passOn = () => get('ff.appPass', null) !== 'off';
  async function checkPass(p) { if (!passOn()) return true; const h = get('ff.appPass', null) || await hash('fadi app'); return (await hash(p)) === h; }

  /* الشعار لا يظهر داخل التطبيق: يُستعمل فقط لأيقونة التطبيق على الشاشة الرئيسية/سطح المكتب.
     في الآيفون: يُجهَّز للإضافة إلى الشاشة الرئيسية (Add to Home Screen) */
  function apply() {
    const a = id();
    const ver = $('#appNameFoot'); if (ver) ver.textContent = a.name;
    // الشاشة الأولى: الصورة فوق «مرحبا» واسم الشخص الذي يرحّب به التطبيق
    $$('.wl-me').forEach(i => i.src = a.logo);
    const gn = $('#wlName'); if (gn) gn.textContent = a.greet || DEF.greet;
    const ps = $('#apPassState'); if (ps) ps.textContent = passOn() ? '🔒 محمي بكلمة سر' : '🔓 بدون كلمة سر';
    document.title = a.name + ' · ' + (Channel.cur?.name || '');
    if (a.logo !== DEF.logo) {
      const at = document.querySelector('link[rel="apple-touch-icon"]') || Object.assign(document.head.appendChild(document.createElement('link')), { rel: 'apple-touch-icon' }); at.href = a.logo;
      let mt = document.querySelector('meta[name="apple-mobile-web-app-title"]'); if (!mt) { mt = document.createElement('meta'); mt.name = 'apple-mobile-web-app-title'; document.head.appendChild(mt); } mt.content = a.name;
      try {
        const m = { name: a.name, short_name: a.name, start_url: location.href.split('#')[0].split('?')[0], display: 'standalone', background_color: '#05070d', theme_color: '#05070d', icons: [{ src: a.logo, sizes: '512x512', type: 'image/png' }, { src: a.logo, sizes: '192x192', type: 'image/png' }] };
        const ml = document.querySelector('link[rel="manifest"]'); if (ml && !NATIVE && !window.fadiDesktop) ml.href = URL.createObjectURL(new Blob([JSON.stringify(m)], { type: 'application/manifest+json' }));
      } catch {}
    }
    if ($('#apPrev') && !apEditing) { $('#apPrev').src = a.logo; $('#apNameShow').textContent = a.name; }
  }
  /* صورة مربعة PNG بالحجم المطلوب */
  async function squarePng(src, size) {
    const im = new Image(); im.src = src; await im.decode();
    const c = document.createElement('canvas'); c.width = c.height = size; const g = c.getContext('2d');
    const k = Math.max(size / im.width, size / im.height); g.drawImage(im, (size - im.width * k) / 2, (size - im.height * k) / 2, im.width * k, im.height * k);
    return new Promise(r => c.toBlob(r, 'image/png'));
  }
  /* يغيّر أيقونة التطبيق واسمه على الهاتف أو الحاسوب */
  async function setHomeIcon(name, logo) {
    if (NATIVE) {
      const b = await squarePng(logo, 192), u8 = new Uint8Array(await b.arrayBuffer()); let bin = ''; for (let i = 0; i < u8.length; i += 0x8000) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
      const r = await capCall('FadiNative', 'pinShortcut', { name, icon: btoa(bin) });
      return r?.updated ? 'تغيّرت أيقونة التطبيق على الشاشة الرئيسية ✓' : 'وافق على إضافة الأيقونة الجديدة للشاشة الرئيسية، ثم احذف الأيقونة القديمة من الشاشة الرئيسية (اسحبها إلى «إزالة»، تبقى في قائمة التطبيقات)';
    }
    if (window.fadiDesktop?.setIcon) {
      const b = await squarePng(logo, 256), r = await window.fadiDesktop.setIcon(new Uint8Array(await b.arrayBuffer()), name);
      if (!r?.ok) throw new Error('تغيير الأيقونة متاح في نسخة Windows فقط');
      return 'تغيّرت أيقونة التطبيق واسمه على سطح المكتب وقائمة ابدأ ✓ (إن لم تظهر فوراً اضغط F5 على سطح المكتب)';
    }
    return 'في الآيفون: احذف أيقونة التطبيق من الشاشة الرئيسية، ثم افتح التطبيق في Safari واضغط «مشاركة» ← «إضافة إلى الشاشة الرئيسية»، فتظهر الصورة والاسم الجديدان';
  }

  /* ---------- نافذة كلمة السر ---------- */
  function askPass(title) {
    const d = $('#passDlg'); $('#passTitle').textContent = title; $('#passIn').value = ''; $('#passErr').hidden = true;
    return new Promise(res => {
      d.onclose = async () => res(d.returnValue === 'ok' ? $('#passIn').value : null);
      d.returnValue = ''; d.showModal(); setTimeout(() => $('#passIn').focus(), 50);
    });
  }

  /* ---------- الوجه ---------- */
  let libP = null;
  function loadLib() {
    return libP ??= new Promise((res, rej) => {
      if (window.faceapi) return res(window.faceapi);
      const s = document.createElement('script'); s.src = FACE_LIB; s.onload = () => res(window.faceapi); s.onerror = () => { libP = null; rej(new Error('تعذّر تحميل أداة التعرّف على الوجه (تحتاج الإنترنت أول مرة)')); };
      document.head.appendChild(s);
    }).then(async fa => {
      await fa.nets.tinyFaceDetector.loadFromUri(FACE_MODELS);
      await fa.nets.faceLandmark68Net.loadFromUri(FACE_MODELS);
      await fa.nets.faceRecognitionNet.loadFromUri(FACE_MODELS);
      return fa;
    });
  }
  let stream = null;
  const stopCam = () => { stream?.getTracks().forEach(t => t.stop()); stream = null; };
  /* يفتح الكاميرا الأمامية ويأخذ بصمة الوجه (متوسط عدة لقطات) */
  async function capture(msg) {
    const d = $('#faceDlg'), v = $('#faceVid'), st = $('#faceMsg');
    st.textContent = 'جاري تجهيز الكاميرا والتعرّف على الوجه…'; d.showModal();
    let cancelled = false; d.onclose = () => { cancelled = true; stopCam(); };
    try {
      const [fa] = await Promise.all([loadLib(), (async () => { stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: 640, height: 480 }, audio: false }); v.srcObject = stream; await v.play(); })()]);
      st.textContent = msg;
      const opts = new fa.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.5 }), got = [];
      const t0 = Date.now();
      while (got.length < 4 && !cancelled && Date.now() - t0 < 25000) {
        const r = await fa.detectSingleFace(v, opts).withFaceLandmarks().withFaceDescriptor();
        if (r) { got.push(Array.from(r.descriptor)); st.textContent = `${msg} (${got.length}/4)`; } else st.textContent = 'لا أرى وجهاً واضحاً. انظر للكاميرا في مكان مضاء';
        await new Promise(x => setTimeout(x, 250));
      }
      if (cancelled) return null;
      if (got.length < 3) throw new Error('لم يُلتقط الوجه بوضوح. حاول في مكان مضاء');
      return got[0].map((_, i) => got.reduce((a, g) => a + g[i], 0) / got.length);
    } catch (e) {
      if (/NotAllowed|Permission/i.test(e.name + e.message)) throw new Error('اسمح للتطبيق باستعمال الكاميرا');
      throw e;
    } finally { stopCam(); if (d.open) d.close(); }
  }
  const dist = (a, b) => Math.sqrt(a.reduce((s, x, i) => s + (x - b[i]) ** 2, 0));

  /* إدارة كلمة السر (تغيير / إلغاء / إضافة): أول مرة يسجّل وجهك، بعدها يجب أن يتعرّف عليه */
  async function verifyFace() {
    const saved = get('ff.ownerFace', null);
    if (!saved) {
      if (passOn()) {
        const p = await askPass('أول مرة: اكتب كلمة السر الحالية لتسجيل وجهك'); if (p == null) return false;
        if (!(await checkPass(p))) { toast('كلمة السر غير صحيحة', 'err'); return false; }
      }
      const f = await capture('انظر للكاميرا، جاري تسجيل وجهك…'); if (!f) return false;
      put('ff.ownerFace', f.map(x => +x.toFixed(5))); toast('سُجّل وجهك ✓'); return true;
    }
    const f = await capture('انظر للكاميرا للتحقق من وجهك…'); if (!f) return false;
    if (dist(f, saved) > 0.5) { toast('الوجه غير مطابق. هذا الإعداد لصاحب التطبيق فقط', 'err', 6000); return false; }
    toast('تم التعرّف على وجهك ✓'); return true;
  }
  function choose(on) {
    const d = $('#passMgr');
    $('#pmChange').hidden = !on; $('#pmOff').hidden = !on; $('#pmOn').hidden = on;
    return new Promise(res => { d.onclose = () => res(d.returnValue); d.returnValue = ''; d.showModal(); });
  }
  async function newPass() {
    const n1 = await askPass('كلمة السر الجديدة'); if (!n1) return false;
    if (n1.trim().length < 4) { toast('كلمة السر قصيرة جداً (4 أحرف على الأقل)', 'err'); return false; }
    const n2 = await askPass('أعد كتابة كلمة السر الجديدة'); if (n2 == null) return false;
    if (n1.trim().toLowerCase() !== n2.trim().toLowerCase()) { toast('الكلمتان غير متطابقتين', 'err'); return false; }
    put('ff.appPass', await hash(n1)); return true;
  }
  async function changePass() {
    try {
      if (!(await verifyFace())) return;
      const c = await choose(passOn());
      if (c === 'change' && await newPass()) toast('تغيّرت كلمة السر ✓');
      if (c === 'on' && await newPass()) toast('أُضيفت كلمة السر ✓');
      if (c === 'off') { put('ff.appPass', 'off'); toast('أُلغيت كلمة السر: التعديل الآن بدون كلمة سر'); }
      apply();
    } catch (e) { toast(e.message, 'err', 7000); }
  }

  /* تعديل الاسم والشعار بعد كلمة السر */
  let apEditing = false, apLogo = null;
  async function unlock() {
    if (passOn()) {
      const p = await askPass('كلمة السر لتعديل اسم التطبيق وشعاره'); if (p == null) return;
      if (!(await checkPass(p))) return toast('كلمة السر غير صحيحة', 'err');
    }
    const a = id(); apEditing = true; apLogo = null;
    $('#apName').value = a.name; $('#apGreet').value = a.greet || DEF.greet; $('#apPrev').src = a.logo; $('#apEdit').hidden = false; $('#apLocked').hidden = true;
  }
  function lock() { apEditing = false; $('#apEdit').hidden = true; $('#apLocked').hidden = false; apply(); }

  function bind() {
    apply();
    $('#apUnlock').onclick = unlock;
    $('#apPass').onclick = changePass;
    $('#apCancel').onclick = lock;
    $('#apPick').onclick = async () => { const r = await pickCropped({ shape: 'square', title: 'شعار التطبيق' }); if (r) { apLogo = r; $('#apPrev').src = r; } };
    $('#apReset').onclick = () => { apLogo = ''; $('#apPrev').src = DEF.logo; $('#apName').value = DEF.name; $('#apGreet').value = DEF.greet; };
    $('#apSave').onclick = async () => {
      const name = $('#apName').value.trim() || DEF.name, greet = $('#apGreet').value.trim() || DEF.greet, cur = id();
      const logo = apLogo === null ? cur.logo : (apLogo || DEF.logo);
      try { put('ff.appId', { name, logo, greet }); } catch (e) { return toast(e.message, 'err'); }
      lock();
      try { toast(await setHomeIcon(name, logo), '', 10000); }
      catch (e) { toast('حُفظ، لكن تعذّر تغيير الأيقونة: ' + e.message, 'err', 9000); }
    };
    $('#passShow').onclick = () => { const i = $('#passIn'); i.type = i.type === 'password' ? 'text' : 'password'; };
  }
  return { bind, apply, askPass, hash, get name() { return id().name; } };
})();
