/* Fadi — اسم التطبيق وشعاره (محمي بكلمة سر)، وتغيير كلمة السر يحتاج التعرّف على وجه صاحب التطبيق.
   كل شيء يُحفظ على هذا الجهاز فقط: بصمة الوجه أرقام (وليست صورة)، وكلمة السر مشفّرة (SHA-256). */
'use strict';

const AppId = (() => {
  const DEF = { name: 'Fadi', logo: 'icons/icon-192.png' };
  const FACE_LIB = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.15/dist/face-api.js';
  const FACE_MODELS = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.15/model/';
  const get = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
  const put = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { throw new Error('لا توجد مساحة كافية (اختر صورة أصغر)'); } };
  const id = () => ({ ...DEF, ...get('ff.appId', {}) });

  async function hash(p) {
    const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('fadi-app|' + String(p).trim().toLowerCase()));
    return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
  }
  async function checkPass(p) { const h = get('ff.appPass', null) || await hash('fadi app'); return (await hash(p)) === h; }

  /* يطبّق الاسم والشعار في كل مكان يظهران فيه */
  function apply() {
    const a = id();
    $$('.wl-me').forEach(i => i.src = a.logo);
    const ver = $('#appNameFoot'); if (ver) ver.textContent = a.name;
    document.title = a.name + ' · ' + (Channel.cur?.name || '');
    let ic = document.querySelector('link[rel="icon"]'); if (!ic) { ic = document.createElement('link'); ic.rel = 'icon'; document.head.appendChild(ic); }
    ic.href = a.logo;
    const at = document.querySelector('link[rel="apple-touch-icon"]'); if (at) at.href = a.logo;
    if ($('#apPrev') && !apEditing) { $('#apPrev').src = a.logo; $('#apNameShow').textContent = a.name; }
  }

  /* ---------- نافذة كلمة السر ---------- */
  function askPass(title) {
    const d = $('#passDlg'); $('#passTitle').textContent = title; $('#passIn').value = ''; $('#passErr').hidden = true;
    return new Promise(res => {
      d.onclose = async () => res(d.returnValue === 'ok' ? $('#passIn').value : null);
      d.returnValue = ''; d.showModal(); setTimeout(() => $('#passIn').focus(), 50);
    });
  }

  /* ---------- الوجه ---------- */
  let libP = null;
  function loadLib() {
    return libP ??= new Promise((res, rej) => {
      if (window.faceapi) return res(window.faceapi);
      const s = document.createElement('script'); s.src = FACE_LIB; s.onload = () => res(window.faceapi); s.onerror = () => { libP = null; rej(new Error('تعذّر تحميل أداة التعرّف على الوجه (تحتاج الإنترنت أول مرة)')); };
      document.head.appendChild(s);
    }).then(async fa => {
      await fa.nets.tinyFaceDetector.loadFromUri(FACE_MODELS);
      await fa.nets.faceLandmark68Net.loadFromUri(FACE_MODELS);
      await fa.nets.faceRecognitionNet.loadFromUri(FACE_MODELS);
      return fa;
    });
  }
  let stream = null;
  const stopCam = () => { stream?.getTracks().forEach(t => t.stop()); stream = null; };
  /* يفتح الكاميرا الأمامية ويأخذ بصمة الوجه (متوسط عدة لقطات) */
  async function capture(msg) {
    const d = $('#faceDlg'), v = $('#faceVid'), st = $('#faceMsg');
    st.textContent = 'جاري تجهيز الكاميرا والتعرّف على الوجه…'; d.showModal();
    let cancelled = false; d.onclose = () => { cancelled = true; stopCam(); };
    try {
      const [fa] = await Promise.all([loadLib(), (async () => { stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: 640, height: 480 }, audio: false }); v.srcObject = stream; await v.play(); })()]);
      st.textContent = msg;
      const opts = new fa.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.5 }), got = [];
      const t0 = Date.now();
      while (got.length < 4 && !cancelled && Date.now() - t0 < 25000) {
        const r = await fa.detectSingleFace(v, opts).withFaceLandmarks().withFaceDescriptor();
        if (r) { got.push(Array.from(r.descriptor)); st.textContent = `${msg} (${got.length}/4)`; } else st.textContent = 'لا أرى وجهاً واضحاً. انظر للكاميرا في مكان مضاء';
        await new Promise(x => setTimeout(x, 250));
      }
      if (cancelled) return null;
      if (got.length < 3) throw new Error('لم يُلتقط الوجه بوضوح. حاول في مكان مضاء');
      return got[0].map((_, i) => got.reduce((a, g) => a + g[i], 0) / got.length);
    } catch (e) {
      if (/NotAllowed|Permission/i.test(e.name + e.message)) throw new Error('اسمح للتطبيق باستعمال الكاميرا');
      throw e;
    } finally { stopCam(); if (d.open) d.close(); }
  }
  const dist = (a, b) => Math.sqrt(a.reduce((s, x, i) => s + (x - b[i]) ** 2, 0));

  /* تغيير كلمة السر: أول مرة يسجّل وجهك، بعدها يجب أن يتعرّف عليه */
  async function changePass() {
    const saved = get('ff.ownerFace', null);
    try {
      if (!saved) {
        const p = await askPass('أول مرة: اكتب كلمة السر الحالية لتسجيل وجهك'); if (p == null) return;
        if (!(await checkPass(p))) return toast('كلمة السر غير صحيحة', 'err');
        const f = await capture('انظر للكاميرا، جاري تسجيل وجهك…'); if (!f) return;
        put('ff.ownerFace', f.map(x => +x.toFixed(5))); toast('سُجّل وجهك ✓');
      } else {
        const f = await capture('انظر للكاميرا للتحقق من وجهك…'); if (!f) return;
        const dd = dist(f, saved);
        if (dd > 0.5) return toast('الوجه غير مطابق. تغيير كلمة السر لصاحب التطبيق فقط', 'err', 6000);
        toast('تم التعرّف على وجهك ✓');
      }
      const n1 = await askPass('كلمة السر الجديدة'); if (!n1) return;
      if (n1.trim().length < 4) return toast('كلمة السر قصيرة جداً (4 أحرف على الأقل)', 'err');
      const n2 = await askPass('أعد كتابة كلمة السر الجديدة'); if (n2 == null) return;
      if (n1.trim().toLowerCase() !== n2.trim().toLowerCase()) return toast('الكلمتان غير متطابقتين', 'err');
      put('ff.appPass', await hash(n1)); toast('تغيّرت كلمة السر ✓');
    } catch (e) { toast(e.message, 'err', 7000); }
  }

  /* تعديل الاسم والشعار بعد كلمة السر */
  let apEditing = false, apLogo = null;
  async function unlock() {
    const p = await askPass('كلمة السر لتعديل اسم التطبيق وشعاره'); if (p == null) return;
    if (!(await checkPass(p))) return toast('كلمة السر غير صحيحة', 'err');
    const a = id(); apEditing = true; apLogo = null;
    $('#apName').value = a.name; $('#apPrev').src = a.logo; $('#apEdit').hidden = false; $('#apLocked').hidden = true;
  }
  function lock() { apEditing = false; $('#apEdit').hidden = true; $('#apLocked').hidden = false; apply(); }

  function bind() {
    apply();
    $('#apUnlock').onclick = unlock;
    $('#apPass').onclick = changePass;
    $('#apCancel').onclick = lock;
    $('#apPick').onclick = () => { $('#apInput').value = ''; $('#apInput').click(); };
    $('#apInput').onchange = async e => { const f = e.target.files[0]; if (!f) return; try { apLogo = await readLogoSmall(f); $('#apPrev').src = apLogo; } catch { toast('تعذّرت قراءة الصورة', 'err'); } };
    $('#apReset').onclick = () => { apLogo = ''; $('#apPrev').src = DEF.logo; $('#apName').value = DEF.name; };
    $('#apSave').onclick = () => {
      const name = $('#apName').value.trim() || DEF.name, cur = id();
      const logo = apLogo === null ? cur.logo : (apLogo || DEF.logo);
      try { put('ff.appId', { name, logo }); } catch (e) { return toast(e.message, 'err'); }
      lock(); toast('حُفظ اسم التطبيق وشعاره');
    };
    $('#passShow').onclick = () => { const i = $('#passIn'); i.type = i.type === 'password' ? 'text' : 'password'; };
  }
  return { bind, apply, get name() { return id().name; } };
})();
