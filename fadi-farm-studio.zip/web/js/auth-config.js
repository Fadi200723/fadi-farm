/* Swift — إعداد نظام الحسابات. يبقى فارغاً = التطبيق يعمل كما هو بدون تسجيل دخول.
   ضع هنا فقط «Project URL» و«anon / publishable key» من Supabase (هذان عامّان بطبيعتهما ومحميّان بسياسات RLS).
   لا تضع هنا أبداً service_role key أو أي كلمة سر أو مفتاح Resend. */
window.SWIFT_AUTH = { url: '', anonKey: '' };
