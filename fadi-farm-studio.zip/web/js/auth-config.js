/* Swift — إعداد نظام الحسابات (Supabase).
   هذان القيمتان عامّتان بطبيعتهما (anon key محمي بسياسات RLS على الخادم).
   لا تضع هنا أبداً service_role key أو أي كلمة سر أو مفتاح Resend. */
window.SWIFT_AUTH = {
  url: 'https://aujkycguxcjxguklhrnz.supabase.co',
  anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImF1amt5Y2d1eGNqeGd1a2xocm56Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTI4NzU0OTYsImV4cCI6MjEwODQ1MTQ5Nn0.lW2NUE5L_XHUxzvL9p83X0eqkrbSyIc1cwPgSnVCOgI',
};
