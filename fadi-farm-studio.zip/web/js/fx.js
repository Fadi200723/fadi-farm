/* Fadi Farm — النصوص الاحترافية على الشاشة (موشن جرافيك):
   جملة مهمة · سؤال · رقم/معلومة · نصيحة · تحذير. تظهر فقط في اللحظات المهمة، ويمكن تعديلها يدوياً. */
'use strict';

const Fx = (() => {
  const TYPES = {
    key: { name: 'جملة مهمة', color: '#FFD23F' },
    question: { name: 'سؤال', color: '#FFD23F' },
    number: { name: 'رقم / معلومة', color: '#FFD23F' },
    tip: { name: 'نصيحة', color: '#3DDC84' },
    warn: { name: 'تحذير', color: '#FF4D3D' },
  };
  const DISPLAY = `"Lalezar", "IBM Plex Sans Arabic", sans-serif`, BODY = `"IBM Plex Sans Arabic", Tahoma, sans-serif`;
  const clamp = x => Math.min(1, Math.max(0, x));
  const easeOut = x => 1 - Math.pow(1 - clamp(x), 3);
  const back = x => { x = clamp(x); const c = 1.70158; return 1 + (c + 1) * Math.pow(x - 1, 3) + c * Math.pow(x - 1, 2); };
  const dur = d => Math.min(Math.max(2.4, d - 0.2), 4.8);

  function rr(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
  function wrap(g, text, maxW) {
    const words = String(text).split(/\s+/).filter(Boolean), lines = []; let c = '';
    for (const w of words) { const x = c ? c + ' ' + w : w; if (g.measureText(x).width > maxW && c) { lines.push(c); c = w; } else c = x; }
    if (c) lines.push(c); return lines;
  }
  function outline(g, text, x, y, fs, fill, k = 0.18) { g.lineJoin = 'round'; g.lineWidth = fs * k; g.strokeStyle = 'rgba(0,0,0,.92)'; g.strokeText(text, x, y); g.fillStyle = fill; g.fillText(text, x, y); }

  /* ظهور واختفاء */
  function life(local, D) {
    const t = local - 0.25;
    if (t < 0 || t > D) return null;
    return { t, inA: easeOut(t / 0.45), outA: t > D - 0.35 ? clamp((D - t) / 0.35) : 1 };
  }

  /* جملة مهمة: كلمات تظهر واحدة تلو الأخرى، والكلمة المميزة داخل شريط ملون */
  function key(g, f, L, W, H, u) {
    const portrait = H > W;
    let fs = Math.round((portrait ? 92 : 84) * u);
    g.font = `400 ${fs}px ${DISPLAY}`;
    let lines = wrap(g, f.text, W * (portrait ? 0.84 : 0.7));
    while (lines.length > 2 && fs > 40 * u) { fs -= 4; g.font = `400 ${fs}px ${DISPLAY}`; lines = wrap(g, f.text, W * (portrait ? 0.84 : 0.7)); }
    lines = lines.slice(0, 2);
    const lh = fs * 1.3, y0 = H * (portrait ? 0.7 : 0.76) - (lines.length - 1) * lh / 2;
    // شريط خلفي ناعم
    const bandA = 0.55 * L.inA * L.outA;
    const gr = g.createLinearGradient(0, y0 - lh, 0, y0 + lines.length * lh);
    gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(0.35, `rgba(0,0,0,${bandA})`); gr.addColorStop(0.75, `rgba(0,0,0,${bandA})`); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr; g.fillRect(0, y0 - lh, W, lh * (lines.length + 1.2));
    g.direction = 'rtl'; g.textAlign = 'right'; g.textBaseline = 'middle';
    let wi = 0;
    lines.forEach((line, li) => {
      const words = line.split(/\s+/), sp = fs * 0.28, ws = words.map(w => g.measureText(w).width), total = ws.reduce((a, b) => a + b, 0) + sp * (words.length - 1);
      let x = W / 2 + total / 2; const y = y0 + li * lh;
      words.forEach((w, k) => {
        const a = easeOut((L.t - wi * 0.09) / 0.3), lift = (1 - a) * fs * 0.4;
        const emph = f.emph && w.replace(/[^\p{L}\p{N}]/gu, '').includes(f.emph.replace(/[^\p{L}\p{N}]/gu, '')) && f.emph.length > 1;
        g.save(); g.globalAlpha = a * L.outA;
        if (emph) {
          const wipe = easeOut((L.t - wi * 0.09 - 0.15) / 0.35);
          g.fillStyle = TYPES.key.color; rr(g, x - ws[k] - fs * 0.16, y - fs * 0.62 + lift, (ws[k] + fs * 0.32) * wipe, fs * 1.18, fs * 0.16); g.fill();
          g.save(); g.translate(x - ws[k] - fs * 0.16, 0); g.restore();
          g.fillStyle = '#121212'; g.fillText(w, x, y + lift + fs * 0.04);
        } else outline(g, w, x, y + lift, fs, '#fff', 0.16);
        g.restore();
        x -= ws[k] + sp; wi++;
      });
    });
  }

  /* سؤال: بطاقة داكنة مع علامة استفهام نابضة */
  function question(g, f, L, W, H, u) {
    const portrait = H > W, fs = Math.round((portrait ? 60 : 56) * u);
    g.save(); g.globalAlpha = L.inA * L.outA;
    g.font = `700 ${fs}px ${BODY}`; g.direction = 'rtl'; g.textAlign = 'right'; g.textBaseline = 'middle';
    const lines = wrap(g, f.text, W * (portrait ? 0.78 : 0.6)).slice(0, 2);
    const tw = Math.max(...lines.map(l => g.measureText(l).width)), icon = fs * 1.6, pad = fs * 0.75;
    const bw = tw + icon + pad * 2.6, bh = Math.max(icon + pad, lines.length * fs * 1.35 + pad * 1.2);
    const x = (W - bw) / 2, y = H * (portrait ? 0.15 : 0.1) - (1 - L.inA) * 40 * u;
    g.shadowColor = 'rgba(0,0,0,.45)'; g.shadowBlur = 30 * u; g.shadowOffsetY = 8 * u;
    g.fillStyle = 'rgba(14,20,12,.88)'; rr(g, x, y, bw, bh, 24 * u); g.fill(); g.shadowColor = 'transparent';
    g.fillStyle = TYPES.question.color; rr(g, x, y, 10 * u, bh, 5 * u); g.fill();
    const pulse = 1 + 0.08 * Math.sin(L.t * 8), cx = x + bw - pad - icon / 2, cy = y + bh / 2;
    g.beginPath(); g.arc(cx, cy, icon / 2 * back(Math.min(1, L.t / 0.5)) * pulse, 0, Math.PI * 2); g.fillStyle = TYPES.question.color; g.fill();
    g.fillStyle = '#111'; g.textAlign = 'center'; g.font = `400 ${Math.round(icon * 0.74)}px ${DISPLAY}`; g.fillText('؟', cx, cy + icon * 0.05);
    g.font = `700 ${fs}px ${BODY}`; g.textAlign = 'right'; g.fillStyle = '#fff';
    lines.forEach((l, i) => g.fillText(l, cx - icon / 2 - pad * 0.6, cy + (i - (lines.length - 1) / 2) * fs * 1.35));
    g.restore();
  }

  /* رقم أو معلومة: رقم كبير يعدّ تصاعدياً مع وصف تحته */
  function number(g, f, L, W, H, u) {
    const portrait = H > W, m = String(f.text).match(/^([^\d٠-٩]*)([\d٠-٩][\d٠-٩.,]*)(.*)$/);
    let txt = f.text;
    if (m) {
      const ar = /[٠-٩]/.test(m[2]), n = parseFloat(m[2].replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(',', '.'));
      if (isFinite(n)) { const v = Math.round(n * easeOut(L.t / 0.8) * (n % 1 ? 10 : 1)) / (n % 1 ? 10 : 1); const sv = String(v); txt = m[1] + (ar ? sv.replace(/\d/g, d => '٠١٢٣٤٥٦٧٨٩'[d]) : sv) + m[3]; }
    }
    const s = back(Math.min(1, L.t / 0.45)), cx = portrait ? W / 2 : W * 0.27, cy = H * (portrait ? 0.36 : 0.42);
    g.save(); g.globalAlpha = L.inA * L.outA; g.translate(cx, cy); g.scale(s, s);
    let fs = Math.round((portrait ? 190 : 170) * u); g.font = `400 ${fs}px ${DISPLAY}`;
    while (g.measureText(txt).width > W * (portrait ? 0.86 : 0.42) && fs > 60 * u) { fs -= 6; g.font = `400 ${fs}px ${DISPLAY}`; }
    g.direction = 'rtl'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.shadowColor = 'rgba(255,210,63,.55)'; g.shadowBlur = 40 * u;
    outline(g, txt, 0, 0, fs, TYPES.number.color, 0.12);
    g.shadowColor = 'transparent';
    if (f.sub) {
      const sfs = Math.round(fs * 0.3); g.font = `700 ${sfs}px ${BODY}`;
      const w = g.measureText(f.sub).width + sfs * 1.2, y = fs * 0.72;
      g.fillStyle = 'rgba(0,0,0,.72)'; rr(g, -w / 2, y - sfs * 0.75, w, sfs * 1.5, sfs * 0.4); g.fill();
      g.fillStyle = '#fff'; g.fillText(f.sub, 0, y + sfs * 0.05);
    }
    g.restore();
  }

  /* نصيحة أو تحذير: شارة ملونة + بطاقة تنزلق من الجانب */
  function badgeCard(g, f, L, W, H, u, type) {
    const portrait = H > W, c = TYPES[type].color, fs = Math.round((portrait ? 56 : 50) * u);
    const shake = type === 'warn' && L.t < 0.6 ? Math.sin(L.t * 60) * 6 * u * (1 - L.t / 0.6) : 0;
    g.save(); g.globalAlpha = L.outA;
    g.font = `700 ${fs}px ${BODY}`; g.direction = 'rtl'; g.textAlign = 'right'; g.textBaseline = 'middle';
    const lines = wrap(g, f.text, W * (portrait ? 0.74 : 0.42)).slice(0, 3);
    const tw = Math.max(...lines.map(l => g.measureText(l).width)), pad = fs * 0.7;
    const bw = tw + pad * 2, bh = lines.length * fs * 1.4 + pad * 1.1;
    const margin = 48 * u, slide = (1 - L.inA) * (bw + margin * 2);
    const x = (portrait ? (W - bw) / 2 : W - bw - margin) + (portrait ? 0 : slide) + shake, y = H * (portrait ? 0.62 : 0.6);
    // الشارة
    const label = type === 'warn' ? '⚠ تحذير' : '✓ نصيحة', lfs = Math.round(fs * 0.75);
    g.font = `700 ${lfs}px ${BODY}`; const lw = g.measureText(label).width + lfs * 1.1, lh = lfs * 1.55;
    g.shadowColor = 'rgba(0,0,0,.4)'; g.shadowBlur = 22 * u; g.shadowOffsetY = 6 * u;
    g.fillStyle = 'rgba(255,255,255,.96)'; rr(g, x, y, bw, bh, 18 * u); g.fill();
    g.fillStyle = c; rr(g, x + bw - lw - pad * 0.2, y - lh * 0.6, lw, lh, lh / 2); g.fill();
    g.shadowColor = 'transparent';
    g.fillStyle = type === 'warn' ? '#fff' : '#0b2a14'; g.textAlign = 'center'; g.fillText(label, x + bw - lw / 2 - pad * 0.2, y - lh * 0.6 + lh / 2 + lfs * 0.04);
    g.fillStyle = c; rr(g, x + bw - 8 * u, y + 14 * u, 8 * u, bh - 28 * u, 4 * u); g.fill();
    g.font = `700 ${fs}px ${BODY}`; g.textAlign = 'right'; g.fillStyle = '#151515';
    lines.forEach((l, i) => g.fillText(l, x + bw - pad, y + pad * 0.75 + fs * 0.55 + i * fs * 1.4));
    g.restore();
  }

  /* يرسم مؤثر المشهد. يرجع true إذا كان ظاهراً (لإخفاء الترجمة العادية وقتها) */
  function draw(g, f, local, d, W, H) {
    if (!f || !f.type || !f.text) return false;
    const L = life(local, dur(d)); if (!L) return false;
    const u = Math.min(W, H) / 1080;
    g.save();
    if (f.type === 'key') key(g, f, L, W, H, u);
    else if (f.type === 'question') question(g, f, L, W, H, u);
    else if (f.type === 'number') number(g, f, L, W, H, u);
    else badgeCard(g, f, L, W, H, u, f.type === 'warn' ? 'warn' : 'tip');
    g.restore();
    return true;
  }

  /* اقتراح محلي بدون Gemini: أسئلة، أرقام، نصائح، تحذيرات، وجمل مفتاحية */
  function auto(scenes) {
    const total = scenes.reduce((a, s) => a + s.d, 0), every = 18;
    let t = 0, lastAt = -every;
    scenes.forEach(s => {
      const start = t; t += s.d;
      if (s.fx?.manual) { lastAt = start; return; }
      s.fx = null;
      if (start - lastAt < every * 0.6 || s.d < 2.2) return;
      const sents = s.text.split(/(?<=[.!؟?…])\s+/).map(x => x.trim()).filter(Boolean);
      const q = sents.find(x => /[؟?]$/.test(x));
      const num = sents.find(x => /[\d٠-٩]+/.test(x));
      const warn = sents.find(x => /(احذر|خطر|خطير|إوعى|اوعى|متعملش|ممنوع|غلط)/.test(x));
      const tip = sents.find(x => /(نصيحة|لازم|مهم|السر|سر |الأفضل|أحسن|جرّب|جرب)/.test(x));
      const short = x => x.split(/\s+/).slice(0, 8).join(' ').replace(/[.،,]+$/, '');
      if (q) s.fx = { type: 'question', text: short(q) + (/[؟?]$/.test(short(q)) ? '' : '؟') };
      else if (num) { const m = num.match(/([\d٠-٩][\d٠-٩.,]*\s*\S*)/); s.fx = { type: 'number', text: m ? m[1] : short(num), sub: short(num.replace(m ? m[1] : '', '')).split(/\s+/).slice(0, 5).join(' ') }; }
      else if (warn) s.fx = { type: 'warn', text: short(warn) };
      else if (tip && start - lastAt > every) { const w = short(tip); s.fx = { type: 'key', text: w, emph: w.split(/\s+/).sort((a, b) => b.length - a.length)[0] }; }
      if (s.fx) lastAt = start;
    });
    return scenes.filter(s => s.fx).length;
  }

  return { draw, auto, TYPES, dur };
})();
