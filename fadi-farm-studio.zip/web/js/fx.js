/* Fadi Farm — النصوص الاحترافية على الشاشة (موشن جرافيك):
   جملة مهمة · سؤال · رقم/معلومة · نصيحة · تحذير. تظهر فقط في اللحظات المهمة، ويمكن تعديلها يدوياً. */
'use strict';

const Fx = (() => {
  const ACC = () => (typeof Channel !== 'undefined' ? Channel.cur.accent : '#FFD23F');
  const TYPES = {
    key: { name: 'جملة مهمة', get color() { return ACC(); } },
    question: { name: 'سؤال', get color() { return ACC(); } },
    number: { name: 'رقم / معلومة', get color() { return ACC(); } },
    tip: { name: 'نصيحة', color: '#3DDC84' },
    warn: { name: 'تحذير', color: '#FF4D3D' },
  };
  const ink = () => { const h = ACC(), n = parseInt(String(h).slice(1, 7), 16) || 0; return ((n >> 16) * 0.3 + ((n >> 8) & 255) * 0.59 + (n & 255) * 0.11) > 150 ? '#121212' : '#ffffff'; };   // لون الكتابة فوق اللون المميز
  const POS = { auto: 'تلقائي (حسب الصورة)', bottom: 'أسفل', center: 'وسط', top: 'أعلى', right: 'يمين', left: 'يسار' };
  const ZONES = { key: ['bottom', 'center', 'top'], question: ['bottom', 'center', 'top'], number: ['left', 'right', 'center'], tip: ['right', 'left', 'bottom'], warn: ['right', 'left', 'bottom'] };

  /* أهدأ منطقة في الصورة (أقل تفاصيل) حتى لا تغطي الكتابة الموضوع الرئيسي */
  const probe = typeof document !== 'undefined' ? document.createElement('canvas') : null;
  function pickZone(g, type, W, H) {
    const opts = ZONES[type] || ['bottom'];
    try {
      const w = 48, h = 27; probe.width = w; probe.height = h;
      const p = probe.getContext('2d', { willReadFrequently: true }); p.drawImage(g.canvas, 0, 0, w, h);
      const d = p.getImageData(0, 0, w, h).data, lum = (x, y) => { const i = (y * w + x) * 4; return d[i] * 0.3 + d[i + 1] * 0.59 + d[i + 2] * 0.11; };
      const energy = (x0, y0, x1, y1) => { let e = 0, n = 0; for (let y = Math.floor(y0 * h); y < Math.ceil(y1 * h) - 1; y++) for (let x = Math.floor(x0 * w); x < Math.ceil(x1 * w) - 1; x++) { e += Math.abs(lum(x, y) - lum(x + 1, y)) + Math.abs(lum(x, y) - lum(x, y + 1)); n++; } return n ? e / n : 0; };
      const R = { bottom: [0.1, 0.62, 0.9, 0.95], center: [0.15, 0.35, 0.85, 0.65], top: [0.1, 0.05, 0.9, 0.35], left: [0.03, 0.2, 0.47, 0.8], right: [0.53, 0.2, 0.97, 0.8] };
      let best = opts[0], be = 1e9;
      opts.forEach((z, k) => { const e = energy(...R[z]) * (1 + k * 0.12); if (e < be) { be = e; best = z; } });
      return best;
    } catch { return opts[0]; }
  }
  const DISPLAY = `"Lalezar", "IBM Plex Sans Arabic", sans-serif`, BODY = `"IBM Plex Sans Arabic", Tahoma, sans-serif`;
  const clamp = x => Math.min(1, Math.max(0, x));
  const easeOut = x => 1 - Math.pow(1 - clamp(x), 3);
  const back = x => { x = clamp(x); const c = 1.70158; return 1 + (c + 1) * Math.pow(x - 1, 3) + c * Math.pow(x - 1, 2); };
  const dur = d => Math.min(Math.max(2.4, d - 0.2), 4.8);

  function rr(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
  function wrap(g, text, maxW) {
    const words = String(text).split(/\s+/).filter(Boolean), lines = []; let c = '';
    for (const w of words) { const x = c ? c + ' ' + w : w; if (g.measureText(x).width > maxW && c) { lines.push(c); c = w; } else c = x; }
    if (c) lines.push(c); return lines;
  }
  function outline(g, text, x, y, fs, fill, k = 0.18) { g.lineJoin = 'round'; g.lineWidth = fs * k; g.strokeStyle = 'rgba(0,0,0,.92)'; g.strokeText(text, x, y); g.fillStyle = fill; g.fillText(text, x, y); }

  /* ظهور واختفاء (يبدأ عندما تُنطق الجملة) */
  function life(local, D, at = 0.25) {
    const t = local - at;
    if (t < 0 || t > D) return null;
    return { t, inA: easeOut(t / 0.45), outA: t > D - 0.35 ? clamp((D - t) / 0.35) : 1 };
  }

  /* جملة مهمة: كلمات تظهر واحدة تلو الأخرى، والكلمة المميزة داخل شريط ملون */
  function key(g, f, L, W, H, u) {
    const portrait = H > W;
    let fs = Math.round((portrait ? 92 : 84) * u);
    g.font = `400 ${fs}px ${DISPLAY}`;
    let lines = wrap(g, f.text, W * (portrait ? 0.84 : 0.7));
    while (lines.length > 2 && fs > 40 * u) { fs -= 4; g.font = `400 ${fs}px ${DISPLAY}`; lines = wrap(g, f.text, W * (portrait ? 0.84 : 0.7)); }
    lines = lines.slice(0, 2);
    const zy = { bottom: portrait ? 0.7 : 0.78, center: 0.5, top: portrait ? 0.2 : 0.2 }[L.zone] || 0.78;
    const lh = fs * 1.3, y0 = H * zy - (lines.length - 1) * lh / 2;
    // شريط خلفي ناعم
    const bandA = 0.55 * L.inA * L.outA;
    const gr = g.createLinearGradient(0, y0 - lh, 0, y0 + lines.length * lh);
    gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(0.35, `rgba(0,0,0,${bandA})`); gr.addColorStop(0.75, `rgba(0,0,0,${bandA})`); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr; g.fillRect(0, y0 - lh, W, lh * (lines.length + 1.2));
    g.direction = 'rtl'; g.textAlign = 'right'; g.textBaseline = 'middle';
    let wi = 0;
    lines.forEach((line, li) => {
      const words = line.split(/\s+/), sp = fs * 0.28, ws = words.map(w => g.measureText(w).width), total = ws.reduce((a, b) => a + b, 0) + sp * (words.length - 1);
      let x = W / 2 + total / 2; const y = y0 + li * lh;
      words.forEach((w, k) => {
        const a = easeOut((L.t - wi * 0.09) / 0.3), lift = (1 - a) * fs * 0.4;
        const emph = f.emph && w.replace(/[^\p{L}\p{N}]/gu, '').includes(f.emph.replace(/[^\p{L}\p{N}]/gu, '')) && f.emph.length > 1;
        g.save(); g.globalAlpha = a * L.outA;
        if (emph) {
          const wipe = easeOut((L.t - wi * 0.09 - 0.15) / 0.35);
          g.fillStyle = TYPES.key.color; rr(g, x - ws[k] - fs * 0.16, y - fs * 0.62 + lift, (ws[k] + fs * 0.32) * wipe, fs * 1.18, fs * 0.16); g.fill();
          g.save(); g.translate(x - ws[k] - fs * 0.16, 0); g.restore();
          g.fillStyle = ink(); g.fillText(w, x, y + lift + fs * 0.04);
        } else outline(g, w, x, y + lift, fs, '#fff', 0.16);
        g.restore();
        x -= ws[k] + sp; wi++;
      });
    });
  }

  /* سؤال: شارة «سؤال» ملونة + نص كبير يكتب نفسه كلمة كلمة + خط سفلي متحرك (علامة استفهام واحدة فقط من النص) */
  function question(g, f, L, W, H, u) {
    const portrait = H > W;
    let fs = Math.round((portrait ? 78 : 70) * u);
    const text = String(f.text).replace(/[؟?]+\s*$/, '').trim() + '؟';
    g.save();
    g.font = `400 ${fs}px ${DISPLAY}`; g.direction = 'rtl'; g.textAlign = 'right'; g.textBaseline = 'middle';
    let lines = wrap(g, text, W * (portrait ? 0.84 : 0.66));
    while (lines.length > 2 && fs > 40 * u) { fs -= 4; g.font = `400 ${fs}px ${DISPLAY}`; lines = wrap(g, text, W * (portrait ? 0.84 : 0.66)); }
    lines = lines.slice(0, 2);
    const lh = fs * 1.28, blockH = lines.length * lh, tagFs = Math.round(fs * 0.42);
    const zc = { top: H * (portrait ? 0.2 : 0.2), center: H * 0.5, bottom: H * (portrait ? 0.7 : 0.76) }[L.zone] ?? H * 0.76;
    const y0 = zc - blockH / 2 + lh / 2 + (1 - L.inA) * 30 * u;
    // ظل خلفي ناعم للقراءة
    const bandA = 0.5 * L.inA * L.outA, gr = g.createLinearGradient(0, y0 - lh * 1.4, 0, y0 + blockH + lh * 0.4);
    gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(0.3, `rgba(0,0,0,${bandA})`); gr.addColorStop(0.8, `rgba(0,0,0,${bandA})`); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr; g.fillRect(0, y0 - lh * 1.4, W, blockH + lh * 1.8);
    const widest = (g.font = `400 ${fs}px ${DISPLAY}`, Math.max(...lines.map(l => g.measureText(l).width)));
    // النص: كلمة كلمة
    g.font = `400 ${fs}px ${DISPLAY}`; g.textAlign = 'right';
    let wi = 0;
    lines.forEach((line, li) => {
      const words = line.split(/\s+/), sp = fs * 0.26, ws = words.map(w => g.measureText(w).width), total = ws.reduce((a, b) => a + b, 0) + sp * (words.length - 1);
      let x = W / 2 + total / 2; const y = y0 + li * lh;
      words.forEach((w, k) => {
        const a = easeOut((L.t - 0.15 - wi * 0.08) / 0.28);
        g.globalAlpha = a * L.outA;
        outline(g, w, x, y + (1 - a) * fs * 0.35, fs, k === words.length - 1 && li === lines.length - 1 ? TYPES.question.color : '#fff', 0.15);
        x -= ws[k] + sp; wi++;
      });
    });
    // خط سفلي يتمدد
    const ul = easeOut((L.t - 0.3) / 0.6), uy = y0 + (lines.length - 1) * lh + fs * 0.72;
    g.globalAlpha = L.outA; g.fillStyle = TYPES.question.color;
    rr(g, W / 2 + widest / 2 - widest * ul, uy, widest * ul, 6 * u, 3 * u); g.fill();
    g.restore();
  }

  /* رقم أو معلومة: رقم كبير يعدّ تصاعدياً مع وصف تحته */
  function number(g, f, L, W, H, u) {
    const portrait = H > W, m = String(f.text).match(/^([^\d٠-٩]*)([\d٠-٩][\d٠-٩.,]*)(.*)$/);
    let txt = f.text;
    if (m) {
      const ar = /[٠-٩]/.test(m[2]), n = parseFloat(m[2].replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(',', '.'));
      if (isFinite(n)) { const v = Math.round(n * easeOut(L.t / 0.8) * (n % 1 ? 10 : 1)) / (n % 1 ? 10 : 1); const sv = String(v); txt = m[1] + (ar ? sv.replace(/\d/g, d => '٠١٢٣٤٥٦٧٨٩'[d]) : sv) + m[3]; }
    }
    const s = back(Math.min(1, L.t / 0.45)), cx = portrait ? W / 2 : W * ({ left: 0.27, right: 0.73, center: 0.5 }[L.zone] || 0.27), cy = H * (portrait ? 0.36 : 0.42);
    g.save(); g.globalAlpha = L.inA * L.outA; g.translate(cx, cy); g.scale(s, s);
    let fs = Math.round((portrait ? 190 : 170) * u); g.font = `400 ${fs}px ${DISPLAY}`;
    while (g.measureText(txt).width > W * (portrait ? 0.86 : 0.42) && fs > 60 * u) { fs -= 6; g.font = `400 ${fs}px ${DISPLAY}`; }
    g.direction = 'rtl'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.shadowColor = ACC(); g.shadowBlur = 40 * u;
    outline(g, txt, 0, 0, fs, TYPES.number.color, 0.12);
    g.shadowColor = 'transparent';
    if (f.sub) {
      const sfs = Math.round(fs * 0.3); g.font = `700 ${sfs}px ${BODY}`;
      const w = g.measureText(f.sub).width + sfs * 1.2, y = fs * 0.72;
      g.fillStyle = 'rgba(0,0,0,.72)'; rr(g, -w / 2, y - sfs * 0.75, w, sfs * 1.5, sfs * 0.4); g.fill();
      g.fillStyle = '#fff'; g.fillText(f.sub, 0, y + sfs * 0.05);
    }
    g.restore();
  }

  /* نصيحة أو تحذير: شارة ملونة + بطاقة تنزلق من الجانب */
  function badgeCard(g, f, L, W, H, u, type) {
    const portrait = H > W, c = TYPES[type].color, fs = Math.round((portrait ? 56 : 50) * u);
    const shake = type === 'warn' && L.t < 0.6 ? Math.sin(L.t * 60) * 6 * u * (1 - L.t / 0.6) : 0;
    g.save(); g.globalAlpha = L.outA;
    g.font = `700 ${fs}px ${BODY}`; g.direction = 'rtl'; g.textAlign = 'right'; g.textBaseline = 'middle';
    const lines = wrap(g, f.text, W * (portrait ? 0.74 : 0.42)).slice(0, 3);
    const tw = Math.max(...lines.map(l => g.measureText(l).width)), pad = fs * 0.7;
    const bw = tw + pad * 2, bh = lines.length * fs * 1.4 + pad * 1.1;
    const margin = 48 * u, slide = (1 - L.inA) * (bw + margin * 2);
    const left = L.zone === 'left', bottom = L.zone === 'bottom' || portrait;
    const x = (bottom ? (W - bw) / 2 : left ? margin - slide : W - bw - margin + slide) + shake, y = bottom ? H * (portrait ? 0.64 : 0.74) : H * 0.55;
    g.shadowColor = 'rgba(0,0,0,.4)'; g.shadowBlur = 22 * u; g.shadowOffsetY = 6 * u;
    g.fillStyle = 'rgba(255,255,255,.96)'; rr(g, x, y, bw, bh, 18 * u); g.fill();
    g.shadowColor = 'transparent';
    g.fillStyle = c; rr(g, x + bw - 8 * u, y + 14 * u, 8 * u, bh - 28 * u, 4 * u); g.fill();
    g.font = `700 ${fs}px ${BODY}`; g.textAlign = 'right'; g.fillStyle = '#151515';
    lines.forEach((l, i) => g.fillText(l, x + bw - pad, y + pad * 0.75 + fs * 0.55 + i * fs * 1.4));
    g.restore();
  }

  /* يرسم مؤثر المشهد. يرجع true إذا كان ظاهراً (لإخفاء الترجمة العادية وقتها) */
  function draw(g, f, local, d, W, H, tm) {
    if (!f || !f.type || !f.text) return false;
    const L = life(local, tm?.dur ?? dur(d), tm?.at ?? 0.25); if (!L) return false;
    // الموضع: يدوي، أو أهدأ منطقة في الصورة (يُحسب مرة واحدة عند ظهور النص)
    if (f.pos && f.pos !== 'auto' && (ZONES[f.type] || []).includes(f.pos)) L.zone = f.pos;
    else { const k = f.type + '|' + W + 'x' + H; if (!f._z || f._zk !== k) { f._z = pickZone(g, f.type, W, H); f._zk = k; } L.zone = f._z; }
    const lv = level(), u = Math.min(W, H) / 1080 * ({ strong: 1.1, extreme: 1.2 }[lv] || 1);
    g.save();
    if (lv !== 'normal') {             // دخول أقوى: قفزة تكبير + وميض خفيف
      const k = lv === 'extreme' ? 0.22 : 0.12, pop = 1 + k * (1 - easeOut(L.t / 0.3));
      g.translate(W / 2, H / 2); g.scale(pop, pop); g.translate(-W / 2, -H / 2);
      if (lv === 'extreme' && L.t < 0.12) { g.save(); g.fillStyle = `rgba(255,255,255,${0.18 * (1 - L.t / 0.12)})`; g.fillRect(0, 0, W, H); g.restore(); }
    }
    if (f.type === 'key') key(g, f, L, W, H, u);
    else if (f.type === 'question') question(g, f, L, W, H, u);
    else if (f.type === 'number') number(g, f, L, W, H, u);
    else badgeCard(g, f, L, W, H, u, f.type === 'warn' ? 'warn' : 'tip');
    g.restore();
    return true;
  }

  /* اقتراح محلي بدون Gemini: أسئلة، أرقام، نصائح، تحذيرات، وجمل مفتاحية — كثافته حسب «قوة النصوص» */
  const level = () => (typeof Settings !== 'undefined' && Settings.get().fxLevel) || 'normal';
  function auto(scenes) {
    const lv = level(), every = { normal: 18, strong: 8, extreme: 4.5 }[lv] || 18, minD = lv === 'normal' ? 2.2 : 1.4;
    let t = 0, lastAt = -every;
    const short = x => x.split(/\s+/).slice(0, 8).join(' ').replace(/[.،,]+$/, '');
    const make = x => {
      if (/[؟?]$/.test(x)) return { type: 'question', text: short(x) + (/[؟?]$/.test(short(x)) ? '' : '؟'), anchor: short(x) };
      if (/[\d٠-٩]+/.test(x)) { const m = x.match(/([\d٠-٩][\d٠-٩.,]*\s*\S*)/); return { type: 'number', text: m ? m[1] : short(x), sub: short(x.replace(m ? m[1] : '', '')).split(/\s+/).slice(0, 5).join(' '), anchor: short(x) }; }
      if (/(احذر|خطر|خطير|إوعى|اوعى|متعملش|ممنوع|غلط)/.test(x)) return { type: 'warn', text: short(x), anchor: short(x) };
      const tip = /(نصيحة|لازم|مهم|السر|سر |الأفضل|أحسن|جرّب|جرب)/.test(x);
      if (tip || lv !== 'normal') { const w = short(x); if (w.split(/\s+/).length < 3) return null; return { type: tip && lv !== 'normal' && Math.random() < 0.4 ? 'tip' : 'key', text: w, emph: w.split(/\s+/).sort((a, b) => b.length - a.length)[0], anchor: w }; }
      return null;
    };
    scenes.forEach(s => {
      const start = t; t += s.d;
      if (s.fx?.manual) { lastAt = start; s.fxs = []; return; }
      s.fx = null; s.fxs = [];
      if (s.d < minD) return;
      const sents = s.text.split(/(?<=[.!؟?…])\s+/).map(x => x.trim()).filter(Boolean), per = s.d / Math.max(1, sents.length);
      // الأولوية: سؤال/رقم/تحذير ثم الجمل المفتاحية
      const rank = x => /[؟?]$/.test(x) ? 0 : /[\d٠-٩]/.test(x) ? 1 : /(احذر|خطر|ممنوع)/.test(x) ? 2 : 3;
      sents.map((x, k) => ({ x, k, at: start + k * per })).sort((a, b) => rank(a.x) - rank(b.x) || a.k - b.k).forEach(({ x, at }) => {
        if (Math.abs(at - lastAt) < every * 0.6) return;
        if (lv === 'normal' && s.fx) return;
        if ((s.fx ? 1 : 0) + s.fxs.length >= (lv === 'extreme' ? 3 : lv === 'strong' ? 2 : 1)) return;
        const f = make(x); if (!f) return;
        if (lv === 'normal' && f.type === 'key' && at - lastAt <= every) return;
        if (!s.fx) s.fx = f; else s.fxs.push(f);
        lastAt = Math.max(lastAt, at);
      });
    });
    return scenes.reduce((n, s) => n + (s.fx ? 1 : 0) + (s.fxs?.length || 0), 0);
  }

  return { draw, auto, level, TYPES, POS, ZONES, dur };
})();
