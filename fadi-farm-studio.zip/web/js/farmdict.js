/* Fadi Farm — قاموس مصطلحات المزرعة (فصحى + لهجات) إلى كلمات بحث إنجليزية.
   يُستخدم عندما لا يتوفر Gemini، أو كاحتياطي لضمان إيجاد لقطة لكل مشهد. */
'use strict';

const FarmDict = (() => {
  // الجذر (بدون "ال") ← كلمة البحث الإنجليزية. الأطول يُطابَق أولاً.
  const D = {
    'دجاج': 'chicken', 'دجاجه': 'hen', 'دجاجات': 'hens', 'فراخ': 'chicken', 'فرخه': 'hen', 'فرخ': 'chick',
    'بلدي': 'free range chicken', 'ديك': 'rooster', 'ديوك': 'roosters', 'كتكوت': 'chicks', 'كتاكيت': 'chicks', 'صوص': 'chicks', 'صيصان': 'chicks',
    'بيض': 'eggs', 'بيضه': 'egg', 'تفريخ': 'egg hatching', 'فقس': 'chick hatching', 'حضانه': 'egg incubator', 'فقاسه': 'egg incubator',
    'رومي': 'turkey', 'ديك رومي': 'turkey', 'بط': 'duck', 'بطه': 'duck', 'بطوط': 'ducklings', 'وز': 'goose', 'اوز': 'goose', 'إوز': 'goose',
    'حمام': 'pigeon', 'سمان': 'quail', 'نعام': 'ostrich', 'طاووس': 'peacock', 'طيور': 'farm birds', 'دواجن': 'poultry',
    'ارانب': 'rabbit', 'أرانب': 'rabbit', 'ارنب': 'rabbit', 'أرنب': 'rabbit',
    'ماعز': 'goat', 'معزه': 'goat', 'معيز': 'goats', 'جدي': 'baby goat', 'غنم': 'sheep', 'خروف': 'sheep', 'خرفان': 'lambs', 'نعاج': 'sheep',
    'بقر': 'cow', 'بقره': 'cow', 'عجل': 'calf', 'عجول': 'calves', 'جاموس': 'water buffalo', 'جاموسه': 'water buffalo',
    'حصان': 'horse', 'خيل': 'horses', 'حمار': 'donkey', 'جمل': 'camel', 'جمال': 'camels', 'نحل': 'bees', 'عسل': 'honey',
    'سمك': 'fish pond', 'كلب': 'farm dog', 'قطه': 'cat', 'حيوانات': 'farm animals', 'مواشي': 'livestock',
    'علف': 'animal feed', 'اعلاف': 'animal feed', 'أعلاف': 'animal feed', 'ذره': 'corn', 'قمح': 'wheat', 'شعير': 'barley', 'برسيم': 'alfalfa',
    'حشيش': 'grass', 'عشب': 'grass', 'مياه': 'drinking water', 'مية': 'drinking water', 'ماء': 'water', 'مسقى': 'water trough',
    'عشه': 'chicken coop', 'عشش': 'chicken coop', 'خم': 'chicken coop', 'قن': 'chicken coop', 'حظيره': 'barn', 'زريبه': 'barn', 'اسطبل': 'stable',
    'سياج': 'farm fence', 'عش': 'nest', 'ريش': 'feathers', 'مزرعه': 'farm', 'ريف': 'countryside', 'قريه': 'village', 'غيط': 'field', 'حقل': 'field',
    'ارض': 'farmland', 'زرع': 'crops', 'زراعه': 'agriculture', 'شجر': 'trees', 'نخل': 'palm trees', 'خضار': 'vegetables', 'فاكهه': 'fruit',
    'فلاح': 'farmer', 'مزارع': 'farmer', 'مربي': 'poultry farmer', 'تربيه': 'poultry farming', 'تربيه دواجن': 'poultry farming',
    'بيطري': 'veterinarian', 'تطعيم': 'vaccination', 'تحصين': 'vaccination', 'لقاح': 'vaccine', 'مرض': 'sick animal', 'امراض': 'animal disease', 'علاج': 'medicine',
    'لحم': 'meat', 'لبن': 'milk', 'حليب': 'milk', 'جبن': 'cheese', 'سوق': 'market', 'بيع': 'market', 'فلوس': 'money', 'ربح': 'money',
    'شمس': 'sunrise', 'صباح': 'morning', 'مسا': 'sunset', 'مساء': 'sunset', 'ليل': 'night', 'شتا': 'winter', 'شتاء': 'winter', 'صيف': 'summer', 'مطر': 'rain', 'برد': 'cold winter',
    'اكل': 'feeding', 'أكل': 'feeding', 'يأكل': 'eating', 'تاكل': 'eating', 'نوم': 'sleeping', 'جري': 'running',
  };
  const keys = Object.keys(D).sort((a, b) => b.length - a.length);
  const norm = w => w.replace(/[ً-ْـ]/g, '').replace(/[إأآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي');
  const strip = w => {
    let x = norm(w);
    for (const p of ['وال', 'بال', 'فال', 'كال', 'لل', 'ال']) if (x.startsWith(p) && x.length - p.length >= 2) { x = x.slice(p.length); break; }
    return x;
  };
  const NK = keys.map(k => [norm(k), D[k]]);

  /* يرجع كلمات إنجليزية مرتبة حسب ظهورها في النص */
  function translate(text) {
    if (typeof Channel !== 'undefined' && !Channel.cur.topicFilter) return [];
    const words = String(text || '').replace(/[^\p{L}\s]/gu, ' ').split(/\s+/).filter(Boolean).map(strip);
    const out = [];
    for (let i = 0; i < words.length; i++) {
      const two = words[i] + ' ' + (words[i + 1] || '');
      let hit = NK.find(([k]) => k.includes(' ') && two.startsWith(k));
      if (!hit) hit = NK.find(([k]) => !k.includes(' ') && (words[i] === k || (k.length >= 4 && words[i].startsWith(k) && words[i].length - k.length <= 2)));
      if (hit && !out.includes(hit[1])) out.push(hit[1]);
    }
    return out;
  }
  return { translate };
})();
