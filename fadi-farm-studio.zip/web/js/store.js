/* Fadi Farm — التخزين: الإعدادات في localStorage، والمشروع والملفات في IndexedDB */
'use strict';

const DEFAULT_SETTINGS = {
  keys: { gemini: '', pexels: '', pixabay: '', unsplash: '', flickr: '', europeana: '' },
  providers: [
    { id: 'pexels', on: true },
    { id: 'pixabay', on: true },
    { id: 'wikimedia', on: true },
    { id: 'inaturalist', on: true },
    { id: 'openverse', on: true },
    { id: 'flickr', on: true },
    { id: 'unsplash', on: true },
    { id: 'europeana', on: true },
    { id: 'archive', on: true },
    { id: 'nasa', on: false },
  ],
  geminiModel: 'gemini-flash-latest',
  context: 'قناة Fadi Farm: الزراعة، الحيوانات، الحياة الريفية',
  prefKind: 'video',
  sceneTarget: 6,
  captions: 'box',       // box | outline | off
  captionSize: 1,        // 0.8 .. 1.4
  transition: 'fade',    // fade | cut
  logo: 'icons/logo.png', // شعار القناة افتراضياً (أو dataURL لشعار مخصص)
  logoPos: 'tr',         // tl | tr | bl | br
  logoOpacity: 0.9,
  ratio: '1920x1080',
  fps: 30,
  ttsVoice: 'Charon',
  ttsPace: 'normal',
  ttsModel: 'gemini-3.8-flash-tts',
  extraVoices: [],
  dlQuality: 'fast',
};

const Settings = (() => {
  let s;
  function load() {
    try { s = JSON.parse(localStorage.getItem('ff.settings') || 'null'); } catch { s = null; }
    s = Object.assign(structuredClone(DEFAULT_SETTINGS), s || {});
    s.keys = Object.assign({}, DEFAULT_SETTINGS.keys, s.keys || {});
    // أضف أي مزوّد جديد لم يكن موجوداً في إعدادات قديمة
    const ids = new Set(s.providers.map(p => p.id));
    DEFAULT_SETTINGS.providers.forEach(p => { if (!ids.has(p.id)) s.providers.push({ ...p }); });
    s.providers = s.providers.filter(p => PROVIDERS[p.id]);
    return s;
  }
  function save() { try { localStorage.setItem('ff.settings', JSON.stringify(s)); } catch (e) { toast('تعذّر حفظ الإعدادات على هذا الجهاز', 'err'); } }
  return {
    get: () => s || load(),
    set(patch) { Object.assign(this.get(), patch); save(); },
    save,
    reset() { s = structuredClone(DEFAULT_SETTINGS); save(); },
  };
})();

const Store = (() => {
  let dbp;
  function db() {
    return dbp ??= new Promise((res, rej) => {
      const r = indexedDB.open('fadifarm', 1);
      r.onupgradeneeded = () => { r.result.createObjectStore('kv'); r.result.createObjectStore('blobs'); };
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
  }
  async function op(store, mode, fn) {
    const d = await db();
    return new Promise((res, rej) => {
      const t = d.transaction(store, mode), req = fn(t.objectStore(store));
      t.oncomplete = () => res(req && req.result);
      t.onerror = () => rej(t.error);
      t.onabort = () => rej(t.error || new Error('abort'));
    });
  }
  return {
    get: k => op('kv', 'readonly', s => s.get(k)),
    set: (k, v) => op('kv', 'readwrite', s => s.put(v, k)),
    getBlob: k => op('blobs', 'readonly', s => s.get(k)),
    putBlob: (k, b) => op('blobs', 'readwrite', s => s.put(b, k)),
    delBlob: k => op('blobs', 'readwrite', s => s.delete(k)),
    blobKeys: () => op('blobs', 'readonly', s => s.getAllKeys()),
    clearAll: async () => { await op('kv', 'readwrite', s => s.clear()); await op('blobs', 'readwrite', s => s.clear()); },
  };
})();
