/* Fadi — التخزين: الإعدادات في localStorage، والمشروع والملفات في IndexedDB */
'use strict';

const DEFAULT_SETTINGS = {
  keys: { gemini: '', pexels: '', pixabay: '', unsplash: '', flickr: '', europeana: '' },
  providers: [
    { id: 'pexels', on: true },
    { id: 'pixabay', on: true },
    { id: 'wikimedia', on: true },
    { id: 'inaturalist', on: true },
    { id: 'openverse', on: true },
    { id: 'flickr', on: true },
    { id: 'unsplash', on: true },
    { id: 'europeana', on: true },
    { id: 'archive', on: true },
    { id: 'nasa', on: false },
  ],
  geminiModel: 'gemini-flash-latest',
  context: 'قناة Fadi Farm: الزراعة، الحيوانات، الحياة الريفية',
  prefKind: 'mix',
  sceneTarget: 6,
  captions: 'words',     // smart | box | outline | off
  captionSize: 1,        // 0.8 .. 1.4
  transition: 'fade',    // fade | cut
  logo: 'icons/logo.png', // شعار القناة افتراضياً (أو dataURL لشعار مخصص)
  logoPos: 'tr',         // tl | tr | bl | br
  logoOpacity: 0.9,
  ratio: '1920x1080',
  fps: 30,
  ttsVoice: 'Charon',
  ttsPace: 'normal',
  ttsModel: 'gemini-3.8-flash-tts',
  extraVoices: [],
  dlQuality: 'fast',
  smartPick: true,
  subRemind: true,
  subEvery: 30,
  questionCards: true,
  blockWords: '',
};

/* إعدادات افتراضية خاصة بكل قناة */
function channelDefaults() {
  const c = Channel.cur, d = structuredClone(DEFAULT_SETTINGS);
  d.context = c.context; d.logo = c.logo;
  d.providers = c.providers.map(id => ({ id, on: !c.providersOff.includes(id) }));
  d.reelCta = c.cta;
  if (c.montage === 'strong') { d.transition = 'cut'; d.sceneTarget = 4; }
  return d;
}

const Settings = (() => {
  let s;
  const KEY = () => Channel.key('ff.settings');
  function load() {
    try { s = JSON.parse(localStorage.getItem(KEY()) || 'null'); } catch { s = null; }
    s = Object.assign(channelDefaults(), s || {});
    // مفاتيح API مشتركة بين كل القنوات
    let shared = null; try { shared = JSON.parse(localStorage.getItem('ff.keys') || 'null'); } catch {}
    s.keys = Object.assign({}, DEFAULT_SETTINGS.keys, s.keys || {}, shared || {});
    for (const k in s.keys) s.keys[k] = cleanKey(s.keys[k]);
    if (Channel.id === 'farm' && s.logo === 'icons/logo.png') s.logo = 'icons/farm-logo.png';
    // لوغو مجرى الجديد (الإطار الشفاف كما أرسله فادي) ما لم يكن هناك لوغو مخصّص مرفوع
    // 5.8: لوغو مجرى الجديد (الإطار الشفاف) في كل الأجهزة، حتى لو كان هناك لوغو قديم محفوظ
    if (Channel.id === 'majra' && !s.mig58) { s.logo = 'icons/majra-overlay.png'; s.logoOpacity = 1; s.mig58 = true; s.mig54 = true; s.topicTag = s.topicTag ?? true; }
    if (Channel.id === 'majra' && !s.mig54) { if (!String(s.logo || '').startsWith('data:')) s.logo = 'icons/majra-overlay.png'; s.logoOpacity = 1; s.mig54 = true; }
    if (!s.mig5) { s.captions = 'smart'; s.mig5 = true; }
    if (!s.mig56) { s.captions = 'words'; s.subRemind = true; s.questionCards = true; s.mig56 = true; }   // ترجمة كلمة بكلمة + الجمل المهمة
    // أضف أي مزوّد جديد لم يكن موجوداً في إعدادات قديمة
    const ids = new Set(s.providers.map(p => p.id));
    channelDefaults().providers.forEach(p => { if (!ids.has(p.id)) s.providers.push({ ...p }); });
    s.providers = s.providers.filter(p => PROVIDERS[p.id]);
    return s;
  }
  /* تنظيف المفتاح: المسافات والأسطر وعلامات الاتجاه الخفية (تأتي مع النسخ من واجهة عربية) تجعل المفتاح يتعطل */
  const cleanKey = v => String(v ?? '').replace(/[\s\u00a0\u200b-\u200f\u202a-\u202e\u2060-\u2069\ufeff"'«»`]/g, '');
  function save() {
    for (const k in s.keys) if (k !== 'azureRegion') s.keys[k] = cleanKey(s.keys[k]); else s.keys[k] = cleanKey(s.keys[k]).toLowerCase();
    try { localStorage.setItem(KEY(), JSON.stringify(s)); localStorage.setItem('ff.keys', JSON.stringify(s.keys)); }
    catch (e) { toast('تعذّر حفظ الإعدادات على هذا الجهاز', 'err'); }
    // نسخة احتياطية من المفاتيح في قاعدة البيانات (تُسترجع تلقائياً إذا مُسح التخزين المحلي)
    try { if (typeof Store !== 'undefined') Store.setRaw('keys-backup', { ...s.keys }).catch(() => {}); } catch {}
  }
  return {
    get: () => s || load(),
    set(patch) { Object.assign(this.get(), patch); save(); },
    save,
    /* استرجاع المفاتيح من النسخة الاحتياطية إذا ضاعت */
    async recoverKeys() {
      try {
        const b = await Store.getRaw('keys-backup'); if (!b) return 0;
        const cur = this.get().keys; let n = 0;
        for (const k in b) if (b[k] && !cur[k]) { cur[k] = b[k]; n++; }
        if (n) save();
        else Store.setRaw('keys-backup', { ...cur }).catch(() => {});
        return n;
      } catch { return 0; }
    },
    reset() { const k = s?.keys; s = channelDefaults(); if (k) s.keys = k; save(); },
  };
})();

const Store = (() => {
  let dbp;
  function db() {
    return dbp ??= new Promise((res, rej) => {
      const r = indexedDB.open('fadifarm', 2);
      r.onupgradeneeded = () => { const d = r.result; for (const n of ['kv', 'blobs']) if (!d.objectStoreNames.contains(n)) d.createObjectStore(n); };
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
  }
  async function op(store, mode, fn) {
    const d = await db();
    return new Promise((res, rej) => {
      const t = d.transaction(store, mode), req = fn(t.objectStore(store));
      t.oncomplete = () => res(req && req.result);
      t.onerror = () => rej(t.error);
      t.onabort = () => rej(t.error || new Error('abort'));
    });
  }
  // كل قناة لها مساحة منفصلة (قناة المزرعة بدون بادئة حفاظاً على المشاريع القديمة)
  const NS = () => Channel.id === 'farm' ? '' : Channel.id + ':';
  const others = () => Object.keys(Channel.LIST).filter(c => c !== 'farm').map(c => c + ':');
  return {
    get: k => op('kv', 'readonly', s => s.get(NS() + k)),
    getRaw: k => op('kv', 'readonly', s => s.get(k)),
    setRaw: (k, v) => op('kv', 'readwrite', s => s.put(v, k)),
    set: (k, v) => op('kv', 'readwrite', s => s.put(v, NS() + k)),
    getBlob: k => op('blobs', 'readonly', s => s.get(NS() + k)),
    putBlob: (k, b) => op('blobs', 'readwrite', s => s.put(b, NS() + k)),
    delBlob: k => op('blobs', 'readwrite', s => s.delete(NS() + k)),
    blobKeys: async () => {
      const all = await op('blobs', 'readonly', s => s.getAllKeys()), ns = NS();
      return all.map(String).filter(k => ns ? k.startsWith(ns) : !others().some(o => k.startsWith(o))).map(k => k.slice(ns.length));
    },
    /* حذف كل بيانات قناة محذوفة (مشروعها وملفاتها) */
    clearNS: async ns => {
      for (const st of ['kv', 'blobs']) {
        const keys = await op(st, 'readonly', s => s.getAllKeys());
        const del = keys.map(String).filter(k => k.startsWith(ns + ':'));
        if (del.length) await op(st, 'readwrite', s => { del.forEach(k => s.delete(k)); });
      }
    },
    clearAll: async () => { await op('kv', 'readwrite', s => s.clear()); await op('blobs', 'readwrite', s => s.clear()); },
  };
})();
