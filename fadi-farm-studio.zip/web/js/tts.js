/* Fadi — التعليق الصوتي التلقائي: Gemini، Microsoft Azure (أصوات اللهجات)، ElevenLabs — مع انتقال تلقائي عند الفشل */
'use strict';

const TTS = (() => {
  const BASE = 'https://generativelanguage.googleapis.com/v1beta/';
  const MALE = [
    ['Charon', 'رزين وواضح (مُعلّق)'], ['Orus', 'قوي وثابت'], ['Sadaltager', 'خبير هادئ'], ['Algenib', 'خشن وعميق'],
    ['Fenrir', 'حماسي'], ['Puck', 'مرح ونشيط'], ['Achird', 'ودود'], ['Iapetus', 'واضح'], ['Alnilam', 'حازم'],
    ['Rasalgethi', 'معلوماتي'], ['Umbriel', 'مريح'], ['Zubenelgenubi', 'عفوي'], ['Schedar', 'متوازن'], ['Enceladus', 'هادئ'],
  ];
  /* أصوات Gemini النسائية (تعمل بالعربية واللهجات واللغات الأخرى؛ اللهجة تُطلب بوصف الأسلوب) */
  const FEMALE = [
    ['Kore', 'حازمة وواضحة (مُعلّقة)'], ['Aoede', 'مشرقة وخفيفة'], ['Leda', 'شابة وودودة'], ['Zephyr', 'مشرقة ونشيطة'],
    ['Callirrhoe', 'هادئة ومريحة'], ['Autonoe', 'مشرقة'], ['Despina', 'ناعمة'], ['Erinome', 'واضحة'],
    ['Laomedeia', 'متفائلة'], ['Achernar', 'ناعمة وهادئة'], ['Gacrux', 'ناضجة ورصينة'], ['Pulcherrima', 'متحمسة'],
    ['Vindemiatrix', 'لطيفة'], ['Sulafat', 'دافئة'],
  ];
  let G = null;   // جنس مؤقت لدور واحد في الحوار (ميكس)
  const asGender = (g, fn) => { const o = G; G = g; try { return fn(); } finally { G = o; } };
  const isFemale = () => (G || (Settings.get().ttsGender === 'female' ? 'female' : 'male')) === 'female';
  /* يختار من قائمة أصوات ([id, اسم]) ما يوافق الجنس المختار: الاسم الذي فيه «امرأة» أو «مُعلّقة»... للإناث */
  const isFemaleLabel = n => /امرأة|\(f\)/i.test(n);
  const byGender = list => { const f = isFemale(), sub = list.filter(v => isFemaleLabel(v[1]) === f); return sub.length ? sub : list; };
  /* الصوت المحفوظ لكل جنس (…M للرجل و…F للمرأة) مع الرجوع للإعداد القديم ثم لأول صوت في القائمة */
  const pickVoice = (base, list, s) => { for (const c of [s[base + (isFemale() ? 'F' : 'M')], s[base]]) if (c && list.some(v => v[0] === c)) return c; return list[0][0]; };
  function voiceFor(id, s = Settings.get()) {
    if (id === 'gemini') return pickVoice('ttsVoice', isFemale() ? FEMALE : [...MALE, ...(s.extraVoices || []).map(x => [x.id, x.name])], s);
    if (id === 'azure') return pickVoice('azureVoice', byGender(Channel.dialect.voices), s);
    if (id === 'openai') return pickVoice('openaiVoice', byGender(OAI_VOICES), s);
    if (id === 'groq') return pickVoice('groqVoice', byGender(GROQ_VOICES), s);
    return '';
  }
  /* يحوّل وصف المتحدث من رجل إلى امرأة */
  const herGem = g => isFemale() ? g.replace(/\bman\b/g, 'woman').replace(/^راجل مصري بيحكي/, 'ست مصرية بتحكي').replace(/^مذيع عربي يتكلم/, 'مذيعة عربية تتكلم').replace(/^رجل (\S+)( يتكلم| بيحكي)/, (m, a, b) => 'امرأة ' + a.replace(/ي$/, 'ية') + ' تتكلم') : g;
  const PACE = {
    normal: 'بسرعة طبيعية',
    fast: 'بإيقاع سريع وحيوي',
    calm: 'بهدوء وتمهّل',
  };

  function style(pace) {
    if (Channel.lg !== 'ar') return `${herGem(Channel.dialect.gem)} for ${isFemale() ? 'her' : 'his'} YouTube audience, warm, natural and enthusiastic voice, ${{ normal: 'natural pace', fast: 'fast and energetic', calm: 'calm and slow' }[pace] || 'natural pace'}, light pauses between sentences.`;
    return `${herGem(Channel.dialect.gem)} لجمهور ${isFemale() ? 'قناتها' : 'قناته'} على يوتيوب، صوت ${isFemale() ? 'دافئ' : 'دافي'} وطبيعي ومتحمّس، ${PACE[pace] || PACE.normal}، مع وقفات خفيفة بين الجمل.`;
  }

  const key = () => { const k = Settings.get().keys.gemini; if (!k) throw new Error('أضف مفتاح Gemini من الإعدادات أولاً'); return k.trim(); };

  function b64ToBytes(b64) {
    const bin = atob(b64), u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u;
  }

  /* يبحث في الرد عن أول بيانات صوت base64 مهما كان شكل الرد */
  function findAudio(o, depth = 0) {
    if (!o || typeof o !== 'object' || depth > 8) return null;
    const t = String(o.type || o.mime_type || o.mimeType || '');
    if (typeof o.data === 'string' && o.data.length > 400 && (/audio/i.test(t) || /audio|l16|pcm|wav/i.test(String(o.mime_type || o.mimeType || '')) || depth > 1))
      return { data: o.data, mime: String(o.mime_type || o.mimeType || '') };
    if (o.inlineData || o.inline_data) return findAudio(o.inlineData || o.inline_data, depth + 1);
    for (const v of Array.isArray(o) ? o : Object.values(o)) { const r = findAudio(v, depth + 1); if (r) return r; }
    return null;
  }

  function errOf(status, d) {
    const m = d?.error?.message || '';
    if (status === 429) return 'تجاوزت حد Gemini للصوت مؤقتاً. انتظر دقيقة ثم أعد المحاولة';
    if (status === 403) return 'مفتاح Gemini لا يملك صلاحية لنموذج الصوت';
    if (status === 404) return 'نموذج الصوت غير متاح. غيّره من الإعدادات';
    if (status === 400 && /API key/i.test(m)) return 'مفتاح Gemini غير صالح';
    return `خطأ في توليد الصوت (${status}) ${m.slice(0, 120)}`;
  }

  async function post(url, body, signal) {
    const r = await fetch(url, { method: 'POST', signal, headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key() }, body: JSON.stringify(body) });
    const d = await r.json().catch(() => ({}));
    return { r, d };
  }

  /* مقطع واحد: يجرب Interactions API ثم generateContent */
  async function speakChunk(text, { voice, pace, signal }) {
    const s = Settings.get();
    const models = [s.ttsModel || 'gemini-3.8-flash-tts', 'gemini-3.8-flash-lite-tts', 'gemini-3.1-flash-tts-preview', 'gemini-2.5-flash-preview-tts', 'gemini-2.5-flash-tts'];
    let d;
    try {
      ({ d } = await AI.send(models, model => ({ url: BASE + 'interactions', body: {
        model,
        input: [{ type: 'user_input', content: [{ type: 'text', text, annotations: [{ type: 'speech_metadata', style: style(pace) }] }] }],
        response_format: { type: 'audio', mime_type: 'audio/l16', sample_rate: 24000 },
        generation_config: { speech_config: [{ voice }] },
      } }), { signal, gap: 6500 }));
    } catch (e) {
      if (/حصة|حد/.test(e.message)) throw new Error(e.message + '. استخدم وضع Google Vids للتعليق الصوتي، فهو بلا حدود');
      throw e;
    }
    const au = findAudio(d);
    if (!au) throw new Error('لم يُرجع Gemini صوتاً لهذا المقطع');   // يُعاد المقطع تلقائياً
    return toBuffer(b64ToBytes(au.data));
  }

  async function toBuffer(bytes) {
    const ctx = Player.audioCtx();
    const isWav = bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46;
    if (isWav) return ctx.decodeAudioData(bytes.buffer.slice(0));
    const n = Math.floor(bytes.length / 2), dv = new DataView(bytes.buffer, bytes.byteOffset, n * 2);
    const buf = ctx.createBuffer(1, n, 24000), ch = buf.getChannelData(0);
    for (let i = 0; i < n; i++) ch[i] = dv.getInt16(i * 2, true) / 32768;
    return buf;
  }

  /* تقسيم النص الطويل إلى مقاطع عند نهايات الجمل */
  function chunks(text, max = 2400) {
    const sents = text.replace(/\s+/g, ' ').split(/(?<=[.!؟?…\n])\s+/).map(x => x.trim()).filter(Boolean);
    const out = []; let c = '';
    for (const s of sents) {
      if (c && (c + ' ' + s).length > max) { out.push(c); c = s; } else c = c ? c + ' ' + s : s;
      while (c.length > max * 1.6) { const cut = c.lastIndexOf('،', max) > 100 ? c.lastIndexOf('،', max) + 1 : c.lastIndexOf(' ', max); out.push(c.slice(0, cut).trim()); c = c.slice(cut).trim(); }
    }
    if (c) out.push(c);
    return out;
  }

  /* ---------- Microsoft Azure Speech (أصوات اللهجات الرسمية) ---------- */
  const RATE = { normal: '+0%', fast: '+8%', calm: '-8%' };
  const xml = t => t.replace(/[<>&'"]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' }[c]));
  async function decodeMp3(b64) { const bytes = Http.b64bytes(b64); return Player.audioCtx().decodeAudioData(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength)); }
  async function azureChunk(text, { pace, signal }) {
    const s = Settings.get(), key = s.keys.azure?.trim(), region = (s.keys.azureRegion || 'westeurope').trim().toLowerCase().replace(/\s+/g, '');
    if (!key) throw new Error('أضف مفتاح Microsoft Azure Speech في الإعدادات');
    const d = Channel.dialect, voice = voiceFor('azure', s);
    const ssml = `<speak version='1.0' xml:lang='${d.locale}'><voice xml:lang='${d.locale}' name='${voice}'><prosody rate='${RATE[pace] || '+0%'}'>${xml(text)}</prosody></voice></speak>`;
    for (let a = 0; a < 4; a++) {
      const r = await Http.request(`https://${region}.tts.speech.microsoft.com/cognitiveservices/v1`, { method: 'POST', binary: true, signal, timeout: 180000,
        headers: { 'Ocp-Apim-Subscription-Key': key, 'Content-Type': 'application/ssml+xml', 'X-Microsoft-OutputFormat': 'audio-24khz-96kbitrate-mono-mp3' }, body: ssml });
      if (r.status === 200) return decodeMp3(r.data);
      if (r.status === 401 || r.status === 403) throw new Error('مفتاح Azure أو المنطقة غير صحيحة (المنطقة مثل westeurope)');
      if (r.status === 429 || r.status >= 500) { await new Promise(res => setTimeout(res, Math.min(20, r.retryAfter || 4 * (a + 1)) * 1000)); continue; }
      throw new Error(`Azure (${r.status}) ${String(r.data || '').slice(0, 120)}`);
    }
    throw new Error('Azure مشغول، أعد المحاولة');
  }

  /* ---------- ElevenLabs ---------- */
  async function elevenChunk(text, { signal }) {
    const s = Settings.get(), key = s.keys.elevenlabs?.trim(), voice = (s.elevenVoice || 'pNInz6obpgDQGcFmaJgB').trim();
    if (!key) throw new Error('أضف مفتاح ElevenLabs في الإعدادات');
    for (let a = 0; a < 3; a++) {
      const r = await Http.request(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voice)}?output_format=mp3_44100_128`, { method: 'POST', binary: true, signal, timeout: 180000,
        headers: { 'xi-api-key': key, 'Content-Type': 'application/json', Accept: 'audio/mpeg' }, body: JSON.stringify({ text, model_id: s.elevenModel || 'eleven_multilingual_v2' }) });
      if (r.status === 200) return decodeMp3(r.data);
      if (r.status === 401) throw new Error('مفتاح ElevenLabs غير صالح أو انتهى رصيده');
      if (r.status === 429 || r.status >= 500) { await new Promise(res => setTimeout(res, 5000 * (a + 1))); continue; }
      throw new Error(`ElevenLabs (${r.status}) ${String(r.data || '').slice(0, 120)}`);
    }
    throw new Error('ElevenLabs مشغول');
  }

  /* ---------- ChatGPT (OpenAI) TTS ---------- */
  const OAI_VOICES = [['onyx', 'Onyx — عميق ورزين'], ['ash', 'Ash — واضح وحيوي'], ['echo', 'Echo — هادئ'], ['verse', 'Verse — معبّر'], ['ballad', 'Ballad — دافئ'], ['coral', 'Coral (امرأة)'], ['nova', 'Nova (امرأة)']];
  async function openaiChunk(text, { pace, signal }) {
    const s = Settings.get(), key = s.keys.openai?.trim();
    if (!key) throw new Error('أضف مفتاح ChatGPT (OpenAI) في الإعدادات');
    const d = Channel.dialect, voice = voiceFor('openai', s);
    const instructions = `Speak in natural ${d.who} ${Channel.langEn} (${d.lang}) with an authentic ${d.who} accent, like a passionate YouTube storyteller (${isFemale() ? 'female' : 'male'} voice): warm, expressive, ${pace === 'fast' ? 'fast and energetic' : pace === 'calm' ? 'calm and slow' : 'natural pace'}, short pauses between sentences.`;
    for (let a = 0; a < 3; a++) {
      const r = await Http.request('https://api.openai.com/v1/audio/speech', { method: 'POST', binary: true, signal, timeout: 180000,
        headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: s.openaiTtsModel || 'gpt-4o-mini-tts', voice, input: text, instructions, response_format: 'mp3' }) });
      if (r.status === 200) return decodeMp3(r.data);
      if (r.status === 401) throw new Error('مفتاح OpenAI غير صالح');
      if (r.status === 429 && /quota|billing/i.test(r.data || '')) throw new Error('رصيد OpenAI منتهٍ');
      if (r.status === 429 || r.status >= 500) { await new Promise(res => setTimeout(res, 5000 * (a + 1))); continue; }
      throw new Error(`ChatGPT (${r.status}) ${String(r.data || '').slice(0, 120)}`);
    }
    throw new Error('ChatGPT مشغول');
  }

  /* ---------- Groq: صوت عربي مجاني (Orpheus، لهجة سعودية) — 200 حرف لكل طلب ---------- */
  const GROQ_VOICES = [['fahad', 'فهد'], ['abdullah', 'عبدالله'], ['sultan', 'سلطان'], ['noura', 'نورة (امرأة)'], ['lulwa', 'لولوة (امرأة)'], ['aisha', 'عائشة (امرأة)']];
  async function groqChunk(text, { signal }) {
    const s = Settings.get(), key = s.keys.groq?.trim();
    if (!key) throw new Error('أضف مفتاح Groq في الإعدادات');
    const voice = voiceFor('groq', s);
    for (let a = 0; a < 4; a++) {
      const r = await Http.request('https://api.groq.com/openai/v1/audio/speech', { method: 'POST', binary: true, signal, timeout: 120000,
        headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: 'canopylabs/orpheus-arabic-saudi', voice, input: text, response_format: 'wav' }) });
      if (r.status === 200) return toBuffer(b64ToBytes(r.data));
      const msg = String(r.data || '');
      if (/terms acceptance/i.test(msg)) throw new Error('صوت Groq العربي يحتاج موافقة مرة واحدة: افتح console.groq.com/playground?model=canopylabs%2Forpheus-arabic-saudi واضغط Accept');
      if (r.status === 401) throw new Error('مفتاح Groq غير صالح');
      if (r.status === 429 || r.status >= 500) { await new Promise(res => setTimeout(res, Math.min(60, (r.retryAfter || 8 * (a + 1))) * 1000)); continue; }
      throw new Error(`Groq (${r.status}) ${msg.slice(0, 120)}`);
    }
    throw new Error('Groq مشغول');
  }

  /* ---------- صوت الهاتف (مجاني بلا مفتاح، تطبيق أندرويد فقط) ---------- */
  let deviceVoices = null;
  async function phoneVoices() {
    if (!NATIVE) return [];
    if (deviceVoices) return deviceVoices;
    try { const r = await capCall('FadiNative', 'ttsVoices', {}); deviceVoices = (r.voices || []).filter(v => v.installed !== false).sort((a, b) => (a.network - b.network) || (b.quality - a.quality)); }
    catch { deviceVoices = []; }
    return deviceVoices;
  }
  async function deviceChunk(text, { pace, signal }) {
    if (!NATIVE) throw new Error('صوت الهاتف المجاني يعمل في تطبيق أندرويد فقط');
    if (signal?.aborted) throw Object.assign(new Error('أُلغي'), { name: 'AbortError' });
    const s = Settings.get(), d = Channel.dialect;
    const r = await capCall('FadiNative', 'ttsSynth', { text, lang: d.locale, voice: s.deviceVoice || undefined, rate: pace === 'fast' ? 1.12 : pace === 'calm' ? 0.9 : 1.0, pitch: 1.0 });
    if (!r?.data) throw new Error('صوت الهاتف لم يُرجع صوتاً');
    return decodeMp3(r.data);
  }

  const ENGINES = {
    gemini: { name: 'Gemini', has: () => !!Settings.get().keys.gemini, chunk: (t, o) => speakChunk(t, o), max: 2400 },
    azure: { name: 'Microsoft Azure', has: () => !!Settings.get().keys.azure, chunk: azureChunk, max: 600 },   // مقاطع قصيرة = مزامنة أدق للكتابة مع الصوت
    eleven: { name: 'ElevenLabs', has: () => !!Settings.get().keys.elevenlabs, chunk: elevenChunk, max: 900 },
    openai: { name: 'ChatGPT', has: () => !!Settings.get().keys.openai && (NATIVE || !!window.fadiDesktop), chunk: openaiChunk, max: 900 },   // المتصفح والآيفون يمنعان صوت ChatGPT
    groq: { name: 'Groq (صوت عربي مجاني)', has: () => !!Settings.get().keys.groq && Channel.lg === 'ar', chunk: groqChunk, max: 190 },
    device: { name: 'صوت الهاتف (مجاني)', has: () => NATIVE, chunk: deviceChunk, max: 320 },
  };
  /* ترتيب المحركات: المختار أولاً، ثم البقية التي لها مفتاح (حتى لا يتوقف التسجيل) */
  /* Gemini أولاً دائماً (إلا إذا اخترت غيره)، وصوت الهاتف لا يُستعمل إلا إذا اخترته أنت */
  function order() {
    const pref = Settings.get().ttsEngine || 'auto';
    const auto = ['gemini', 'azure', 'eleven', 'openai', 'groq'];
    const list = pref === 'auto' ? auto : [pref, ...auto.filter(x => x !== pref)];
    return list.filter(id => ENGINES[id] && ENGINES[id].has());
  }
  /* ذاكرة المقاطع المسجّلة: إذا توقف التسجيل يكمل من حيث توقف بدل البدء من الصفر */
  const ck = (id, t, voice, pace) => { const x = id + '|' + voice + '|' + pace + '|' + t; let h = 5381; for (let i = 0; i < x.length; i++) h = ((h * 33) ^ x.charCodeAt(i)) >>> 0; return 'ttsc-' + h.toString(36) + x.length; };
  async function cached(key) { try { const b = await Store.getBlob(key); return b ? await Player.audioCtx().decodeAudioData(await b.arrayBuffer()) : null; } catch { return null; } }
  async function remember(key, buf) {
    try {
      await Store.putBlob(key, wav(buf));
      const idx = (await Store.get('ttsc-index')) || []; idx.push(key);
      while (idx.length > 400) Store.delBlob(idx.shift()).catch(() => {});
      await Store.set('ttsc-index', idx);
    } catch {}
  }

  async function speakWith(id, text, { voice, pace, onProgress, signal }) {
    const E = ENGINES[id], parts = chunks(text, E.max);
    if (!parts.length) throw new Error('اكتب النص أولاً');
    const bufs = [];
    for (let i = 0; i < parts.length; i++) {
      const key = ck(id, parts[i], voice, pace);
      const hit = await cached(key); if (hit) { bufs.push(hit); continue; }
      let b = null, last = null;
      // كل مقطع يُعاد حتى 4 مرات (مع انتظار متزايد) قبل الانتقال لمحرك آخر
      for (let a = 0; a < 4 && !b; a++) {
        onProgress?.(`${E.name}: تسجيل المقطع ${i + 1} من ${parts.length}${a ? ` (محاولة ${a + 1})` : ''}…`, i / parts.length);
        try { b = await E.chunk(parts[i], { voice, pace, signal }); }
        catch (e) {
          if (e.name === 'AbortError' || signal?.aborted) throw e;
          last = e; if (/غير صالح|موافقة|رصيد|لا يملك صلاحية|أضف مفتاح/.test(e.message)) break;
          await new Promise(r => setTimeout(r, [10, 25, 45][a] * 1000));
        }
      }
      if (!b) { const err = new Error(last?.message || 'تعذّر التسجيل'); err.at = i; err.total = parts.length; throw err; }
      bufs.push(b); remember(key, b);
    }
    return { parts, bufs };
  }

  /* ---------- حوار بين رجل وامرأة (ميكس): اكتب اسم المتحدث قبل كلامه ---------- */
  const normLabel = x => String(x).toLowerCase().normalize('NFKC').replace(/[\u064B-\u0652\u0640]/g, '').replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').replace(/[\s\d_\-.*#()\[\]«»"']+/g, '');
  const MALE_LABELS = ['رجل', 'الرجل', 'ذكر', 'الذكر', 'مقدم', 'المقدم', 'مذيع', 'المذيع', 'man', 'male', 'm', 'homme', 'hombre', 'he'];
  const FEMALE_LABELS = ['امرأة', 'المرأة', 'إمرأة', 'امراة', 'المراة', 'أنثى', 'انثى', 'الأنثى', 'مقدمة', 'المقدمة', 'مذيعة', 'المذيعة', 'سيدة', 'woman', 'female', 'f', 'femme', 'mujer', 'she'];
  function parseDialogue(text) {
    const s = Settings.get();
    const names = k => String(s[k] || '').split(/[,،;؛\n]+/).map(normLabel).filter(Boolean);
    const M = new Set([...MALE_LABELS.map(normLabel), ...names('mixMaleNames')]), F = new Set([...FEMALE_LABELS.map(normLabel), ...names('mixFemaleNames')]);
    const turns = []; let cur = null, found = 0;
    for (const raw of String(text).split(/\n+/)) {
      const line = raw.trim(); if (!line) continue;
      const m = line.match(/^[\s*#>\-–—•\[(]*([^:：\n]{1,30}?)[\s*\])]*[:：]\s*(.*)$/);
      const lab = m && normLabel(m[1]), g = lab ? (M.has(lab) ? 'male' : F.has(lab) ? 'female' : null) : null;
      if (g) { found++; cur = { g, text: (m[2] || '').trim() }; turns.push(cur); }
      else if (cur) cur.text += (cur.text ? ' ' : '') + line;
      else { cur = { g: 'male', text: line }; turns.push(cur); }
    }
    return { turns: turns.filter(x => x.text), found };
  }
  /* النص بدون أسماء المتحدثين (للمشاهد والكتابة على الفيديو) */
  const cleanText = text => Settings.get().ttsGender === 'mix' ? parseDialogue(text).turns.map(x => x.text).join('\n') : text;

  /* يقرأ النص كاملاً ويرجع AudioBuffer واحد + موضع كل مقطع. عند فشل محرك يعيد التسجيل كاملاً بالمحرك التالي (صوت واحد في كل الفيديو) */
  async function speak(text, { voice, pace, onProgress, signal } = {}) {
    const s = Settings.get();
    pace = pace || s.ttsPace || 'normal';
    const ids = order();
    if (!ids.length) throw new Error('أضف مفتاح Gemini أو Microsoft Azure أو ChatGPT في الإعدادات، أو استعمل تطبيق أندرويد (فيه صوت الهاتف المجاني)');
    let turns;
    if (s.ttsGender === 'mix') {
      const pd = parseDialogue(text);
      if (!pd.found) throw new Error('وضع «ميكس»: اكتب اسم المتحدث قبل كلامه في كل سطر، مثل «رجل: ...» و«امرأة: ...»');
      turns = pd.turns;
    } else turns = [{ g: s.ttsGender === 'female' ? 'female' : 'male', text }];
    /* كل دور بصوت جنسه؛ وعند فشل محرك يُعاد الحوار كله بالمحرك التالي */
    const run = async id => {
      const parts = [], bufs = [];
      for (let ti = 0; ti < turns.length; ti++) {
        const t = turns[ti], G0 = G; G = t.g;
        try {
          const r = await speakWith(id, t.text, { voice: (voice && id === 'gemini' && turns.length === 1) ? voice : voiceFor(id, s), pace, signal,
            onProgress: (m, f) => onProgress?.(turns.length > 1 ? `${t.g === 'female' ? '👩' : '👨'} ${m}` : m, (ti + f) / turns.length) });
          parts.push(...r.parts); bufs.push(...r.bufs);
        } finally { G = G0; }
      }
      return { parts, bufs };
    };
    let res = null, used = null; const errs = [];
    for (const id of ids) {
      try { res = await run(id); used = id; break; }
      catch (e) {
        if (e.name === 'AbortError' || signal?.aborted) throw e;
        errs.push(`${ENGINES[id].name}: ${e.message.replace(/\. استخدم وضع Google Vids.*$/, '')}`);
        const nx = ids[ids.indexOf(id) + 1];
        if (nx) toast(`${ENGINES[id].name} لم ينجح، أكمل تلقائياً بـ ${ENGINES[nx].name}…`, '', 6000);
      }
    }
    if (!res) throw new Error(errs.join(' · ') + ' — المقاطع التي سُجّلت محفوظة: اضغط «اصنع التعليق» مرة أخرى بعد قليل ليكمل من حيث توقف' + (ids.length < 2 ? ' (ولأمان أكثر أضف مفتاح Microsoft Azure Speech المجاني كمحرك احتياطي)' : ''));
    const { parts, bufs } = res;
    const ctx = Player.audioCtx(), sr = bufs[0].sampleRate, gap = Math.round(sr * 0.25);
    const total = bufs.reduce((a, b) => a + Math.round(b.length * sr / b.sampleRate), 0) + gap * (bufs.length - 1);
    const out = ctx.createBuffer(1, total, sr), o = out.getChannelData(0);
    const segs = []; let pos = 0;
    bufs.forEach((b, i) => {
      let data = b.getChannelData(0);
      if (b.sampleRate !== sr) { const k = b.sampleRate / sr, n = Math.floor(data.length / k), r = new Float32Array(n); for (let j = 0; j < n; j++) r[j] = data[Math.min(data.length - 1, Math.round(j * k))]; data = r; }
      if (pos + data.length > o.length) data = data.subarray(0, o.length - pos);
      o.set(data, pos);
      segs.push({ text: parts[i], start: pos / sr, end: (pos + data.length) / sr, data, sr });
      pos += data.length + gap;
    });
    onProgress?.('اكتمل التسجيل', 1);
    return { buffer: out, segs, engine: ENGINES[used].name };
  }

  /* أصوات مكتبة Gemini الموسّعة باللهجة المصرية */
  async function listVoices() {
    const r = await fetch(BASE + 'voices?language_code=ar-EG&gender=male&page_size=200', { headers: { 'x-goog-api-key': key() } });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(errOf(r.status, d));
    return (d.voices || []).map(v => ({ id: v.id || v.name, name: v.display_name || v.displayName || v.id, desc: [v.accent, v.description].filter(Boolean).join(' · ') }));
  }

  /* WAV من AudioBuffer (لحفظ الصوت وتنزيله) */
  function wav(buf) {
    const d = buf.getChannelData(0), sr = buf.sampleRate, b = new ArrayBuffer(44 + d.length * 2), v = new DataView(b);
    const w = (o, s) => [...s].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
    w(0, 'RIFF'); v.setUint32(4, 36 + d.length * 2, true); w(8, 'WAVE'); w(12, 'fmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true);
    v.setUint16(22, 1, true); v.setUint32(24, sr, true); v.setUint32(28, sr * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
    w(36, 'data'); v.setUint32(40, d.length * 2, true);
    for (let i = 0; i < d.length; i++) { const x = Math.max(-1, Math.min(1, d[i])); v.setInt16(44 + i * 2, x < 0 ? x * 0x8000 : x * 0x7fff, true); }
    return new Blob([b], { type: 'audio/wav' });
  }

  return { speak, listVoices, wav, chunks, MALE, FEMALE, byGender, isFemale, asGender, pickVoice, voiceFor, parseDialogue, cleanText, PACE, ENGINES, order, OAI_VOICES, GROQ_VOICES, phoneVoices };
})();
