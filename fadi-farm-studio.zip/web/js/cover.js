/* Fadi — غلاف الريل (9:16): وصف مبالغ فيه واحترافي مع فادي، يُرسل إلى Google Flow ويُلتقط تلقائياً */
'use strict';

const Cover = (() => {
  const W = 1080, H = 1920;
  const st = { custom: null, img: null };
  const HOST = 'the channel host "Fadi", a handsome young Arab man around 25 years old with North African Arab features, short styled black hair, a neat short beard, light olive skin, modern casual jacket';

  function story() {
    const plan = window.Reel?.plan;
    const sc = plan ? App.scenes.slice(plan.start, plan.end + 1) : App.scenes.slice(0, 3);
    return { text: sc.map(s => s.text).join(' ').slice(0, 220), kw: [...new Set(sc.flatMap(s => s.kw).filter(w => /^[a-z ]+$/i.test(w)))].slice(0, 3) };
  }

  function autoPrompt() {
    const s = story(), farm = Channel.id === 'farm', glow = farm ? 'golden yellow' : 'electric blue';
    const hook = ($('#rlHook')?.value || Publish.promo?.thumbTitle || window.Reel?.plan?.hook || App.projName || Channel.cur.name).trim().split(/\s+/).slice(0, 3).join(' ');
    const subject = s.kw.length ? s.kw.join(', ') : (farm ? 'Egyptian baladi chickens and a proud rooster' : 'the trending news event');
    const host = Settings.get().coverHost !== false;
    return [
      `An insanely eye-catching, over-the-top dramatic vertical YouTube Shorts cover, 9:16 portrait, 1080x1920, about: ${s.text.replace(/[.!؟?…]+$/, '')}.`,
      host ? `In the foreground, ${HOST}, shown from the chest up, filling the lower-left half of the frame, with a HUGE exaggerated reaction: eyes wide open, jaw dropped in shock, one hand on his head and the other pointing dramatically at the subject behind him.` : '',
      `Behind him, giant and close, ${subject}, in the most dramatic moment of the story, ${Channel.cur.setting}.`,
      `Explosive dynamic composition with a strong diagonal, extreme close-up perspective, flying particles and dust, cinematic volumetric light rays, intense ${glow} rim light, hyper-saturated colors, extreme contrast, shallow depth of field, slight motion blur on the edges.`,
      Settings.get().coverText !== false ? `In the top third, the Arabic phrase "${hook}" in GIANT bold 3D Arabic letters, white fill, very thick black outline and a strong ${glow} glow, slightly tilted, perfectly legible and spelled exactly.` : 'No text at all.',
      `Keep the bottom 15% calm and darker for the YouTube interface.`,
      `Ultra realistic, 8k, razor sharp, viral YouTube Shorts thumbnail style, everything exaggerated and emotional, no logos, no watermark${Settings.get().coverText !== false ? ', no other text' : ''}.`,
    ].filter(Boolean).join(' ');
  }
  const prompt = () => (st.custom || '').trim() || autoPrompt();
  function show() {
    const el = $('#cvPrompt'); if (el && document.activeElement !== el) el.value = prompt();
    $('#cvReset').hidden = !st.custom;
  }

  async function draw() {
    const cv = $('#cvCanvas'); if (!cv) return;
    const g = cv.getContext('2d'), w = cv.width, h = cv.height;
    g.fillStyle = '#0b0f18'; g.fillRect(0, 0, w, h);
    if (!st.img) { try { const b = await Store.getBlob('reel-cover'); if (b) st.img = await createImageBitmap(b); } catch {} }
    if (st.img) {
      const k = Math.max(w / st.img.width, h / st.img.height);
      g.drawImage(st.img, (w - st.img.width * k) / 2, (h - st.img.height * k) / 2, st.img.width * k, st.img.height * k);
    } else {
      g.fillStyle = '#8aa'; g.font = '600 30px "IBM Plex Sans Arabic", sans-serif'; g.textAlign = 'center'; g.direction = 'rtl';
      g.fillText('غلاف الريل 9:16', w / 2, h / 2 - 22); g.fillText('اصنعه بـ Google Flow', w / 2, h / 2 + 22);
    }
    $('#cvSave').disabled = !st.img;
  }

  async function setImage(f) {
    await Store.putBlob('reel-cover', f).catch(() => {});
    st.img = await createImageBitmap(f);
    await draw();
  }

  async function viaFlow() {
    if (!NATIVE) { await copyText(prompt()); window.open(Capture.URLS.flow, '_blank'); return toast('نُسخ الوصف. بعد تنزيل الصورة اضغط «من المعرض»', '', 7000); }
    if (!(await Capture.prepare())) return;
    Capture.start({ kind: 'image', action: 'reelcover', label: 'غلاف الريل من Google Flow', onFound: f => found(f) });
    await Capture.copyOpen(prompt(), 'flow');
    toast('نُسخ وصف الغلاف (عمودي 9:16). في Flow اختر صورة بمقاس 9:16، اصنعها ونزّلها', '', 9000);
  }
  async function found(f) { if (App.view !== 'publish') go('publish'); await setImage(f); toast('أُضيف غلاف الريل'); }

  function save(share) { $('#cvCanvas').toBlob(b => b && saveFile(b, `${safeName()}-reel-cover.jpg`, { share }).catch(e => toast(e.message, 'err')), 'image/jpeg', 0.93); }

  async function enter() {
    if (st.custom == null) { try { st.custom = (await Store.get('cover-prompt')) || ''; } catch { st.custom = ''; } }
    $('#cvHost').checked = Settings.get().coverHost !== false;
    $('#cvText').checked = Settings.get().coverText !== false;
    show(); draw();
  }
  function reset() { st.custom = ''; st.img = null; Store.set('cover-prompt', '').catch(() => {}); Store.delBlob('reel-cover').catch(() => {}); }

  function bind() {
    Capture.register('reelcover', f => found(f));
    $('#cvFlow').onclick = viaFlow;
    $('#cvGallery').onclick = async () => {
      let f = null;
      if (NATIVE) f = await pickFromGallery('image').catch(() => null);
      else f = await new Promise(r => { const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*'; i.onchange = () => r(i.files[0] || null); i.click(); });
      if (f) setImage(f);
    };
    $('#cvSave').onclick = () => save(false);
    $('#cvShare').onclick = () => save(true);
    $('#cvCopy').onclick = async () => { if (await copyText(prompt())) toast('نُسخ الوصف'); };
    $('#cvPrompt').addEventListener('input', e => { st.custom = e.target.value; Store.set('cover-prompt', st.custom).catch(() => {}); $('#cvReset').hidden = false; });
    $('#cvReset').onclick = () => { st.custom = ''; Store.set('cover-prompt', '').catch(() => {}); $('#cvPrompt').value = autoPrompt(); $('#cvReset').hidden = true; };
    $('#cvHost').onchange = e => { Settings.set({ coverHost: e.target.checked }); show(); };
    $('#cvText').onchange = e => { Settings.set({ coverText: e.target.checked }); show(); };
    $('#rlHook').addEventListener('input', () => show());
  }

  return { enter, bind, reset, show };
})();
