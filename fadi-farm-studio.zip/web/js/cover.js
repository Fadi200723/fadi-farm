/* Fadi — غلاف الريل (9:16): وصف احترافي يُرسل إلى Google Flow ويُلتقط تلقائياً،
   نص تكتبه أنت فوق الغلاف، ويمكن دمجه في أول جزء من الريل ليختاره يوتيوب كصورة مصغرة */
'use strict';

const Cover = (() => {
  const W = 1080, H = 1920;
  const st = { custom: null, img: null };
  const FONT = n => `400 ${n}px "Lalezar", "IBM Plex Sans Arabic", sans-serif`;
  const HOST = 'the channel host "Fadi", a handsome young Arab man around 25 years old with North African Arab features, short styled black hair, a neat short beard, light olive skin, modern casual jacket';

  function story() {
    const plan = window.Reel?.plan;
    const sc = plan ? App.scenes.slice(plan.start, plan.end + 1) : App.scenes.slice(0, 3);
    return { text: sc.map(s => s.text).join(' ').slice(0, 220), kw: [...new Set(sc.flatMap(s => s.kw).filter(w => /^[a-z ]+$/i.test(w)))].slice(0, 3) };
  }
  /* النص على الغلاف: ما تكتبه أنت، وإلا عنوان الخطّاف */
  const title = () => ($('#cvTitle')?.value || $('#rlHook')?.value || Publish.promo?.thumbTitle || window.Reel?.plan?.hook || App.projName || Channel.cur.name).trim();
  const textMode = () => Settings.get().coverTextMode || (Settings.get().coverText === false ? 'off' : 'app');

  function autoPrompt() {
    const s = story(), farm = Channel.id === 'farm', glow = farm ? 'golden yellow' : 'electric blue';
    const hook = title().split(/\s+/).slice(0, 5).join(' ');
    const subject = s.kw.length ? s.kw.join(', ') : (farm ? 'Egyptian baladi chickens and a proud rooster' : 'the trending news event');
    const pm = Thumb.personMode('cover'), tm = textMode();
    return [
      `An insanely eye-catching, dramatic vertical YouTube Shorts cover, 9:16 portrait, 1080x1920, about: ${s.text.replace(/[.!؟?…]+$/, '')}.`,
      pm === 'fadi' ? `In the foreground, ${HOST}, shown from the chest up, filling the lower-left half of the frame, with a HUGE exaggerated reaction that matches the emotion of the story (shock, joy, worry or curiosity), pointing at the subject behind him.`
        : pm === 'person' ? `In the foreground, chest up: ${Thumb.PERSON}.` : '',
      `${pm === 'none' ? 'Giant and close in the center' : 'Behind, giant and close'}: ${subject}, in the most dramatic moment of the story, ${Channel.cur.setting}.`,
      Channel.id === 'majra' ? 'Small waving national flags of the countries in the story in the top corners, photorealistic cinematic collage of 2 small scenes from the story blended in the background.' : '',
      `Explosive dynamic composition with a strong diagonal, cinematic volumetric light rays, intense ${glow} rim light, hyper-saturated colors, extreme contrast, shallow depth of field.`,
      tm === 'flow' ? `In the top third, the Arabic phrase "${hook}" in GIANT bold Arabic letters, white fill, very thick black outline${Channel.id === 'majra' ? ', the key word inside a solid red banner' : ` and a strong ${glow} glow`}, perfectly legible and spelled exactly.`
        : `Leave the top third calmer for a title added later. No text at all.`,
      pm === 'none' ? Thumb.NO_PEOPLE : '',
      `Keep the bottom 15% calm and darker for the YouTube interface.`,
      `Ultra realistic, 8k, razor sharp, viral YouTube Shorts thumbnail style, no logos, no watermark${tm === 'flow' ? ', no other text' : ''}.`,
    ].filter(Boolean).join(' ');
  }
  const prompt = () => (st.custom || '').trim() || autoPrompt();
  function show() {
    const el = $('#cvPrompt'); if (el && document.activeElement !== el) el.value = prompt();
    $('#cvReset').hidden = !st.custom;
  }

  /* ---------- الرسم: الصورة + النص ---------- */
  function splitTwo(t) { const w = t.split(/\s+/).filter(Boolean); if (w.length < 3) return [t]; const m = Math.ceil(w.length / 2); return [w.slice(0, m).join(' '), w.slice(m).join(' ')]; }
  function drawText(g, text) {
    if (!text) return;
    const acc = Channel.id === 'majra' ? '#D62828' : Channel.cur.accent, fg = /^#FF[DE]/i.test(acc) ? '#111' : '#fff';
    const lines = splitTwo(text);
    let fs = 150; g.font = FONT(fs);
    while (Math.max(...lines.map(l => g.measureText(l).width)) > W * 0.84 && fs > 64) { fs -= 4; g.font = FONT(fs); }
    g.save(); g.direction = 'rtl'; g.textAlign = 'center'; g.textBaseline = 'middle';
    const gr = g.createLinearGradient(0, 0, 0, H * 0.42); gr.addColorStop(0, 'rgba(0,0,0,.55)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(0, 0, W, H * 0.42);
    const y0 = H * 0.17 - (lines.length - 1) * fs * 0.62;
    lines.forEach((l, i) => {
      const y = y0 + i * fs * 1.25;
      if (i === lines.length - 1 && lines.length > 1) {
        const w = g.measureText(l).width + fs * 0.7, h = fs * 1.25;
        g.save(); g.translate(W / 2, y); g.rotate(-0.03);
        g.shadowColor = 'rgba(0,0,0,.5)'; g.shadowBlur = 24; g.fillStyle = acc;
        g.beginPath(); g.roundRect ? g.roundRect(-w / 2, -h / 2, w, h, fs * 0.18) : g.rect(-w / 2, -h / 2, w, h); g.fill();
        g.shadowColor = 'transparent'; g.lineWidth = 7; g.strokeStyle = '#000'; g.stroke();
        g.fillStyle = fg; g.fillText(l, 0, fs * 0.05); g.restore();
      } else {
        g.lineJoin = 'round'; g.shadowColor = 'rgba(0,0,0,.6)'; g.shadowBlur = fs * 0.2; g.lineWidth = fs * 0.2; g.strokeStyle = '#000'; g.strokeText(l, W / 2, y);
        g.shadowColor = 'transparent'; g.fillStyle = '#fff'; g.fillText(l, W / 2, y);
      }
    });
    g.restore();
  }
  /* الغلاف النهائي بالحجم الكامل 1080×1920 (يُحفظ ويُدمج في الريل) */
  async function compose() {
    if (!st.img) { try { const b = await Store.getBlob('reel-cover'); if (b) st.img = await createImageBitmap(b); } catch {} }
    if (!st.img) return null;
    try { await document.fonts.load(FONT(120)); } catch {}
    const c = document.createElement('canvas'); c.width = W; c.height = H; const g = c.getContext('2d');
    const k = Math.max(W / st.img.width, H / st.img.height);
    g.filter = 'saturate(1.12) contrast(1.05)';
    g.drawImage(st.img, (W - st.img.width * k) / 2, (H - st.img.height * k) / 2, st.img.width * k, st.img.height * k);
    g.filter = 'none';
    if (textMode() === 'app') drawText(g, title());
    return c;
  }

  async function draw() {
    const cv = $('#cvCanvas'); if (!cv) return;
    const g = cv.getContext('2d'), w = cv.width, h = cv.height;
    g.fillStyle = '#0b0f18'; g.fillRect(0, 0, w, h);
    const c = await compose();
    if (c) g.drawImage(c, 0, 0, w, h);
    else {
      g.fillStyle = '#8aa'; g.font = '600 30px "IBM Plex Sans Arabic", sans-serif'; g.textAlign = 'center'; g.direction = 'rtl';
      g.fillText('غلاف الريل 9:16', w / 2, h / 2 - 22); g.fillText('اصنعه بـ Google Flow أو اختر صورة', w / 2, h / 2 + 22);
    }
    $('#cvSave').disabled = !c;
  }

  async function setImage(f) {
    await Store.putBlob('reel-cover', f).catch(() => {});
    st.img = await createImageBitmap(f);
    await draw();
  }

  async function viaFlow() {
    if (!(await Capture.prepare())) return;
    Capture.start({ kind: 'image', action: 'reelcover', label: 'غلاف الريل من Google Flow', onFound: f => found(f) });
    await Capture.copyOpen(prompt(), 'flow');
    toast('نُسخ وصف الغلاف (عمودي 9:16). في Flow اختر صورة بمقاس 9:16، اصنعها ونزّلها', '', 9000);
  }
  async function found(f) { if (App.view !== 'publish') go('publish'); await setImage(f); toast('أُضيف غلاف الريل'); }

  async function save(share) { const c = await compose(); if (!c) return; c.toBlob(b => b && saveFile(b, `${safeName()}-reel-cover.jpg`, { share }).catch(e => toast(e.message, 'err')), 'image/jpeg', 0.93); }

  async function enter() {
    if (st.custom == null) { try { st.custom = (await Store.get('cover-prompt')) || ''; } catch { st.custom = ''; } }
    if (!$('#cvTitle').value) { try { $('#cvTitle').value = (await Store.get('cover-title')) || ''; } catch {} }
    $('#cvPerson').value = Thumb.personMode('cover');
    $('#cvTextMode').value = textMode();
    $('#cvInReel').checked = Settings.get().coverInReel !== false;
    show(); draw();
  }
  function reset() { st.custom = ''; st.img = null; Store.set('cover-prompt', '').catch(() => {}); Store.set('cover-title', '').catch(() => {}); if ($('#cvTitle')) $('#cvTitle').value = ''; Store.delBlob('reel-cover').catch(() => {}); }

  function bind() {
    Capture.register('reelcover', f => found(f));
    $('#cvFlow').onclick = viaFlow;
    $('#cvGallery').onclick = async () => {
      let f = null;
      if (NATIVE) f = await pickFromGallery('image').catch(() => null);
      else f = await new Promise(r => { const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*'; i.onchange = () => r(i.files[0] || null); i.click(); });
      if (f) setImage(f);
    };
    $('#cvSave').onclick = () => save(false);
    $('#cvShare').onclick = () => save(true);
    $('#cvCopy').onclick = async () => { if (await copyText(prompt())) toast('نُسخ الوصف'); };
    $('#cvPrompt').addEventListener('input', e => { st.custom = e.target.value; Store.set('cover-prompt', st.custom).catch(() => {}); $('#cvReset').hidden = false; });
    $('#cvReset').onclick = () => { st.custom = ''; Store.set('cover-prompt', '').catch(() => {}); $('#cvPrompt').value = autoPrompt(); $('#cvReset').hidden = true; };
    $('#cvPerson').onchange = e => { Settings.set({ coverPerson: e.target.value }); st.custom = ''; Store.set('cover-prompt', '').catch(() => {}); show(); };
    $('#cvTextMode').onchange = e => { Settings.set({ coverTextMode: e.target.value }); st.custom = ''; Store.set('cover-prompt', '').catch(() => {}); show(); draw(); };
    $('#cvInReel').onchange = e => Settings.set({ coverInReel: e.target.checked });
    let t; $('#cvTitle').addEventListener('input', e => { Store.set('cover-title', e.target.value).catch(() => {}); show(); clearTimeout(t); t = setTimeout(draw, 250); });
    $('#rlHook').addEventListener('input', () => { show(); if (!$('#cvTitle').value) { clearTimeout(t); t = setTimeout(draw, 400); } });
  }

  return { enter, bind, reset, show, compose };
})();
