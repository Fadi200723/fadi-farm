/* Fadi — لوحة قص الصورة (مثل صورة البروفايل في يوتيوب وتيك توك):
   ترى كيف ستظهر بالمقاس النهائي، تسحبها لتحريكها، وتكبّر أو تصغّر بالشريط أو بإصبعين أو بعجلة الفأرة */
'use strict';

const Cropper = (() => {
  const VIEW = 320;            // حجم اللوحة على الشاشة (بكسل منطقي)
  let st = null;

  function draw() {
    const { cv, img, z, x, y, shape } = st, g = cv.getContext('2d'), S = cv.width, k = S / VIEW;
    g.clearRect(0, 0, S, S);
    g.fillStyle = '#0b0f18'; g.fillRect(0, 0, S, S);
    const base = Math.max(S / img.width, S / img.height) * z, w = img.width * base, h = img.height * base;
    g.drawImage(img, S / 2 - w / 2 + x * k, S / 2 - h / 2 + y * k, w, h);
    // ما خارج الإطار معتّم، مثل يوتيوب
    const r = S * 0.46;
    g.save(); g.fillStyle = 'rgba(0,0,0,.55)'; g.beginPath(); g.rect(0, 0, S, S);
    if (shape === 'circle') g.arc(S / 2, S / 2, r, 0, Math.PI * 2, true);
    else { const R = S * 0.2, a = S / 2 - r, b = S / 2 + r; g.moveTo(a + R, a); g.arcTo(a, a, a, a + R, R); g.arcTo(a, b, a + R, b, R); g.arcTo(b, b, b, b - R, R); g.arcTo(b, a, b - R, a, R); g.closePath(); }
    g.fill('evenodd'); g.restore();
    g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 2 * k; g.beginPath();
    if (shape === 'circle') g.arc(S / 2, S / 2, r, 0, Math.PI * 2); else g.rect(S / 2 - r, S / 2 - r, 2 * r, 2 * r);
    g.stroke();
  }
  function clampPos() {
    const { img, z } = st, base = Math.max(VIEW / img.width, VIEW / img.height) * z, w = img.width * base, h = img.height * base, r = VIEW * 0.46;
    const mx = Math.max(0, w / 2 - r), my = Math.max(0, h / 2 - r);
    st.x = Math.max(-mx, Math.min(mx, st.x)); st.y = Math.max(-my, Math.min(my, st.y));
  }
  /* الصورة النهائية: ما داخل الإطار فقط، مربعة 512×512 */
  function result(size = 512) {
    const { img, z, x, y } = st, r = VIEW * 0.46, c = document.createElement('canvas'); c.width = c.height = size;
    const g = c.getContext('2d'), base = Math.max(VIEW / img.width, VIEW / img.height) * z, k = size / (2 * r);
    const w = img.width * base * k, h = img.height * base * k;
    g.drawImage(img, size / 2 - w / 2 + x * k, size / 2 - h / 2 + y * k, w, h);
    return c.toDataURL('image/png');
  }

  async function load(src) {
    const url = src instanceof Blob ? URL.createObjectURL(src) : src, im = new Image();
    im.src = url; await im.decode(); return im;
  }

  /* يفتح اللوحة ← dataURL للصورة المقصوصة، أو null عند الإلغاء */
  async function open(src, { shape = 'circle', title = 'ضبط الصورة' } = {}) {
    const img = await load(src);
    const d = $('#cropDlg'), cv = $('#cropCv'), zr = $('#cropZoom');
    cv.width = cv.height = Math.round(VIEW * Math.min(2, window.devicePixelRatio || 1));
    $('#cropTitle').textContent = title;
    st = { cv, img, z: 1, x: 0, y: 0, shape };
    zr.value = 1; draw();
    const pts = new Map(); let pinch = null;
    const pos = e => { const b = cv.getBoundingClientRect(); return { x: (e.clientX - b.left) * VIEW / b.width, y: (e.clientY - b.top) * VIEW / b.height }; };
    cv.onpointerdown = e => { cv.setPointerCapture(e.pointerId); pts.set(e.pointerId, pos(e)); if (pts.size === 2) { const [a, b] = [...pts.values()]; pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), z: st.z }; } };
    cv.onpointermove = e => {
      if (!pts.has(e.pointerId)) return;
      const p = pos(e), q = pts.get(e.pointerId); pts.set(e.pointerId, p);
      if (pts.size === 2 && pinch) { const [a, b] = [...pts.values()]; st.z = Math.max(1, Math.min(5, pinch.z * Math.hypot(a.x - b.x, a.y - b.y) / Math.max(1, pinch.d))); zr.value = st.z; }
      else if (pts.size === 1) { st.x += p.x - q.x; st.y += p.y - q.y; }
      clampPos(); draw();
    };
    const up = e => { pts.delete(e.pointerId); if (pts.size < 2) pinch = null; };
    cv.onpointerup = up; cv.onpointercancel = up;
    cv.onwheel = e => { e.preventDefault(); st.z = Math.max(1, Math.min(5, st.z * (e.deltaY < 0 ? 1.08 : 0.93))); zr.value = st.z; clampPos(); draw(); };
    zr.oninput = () => { st.z = +zr.value; clampPos(); draw(); };
    $('#cropReset').onclick = () => { st.z = 1; st.x = st.y = 0; zr.value = 1; draw(); };
    return new Promise(res => {
      d.onclose = () => { const ok = d.returnValue === 'ok'; res(ok ? result() : null); st = null; };
      d.returnValue = ''; d.showModal();
    });
  }
  /* اختيار ملف من الجهاز ثم ضبطه */
  function pick(opts) {
    return new Promise(res => {
      const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*';
      i.onchange = async () => { const f = i.files[0]; if (!f) return res(null); try { res(await open(f, opts)); } catch { toast('تعذّرت قراءة الصورة', 'err'); res(null); } };
      i.click();
    });
  }
  return { open, pick };
})();
