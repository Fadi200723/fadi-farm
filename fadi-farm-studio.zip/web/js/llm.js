/* Fadi — كاتب النصوص بعدة مزوّدين: Gemini وChatGPT وGroq وOpenRouter، مع انتقال تلقائي عند الانشغال أو نفاد الحصة.
   Gemini وChatGPT يدعمان البحث في الإنترنت قبل الكتابة */
'use strict';

const LLM = (() => {
  const PROVIDERS = {
    groq: {
      name: 'Groq', url: 'https://api.groq.com/openai/v1/chat/completions',
      models: () => [Settings.get().groqModel, 'openai/gpt-oss-120b', 'llama-3.3-70b-versatile', 'qwen/qwen3-32b', 'openai/gpt-oss-20b'],
      maxTokens: 8000,
    },
    openrouter: {
      name: 'OpenRouter', url: 'https://openrouter.ai/api/v1/chat/completions',
      models: () => [Settings.get().openrouterModel, 'deepseek/deepseek-chat-v3-0324:free', 'meta-llama/llama-3.3-70b-instruct:free', 'google/gemma-3-27b-it:free', 'qwen/qwen3-235b-a22b:free'],
      maxTokens: 12000,
      extra: { 'HTTP-Referer': 'https://fadi200723.github.io/fadi-farm/', 'X-Title': 'Fadi' },
    },
  };
  const NAMES = { gemini: 'Gemini', openai: 'ChatGPT', groq: 'Groq', openrouter: 'OpenRouter' };
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  /* ChatGPT عبر Responses API (مع بحث الويب عند الطلب) */
  async function openai(prompt, { signal, onNote, onSources, search, min }) {
    const key = Settings.get().keys.openai.trim();
    const models = [...new Set([Settings.get().openaiModel, 'gpt-5-mini', 'gpt-4.1-mini', 'gpt-4o-mini'].filter(Boolean))];
    let last = null, useSearch = search;
    for (let mi = 0; mi < models.length; mi++) {
      const model = models[mi];
      for (let a = 0; a < 3; a++) {
        onNote?.(useSearch ? 'ChatGPT يبحث في الإنترنت ثم يكتب…' : 'يكتب عبر ChatGPT…');
        const body = { model, input: prompt, max_output_tokens: 16000 };
        if (/^(gpt-5|o\d)/.test(model)) body.reasoning = { effort: 'low' };
        if (useSearch) body.tools = [{ type: 'web_search' }];
        const r = await Http.json('https://api.openai.com/v1/responses', { method: 'POST', signal, timeout: 300000, headers: { Authorization: 'Bearer ' + key }, body });
        if (r.status === 200) {
          const msgs = (r.d.output || []).filter(o => o.type === 'message').flatMap(o => o.content || []).filter(c => c.type === 'output_text');
          const out = msgs.map(c => c.text).join('').trim();
          const src = msgs.flatMap(c => c.annotations || []).filter(x => x.url).map(x => ({ url: x.url, title: x.title }));
          if (src.length) onSources?.(src);
          if (out.length >= (min ?? 40)) return out;
          last = 'ChatGPT: رد فارغ'; break;
        }
        const msg = r.d?.error?.message || '';
        last = `ChatGPT (${r.status}) ${msg}`.slice(0, 200);
        if (r.status === 401) throw new Error('مفتاح ChatGPT (OpenAI) غير صالح');
        if (r.status === 429 && /quota|billing|insufficient/i.test(msg)) throw new Error('رصيد OpenAI منتهٍ: اشحن رصيداً في platform.openai.com');
        if (r.status === 400 && useSearch && /tool|web_search/i.test(msg)) { useSearch = false; a--; continue; }
        if (r.status === 429 || r.status >= 500) { const w = Math.min(30, r.retryAfter || 6 * (a + 1)); onNote?.(`ChatGPT مشغول، انتظار ${Math.ceil(w)} ث…`); await sleep(w * 1000); continue; }
        break;
      }
    }
    throw new Error(last || 'ChatGPT: تعذّرت الكتابة');
  }
  const has = id => !!Settings.get().keys[id]?.trim();
  let geminiDown = 0;   // بعد فشل Gemini نتخطاه 3 دقائق حتى لا ننتظره في كل جزء
  /* الترتيب: المزوّد المفضّل من الإعدادات أولاً، ثم البقية. مع البحث نقدّم من يدعمه */
  const available = (search = false) => {
    const pref = Settings.get().textPref || 'auto';
    let all = ['gemini', 'openai', ...Object.keys(PROVIDERS)];
    if (pref !== 'auto' && all.includes(pref)) all = [pref, ...all.filter(x => x !== pref)];
    if (search) all = [...all.filter(x => x === 'gemini' || x === 'openai'), ...all.filter(x => x !== 'gemini' && x !== 'openai')];
    return all.filter(has);
  };

  async function chat(id, prompt, { signal, onNote, temperature = 0.85, min }) {
    const P = PROVIDERS[id], key = Settings.get().keys[id].trim();
    let last = null;
    for (const model of [...new Set(P.models().filter(Boolean))]) {
      for (let a = 0; a < 3; a++) {
        onNote?.(`يكتب عبر ${P.name}…`);
        const r = await Http.json(P.url, { method: 'POST', signal, timeout: 180000, headers: { Authorization: 'Bearer ' + key, ...(P.extra || {}) },
          body: { model, temperature, max_tokens: P.maxTokens, messages: [{ role: 'user', content: prompt }] } });
        if (r.status === 200) {
          const out = String(r.d.choices?.[0]?.message?.content || '').replace(/<think>[\s\S]*?<\/think>/g, '').trim();
          if (out.length >= (min ?? 40)) return out;
          last = `${P.name}: رد فارغ`; break;
        }
        const msg = r.d?.error?.message || r.raw?.slice?.(0, 140) || '';
        last = `${P.name} (${r.status}) ${msg}`.slice(0, 200);
        if (r.status === 401 || r.status === 403) throw new Error(`مفتاح ${P.name} غير صالح`);
        if (r.status === 429 || r.status >= 500) { const w = Math.min(30, r.retryAfter || 6 * (a + 1)); onNote?.(`${P.name} مشغول، انتظار ${Math.ceil(w)} ث…`); await sleep(w * 1000); continue; }
        break;                                   // 400/404: النموذج غير متاح ← التالي
      }
    }
    throw new Error(last || `${P.name}: تعذّرت الكتابة`);
  }

  /* نص حر: يجرب كل المزوّدين المتاحين بالترتيب حتى ينجح أحدهم */
  async function text(prompt, opts = {}) {
    let order = available(!!opts.search).filter(id => !(opts.skipGemini && id === 'gemini'));
    if (Date.now() < geminiDown && order.length > 1) order = order.filter(id => id !== 'gemini');
    if (!order.length) throw new Error('أضف مفتاح Gemini أو ChatGPT أو Groq من الإعدادات أولاً');
    const errs = [];
    for (const id of order) {
      try {
        if (id === 'gemini') return await AI.text(prompt, opts);
        if (id !== order[0]) opts.onNote?.(`أنتقل إلى ${NAMES[id]}…`);
        const out = id === 'openai' ? await openai(prompt, opts) : await chat(id, prompt, opts);
        opts.onText?.(out);
        return out;
      } catch (e) {
        if (e.name === 'AbortError' || opts.signal?.aborted) throw e;
        if (id === 'gemini') geminiDown = Date.now() + 180e3;
        errs.push(e.message.replace(/\. اضغط «أعد الكتابة»$/, ''));
      }
    }
    const tip = order.length === 1 ? ' — أضف مفتاح Groq المجاني في الإعدادات كمزوّد احتياطي حتى لا تتوقف الكتابة' : '';
    throw new Error(errs.join(' · ') + tip);
  }

  /* اختبار سريع لمزوّد */
  async function test(id) {
    const p = 'Reply with the single word OK';
    if (id === 'gemini') { await AI.test(); return true; }
    const out = id === 'openai' ? await openai(p, { min: 1 }) : await chat(id, p, { min: 1 });
    return !!out;
  }
  return { text, available, test, PROVIDERS, NAMES };
})();
