/* Fadi — كاتب النصوص بعدة مزوّدين: Gemini أولاً، وعند انشغاله أو نفاد حصته ينتقل تلقائياً إلى Groq ثم OpenRouter */
'use strict';

const LLM = (() => {
  const PROVIDERS = {
    groq: {
      name: 'Groq', url: 'https://api.groq.com/openai/v1/chat/completions',
      models: () => [Settings.get().groqModel, 'openai/gpt-oss-120b', 'llama-3.3-70b-versatile', 'qwen/qwen3-32b', 'openai/gpt-oss-20b'],
      maxTokens: 8000,
    },
    openrouter: {
      name: 'OpenRouter', url: 'https://openrouter.ai/api/v1/chat/completions',
      models: () => [Settings.get().openrouterModel, 'deepseek/deepseek-chat-v3-0324:free', 'meta-llama/llama-3.3-70b-instruct:free', 'google/gemma-3-27b-it:free', 'qwen/qwen3-235b-a22b:free'],
      maxTokens: 12000,
      extra: { 'HTTP-Referer': 'https://fadi200723.github.io/fadi-farm/', 'X-Title': 'Fadi' },
    },
  };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const has = id => !!Settings.get().keys[id]?.trim();
  let geminiDown = 0;   // بعد فشل Gemini نتخطاه 3 دقائق حتى لا ننتظره في كل جزء
  const available = () => ['gemini', ...Object.keys(PROVIDERS)].filter(has);

  async function chat(id, prompt, { signal, onNote, temperature = 0.85 }) {
    const P = PROVIDERS[id], key = Settings.get().keys[id].trim();
    let last = null;
    for (const model of [...new Set(P.models().filter(Boolean))]) {
      for (let a = 0; a < 3; a++) {
        onNote?.(`يكتب عبر ${P.name}…`);
        const r = await Http.json(P.url, { method: 'POST', signal, timeout: 180000, headers: { Authorization: 'Bearer ' + key, ...(P.extra || {}) },
          body: { model, temperature, max_tokens: P.maxTokens, messages: [{ role: 'user', content: prompt }] } });
        if (r.status === 200) {
          const out = String(r.d.choices?.[0]?.message?.content || '').replace(/<think>[\s\S]*?<\/think>/g, '').trim();
          if (out.length > 40) return out;
          last = `${P.name}: رد فارغ`; break;
        }
        const msg = r.d?.error?.message || r.raw?.slice?.(0, 140) || '';
        last = `${P.name} (${r.status}) ${msg}`.slice(0, 200);
        if (r.status === 401 || r.status === 403) throw new Error(`مفتاح ${P.name} غير صالح`);
        if (r.status === 429 || r.status >= 500) { const w = Math.min(30, r.retryAfter || 6 * (a + 1)); onNote?.(`${P.name} مشغول، انتظار ${Math.ceil(w)} ث…`); await sleep(w * 1000); continue; }
        break;                                   // 400/404: النموذج غير متاح ← التالي
      }
    }
    throw new Error(last || `${P.name}: تعذّرت الكتابة`);
  }

  /* نص حر: يجرب كل المزوّدين المتاحين بالترتيب حتى ينجح أحدهم */
  async function text(prompt, opts = {}) {
    let order = available().filter(id => !(opts.skipGemini && id === 'gemini'));
    if (Date.now() < geminiDown && order.length > 1) order = order.filter(id => id !== 'gemini');
    if (!order.length) throw new Error('أضف مفتاح Gemini (أو Groq / OpenRouter) من الإعدادات أولاً');
    const errs = [];
    for (const id of order) {
      try {
        if (id === 'gemini') return await AI.text(prompt, opts);
        opts.onNote?.(`Gemini غير متاح الآن، أنتقل إلى ${PROVIDERS[id].name}…`);
        const out = await chat(id, prompt, opts);
        opts.onText?.(out);
        return out;
      } catch (e) {
        if (e.name === 'AbortError' || opts.signal?.aborted) throw e;
        if (id === 'gemini') geminiDown = Date.now() + 180e3;
        errs.push(e.message.replace(/\. اضغط «أعد الكتابة»$/, ''));
      }
    }
    const tip = order.length === 1 ? ' — أضف مفتاح Groq المجاني في الإعدادات كمزوّد احتياطي حتى لا تتوقف الكتابة' : '';
    throw new Error(errs.join(' · ') + tip);
  }

  return { text, available, PROVIDERS };
})();
