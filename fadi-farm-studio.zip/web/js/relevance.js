/* Fadi Farm — فلتر الصلة: يمنع اللقطات الخارجة عن موضوع القناة ويرتّب النتائج حسب قربها من المشهد */
'use strict';

const Relevance = (() => {
  // محتوى غير مناسب لقناة عائلية عن الحيوانات: يُرفض دائماً
  const BLOCK = [
    'cigarette', 'cigarettes', 'cigar', 'cigars', 'smoking', 'smoker', 'smoke', 'tobacco', 'vape', 'vaping', 'hookah', 'shisha', 'nicotine', 'ashtray', 'lighter',
    'alcohol', 'beer', 'wine', 'whiskey', 'whisky', 'vodka', 'cocktail', 'liquor', 'drunk', 'bar', 'pub', 'champagne',
    'drug', 'drugs', 'cocaine', 'marijuana', 'cannabis', 'weed', 'joint', 'syringe', 'pills',
    'gun', 'guns', 'rifle', 'pistol', 'weapon', 'weapons', 'ammo', 'bullet', 'bullets', 'soldier', 'soldiers', 'army', 'war', 'military', 'bomb', 'explosion', 'hunting', 'hunter',
    'blood', 'bloody', 'gore', 'corpse', 'dead', 'death', 'slaughter', 'butcher', 'carcass', 'skull',
    'nude', 'naked', 'bikini', 'lingerie', 'underwear', 'sexy', 'erotic', 'sensual', 'seductive', 'kissing', 'kiss', 'couple', 'romance', 'romantic',
    'nightclub', 'club', 'disco', 'party', 'casino', 'gambling', 'poker', 'dance', 'dancing',
    'fashion', 'model', 'models', 'makeup', 'cosmetics', 'selfie',
    'pork', 'bacon', 'ham', 'sausage', 'pepperoni',
    'halloween', 'zombie', 'horror', 'demon', 'witch',
  ];
  // الحشمة (للقناتين): لا نساء ولا محرمات في اللقطات
  const MODEST = ('woman women girl girls lady ladies female females feminine wife wives bride bridal bridesmaid girlfriend actress actresses ballerina ' +
    'hijab niqab dress dresses skirt skirts heels lipstick hairstyle blonde brunette beauty beautiful pretty glamour glamorous makeup ' +
    'bikini swimsuit swimwear beach pool yoga fitness gym workout cheerleader ' +
    'pig pigs piglet piglets swine hog hogs boar sow pork bacon ham ' +
    'concert dj singer nightclub club disco dance dancing dancer party wedding couple couples ' +
    'beer wine whiskey vodka cocktail alcohol liquor champagne casino gambling poker bet betting').split(/\s+/);
  const MODESTSET = new Set(MODEST);
  const BLOCKSET = new Set(BLOCK);
  // قناة الأخبار والترندات: لا نمنع الحرب أو الشرطة… فهي أخبار. نمنع فقط المحتوى غير اللائق
  const NEWS_BLOCK = new Set(['nude', 'naked', 'bikini', 'lingerie', 'underwear', 'sexy', 'erotic', 'sensual', 'seductive', 'gore', 'corpse', 'carcass', 'pork', 'bacon', 'cigarette', 'cigarettes', 'vape', 'cocaine', 'marijuana', 'cannabis', 'casino', 'gambling', 'poker', 'beer', 'wine', 'whiskey', 'vodka', 'cocktail']);
  const farm = () => typeof Channel === 'undefined' || Channel.cur.topicFilter;

  // مفردات عالم القناة: وجود واحدة منها يعني أن اللقطة غالباً في الموضوع
  const TOPIC = new Set(('chicken chickens hen hens rooster roosters cock chick chicks poultry broiler broilers layer layers egg eggs ' +
    'duck ducks duckling ducklings turkey turkeys goose geese gosling pigeon pigeons dove quail ostrich peacock bird birds fowl feather feathers ' +
    'goat goats kid sheep lamb lambs ram ewe cow cows calf calves cattle bull ox buffalo horse horses foal donkey mule camel camels rabbit rabbits bunny ' +
    'bee bees beehive honey fish pond animal animals livestock pet pets wildlife nature ' +
    'farm farms farmer farmers farming barn coop henhouse stable shed pen fence nest hay straw feed feeding grain corn wheat barley seeds alfalfa grass pasture meadow field fields ' +
    'village rural countryside agriculture agricultural crop crops harvest tractor garden vegetables trough water sunrise sunset morning').split(/\s+/));

  const tokens = s => String(s || '').toLowerCase().replace(/[^a-z؀-ۿ\s]/g, ' ').split(/\s+/).filter(w => w.length > 1);
  const stem = w => w.replace(/(ies)$/, 'y').replace(/(es|s)$/, '');
  const extra = () => tokens(Settings.get().blockWords || '');

  function blocked(it) {
    const t = tokens(`${it.title} ${it.tags || ''}`);
    const ex = new Set(extra());
    const B = farm() ? BLOCKSET : NEWS_BLOCK;
    return t.some(w => B.has(w) || ex.has(w) || MODESTSET.has(w) || MODESTSET.has(stem(w)));
  }

  /* درجة الصلة: كلمات المشهد (أهمها الأولى) + مفردات القناة */
  function score(it, query, subjects = []) {
    if (blocked(it)) return -1;
    const meta = new Set(tokens(`${it.title} ${it.tags || ''}`).map(stem));
    const q = tokens(query).map(stem), subj = subjects.flatMap(tokens).map(stem);
    let sc = 0;
    q.forEach((w, i) => { if (meta.has(w)) sc += i === 0 ? 3 : 2; });
    subj.forEach(w => { if (meta.has(w)) sc += 2; });
    if (farm()) meta.forEach(w => { if (TOPIC.has(w) || TOPIC.has(w + 's')) sc += 1; });
    // بيانات وصفية فقيرة (اسم المزوّد فقط): لا نرفضها لكن نعطيها أقل أولوية
    if (meta.size <= 1) sc = Math.max(sc, 0.5);
    return sc;
  }

  const ANIMALS = new Set(('chicken hen rooster cock chick poultry broiler layer egg duck duckling turkey goose gosling pigeon dove quail ostrich peacock bird fowl ' +
    'goat kid sheep lamb ram ewe cow calf cattle bull ox buffalo horse foal donkey mule camel rabbit bunny bee fish animal livestock').split(' '));
  const HUMAN = new Set('farmer man person people boy child hand hands face talking speaking worker family'.split(' '));
  const isAnimal = w => ANIMALS.has(w) || ANIMALS.has(stem(w));

  /* يضيف حيوان الموضوع إلى أي بحث عن أشخاص أو خارج عالم المزرعة، حتى لا تأتي لقطة لشخص فقط */
  function anchor(query, subject) {
    if (!farm()) return query;
    const t = tokens(query).map(stem);
    if (t.some(isAnimal)) return query;
    const human = t.some(w => HUMAN.has(w)), topic = t.some(w => TOPIC.has(w) || TOPIC.has(w + 's'));
    if (topic && !human) return query;
    return `${query} ${subject || 'farm animals'}`.trim();
  }

  const onTopic = it => [...tokens(`${it.title} ${it.tags || ''}`)].some(w => TOPIC.has(w) || TOPIC.has(stem(w)) || TOPIC.has(stem(w) + 's'));

  return { score, anchor, blocked, onTopic, tokens, isAnimal };
})();
