/* Fadi — كاتب السكريبت + أفكار القناة:
   - يربط قناة يوتيوب (بدون مفتاح) ليقرأ عناوين الفيديوهات ويقترح أفكاراً جديدة غير مكررة
   - يكتب سكريبت كامل باللهجة المختارة بالبنية: خطّاف ← اشتراك ولايك ← المحتوى ← خاتمة */
'use strict';

const Script = (() => {
  const st = { req: null, busy: false, ctl: null, ideas: [], videos: null, cat: null };

  /* ---------- الشبكة ---------- */
  const DESKTOP_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36';
  async function getText(url) {
    if (NATIVE) {
      const r = await capCall('FadiNative', 'fetchText', { url, headers: { 'Accept-Language': 'ar,en;q=0.8', 'User-Agent': DESKTOP_UA } });
      if (r && r.status < 400) return r.data;
      throw new Error('HTTP ' + (r?.status || '?'));
    }
    const r = await fetch(url); if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.text();
  }

  /* ---------- قناة يوتيوب ---------- */
  function channelUrl(h) {
    h = String(h || '').trim().replace(/\s+/g, ''); if (!h) return '';
    if (/^(www\.|m\.)?youtube\.com\//i.test(h)) h = 'https://' + h;
    if (/^https?:\/\//.test(h)) h = h.replace('://m.', '://www.').split('?')[0];
    if (/^https?:\/\//.test(h)) return h.replace(/\/(videos|shorts|featured|streams)\/?$/, '').replace(/\/$/, '');
    if (/^UC[\w-]{20,}$/.test(h)) return 'https://www.youtube.com/channel/' + h;
    return 'https://www.youtube.com/' + encodeURI(h.startsWith('@') ? h : '@' + h);
  }
  const txt = t => t ? (t.simpleText || t.content || (t.runs || []).map(r => r.text).join('') || '') : '';
  function collect(o, out, depth = 0) {
    if (!o || typeof o !== 'object' || depth > 40) return;
    if (Array.isArray(o)) { o.forEach(x => collect(x, out, depth + 1)); return; }
    const v = o.videoRenderer || o.gridVideoRenderer;
    if (v?.videoId) out.push({ id: v.videoId, title: txt(v.title), views: txt(v.viewCountText) || txt(v.shortViewCountText), date: txt(v.publishedTimeText) });
    const r = o.reelItemRenderer;
    if (r?.videoId) out.push({ id: r.videoId, title: txt(r.headline), views: txt(r.viewCountText), date: '', short: true });
    const sl = o.shortsLockupViewModel;
    if (sl) { const id = (sl.entityId || '').replace(/^shorts-shelf-item-/, ''); out.push({ id, title: sl.overlayMetadata?.primaryText?.content || '', views: sl.overlayMetadata?.secondaryText?.content || '', date: '', short: true }); }
    const lk = o.lockupViewModel;
    if (lk?.contentId) {
      const md = lk.metadata?.lockupMetadataViewModel, rows = md?.metadata?.contentMetadataViewModel?.metadataRows || [];
      const parts = rows.flatMap(rw => (rw.metadataParts || []).map(p => p.text?.content || '')).filter(Boolean);
      const vw = parts.find(p => /view|vue|مشاهد/i.test(p)) || parts.find(p => /^[\d.,\s]+[KkMm\u0623\u0644\u0641]*$/.test(p.trim())) || '';
      out.push({ id: lk.contentId, title: md?.title?.content || '', views: vw ? (/\D{3,}/.test(vw) ? vw : vw + ' مشاهدة') : '', date: parts.find(p => p !== vw) || '' });
    }
    for (const k in o) if (k !== 'videoRenderer' && k !== 'lockupViewModel') collect(o[k], out, depth + 1);
  }
  /* ytInitialData: شكل الحاسوب (JSON) أو شكل الهاتف (نص مُهرَّب \x7b…) */
  function initialData(html) {
    let m = html.match(/ytInitialData\s*=\s*(\{.+?\});\s*<\/script>/s) || html.match(/ytInitialData"\]\s*=\s*(\{.+?\});/s);
    if (m) { try { return JSON.parse(m[1]); } catch {} }
    m = html.match(/ytInitialData\s*=\s*'((?:[^'\\]|\\.)+)'/s);
    if (m) { try { return JSON.parse(m[1].replace(/\\x([0-9a-fA-F]{2})/g, (_, h) => String.fromCharCode(parseInt(h, 16))).replace(/\\u([0-9a-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16))).replace(/\\(["\\/])/g, '$1')); } catch {} }
    return null;
  }
  function parsePage(html) {
    const d = initialData(html);
    const id = (html.match(/"externalId":"(UC[\w-]{22})"/) || html.match(/<link rel="canonical" href="https:\/\/www\.youtube\.com\/channel\/(UC[\w-]{22})"/) || html.match(/channel_id=(UC[\w-]{22})/) || html.match(/"browseId":"(UC[\w-]{22})"/) || html.match(/\b(UC[\w-]{22})\b/) || [])[1] || '';
    if (!d) return { items: [], name: (html.match(/<meta property="og:title" content="([^"]+)"/) || [])[1] || '', id };
    const out = []; collect(d.contents || d, out);
    const name = d.metadata?.channelMetadataRenderer?.title || d.header?.pageHeaderRenderer?.pageTitle || '';
    return { items: out, name, id: d.metadata?.channelMetadataRenderer?.externalId || id };
  }
  /* خلاصة RSS الرسمية للقناة (آخر 15 فيديو مع المشاهدات) */
  function parseRss(xmlText) {
    const d = new DOMParser().parseFromString(xmlText, 'text/xml');
    const name = d.querySelector('feed > title')?.textContent || '';
    const items = [...d.getElementsByTagName('entry')].map(e => ({
      id: e.getElementsByTagName('yt:videoId')[0]?.textContent || '', title: e.getElementsByTagName('title')[0]?.textContent || '',
      views: (e.getElementsByTagName('media:statistics')[0]?.getAttribute('views') || '') + (e.getElementsByTagName('media:statistics')[0] ? ' مشاهدة' : ''),
      date: (e.getElementsByTagName('published')[0]?.textContent || '').slice(0, 10),
    })).filter(x => x.title);
    return { items, name };
  }
  /* YouTube Data API (مفتاح اختياري): أدق وأشمل ويعمل في كل الأجهزة */
  async function viaApi(handle, key) {
    const g = async u => { const r = await fetch(u); const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error('YouTube API: ' + (j.error?.message || r.status)); return j; };
    const h = String(handle).trim(), base = 'https://www.googleapis.com/youtube/v3/';
    const q = /^UC[\w-]{22}$/.test(h) ? `id=${h}` : (h.match(/channel\/(UC[\w-]{22})/) ? `id=${h.match(/channel\/(UC[\w-]{22})/)[1]}` : `forHandle=${encodeURIComponent(h.replace(/^.*\/(@[^/?]+).*$/, '$1').replace(/^@?/, '@'))}`);
    const ch = (await g(`${base}channels?part=contentDetails,snippet&${q}&key=${key}`)).items?.[0];
    if (!ch) throw new Error('لم يجد YouTube هذه القناة');
    const pl = ch.contentDetails.relatedPlaylists.uploads, ids = [];
    let tok = '';
    for (let i = 0; i < 3; i++) { const j = await g(`${base}playlistItems?part=contentDetails&maxResults=50&playlistId=${pl}&key=${key}${tok ? '&pageToken=' + tok : ''}`); ids.push(...j.items.map(x => x.contentDetails.videoId)); tok = j.nextPageToken; if (!tok) break; }
    const items = [];
    for (let i = 0; i < ids.length; i += 50) { const j = await g(`${base}videos?part=snippet,statistics&id=${ids.slice(i, i + 50).join(',')}&key=${key}`); j.items.forEach(v => items.push({ id: v.id, title: v.snippet.title, views: (+v.statistics.viewCount || 0).toLocaleString('ar') + ' مشاهدة', date: v.snippet.publishedAt.slice(0, 10) })); }
    return { name: ch.snippet.title, items };
  }
  async function fetchChannel(handle) {
    const base = channelUrl(handle); if (!base) throw new Error('اكتب اسم قناتك مثل @fadifarm');
    const key = Settings.get().keys.youtube?.trim(), errs = [];
    if (key) { try { const r = await viaApi(handle, key); if (r.items.length) return { ...r, handle, at: Date.now(), items: r.items.slice(0, 150) }; } catch (e) { errs.push(e.message); } }
    const seen = new Set(), items = []; let name = '', cid = (base.match(/channel\/(UC[\w-]{22})/) || [])[1] || '';
    const add = list => list.forEach(v => { if (v.title && v.id && !seen.has(v.id)) { seen.add(v.id); items.push(v); } });
    if (NATIVE || DESKTOP) {
      const pages = await Promise.allSettled([getText(base + '/videos?hl=ar&persist_hl=1'), getText(base + '/shorts?hl=ar')]);
      pages.forEach(p => { if (p.status !== 'fulfilled') { errs.push(String(p.reason?.message || p.reason)); return; } const r = parsePage(p.value); name ||= r.name; cid ||= r.id; add(r.items); });
      if (cid) { try { const r = parseRss(await getText(`https://www.youtube.com/feeds/videos.xml?channel_id=${cid}`)); name ||= r.name; add(r.items); } catch (e) { errs.push('RSS ' + e.message); } }
    } else {
      // الآيفون والحاسوب: نسخة RSS تُحدّث كل ساعة على موقع التطبيق
      const h = decodeURI(base.split('youtube.com/')[1] || '');
      try { const r = await fetch(`data/feeds/${Trends.fid('yt:' + h.toLowerCase())}.txt`, { cache: 'no-cache' }); if (r.ok) { const x = parseRss(await r.text()); name ||= x.name; add(x.items); } } catch {}
    }
    if (!items.length) throw new Error(NATIVE ? `لم أستطع قراءة القناة${errs.length ? ' (' + errs[0].slice(0, 60) + ')' : ''}. أضف مفتاح YouTube Data API في الإعدادات (يعمل دائماً)، أو الصق العناوين يدوياً` : 'في الآيفون والحاسوب أضف مفتاح YouTube Data API في الإعدادات، أو الصق العناوين يدوياً');
    return { name, handle, at: Date.now(), items: items.slice(0, 150) };
  }
  async function loadVideos() {
    if (st.videos == null) { try { st.videos = (await Store.get('yt-videos')) || null; } catch { st.videos = null; } }
    return st.videos;
  }
  async function link() {
    const h = $('#ytHandle').value.trim(); Settings.set({ ytHandle: h });
    const b = $('#ytLink'); b.disabled = true; b.textContent = 'يقرأ القناة…';
    try {
      st.videos = await fetchChannel(h);
      await Store.set('yt-videos', st.videos).catch(() => {});
      toast(`رُبطت القناة: ${st.videos.items.length} فيديو`);
      ideasFromCache(true);
    } catch (e) { toast(e.message, 'err', 7000); }
    finally { b.disabled = false; b.textContent = 'اربط / حدّث'; showChannel(); }
  }
  function manualTitles() { return ($('#ytManual')?.value || '').split('\n').map(x => x.trim()).filter(Boolean); }
  function pastTitles() {
    const v = st.videos?.items || [];
    return [...v.map(x => x.title + (x.views ? ` (${x.views})` : '')), ...manualTitles()].slice(0, 120);
  }
  function showChannel() {
    const el = $('#ytState'); if (!el) return;
    const v = st.videos;
    el.innerHTML = v ? `<b>${esc(v.name || v.handle)}</b> · ${v.items.length} فيديو · آخر تحديث ${new Date(v.at).toLocaleDateString('ar')}` : 'لم تُربط قناة بعد. الأفكار ستكون عامة.';
  }

  /* ---------- الأفكار ---------- */
  async function suggest() {
    if (!LLM.available().length) return toast('أضف مفتاح Gemini (أو Groq) في الإعدادات أولاً', 'err');
    const b = $('#idGo'), cat = st.cat || Channel.cur.ideaDefault || 'all', cats = Channel.cur.ideaCats || {};
    b.disabled = true; b.textContent = 'يفكّر…';
    $('#idList').innerHTML = '<p class="hint">Gemini يحلل قناتك ويجهز أفكاراً جديدة…</p>';
    const past = pastTitles();
    const c = Channel.cur, focus = (c.ideaFocus || {})[cat] || '';
    const trends = (() => { try { return (JSON.parse(localStorage.getItem(Channel.key('ff.trends')) || 'null')?.items || []).slice(0, 25).map(x => x.title); } catch { return []; } })();
    try {
      const raw = await LLM.text(
`You are a senior YouTube content strategist for ${c.niche}.
${past.length ? `The channel already published these videos (with views when known):\n${past.map(t => '- ' + t).join('\n')}\n\nAnalyze what works best (topics, angles, title style, what got most views) and NEVER repeat or closely copy any of these topics.` : 'The channel is new.'}
${c.custom ? `CHANNEL NICHE (strict): ${c.niche}.${c.audience ? ' Audience: ' + c.audience + '.' : ''}${c.style ? ' Video style: ' + c.style + '.' : ''}${c.topics?.length ? ' Main topics: ' + c.topics.join('، ') + '.' : ''} EVERY idea must be inside this exact niche and style; never suggest ideas from another field (e.g. no stories for a health channel unless the channel tells stories). Search the web for what people in this niche search and talk about now.` : ''}
${c.id === 'majra' ? `Use Google Search to find what is happening NOW (this week) so ideas are fresh and accurate.${trends.length ? '\nCurrent trending searches: ' + trends.join(' | ') : ''}` : ''}
Focus category: ${cat === 'all' ? 'anything that fits the channel' : cats[cat]}. ${focus}
Give 12 NEW, highly clickable, strong video ideas this audience will love. Mix angles: shocking facts, explainers, comparisons, "why does X happen", human stories, numbers that surprise, myths vs truth.
For each idea: "title" (catchy Arabic YouTube title in ${Channel.dialect.who} dialect, max 70 chars), "hook" (opening line in ${Channel.dialect.who} dialect), "angle" (1 Arabic sentence: what the video covers), "why" (1 short Arabic reason it will perform).
Answer ONLY with JSON, no other text: {"insight": "2 short Arabic sentences about what works on this channel", "ideas": [{"title":"","hook":"","angle":"","why":""}]}`, { search: c.id === 'majra' || !!c.custom, temperature: 0.9 });
      const j = raw.replace(/^[^{]*/, '').replace(/[^}]*$/, '');
      let r; try { r = JSON.parse(j); } catch { throw new Error('ردّ Gemini غير منسّق، اضغط مرة أخرى'); }
      st.ideas = (r.ideas || []).filter(x => x.title).slice(0, 12);
      await Store.set('ideas', { cat, at: Date.now(), insight: r.insight || '', ideas: st.ideas }).catch(() => {});
      renderIdeas(r.insight);
    } catch (e) { $('#idList').innerHTML = `<p class="hint err">${esc(e.message)}</p>`; }
    finally { b.disabled = false; b.textContent = 'اقترح أفكاراً جديدة'; }
  }
  function renderIdeas(insight) {
    const box = $('#idList'); if (!box) return;
    box.innerHTML = (insight ? `<p class="idea-insight">${esc(insight)}</p>` : '') + st.ideas.map((x, i) => `
      <div class="idea"><div class="idea-body"><b>${esc(x.title)}</b><span>${esc(x.angle || '')}</span>${x.why ? `<small>${esc(x.why)}</small>` : ''}</div>
      <button class="btn primary sm" data-idea="${i}" type="button">اكتب السكريبت</button></div>`).join('');
  }
  async function ideasFromCache(force) {
    try { const c = await Store.get('ideas'); if (c?.ideas?.length && !force) { st.ideas = c.ideas; st.cat = c.cat; renderIdeas(c.insight); markCat(); } } catch {}
  }
  function markCat() { $$('#idCat button').forEach(b => b.classList.toggle('on', b.dataset.c === (st.cat || Channel.cur.ideaDefault))); }

  /* ---------- كتابة السكريبت ---------- */
  /* السكريبتات الطويلة (حتى ساعة): نرسل البداية وآخر جزء فقط حتى لا يكبر الطلب */
  function prevCut(prev) {
    const w = prev.split(/\s+/);
    if (w.length <= 2600) return { text: prev, cut: false };
    return { text: w.slice(0, 300).join(' ') + '\n[…]\n' + w.slice(-1900).join(' '), cut: true };
  }
  function promptFor(req, mins, notes, part = 1, parts = 1, prev = '', search = false) {
    const c = Channel.cur, d = Channel.dialect, words = Math.round(mins * 140), pw = Math.round(words / parts);
    // سكريبت طويل = فيديو واحد متصل؛ يُكتب على دفعات لأسباب تقنية فقط ولا يجوز أن يشعر المشاهد بذلك
    const ONE = `This is ONE single continuous video. The text is generated in ${parts} chunks only for technical reasons, the viewer must NEVER notice it: never mention parts, chunks, episodes, "the next part", "in the next video", "we will continue later", "to be continued", and never summarize or say goodbye before the very end.`;
    const partRule = parts === 1 ? `Write the COMPLETE script now (about ${words} words).`
      : part === 1 ? `${ONE} Write ONLY the first chunk now (about ${pw} words): the title line, the HOOK, the SUBSCRIBE & LIKE request, then the beginning of the main content. Stop in the middle of the flow (the text continues right after). Do NOT write any ending, recap, goodbye or "see you" phrase.`
      : `${ONE}\nHere is the script written so far${prevCut(prev).cut ? ' (beginning and the most recent text; the middle is omitted)' : ''}:\n<<<\n${prevCut(prev).text}\n>>>\nContinue it seamlessly from the exact last sentence, as if it were the same paragraph (chunk ${part} of ${parts}, about ${pw} words)${part === parts ? ': finish the main content, then write the ENDING' : ' of the main content. Do NOT write any ending, recap or goodbye'}. Do not repeat anything already said, do not greet again, do not re-introduce the narrator, do not write a title line, output only the new text.`;
    return `You are the head scriptwriter of ${c.niche} (channel name: "${c.name}").
Narrator style: ${Channel.voice}.
${Channel.persona($('#smPersona')?.value, $('#smName')?.value.trim()) ? 'NARRATOR IDENTITY (important): ' + Channel.persona($('#smPersona').value, $('#smName').value.trim()) + ' Keep this identity and point of view through the whole script, and make the self-introduction come right after the hook.' : ''}${Settings.get().noName ? '\nNO NAMES: never mention any personal name for the narrator anywhere in the script.' : ''}
Voiceover script for a YouTube video about: "${req.topic}" — total length about ${words} words (about ${mins} minutes of narration).
TOPIC FIDELITY (most important rule): the whole video is ONLY about exactly this topic: "${req.topic}". ${search ? 'Search the web for this exact topic using its exact names, places and dates. ' : ''}Keep the exact same event, place, country and people named in the topic. Never replace it with a different or similar event, and never move it to Algeria or another country unless the topic itself says so. The channel description is only about style, not about the subject.
${req.details ? 'Background / facts to use:\n' + req.details + '\n' : ''}${search ? 'First search the web for the latest accurate facts, numbers and context about this exact topic, then write. Use only verified facts from your search; if something is unclear say so.\n' : ''}${notes ? 'Extra instructions from the creator: ' + notes + '\n' : ''}
${c.id === 'farm' ? 'CONTENT SCOPE: the dialect and the narrator nationality only change the spoken language style. The content must stay GENERAL and useful for viewers in every country: do not focus on the animals, markets, prices, climate or laws of one specific country unless the topic itself asks for it.\n' : ''}${d.who === 'Arab' ? 'LANGUAGE (strict): Modern Standard Arabic (الفصحى) ONLY — simple, lively, clear fusha for every single sentence. Do NOT use ANY dialect words at all (no Egyptian like دلوقتي، إزاي، كده، بص، عشان، يا جماعة؛ no Gulf, Levantine or Maghrebi words). Address the viewer in fusha (e.g. "أيها المشاهد"، "هل تعلم"، "تابعوا معنا").' : `LANGUAGE (strict): ${d.lang} ONLY — natural spoken ${d.who} Arabic exactly how people from ${d.nat === 'عربي' ? 'the Arab world' : 'this country'} really talk, never formal fusha and never another dialect (e.g. do not use Egyptian words unless the chosen dialect is Egyptian). Write every sentence in this dialect.`}

MANDATORY STRUCTURE, in this exact order:
1) HOOK (2-4 sentences): open with the most shocking/curious point or a strong question that makes leaving impossible.
2) SUBSCRIBE & LIKE (1-2 sentences, right after the hook and BEFORE the main topic): warmly ask the viewer, in the same dialect, to subscribe to the channel, press like and turn on the bell before starting — vary the wording, friendly, never begging.
3) MAIN CONTENT: ${c.scriptRules}. Build it as one continuous journey with small curiosity hooks between ideas (never between "parts" or "episodes"), concrete examples and vivid images.
4) ENDING: a quick recap, one question for the viewer to answer in the comments, and a short warm goodbye mentioning "${c.name}".

STYLE: short spoken sentences, each ending with . or ؟ or !; rhetorical questions to the viewer; emotional rhythm (surprise, humor, empathy); simple words.
FORBIDDEN: headings, section labels or numbers like "1)", stage directions, brackets, emojis, markdown, hashtags, English words unless unavoidable.

${partRule}
${part === 1 ? 'Output format: first line exactly "العنوان: <catchy Arabic YouTube title in the same dialect, max 70 chars>", then one empty line, then ONLY the script text.' : 'Output ONLY the continuation text.'}`;
  }

  function fillPersonas() {
    const ids = Channel.cur.personas || ['none'], sel = $('#smPersona'), cur = Settings.get().persona;
    sel.innerHTML = ids.map(i => `<option value="${i}">${Channel.PERSONAS[i].name}</option>`).join('');
    sel.value = ids.includes(cur) ? cur : ids[0];
    $('#smName').value = Settings.get().narratorName || 'فادي';
  }
  function fillDialects() {
    fillPersonas();
    const sel = $('#smDialect'), ids = Channel.cur.dialects || ['eg'];
    sel.innerHTML = ids.map(i => `<option value="${i}">${Channel.DIALECTS[i].name}</option>`).join('');
    sel.value = Channel.dialectId; $('#smDialectWrap').hidden = ids.length < 2;
  }

  function open(req) {
    st.req = req;
    const m = $('#scriptModal');
    $('#smTopic').textContent = req.topic;
    $('#smNotes').value = '';
    $('#smLen').value = String(Settings.get().scriptMins || 3);
    if (!$('#smLen').value) $('#smLen').value = '3';
    fillDialects();
    $('#smSearch').checked = req.search === false ? false : Settings.get().scriptSearch !== false;
    st.sources = []; showSources();
    $('#smText').value = ''; $('#smTitle').value = '';
    m.hidden = false; document.body.classList.add('modal-open');
    $('#smAgain').textContent = 'اكتب السكريبت';
    status('اختر المدة واللهجة والمقدّم، ثم اضغط «اكتب السكريبت»');
    if (Settings.get().scriptAuto !== false && !req._draft) write();   // الإعدادات مختارة مسبقاً من صفحة المشروع
  }
  /* إعدادات السكريبت في صفحة المشروع (قبل اختيار الموضوع) */
  function fillPrefs() {
    const S = Settings.get(), ds = Channel.cur.dialects || ['eg'], ps = Channel.cur.personas || ['none'];
    $('#psDialect').innerHTML = ds.map(i => `<option value="${i}">${Channel.DIALECTS[i].name}</option>`).join(''); $('#psDialect').value = Channel.dialectId;
    $('#psPersona').innerHTML = ps.map(i => `<option value="${i}">${Channel.PERSONAS[i].name}</option>`).join(''); $('#psPersona').value = ps.includes(S.persona) ? S.persona : ps[0];
    $('#psName').value = S.narratorName || 'فادي'; $('#psLen').value = String(S.scriptMins || 3); if (!$('#psLen').value) $('#psLen').value = '3';
    $('#psSearch').checked = S.scriptSearch !== false; $('#psAuto').checked = S.scriptAuto !== false;
  }
  function showSources() {
    const list = [...new Map((st.sources || []).filter(x => x.url).map(x => [x.url, x])).values()].slice(0, 12);
    $('#smSourcesBox').hidden = !list.length;
    $('#smSources').innerHTML = list.map(x => `<li><a href="${esc(x.url)}" target="_blank" rel="noopener">${esc(x.title || x.url)}</a></li>`).join('');
  }
  function close() { st.ctl?.abort(); $('#scriptModal').hidden = true; document.body.classList.remove('modal-open'); }

  const split = raw => {
    let title = '', body = raw.replace(/\*\*/g, '').replace(/^#+\s*/gm, '');
    const m = body.match(/^\s*العنوان\s*[:：]\s*(.+)\s*\n/);
    if (m) { title = m[1].trim().replace(/^["«]|["»]$/g, ''); body = body.slice(m[0].length); }
    else if (/^\s*العنوان/.test(body) && !body.includes('\n')) body = '';
    return { title, body };
  };
  const tidy = body => body.split('\n').map(l => l.trim()).filter(l => l && !/^(\d+[).]|الخطاف|المقدمة|الخاتمة|المحتوى|الجزء\s*\S+)\s*[:：]?$/.test(l) && !/^(<<<|>>>)$/.test(l)).join('\n');

  async function write() {
    if (!st.req) return;
    if (st.busy) { st.ctl?.abort(); st.pending = true; return; }
    if (!LLM.available().length) { status('أضف مفتاح Gemini (أو Groq) في الإعدادات لكتابة السكريبت', true); return; }
    const mins = +$('#smLen').value || 3; Settings.set({ scriptMins: mins, dialect: $('#smDialect').value || Settings.get().dialect, persona: $('#smPersona').value, narratorName: $('#smName').value.trim() });
    const parts = mins <= 8 ? 1 : Math.ceil(mins / 6);      // حتى 3 ساعات = 30 دفعة
    st.busy = true; st.ctl = new AbortController();
    $('#smUse').disabled = true; $('#smAgain').disabled = true;
    $('#smText').value = ''; $('#smBody').classList.add('loading');
    let note = '', part = 1;
    const t0 = Date.now(), tick = setInterval(() => status(`${note || ($('#smText').value ? 'يكتب…' : `يجهّز السكريبت باللهجة ${Channel.dialect.name}…`)}${parts > 1 ? ` (الجزء ${part} من ${parts})` : ''} ${Math.round((Date.now() - t0) / 1000)} ث`), 500);
    let done = '', title = '';
    try {
      for (part = 1; part <= parts; part++) {
        let raw = null;
        for (let tr = 0; tr < 3 && raw == null; tr++) {          // كل دفعة تُعاد حتى 3 مرات قبل التوقف (للسكريبتات الطويلة جداً)
          try {
        raw = await LLM.text(promptFor(st.req, mins, $('#smNotes').value.trim(), part, parts, done, $('#smSearch').checked && part === 1), {
          search: $('#smSearch').checked && part === 1, signal: st.ctl.signal,
          onSources: src => { st.sources = [...(st.sources || []), ...src]; showSources(); },
          onNote: n => { note = n; },
          onText: t => { const r = part === 1 ? split(t) : { title: '', body: t }; if (r.title) $('#smTitle').value = r.title; const ta = $('#smText'); ta.value = (done ? done + '\n' : '') + r.body.trimStart(); ta.scrollTop = ta.scrollHeight; $('#smBody').classList.remove('loading'); note = ''; },
        });
          } catch (e) { if (e.name === 'AbortError' || st.ctl.signal.aborted || tr === 2) throw e; note = `إعادة المحاولة للدفعة ${part}…`; await new Promise(x => setTimeout(x, 4000 * (tr + 1))); }
        }
        const r = part === 1 ? split(raw) : { title: '', body: raw };
        if (r.title) title = r.title;
        // احتياط: نحذف أي جملة تذكر «الجزء القادم» أو «نكمل في الحلقة الجاية» قبل النهاية
        if (parts > 1 && part < parts) r.body = r.body.split(/(?<=[.!؟?…])\s+/).filter(x => !/(الجزء|الحلقة|البارت)\s*(الجاي|الجاية|القادم|القادمة|التالي|التالية|الثاني|الجديد)|نكمل(ها)?\s*(في|ف)\s*(الجزء|الحلقة)|انتظرونا|إلى اللقاء|الى اللقاء|نشوفكم/.test(x)).join(' ');
        done = (done ? done + '\n' : '') + tidy(r.body);
        $('#smText').value = done;
        if (parts > 1) { $('#smTitle').value = title || $('#smTitle').value; saveDraft(); }   // كل جزء يُحفظ فوراً
      }
      $('#smTitle').value = title || $('#smTitle').value || st.req.topic;
      const words = done.split(/\s+/).length;
      status(`جاهز: ${words} كلمة ≈ ${Math.max(1, Math.round(words / 140))} دقيقة. يمكنك تعديله قبل الاستعمال.`);
      $('#smUse').disabled = false; $('#smAgain').textContent = 'أعد الكتابة';
      saveDraft();
    } catch (e) {
      if (e.name !== 'AbortError' && !st.ctl.signal.aborted) {
        status((done ? `توقف عند الجزء ${part} من ${parts} (ما كُتب محفوظ ويمكن استعماله). ` : '') + (e.message || 'تعذّرت الكتابة'), true);
        if (done) $('#smUse').disabled = false;
      }
    } finally {
      clearInterval(tick); st.busy = false; $('#smAgain').disabled = false; $('#smBody').classList.remove('loading');
      if (st.pending && !$('#scriptModal').hidden) { st.pending = false; setTimeout(write, 0); } else st.pending = false;
    }
  }
  /* آخر سكريبت يبقى محفوظاً بعد الخروج من التطبيق */
  function saveDraft() { Store.set('script-draft', { req: st.req, title: $('#smTitle').value, text: $('#smText').value, sources: st.sources || [], at: Date.now() }).catch(() => {}); updateDraftBtn(); }
  async function updateDraftBtn() { const d = await Store.get('script-draft').catch(() => null), b = $('#qDraft'); if (b) { b.hidden = !d?.text; if (d?.text) b.textContent = 'افتح آخر سكريبت: ' + String(d.req?.topic || '').slice(0, 30); } }
  async function openDraft() {
    const d = await Store.get('script-draft').catch(() => null); if (!d?.text) return;
    open({ ...(d.req || { topic: d.title }), _draft: true });
    $('#smTitle').value = d.title || ''; $('#smText').value = d.text; st.sources = d.sources || []; showSources();
    $('#smUse').disabled = false; $('#smAgain').textContent = 'أعد الكتابة'; status('آخر سكريبت محفوظ. عدّله أو استعمله');
  }
  function status(t, err) { const s = $('#smStatus'); s.textContent = t; s.classList.toggle('err', !!err); }

  async function use() {
    const text = $('#smText').value.trim(); if (!text) return;
    const ta = $('#ttsText');
    if (ta.value.trim() && ta.value.trim() !== text && !(await confirmBox('استبدال النص الموجود في المشروع بهذا السكريبت؟', 'استبدل'))) return;
    ta.value = text; ta.dispatchEvent(new Event('input', { bubbles: true }));
    const title = $('#smTitle').value.trim();
    if (title) { App.projName = title.slice(0, 80); $('#projName').value = App.projName; App.nameFor = '@script:' + text.slice(0, 120); save(); }
    close();
    if (App.view !== 'project') go('project');
    setTimeout(() => { ta.scrollIntoView({ behavior: 'smooth', block: 'center' }); ta.classList.add('flash'); setTimeout(() => ta.classList.remove('flash'), 1600); }, 200);
    toast('وُضع السكريبت في المشروع. الآن اصنع التعليق الصوتي', '', 6000);
  }

  /* ---------- الواجهة ---------- */
  async function enter() {
    updateDraftBtn(); fillPrefs();
    const p = $('#ideasPanel'); if (!p) return;
    p.hidden = !Channel.cur.ideaCats;
    if (p.hidden) return;
    if (!$('#ytHandle').value) $('#ytHandle').value = Settings.get().ytHandle ?? Channel.cur.yt ?? '';
    $('#ytHandle').placeholder = Channel.id === 'farm' ? '@fadifarm' : '@majra';
    await loadVideos(); showChannel();
    if (!st.ideas.length) ideasFromCache();
  }
  function bind() {
    $('#smClose').onclick = close;
    $('#scriptModal').addEventListener('click', e => { if (e.target.id === 'scriptModal') close(); });
    $('#smAgain').onclick = write;
    const q = () => { const t = $('#qTopic').value.trim(); if (!t) return toast('اكتب الموضوع الذي تريد البحث عنه', 'err'); open({ topic: t, search: true }); };
    $('#qGo').onclick = q;
    $('#qTopic').addEventListener('keydown', e => { if (e.key === 'Enter') q(); });
    $('#smDialect').onchange = e => { Settings.set({ dialect: e.target.value }); if (typeof fillVoices === 'function') fillVoices(); };
    $('#smPersona').onchange = e => Settings.set({ persona: e.target.value });
    $('#smName').addEventListener('input', e => Settings.set({ narratorName: e.target.value.trim() }));
    $('#smUse').onclick = use;
    $('#smText').addEventListener('input', () => { clearTimeout(saveDraft.t); saveDraft.t = setTimeout(saveDraft, 600); });
    $('#smTitle').addEventListener('input', () => { clearTimeout(saveDraft.t); saveDraft.t = setTimeout(saveDraft, 600); });
    $('#qDraft').onclick = openDraft;
    $('#psDialect').onchange = e => { Settings.set({ dialect: e.target.value }); if (typeof fillVoices === 'function') fillVoices(); };
    $('#psPersona').onchange = e => Settings.set({ persona: e.target.value });
    $('#psName').addEventListener('input', e => Settings.set({ narratorName: e.target.value.trim() }));
    const noName = v => { Settings.set({ noName: v }); ['#smNoName', '#psNoName'].forEach(x => { if ($(x)) $(x).checked = v; }); ['#smName', '#psName'].forEach(x => { if ($(x)) $(x).disabled = v; }); };
    $('#smNoName').onchange = e => noName(e.target.checked);
    $('#psNoName').onchange = e => noName(e.target.checked);
    noName(Settings.get().noName === true);
    $('#psLen').onchange = e => Settings.set({ scriptMins: +e.target.value });
    $('#psSearch').onchange = e => Settings.set({ scriptSearch: e.target.checked });
    $('#psAuto').onchange = e => Settings.set({ scriptAuto: e.target.checked });
    $('#smCopy').onclick = async () => { if (await copyText($('#smText').value)) toast('نُسخ السكريبت'); };
    const cats = Channel.cur.ideaCats;
    if (cats && $('#idCat')) {
      $('#idCat').innerHTML = Object.entries(cats).map(([k, v]) => `<button type="button" data-c="${k}">${v}</button>`).join('');
      markCat();
      $('#idCat').onclick = e => { const b = e.target.closest('[data-c]'); if (!b) return; st.cat = b.dataset.c; markCat(); };
      $('#idGo').onclick = suggest;
      $('#ytLink').onclick = link;
      $('#idList').onclick = e => { const b = e.target.closest('[data-idea]'); if (!b) return; const x = st.ideas[+b.dataset.idea]; open({ topic: x.title, details: [x.angle, x.hook && 'Suggested opening line: ' + x.hook].filter(Boolean).join('\n') }); };
      $('#idOwn').onclick = () => { const t = $('#idTopic').value.trim(); if (!t) return toast('اكتب موضوع الفيديو أولاً', 'err'); open({ topic: t, search: true }); };
    }
  }
  return { open, bind, enter, fetchChannel, parsePage, parseRss };
})();
