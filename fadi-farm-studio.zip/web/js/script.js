/* Fadi — كاتب السكريبت + أفكار القناة:
   - يربط قناة يوتيوب (بدون مفتاح) ليقرأ عناوين الفيديوهات ويقترح أفكاراً جديدة غير مكررة
   - يكتب سكريبت كامل بالعامية المصرية بالبنية: خطّاف ← اشتراك ولايك ← المحتوى ← خاتمة */
'use strict';

const Script = (() => {
  const st = { req: null, busy: false, ctl: null, ideas: [], videos: null, cat: null };

  /* ---------- الشبكة ---------- */
  async function getText(url) {
    if (NATIVE) {
      const r = await capCall('FadiNative', 'fetchText', { url, headers: { 'Accept-Language': 'ar,en;q=0.8' } });
      if (r && r.status < 400) return r.data;
      throw new Error('HTTP ' + (r?.status || '?'));
    }
    const r = await fetch(url); if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.text();
  }

  /* ---------- قناة يوتيوب ---------- */
  function channelUrl(h) {
    h = String(h || '').trim(); if (!h) return '';
    if (/^https?:\/\//.test(h)) return h.replace(/\/(videos|shorts|featured|streams)\/?$/, '').replace(/\/$/, '');
    if (/^UC[\w-]{20,}$/.test(h)) return 'https://www.youtube.com/channel/' + h;
    return 'https://www.youtube.com/' + (h.startsWith('@') ? h : '@' + h);
  }
  const txt = t => t ? (t.simpleText || t.content || (t.runs || []).map(r => r.text).join('') || '') : '';
  function collect(o, out, depth = 0) {
    if (!o || typeof o !== 'object' || depth > 40) return;
    if (Array.isArray(o)) { o.forEach(x => collect(x, out, depth + 1)); return; }
    const v = o.videoRenderer || o.gridVideoRenderer;
    if (v?.videoId) out.push({ id: v.videoId, title: txt(v.title), views: txt(v.viewCountText) || txt(v.shortViewCountText), date: txt(v.publishedTimeText) });
    const r = o.reelItemRenderer;
    if (r?.videoId) out.push({ id: r.videoId, title: txt(r.headline), views: txt(r.viewCountText), date: '', short: true });
    const sl = o.shortsLockupViewModel;
    if (sl) { const id = (sl.entityId || '').replace(/^shorts-shelf-item-/, ''); out.push({ id, title: sl.overlayMetadata?.primaryText?.content || '', views: sl.overlayMetadata?.secondaryText?.content || '', date: '', short: true }); }
    const lk = o.lockupViewModel;
    if (lk?.contentId) {
      const md = lk.metadata?.lockupMetadataViewModel, rows = md?.metadata?.contentMetadataViewModel?.metadataRows || [];
      const parts = rows.flatMap(rw => (rw.metadataParts || []).map(p => p.text?.content || '')).filter(Boolean);
      out.push({ id: lk.contentId, title: md?.title?.content || '', views: parts.find(p => /view|مشاهد/i.test(p)) || '', date: parts.find(p => /ago|منذ|قبل/i.test(p)) || '' });
    }
    for (const k in o) if (k !== 'videoRenderer' && k !== 'lockupViewModel') collect(o[k], out, depth + 1);
  }
  function parsePage(html) {
    const m = html.match(/ytInitialData\s*=\s*(\{.+?\});\s*<\/script>/s) || html.match(/ytInitialData"\]\s*=\s*(\{.+?\});/s);
    if (!m) return { items: [], name: '' };
    let d; try { d = JSON.parse(m[1]); } catch { return { items: [], name: '' }; }
    const out = []; collect(d.contents || d, out);
    const name = d.metadata?.channelMetadataRenderer?.title || d.header?.pageHeaderRenderer?.pageTitle || '';
    return { items: out, name };
  }
  async function fetchChannel(handle) {
    const base = channelUrl(handle); if (!base) throw new Error('اكتب اسم قناتك مثل @fadifarm');
    const pages = await Promise.allSettled([getText(base + '/videos?hl=ar'), getText(base + '/shorts?hl=ar')]);
    const seen = new Set(), items = []; let name = '';
    pages.forEach(p => { if (p.status !== 'fulfilled') return; const r = parsePage(p.value); name ||= r.name; r.items.forEach(v => { if (v.title && v.id && !seen.has(v.id)) { seen.add(v.id); items.push(v); } }); });
    if (!items.length) throw new Error(NATIVE ? 'لم أجد فيديوهات. تأكد من اسم القناة (مثل @fadifarm)' : 'ربط القناة يعمل داخل تطبيق الهاتف. في المتصفح الصق العناوين يدوياً');
    return { name, handle, at: Date.now(), items: items.slice(0, 120) };
  }
  async function loadVideos() {
    if (st.videos == null) { try { st.videos = (await Store.get('yt-videos')) || null; } catch { st.videos = null; } }
    return st.videos;
  }
  async function link() {
    const h = $('#ytHandle').value.trim(); Settings.set({ ytHandle: h });
    const b = $('#ytLink'); b.disabled = true; b.textContent = 'يقرأ القناة…';
    try {
      st.videos = await fetchChannel(h);
      await Store.set('yt-videos', st.videos).catch(() => {});
      toast(`رُبطت القناة: ${st.videos.items.length} فيديو`);
      ideasFromCache(true);
    } catch (e) { toast(e.message, 'err', 7000); }
    finally { b.disabled = false; b.textContent = 'اربط / حدّث'; showChannel(); }
  }
  function manualTitles() { return ($('#ytManual')?.value || '').split('\n').map(x => x.trim()).filter(Boolean); }
  function pastTitles() {
    const v = st.videos?.items || [];
    return [...v.map(x => x.title + (x.views ? ` (${x.views})` : '')), ...manualTitles()].slice(0, 120);
  }
  function showChannel() {
    const el = $('#ytState'); if (!el) return;
    const v = st.videos;
    el.innerHTML = v ? `<b>${esc(v.name || v.handle)}</b> · ${v.items.length} فيديو · آخر تحديث ${new Date(v.at).toLocaleDateString('ar')}` : 'لم تُربط قناة بعد. الأفكار ستكون عامة.';
  }

  /* ---------- الأفكار ---------- */
  async function suggest() {
    if (!Settings.get().keys.gemini) return toast('أضف مفتاح Gemini في الإعدادات أولاً', 'err');
    const b = $('#idGo'), cat = st.cat || Channel.cur.ideaDefault || 'all', cats = Channel.cur.ideaCats || {};
    b.disabled = true; b.textContent = 'يفكّر…';
    $('#idList').innerHTML = '<p class="hint">Gemini يحلل قناتك ويجهز أفكاراً جديدة…</p>';
    const past = pastTitles();
    const c = Channel.cur, focus = (c.ideaFocus || {})[cat] || '';
    const trends = (() => { try { return (JSON.parse(localStorage.getItem(Channel.key('ff.trends')) || 'null')?.items || []).slice(0, 25).map(x => x.title); } catch { return []; } })();
    try {
      const raw = await AI.text(
`You are a senior YouTube content strategist for ${c.niche}.
${past.length ? `The channel already published these videos (with views when known):\n${past.map(t => '- ' + t).join('\n')}\n\nAnalyze what works best (topics, angles, title style, what got most views) and NEVER repeat or closely copy any of these topics.` : 'The channel is new.'}
${c.id === 'majra' ? `Use Google Search to find what is happening NOW (this week) so ideas are fresh and accurate.${trends.length ? '\nCurrent trending searches: ' + trends.join(' | ') : ''}` : ''}
Focus category: ${cat === 'all' ? 'anything that fits the channel' : cats[cat]}. ${focus}
Give 12 NEW, highly clickable, strong video ideas this audience will love. Mix angles: shocking facts, explainers, comparisons, "why does X happen", human stories, numbers that surprise, myths vs truth.
For each idea: "title" (catchy Arabic YouTube title in Egyptian dialect, max 70 chars), "hook" (opening line in Egyptian dialect), "angle" (1 Arabic sentence: what the video covers), "why" (1 short Arabic reason it will perform).
Answer ONLY with JSON, no other text: {"insight": "2 short Arabic sentences about what works on this channel", "ideas": [{"title":"","hook":"","angle":"","why":""}]}`, { search: c.id === 'majra', temperature: 0.9 });
      const j = raw.replace(/^[^{]*/, '').replace(/[^}]*$/, '');
      let r; try { r = JSON.parse(j); } catch { throw new Error('ردّ Gemini غير منسّق، اضغط مرة أخرى'); }
      st.ideas = (r.ideas || []).filter(x => x.title).slice(0, 12);
      await Store.set('ideas', { cat, at: Date.now(), insight: r.insight || '', ideas: st.ideas }).catch(() => {});
      renderIdeas(r.insight);
    } catch (e) { $('#idList').innerHTML = `<p class="hint err">${esc(e.message)}</p>`; }
    finally { b.disabled = false; b.textContent = 'اقترح أفكاراً جديدة'; }
  }
  function renderIdeas(insight) {
    const box = $('#idList'); if (!box) return;
    box.innerHTML = (insight ? `<p class="idea-insight">${esc(insight)}</p>` : '') + st.ideas.map((x, i) => `
      <div class="idea"><div class="idea-body"><b>${esc(x.title)}</b><span>${esc(x.angle || '')}</span>${x.why ? `<small>${esc(x.why)}</small>` : ''}</div>
      <button class="btn primary sm" data-idea="${i}" type="button">اكتب السكريبت</button></div>`).join('');
  }
  async function ideasFromCache(force) {
    try { const c = await Store.get('ideas'); if (c?.ideas?.length && !force) { st.ideas = c.ideas; st.cat = c.cat; renderIdeas(c.insight); markCat(); } } catch {}
  }
  function markCat() { $$('#idCat button').forEach(b => b.classList.toggle('on', b.dataset.c === (st.cat || Channel.cur.ideaDefault))); }

  /* ---------- كتابة السكريبت ---------- */
  function promptFor(req, mins, notes) {
    const c = Channel.cur;
    return `You are the head scriptwriter of ${c.niche} (channel name: "${c.name}").
Narrator persona: ${c.voice}.
Write the COMPLETE voiceover script for a YouTube video about: "${req.topic}".
${req.details ? 'Background / facts to use:\n' + req.details + '\n' : ''}${req.search ? 'Use Google Search to get the latest accurate facts about this topic before writing.\n' : ''}${notes ? 'Extra instructions from the creator: ' + notes + '\n' : ''}
Length: about ${Math.round(mins * 140)} words (about ${mins} minutes of narration).
Language: ${c.lang} ONLY — natural spoken Egyptian colloquial, exactly how Egyptians really talk, never formal fusha.

MANDATORY STRUCTURE, in this exact order:
1) HOOK (2-4 sentences): open with the most shocking/curious point or a strong question that makes leaving impossible.
2) SUBSCRIBE & LIKE (1-2 sentences, right after the hook and BEFORE the main topic): warmly ask the viewer to subscribe to the channel, press like and turn on the bell, e.g. "وقبل ما نبدأ، لو لسه مش مشترك في القناة اشترك دلوقتي، ودوس لايك وفعّل الجرس عشان يوصلك كل جديد." — vary the wording, friendly, never begging.
3) MAIN CONTENT: ${c.scriptRules}. Build it as a journey with mini-cliffhangers between parts ("بس استنى… الأغرب جاي"), concrete examples and vivid images.
4) ENDING: a quick recap, one question for the viewer to answer in the comments, and a short warm goodbye mentioning "${c.name}".

STYLE: short spoken sentences, each ending with . or ؟ or !; 3-5 rhetorical questions to the viewer; emotional rhythm (surprise, humor, empathy); simple words.
FORBIDDEN: headings, section labels or numbers like "1)", stage directions, brackets, emojis, markdown, hashtags, English words unless unavoidable.

Output format: first line exactly "العنوان: <catchy Arabic YouTube title, max 70 chars>", then one empty line, then ONLY the script text.`;
  }

  function open(req) {
    st.req = req;
    const m = $('#scriptModal');
    $('#smTopic').textContent = req.topic;
    $('#smNotes').value = '';
    $('#smLen').value = String(Settings.get().scriptMins || 3);
    $('#smText').value = ''; $('#smTitle').value = '';
    m.hidden = false; document.body.classList.add('modal-open');
    write();
  }
  function close() { st.ctl?.abort(); $('#scriptModal').hidden = true; document.body.classList.remove('modal-open'); }

  async function write() {
    if (!st.req || st.busy) return;
    if (!Settings.get().keys.gemini) { status('أضف مفتاح Gemini في الإعدادات لكتابة السكريبت', true); return; }
    const mins = +$('#smLen').value || 3; Settings.set({ scriptMins: mins });
    st.busy = true; st.ctl = new AbortController();
    $('#smUse').disabled = true; $('#smAgain').disabled = true;
    $('#smText').value = ''; $('#smBody').classList.add('loading');
    let note = '';
    const t0 = Date.now(), tick = setInterval(() => status(`${note || ($('#smText').value ? 'يكتب…' : 'يجهّز السكريبت بالعامية المصرية…')} ${Math.round((Date.now() - t0) / 1000)} ث`), 500);
    const split = raw => {
      let title = '', body = raw.replace(/\*\*/g, '').replace(/^#+\s*/gm, '');
      const m = body.match(/^\s*العنوان\s*[:：]\s*(.+)\s*\n/);
      if (m) { title = m[1].trim().replace(/^["«]|["»]$/g, ''); body = body.slice(m[0].length); }
      else if (/^\s*العنوان/.test(body) && !body.includes('\n')) body = '';
      return { title, body };
    };
    try {
      const raw = await AI.text(promptFor(st.req, mins, $('#smNotes').value.trim()), {
        search: !!st.req.search, signal: st.ctl.signal,
        onNote: n => { note = n; },
        onText: t => { const r = split(t); if (r.title) $('#smTitle').value = r.title; const ta = $('#smText'); ta.value = r.body.trimStart(); ta.scrollTop = ta.scrollHeight; $('#smBody').classList.remove('loading'); note = ''; },
      });
      let { title, body } = split(raw);
      body = body.split('\n').map(l => l.trim()).filter(l => l && !/^(\d+[).]|الخطاف|المقدمة|الخاتمة|المحتوى)\s*[:：]?$/.test(l)).join('\n');
      $('#smTitle').value = title || $('#smTitle').value || st.req.topic;
      $('#smText').value = body;
      const words = body.split(/\s+/).length;
      status(`جاهز: ${words} كلمة ≈ ${Math.max(1, Math.round(words / 140))} دقيقة. يمكنك تعديله قبل الاستعمال.`);
      $('#smUse').disabled = false;
    } catch (e) {
      if (e.name !== 'AbortError') status(e.message || 'تعذّرت الكتابة', true);
    } finally { clearInterval(tick); st.busy = false; $('#smAgain').disabled = false; $('#smBody').classList.remove('loading'); }
  }
  function status(t, err) { const s = $('#smStatus'); s.textContent = t; s.classList.toggle('err', !!err); }

  async function use() {
    const text = $('#smText').value.trim(); if (!text) return;
    const ta = $('#ttsText');
    if (ta.value.trim() && ta.value.trim() !== text && !(await confirmBox('استبدال النص الموجود في المشروع بهذا السكريبت؟', 'استبدل'))) return;
    ta.value = text; ta.dispatchEvent(new Event('input', { bubbles: true }));
    const title = $('#smTitle').value.trim();
    if (title) { App.projName = title.slice(0, 80); $('#projName').value = App.projName; save(); }
    close();
    if (App.view !== 'project') go('project');
    setTimeout(() => { ta.scrollIntoView({ behavior: 'smooth', block: 'center' }); ta.classList.add('flash'); setTimeout(() => ta.classList.remove('flash'), 1600); }, 200);
    toast('وُضع السكريبت في المشروع. الآن اصنع التعليق الصوتي', '', 6000);
  }

  /* ---------- الواجهة ---------- */
  async function enter() {
    const p = $('#ideasPanel'); if (!p) return;
    p.hidden = !Channel.cur.ideaCats;
    if (p.hidden) return;
    if (!$('#ytHandle').value) $('#ytHandle').value = Settings.get().ytHandle ?? Channel.cur.yt ?? '';
    $('#ytHandle').placeholder = Channel.id === 'farm' ? '@fadifarm' : '@majra';
    await loadVideos(); showChannel();
    if (!st.ideas.length) ideasFromCache();
  }
  function bind() {
    $('#smClose').onclick = close;
    $('#scriptModal').addEventListener('click', e => { if (e.target.id === 'scriptModal') close(); });
    $('#smAgain').onclick = write;
    $('#smUse').onclick = use;
    $('#smCopy').onclick = async () => { if (await copyText($('#smText').value)) toast('نُسخ السكريبت'); };
    const cats = Channel.cur.ideaCats;
    if (cats && $('#idCat')) {
      $('#idCat').innerHTML = Object.entries(cats).map(([k, v]) => `<button type="button" data-c="${k}">${v}</button>`).join('');
      markCat();
      $('#idCat').onclick = e => { const b = e.target.closest('[data-c]'); if (!b) return; st.cat = b.dataset.c; markCat(); };
      $('#idGo').onclick = suggest;
      $('#ytLink').onclick = link;
      $('#idList').onclick = e => { const b = e.target.closest('[data-idea]'); if (!b) return; const x = st.ideas[+b.dataset.idea]; open({ topic: x.title, details: [x.angle, x.hook && 'Suggested opening line: ' + x.hook].filter(Boolean).join('\n') }); };
      $('#idOwn').onclick = () => { const t = $('#idTopic').value.trim(); if (!t) return toast('اكتب موضوع الفيديو أولاً', 'err'); open({ topic: t }); };
    }
  }
  return { open, bind, enter, fetchChannel, parsePage };
})();
