/* Swift — الحسابات: تسجيل بالبريد وكلمة السر + تأكيد البريد + موافقة المالك + جهاز واحد لكل حساب.
   كل القرارات (الحالة، الدور، الجهاز، الحظر) تُتحقق على الخادم (Supabase RLS + دوال security definer).
   الواجهة هنا تعرض فقط ما يرجعه الخادم. لا يعمل إلا إذا مُلئ js/auth-config.js. */
'use strict';
const Auth = (() => {
  const cfg = window.SWIFT_AUTH || {};
  const enabled = !!(cfg.url && cfg.anonKey);
  let sb = null, state = { status: 'off', role: '', email: '' }, timer = 0;
  const q = s => document.querySelector(s);
  const h = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const WEB = 'https://fadi200723.github.io/fadi-farm/';
  // روابط البريد (تأكيد/استعادة) تفتح دائماً نسخة الويب، لأن تطبيق الأندرويد وويندوز لا يملكان عنواناً على الإنترنت
  const appUrl = () => location.origin === 'https://fadi200723.github.io' ? location.origin + location.pathname : WEB;

  /* معرّف الجهاز: عشوائي يُحفظ على هذا الجهاز (في سطح المكتب والأندرويد يبقى ثابتاً؛ في المتصفح يتغير إذا مُسحت بيانات الموقع → يطلب موافقة المالك من جديد) */
  function deviceId() {
    try { let d = localStorage.getItem('swift.device'); if (!d) { d = crypto.randomUUID(); localStorage.setItem('swift.device', d); } return d; } catch { return ''; }
  }
  const deviceLabel = () => { const u = navigator.userAgent; return (window.fadiDesktop ? 'Windows (تطبيق)' : /Android/.test(u) ? 'Android' : /iPhone|iPad/.test(u) ? 'iPhone' : /Windows/.test(u) ? 'Windows (متصفح)' : /Mac/.test(u) ? 'Mac' : 'متصفح'); };

  function loadLib() {
    if (window.supabase?.createClient) return Promise.resolve();
    return new Promise((ok, no) => { const s = document.createElement('script'); s.src = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.min.js'; s.onload = ok; s.onerror = () => no(new Error('تعذر تحميل نظام الحسابات. تحقق من الإنترنت')); document.head.appendChild(s); });
  }

  /* ---------- الشاشة ---------- */
  const gate = () => q('#authGate');
  function show(html) { const g = gate(); g.innerHTML = `<div class="auth-card"><img src="icons/icon-192.png" alt="" class="auth-logo"><h2>Swift</h2>${html}</div>`; g.hidden = false; document.documentElement.classList.add('auth-locked'); }
  function hide() { gate().hidden = true; document.documentElement.classList.remove('auth-locked'); }
  const msg = (t, kind = '') => { const m = q('#auMsg'); if (m) { m.textContent = t; m.className = 'auth-msg ' + kind; } };
  const busy = (on) => gate().querySelectorAll('button,input').forEach(x => x.disabled = on);
  const strong = p => p.length >= 10 && /[a-z]/i.test(p) && /\d/.test(p);

  function loginForm(mode = 'in') {
    const up = mode === 'up';
    show(`<p class="muted">${up ? 'إنشاء حساب جديد. بعد تأكيد بريدك سيراجع المالك طلبك.' : 'سجّل الدخول للمتابعة'}</p>
      <input id="auEmail" type="email" autocomplete="email" placeholder="البريد الإلكتروني" dir="ltr">
      <input id="auPass" type="password" autocomplete="${up ? 'new-password' : 'current-password'}" placeholder="كلمة السر${up ? ' (10 أحرف على الأقل، حروف وأرقام)' : ''}" dir="ltr">
      ${up ? '<input id="auPass2" type="password" autocomplete="new-password" placeholder="أعد كتابة كلمة السر" dir="ltr">' : ''}
      <p id="auMsg" class="auth-msg"></p>
      <button class="btn primary" id="auGo" type="button">${up ? 'إنشاء الحساب' : 'دخول'}</button>
      <div class="auth-links"><button class="linkish" id="auSwitch" type="button">${up ? 'عندي حساب: تسجيل الدخول' : 'ليس عندي حساب: إنشاء حساب'}</button>${up ? '' : '<button class="linkish" id="auForgot" type="button">نسيت كلمة السر</button>'}</div>`);
    q('#auSwitch').onclick = () => loginForm(up ? 'in' : 'up');
    q('#auForgot') && (q('#auForgot').onclick = forgot);
    q('#auPass').onkeydown = e => { if (e.key === 'Enter' && !up) q('#auGo').click(); };
    q('#auGo').onclick = async () => {
      const email = q('#auEmail').value.trim().toLowerCase(), pass = q('#auPass').value;
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return msg('اكتب بريداً صحيحاً', 'err');
      if (up) {
        if (!strong(pass)) return msg('كلمة السر ضعيفة: 10 أحرف على الأقل وفيها حروف وأرقام', 'err');
        if (pass !== q('#auPass2').value) return msg('كلمتا السر غير متطابقتين', 'err');
      } else if (!pass) return msg('اكتب كلمة السر', 'err');
      busy(true); msg('…');
      try {
        if (up) {
          const { error } = await sb.auth.signUp({ email, password: pass, options: { emailRedirectTo: appUrl() } });
          if (error) throw error;
          show(`<p>أرسلنا رسالة تأكيد إلى بريدك. افتحها واضغط الرابط، ثم سجّل الدخول.</p><p class="muted small">بعد التأكيد سيبقى حسابك «قيد المراجعة» حتى يوافق المالك.</p><button class="btn" id="auBack" type="button">تسجيل الدخول</button>`);
          q('#auBack').onclick = () => loginForm('in');
        } else {
          const { error } = await sb.auth.signInWithPassword({ email, password: pass });
          if (error) throw error;
          await check();
        }
      } catch (e) {
        busy(false);
        const m = String(e.message || e);
        msg(/Invalid login/i.test(m) ? 'البريد أو كلمة السر غير صحيحة' : /Email not confirmed/i.test(m) ? 'أكّد بريدك أولاً من الرسالة التي وصلتك' : /rate|too many|429/i.test(m) ? 'محاولات كثيرة. انتظر قليلاً ثم أعد المحاولة' : 'تعذّر: ' + m, 'err');
      }
    };
  }

  function forgot() {
    show(`<p class="muted">اكتب بريدك وسنرسل رابطاً لتعيين كلمة سر جديدة (صالح مرة واحدة).</p><input id="auEmail" type="email" placeholder="البريد الإلكتروني" dir="ltr"><p id="auMsg" class="auth-msg"></p><button class="btn primary" id="auGo" type="button">إرسال الرابط</button><button class="linkish" id="auBack" type="button">رجوع</button>`);
    q('#auBack').onclick = () => loginForm('in');
    q('#auGo').onclick = async () => {
      busy(true);
      try { await sb.auth.resetPasswordForEmail(q('#auEmail').value.trim().toLowerCase(), { redirectTo: appUrl() }); } catch {}
      // نفس الرسالة دائماً (لا نكشف هل البريد مسجّل أم لا)
      busy(false); msg('إذا كان هذا البريد مسجّلاً فستصلك رسالة خلال دقائق.', 'ok');
    };
  }

  function newPassword() {
    show(`<p>اكتب كلمة سر جديدة</p><input id="auPass" type="password" autocomplete="new-password" placeholder="10 أحرف على الأقل، حروف وأرقام" dir="ltr"><input id="auPass2" type="password" autocomplete="new-password" placeholder="أعد كتابتها" dir="ltr"><p id="auMsg" class="auth-msg"></p><button class="btn primary" id="auGo" type="button">حفظ</button>`);
    q('#auGo').onclick = async () => {
      const p = q('#auPass').value;
      if (!strong(p)) return msg('كلمة السر ضعيفة: 10 أحرف على الأقل وفيها حروف وأرقام', 'err');
      if (p !== q('#auPass2').value) return msg('كلمتا السر غير متطابقتين', 'err');
      busy(true);
      const { error } = await sb.auth.updateUser({ password: p });
      if (error) { busy(false); return msg('تعذّر: ' + error.message, 'err'); }
      history.replaceState(null, '', appUrl());
      await check();       // تغيير كلمة السر لا يتجاوز الموافقة ولا الإيقاف: الخادم يقرر
    };
  }

  const STATUS = {
    unverified: ['أكّد بريدك الإلكتروني', 'افتح رسالة التأكيد التي وصلتك ثم ارجع هنا.'],
    pending: ['حسابك قيد المراجعة', 'سيراجع المالك طلبك. ستتمكن من الدخول بعد الموافقة.'],
    rejected: ['تم رفض الطلب', 'لا يمكن استعمال هذا الحساب.'],
    suspended: ['الحساب موقوف مؤقتاً', 'تواصل مع صاحب التطبيق.'],
    banned: ['الحساب محظور', 'لا يمكن استعمال هذا الحساب.'],
    device_pending: ['جهاز جديد', 'هذا الحساب مرتبط بجهاز آخر. أُرسل طلب تغيير الجهاز للمالك، وستتمكن من الدخول بعد موافقته.'],
  };
  function blocked(st) {
    const [t, d] = STATUS[st] || ['لا يمكن الدخول', ''];
    show(`<h3>${h(t)}</h3><p class="muted">${h(d)}</p><button class="btn" id="auRe" type="button">تحقق من جديد</button><button class="linkish" id="auOut" type="button">تسجيل الخروج</button>`);
    q('#auRe').onclick = () => check(); q('#auOut').onclick = logout;
  }

  /* ---------- الحالة من الخادم ---------- */
  async function check() {
    const { data: { session } } = await sb.auth.getSession();
    if (!session) { state = { status: 'signed_out' }; ownerUi(); return loginForm('in'); }
    const { data, error } = await sb.rpc('my_access', { p_device: deviceId(), p_label: deviceLabel() });
    if (error) {
      // بدون إنترنت: نبقي آخر حالة «نشطة» مؤكدة على هذا الجهاز فقط لمدة قصيرة
      if (state.status === 'active') return;
      show(`<p class="auth-msg err">تعذّر الاتصال بالخادم: ${h(error.message)}</p><button class="btn" id="auRe" type="button">إعادة المحاولة</button>`); q('#auRe').onclick = () => check(); return;
    }
    state = { status: data.status, role: data.role || '', email: data.email || session.user.email };
    ownerUi();
    if (data.status === 'active') hide(); else blocked(data.status);
  }
  async function logout() { try { await sb.auth.signOut({ scope: 'local' }); } catch {} state = { status: 'signed_out' }; ownerUi(); loginForm('in'); }
  async function logoutAll() { if (!confirm('تسجيل الخروج من كل الأجهزة؟')) return; try { await sb.auth.signOut({ scope: 'global' }); } catch {} logout(); }

  /* ---------- لوحة المالك (تظهر فقط إذا قال الخادم إن الدور owner) ---------- */
  function ownerUi() {
    const isOwner = state.status === 'active' && state.role === 'owner';
    const b = q('#authReqBtn'); if (b) b.hidden = !isOwner;
    const box = q('#authAccount');
    if (box) { box.hidden = !enabled || state.status !== 'active'; const e = q('#authEmail'); if (e) e.textContent = state.email || ''; }
    if (!isOwner) { const d = q('#authAdmin'); if (d?.open) d.close(); }
  }
  const LBL = { pending: 'قيد المراجعة', active: 'نشط', rejected: 'مرفوض', suspended: 'موقوف', banned: 'محظور' };
  async function admin(filter = '') {
    const d = q('#authAdmin'), list = q('#aaList');
    if (!d.open) d.showModal();
    list.innerHTML = '<p class="muted">جاري التحميل…</p>';
    let qy = sb.from('profiles').select('id,email,role,status,device_label,pending_device,pending_label,created_at,last_seen').order('created_at', { ascending: false }).limit(200);
    if (filter) qy = qy.ilike('email', `%${filter.replace(/[%_]/g, '')}%`);
    const { data, error } = await qy;
    if (error) { list.innerHTML = `<p class="auth-msg err">${h(error.message)}</p>`; return; }
    const pend = data.filter(u => u.status === 'pending' || u.pending_device).length;
    q('#aaCount').textContent = pend ? `${pend} طلب ينتظر` : 'لا توجد طلبات جديدة';
    list.innerHTML = data.filter(u => u.role !== 'owner').map(u => `<div class="aa-row" data-id="${h(u.id)}">
      <div><b dir="ltr">${h(u.email)}</b> <span class="chip st-${h(u.status)}">${LBL[u.status] || h(u.status)}</span>
      <div class="muted small">سُجّل ${new Date(u.created_at).toLocaleString('ar')}${u.last_seen ? ' · آخر دخول ' + new Date(u.last_seen).toLocaleString('ar') : ''}${u.device_label ? ' · الجهاز: ' + h(u.device_label) : ''}</div>
      ${u.pending_device ? `<div class="small">طلب جهاز جديد: ${h(u.pending_label || '')} <button class="btn sm primary" data-a="dev1">موافقة</button> <button class="btn sm ghost" data-a="dev0">رفض</button></div>` : ''}</div>
      <div class="aa-acts">${u.status !== 'active' ? '<button class="btn sm primary" data-a="active">قبول / تفعيل</button>' : ''}${u.status === 'pending' ? '<button class="btn sm ghost" data-a="rejected">رفض</button>' : ''}${u.status === 'active' ? '<button class="btn sm ghost" data-a="suspended">إيقاف</button>' : ''}${u.status !== 'banned' ? '<button class="btn sm danger" data-a="banned">حظر</button>' : ''}<button class="btn sm ghost" data-a="devreset">فك ربط الجهاز</button></div></div>`).join('') || '<p class="muted">لا توجد حسابات.</p>';
  }
  const ASK = { active: 'تفعيل هذا الحساب؟', rejected: 'رفض هذا الطلب؟', suspended: 'إيقاف الحساب مؤقتاً؟ سيُسجَّل خروجه فوراً.', banned: 'حظر هذا الحساب؟ سيُسجَّل خروجه فوراً ولن يستطيع الدخول.', dev1: 'الموافقة على الجهاز الجديد؟ الجهاز القديم لن يعود يدخل.', dev0: 'رفض الجهاز الجديد؟', devreset: 'فك ربط الجهاز؟ سيرتبط الحساب بأول جهاز يدخل منه.' };
  async function act(id, a, email) {
    if (!confirm(`${ASK[a]}\n${email}`)) return;
    const r = a === 'dev1' || a === 'dev0' ? await sb.rpc('admin_device', { p_user: id, p_approve: a === 'dev1' })
      : a === 'devreset' ? await sb.rpc('admin_reset_device', { p_user: id })
      : await sb.rpc('admin_set_status', { p_user: id, p_status: a });
    if (r.error) alert('تعذّر: ' + r.error.message);
    admin(q('#aaSearch').value.trim());
  }

  async function init() {
    if (!enabled) return;
    show('<p class="muted">جاري التحقق من الحساب…</p>');
    try { await loadLib(); } catch (e) { show(`<p class="auth-msg err">${h(e.message)}</p><button class="btn" onclick="location.reload()">إعادة المحاولة</button>`); return; }
    sb = window.supabase.createClient(cfg.url, cfg.anonKey, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true, flowType: 'implicit' } });
    let recovering = /type=recovery/.test(location.hash + location.search);
    sb.auth.onAuthStateChange((ev) => { if (ev === 'PASSWORD_RECOVERY') { recovering = true; newPassword(); } else if (ev === 'SIGNED_OUT') { state = { status: 'signed_out' }; ownerUi(); loginForm('in'); } });
    q('#authReqBtn')?.addEventListener('click', () => state.role === 'owner' && admin());
    q('#aaSearch')?.addEventListener('input', e => { clearTimeout(q('#aaSearch')._t); q('#aaSearch')._t = setTimeout(() => admin(e.target.value.trim()), 350); });
    q('#aaList')?.addEventListener('click', e => { const b = e.target.closest('[data-a]'); if (!b) return; const row = b.closest('[data-id]'); act(row.dataset.id, b.dataset.a, row.querySelector('b').textContent); });
    q('#authLogout')?.addEventListener('click', logout);
    q('#authLogoutAll')?.addEventListener('click', logoutAll);
    await new Promise(r => setTimeout(r, 150));
    if (!recovering) await check();
    // تحقق دوري: الإيقاف أو الحظر يطبق خلال دقائق حتى لو بقي التطبيق مفتوحاً
    clearInterval(timer); timer = setInterval(() => { if (state.status === 'active') check(); }, 3 * 60e3);
    document.addEventListener('visibilitychange', () => { if (!document.hidden && state.status === 'active') check(); });
  }
  return { init, enabled, get state() { return state; } };
})();
document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', Auth.init) : Auth.init();
