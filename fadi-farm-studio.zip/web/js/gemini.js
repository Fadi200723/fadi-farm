/* Fadi Farm — طبقة الذكاء الاصطناعي (Gemini). يمكن استبدالها بمزوّد آخر بتغيير هذا الملف فقط. */
'use strict';

const AI = (() => {
  const API = 'https://generativelanguage.googleapis.com/v1beta/models/';

  function errMsg(status, d) {
    const m = d?.error?.message || '';
    if (status === 400 && /API key/i.test(m)) return 'مفتاح Gemini غير صالح';
    if (status === 400) return 'رفض Gemini الطلب: ' + m.slice(0, 160);
    if (status === 403) return 'مفتاح Gemini لا يملك صلاحية لهذا النموذج';
    if (status === 404) return 'اسم النموذج غير موجود. غيّره من الإعدادات';
    if (status === 429) return 'تجاوزت حدّ Gemini المجاني مؤقتاً. انتظر دقيقة ثم أعد المحاولة';
    if (status >= 500) return 'خوادم Gemini مشغولة. أعد المحاولة بعد قليل';
    return `خطأ Gemini (${status})`;
  }

  async function call(parts, { retries = 2, signal } = {}) {
    const s = Settings.get();
    if (!s.keys.gemini) throw new Error('أضف مفتاح Gemini من الإعدادات أولاً');
    for (let a = 0; ; a++) {
      let r, d;
      try {
        r = await fetch(API + encodeURIComponent(s.geminiModel.trim()) + ':generateContent', {
          method: 'POST', signal,
          headers: { 'Content-Type': 'application/json', 'x-goog-api-key': s.keys.gemini.trim() },
          body: JSON.stringify({ contents: [{ role: 'user', parts }], generationConfig: { temperature: 0.2, responseMimeType: 'application/json' } }),
        });
        d = await r.json().catch(() => ({}));
      } catch (e) {
        if (e.name === 'AbortError') throw e;
        if (a < retries) { await sleep(1500 * (a + 1)); continue; }
        throw new Error('تعذّر الاتصال بـ Gemini. تحقق من الإنترنت');
      }
      if (!r.ok) {
        if ((r.status === 429 || r.status >= 500) && a < retries) { await sleep(4000 * (a + 1)); continue; }
        throw new Error(errMsg(r.status, d));
      }
      const c = d.candidates?.[0];
      const text = (c?.content?.parts || []).map(p => p.text || '').join('').trim();
      if (!text) throw new Error('لم يُرجع Gemini نتيجة (' + (c?.finishReason || d.promptFeedback?.blockReason || 'رد فارغ') + ')');
      try { return JSON.parse(text.replace(/^```(?:json)?\s*|\s*```$/g, '')); }
      catch { if (a < retries) continue; throw new Error('ردّ Gemini غير منسّق، أعد المحاولة'); }
    }
  }

  /* تحويل الصوت إلى WAV أحادي 16kHz ثم تقطيعه عند لحظات الصمت */
  async function audioChunks(buf, chunkSec = 240) {
    const sr = 16000, len = Math.ceil(buf.duration * sr);
    const off = new OfflineAudioContext(1, len, sr);
    const src = off.createBufferSource(); src.buffer = buf; src.connect(off.destination); src.start();
    const data = (await off.startRendering()).getChannelData(0);
    const cuts = [0];
    const win = Math.floor(sr * 0.05);
    for (let b = chunkSec * sr; b < data.length - sr * 20; b += chunkSec * sr) {
      let best = b, bestE = Infinity;
      for (let x = b - 8 * sr; x < b + 8 * sr; x += win) {
        let e = 0; for (let k = 0; k < win; k += 4) e += data[x + k] * data[x + k];
        if (e < bestE) { bestE = e; best = x; }
      }
      cuts.push(best); b = best;
    }
    cuts.push(data.length);
    const out = [];
    for (let i = 0; i < cuts.length - 1; i++) {
      const seg = data.subarray(cuts[i], cuts[i + 1]);
      out.push({ offset: cuts[i] / sr, dur: seg.length / sr, blob: wav(seg, sr) });
    }
    return out;
  }

  function wav(f32, sr) {
    const b = new ArrayBuffer(44 + f32.length * 2), v = new DataView(b);
    const w = (o, s) => [...s].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
    w(0, 'RIFF'); v.setUint32(4, 36 + f32.length * 2, true); w(8, 'WAVE'); w(12, 'fmt ');
    v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true); v.setUint32(24, sr, true);
    v.setUint32(28, sr * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, f32.length * 2, true);
    for (let i = 0; i < f32.length; i++) { const x = Math.max(-1, Math.min(1, f32[i])); v.setInt16(44 + i * 2, x < 0 ? x * 0x8000 : x * 0x7fff, true); }
    return new Blob([b], { type: 'audio/wav' });
  }

  const b64 = blob => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.onerror = rej; r.readAsDataURL(blob); });

  function guide(target) {
    const s = Settings.get();
    return `Channel context: ${s.context || 'general'}.
For each scene also give 3 to 5 visual search keywords IN ENGLISH for stock footage sites (Pexels, Pixabay, Wikimedia, NASA). Keywords must describe concrete filmable things: subjects, animals, objects, places, actions, mood of the shot (e.g. "goat grazing hillside", "farmer planting seedlings", "sunrise over wheat field"). Most specific keyword first, short phrases of 1 to 4 words, no abstract words.
Also choose "kind": "video" if moving footage suits the scene better, otherwise "image".
Target scene length about ${target} seconds (allowed ${Math.max(2, target * 0.5)} to ${target * 2}). Split only at sentence or clause boundaries.`;
  }

  /* تفريغ الصوت إلى مشاهد بتوقيتات */
  async function transcribe(buf, { target = 6, onProgress, signal } = {}) {
    onProgress?.('تجهيز الصوت…', 0);
    const chunks = await audioChunks(buf);
    const all = [];
    for (let i = 0; i < chunks.length; i++) {
      const c = chunks[i];
      onProgress?.(`تفريغ الجزء ${i + 1} من ${chunks.length}…`, i / chunks.length);
      const data = await b64(c.blob);
      const prompt = `You are the assistant of a video editor. Transcribe this narration audio exactly, word for word, in its ORIGINAL language and script (do not translate, keep Arabic dialect as spoken). This clip is ${c.dur.toFixed(1)} seconds long. Timestamps are in seconds from the start of THIS clip.
Split the transcript into consecutive scenes that cover the whole clip without gaps.
${guide(target)}
Return only JSON: {"scenes":[{"start":0.0,"end":5.2,"text":"...","keywords":["..."],"kind":"video"}]}`;
      const r = await call([{ inline_data: { mime_type: 'audio/wav', data } }, { text: prompt }], { signal });
      (r.scenes || []).forEach(x => {
        const st = Math.max(0, Math.min(c.dur, +x.start || 0)), en = Math.max(st, Math.min(c.dur, +x.end || st));
        if (String(x.text || '').trim()) all.push({ start: c.offset + st, end: c.offset + en, text: String(x.text).trim(), kw: clean(x.keywords), kind: x.kind === 'image' ? 'image' : 'video' });
      });
    }
    if (!all.length) throw new Error('لم يتعرّف Gemini على كلام في الملف');
    all.sort((a, b) => a.start - b.start);
    // اجعل المشاهد متصلة وتغطي كامل مدة الصوت
    for (let i = 0; i < all.length; i++) {
      all[i].start = i ? all[i - 1].end : 0;
      const next = all[i + 1]?.start ?? buf.duration;
      all[i].end = Math.max(all[i].start + 0.4, i === all.length - 1 ? buf.duration : Math.max(all[i].end, (all[i].end + next) / 2));
    }
    all[all.length - 1].end = Math.max(all[all.length - 1].end, buf.duration);
    onProgress?.('اكتمل التفريغ', 1);
    return all.map(x => ({ text: x.text, d: x.end - x.start, kw: x.kw, kind: x.kind }));
  }

  /* اقتراح كلمات بحث لنصوص مشاهد جاهزة */
  async function keywords(texts, { signal } = {}) {
    const out = [];
    for (let i = 0; i < texts.length; i += 40) {
      const part = texts.slice(i, i + 40);
      const prompt = `${guide(Settings.get().sceneTarget)}
Here are ${part.length} narration scenes (JSON array). Return JSON {"scenes":[{"keywords":["..."],"kind":"video"}]} with exactly ${part.length} items in the same order.
${JSON.stringify(part)}`;
      const r = await call([{ text: prompt }], { signal });
      part.forEach((_, k) => { const x = r.scenes?.[k] || {}; out.push({ kw: clean(x.keywords), kind: x.kind === 'image' ? 'image' : 'video' }); });
    }
    return out;
  }

  async function test() {
    const r = await call([{ text: 'Return JSON {"ok":true}' }], { retries: 0 });
    return !!r;
  }

  const clean = k => [...new Set((Array.isArray(k) ? k : String(k || '').split(',')).map(x => String(x).trim()).filter(Boolean))].slice(0, 5);
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  return { transcribe, keywords, test };
})();
