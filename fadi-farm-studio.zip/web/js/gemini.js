/* Fadi Farm — طبقة الذكاء الاصطناعي (Gemini). يمكن استبدالها بمزوّد آخر بتغيير هذا الملف فقط. */
'use strict';

const AI = (() => {
  const API = 'https://generativelanguage.googleapis.com/v1beta/models/';

  function errMsg(status, d) {
    const m = d?.error?.message || '';
    if (status === 400 && /API key/i.test(m)) return 'مفتاح Gemini غير صالح';
    if (status === 400) return 'رفض Gemini الطلب: ' + m.slice(0, 160);
    if (status === 403) return 'مفتاح Gemini لا يملك صلاحية لهذا النموذج';
    if (status === 404) return 'اسم النموذج غير موجود. غيّره من الإعدادات';
    if (status === 429) return 'تجاوزت حدّ Gemini المجاني مؤقتاً. انتظر دقيقة ثم أعد المحاولة';
    if (status >= 500) return 'خوادم Gemini مشغولة. أعد المحاولة بعد قليل';
    return `خطأ Gemini (${status})`;
  }

  async function call(parts, { retries = 2, signal } = {}) {
    const s = Settings.get();
    if (!s.keys.gemini) throw new Error('أضف مفتاح Gemini من الإعدادات أولاً');
    for (let a = 0; ; a++) {
      let r, d;
      try {
        r = await fetch(API + encodeURIComponent(s.geminiModel.trim()) + ':generateContent', {
          method: 'POST', signal,
          headers: { 'Content-Type': 'application/json', 'x-goog-api-key': s.keys.gemini.trim() },
          body: JSON.stringify({ contents: [{ role: 'user', parts }], generationConfig: { temperature: 0.2, responseMimeType: 'application/json' } }),
        });
        d = await r.json().catch(() => ({}));
      } catch (e) {
        if (e.name === 'AbortError') throw e;
        if (a < retries) { await sleep(1500 * (a + 1)); continue; }
        throw new Error('تعذّر الاتصال بـ Gemini. تحقق من الإنترنت');
      }
      if (!r.ok) {
        if ((r.status === 429 || r.status >= 500) && a < retries) { await sleep(4000 * (a + 1)); continue; }
        throw new Error(errMsg(r.status, d));
      }
      const c = d.candidates?.[0];
      const text = (c?.content?.parts || []).map(p => p.text || '').join('').trim();
      if (!text) throw new Error('لم يُرجع Gemini نتيجة (' + (c?.finishReason || d.promptFeedback?.blockReason || 'رد فارغ') + ')');
      try { return JSON.parse(text.replace(/^```(?:json)?\s*|\s*```$/g, '')); }
      catch { if (a < retries) continue; throw new Error('ردّ Gemini غير منسّق، أعد المحاولة'); }
    }
  }

  /* تحويل الصوت إلى WAV أحادي 16kHz ثم تقطيعه عند لحظات الصمت */
  async function audioChunks(buf, chunkSec = 240) {
    const sr = 16000, len = Math.ceil(buf.duration * sr);
    const off = new OfflineAudioContext(1, len, sr);
    const src = off.createBufferSource(); src.buffer = buf; src.connect(off.destination); src.start();
    const data = (await off.startRendering()).getChannelData(0);
    const cuts = [0];
    const win = Math.floor(sr * 0.05);
    for (let b = chunkSec * sr; b < data.length - sr * 20; b += chunkSec * sr) {
      let best = b, bestE = Infinity;
      for (let x = b - 8 * sr; x < b + 8 * sr; x += win) {
        let e = 0; for (let k = 0; k < win; k += 4) e += data[x + k] * data[x + k];
        if (e < bestE) { bestE = e; best = x; }
      }
      cuts.push(best); b = best;
    }
    cuts.push(data.length);
    const out = [];
    for (let i = 0; i < cuts.length - 1; i++) {
      const seg = data.subarray(cuts[i], cuts[i + 1]);
      out.push({ offset: cuts[i] / sr, dur: seg.length / sr, blob: wav(seg, sr) });
    }
    return out;
  }

  function wav(f32, sr) {
    const b = new ArrayBuffer(44 + f32.length * 2), v = new DataView(b);
    const w = (o, s) => [...s].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
    w(0, 'RIFF'); v.setUint32(4, 36 + f32.length * 2, true); w(8, 'WAVE'); w(12, 'fmt ');
    v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true); v.setUint32(24, sr, true);
    v.setUint32(28, sr * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, f32.length * 2, true);
    for (let i = 0; i < f32.length; i++) { const x = Math.max(-1, Math.min(1, f32[i])); v.setInt16(44 + i * 2, x < 0 ? x * 0x8000 : x * 0x7fff, true); }
    return new Blob([b], { type: 'audio/wav' });
  }

  const b64 = blob => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.onerror = rej; r.readAsDataURL(blob); });

  function guide(target) {
    const s = Settings.get();
    return `Channel context: ${s.context || 'general'}.
For each scene also give 3 to 5 visual search keywords IN ENGLISH for stock footage sites (Pexels, Pixabay, Wikimedia, NASA). Keywords must describe concrete filmable things: subjects, animals, objects, places, actions, mood of the shot (e.g. "goat grazing hillside", "farmer planting seedlings", "sunrise over wheat field"). Most specific keyword first, short phrases of 1 to 4 words, no abstract words.
Also give "subject": the single main animal, object or place of the scene in English, 1 or 2 words (e.g. "chicken", "turkey", "duck", "chicken coop", "farmer"). If the narration talks about a specific animal breed or type (local/baladi chickens, turkeys, ducks, geese, rabbits, goats), name that animal in the subject and in the first keyword, because stock sites are searched with it.
When the scene is abstract (greetings, "subscribe", opinions), still give keywords that show the channel's world (e.g. "chickens free range farm", "farmer feeding chickens").
Also choose "kind": "video" if moving footage suits the scene better, otherwise "image".
Target scene length about ${target} seconds (allowed ${Math.max(2, target * 0.5)} to ${target * 2}). Split only at sentence or clause boundaries.`;
  }

  /* تفريغ الصوت إلى مشاهد بتوقيتات */
  async function transcribe(buf, { target = 6, onProgress, signal } = {}) {
    onProgress?.('تجهيز الصوت…', 0);
    const chunks = await audioChunks(buf);
    const all = [];
    for (let i = 0; i < chunks.length; i++) {
      const c = chunks[i];
      onProgress?.(`تفريغ الجزء ${i + 1} من ${chunks.length}…`, i / chunks.length);
      const data = await b64(c.blob);
      const prompt = `You are the assistant of a video editor. Transcribe this narration audio exactly, word for word, in its ORIGINAL language and script (do not translate, keep Arabic dialect as spoken). This clip is ${c.dur.toFixed(1)} seconds long. Timestamps are in seconds from the start of THIS clip.
Split the transcript into consecutive scenes that cover the whole clip without gaps.
${guide(target)}
Return only JSON: {"scenes":[{"start":0.0,"end":5.2,"text":"...","keywords":["..."],"subject":"chicken","kind":"video"}]}`;
      const r = await call([{ inline_data: { mime_type: 'audio/wav', data } }, { text: prompt }], { signal });
      (r.scenes || []).forEach(x => {
        const st = Math.max(0, Math.min(c.dur, +x.start || 0)), en = Math.max(st, Math.min(c.dur, +x.end || st));
        if (String(x.text || '').trim()) all.push({ start: c.offset + st, end: c.offset + en, text: String(x.text).trim(), kw: clean([...[].concat(x.keywords || []), x.subject]), kind: x.kind === 'image' ? 'image' : 'video' });
      });
    }
    if (!all.length) throw new Error('لم يتعرّف Gemini على كلام في الملف');
    all.sort((a, b) => a.start - b.start);
    // اجعل المشاهد متصلة وتغطي كامل مدة الصوت
    for (let i = 0; i < all.length; i++) {
      all[i].start = i ? all[i - 1].end : 0;
      const next = all[i + 1]?.start ?? buf.duration;
      all[i].end = Math.max(all[i].start + 0.4, i === all.length - 1 ? buf.duration : Math.max(all[i].end, (all[i].end + next) / 2));
    }
    all[all.length - 1].end = Math.max(all[all.length - 1].end, buf.duration);
    onProgress?.('اكتمل التفريغ', 1);
    return all.map(x => ({ text: x.text, d: x.end - x.start, kw: x.kw, kind: x.kind }));
  }

  /* اقتراح كلمات بحث لنصوص مشاهد جاهزة */
  async function keywords(texts, { signal } = {}) {
    const out = [];
    for (let i = 0; i < texts.length; i += 40) {
      const part = texts.slice(i, i + 40);
      const prompt = `${guide(Settings.get().sceneTarget)}
Here are ${part.length} narration scenes (JSON array). Return JSON {"scenes":[{"keywords":["..."],"subject":"chicken","kind":"video"}]} with exactly ${part.length} items in the same order.
${JSON.stringify(part)}`;
      const r = await call([{ text: prompt }], { signal });
      part.forEach((_, k) => { const x = r.scenes?.[k] || {}; out.push({ kw: clean([...[].concat(x.keywords || []), x.subject]), kind: x.kind === 'image' ? 'image' : 'video' }); });
    }
    return out;
  }

  /* مواد النشر: سكربت الشورت، عنوان الصورة المصغرة، عنوان ووصف يوتيوب */
  async function promo(sceneTexts, { signal } = {}) {
    const s = Settings.get();
    const prompt = `You are a YouTube growth expert for an Egyptian Arabic farming channel. Channel context: ${s.context}.
Below is the narration of a new long video, split into numbered scenes (JSON array, index from 0).
Write, in EGYPTIAN ARABIC dialect (عامية مصرية):
1. "teaser": a 10-15 second voice-over script for a YouTube Short that makes viewers want to watch the full video. 25 to 38 words. Start with a strong hook (question or surprising fact from the video), do not reveal the full answer, end with an invitation to watch the full video on the channel.
2. "teaserScenes": 4 scene indexes whose visuals best fit the teaser, in order.
3. "thumbTitle": 2 to 4 punchy Egyptian words for the thumbnail (big text), no emojis. If the video compares two things use the form "X ولا Y؟".
4. "thumbScene": the scene index with the most eye-catching visual for the thumbnail.
4b. "thumbHighlight": the single most important word of thumbTitle (copied exactly) to highlight in color.
4c. "thumbLayout": "vs" if the video compares two animals/options, otherwise "hero".
4d. "thumbPrompt": an ENGLISH prompt for an AI image generator to create the thumbnail background: photorealistic, ultra detailed, vivid saturated colors, dramatic warm lighting, shallow depth of field, close-up of the main animal(s) of the video with an expressive pose, rural Egyptian farm setting. For "hero": main subject large on the LEFT half, the RIGHT 45% is a calm blurred area for text. For "vs": the two subjects facing each other, one on the left and one on the right, empty center. Always end with: "no text, no letters, no logos, no watermark".
5. "ytTitle": an attractive YouTube title under 70 characters in Egyptian Arabic.
6. "description": a 3-4 line YouTube description in Egyptian Arabic.
7. "tags": 8 to 12 relevant hashtags (Arabic and English), without spaces inside a tag.
Return only JSON: {"teaser":"","teaserScenes":[0,1,2,3],"thumbTitle":"","thumbScene":0,"thumbHighlight":"","thumbLayout":"hero","thumbPrompt":"","ytTitle":"","description":"","tags":["#..."]}
Scenes:
${JSON.stringify(sceneTexts.map(t => t.slice(0, 300)))}`;
    const r = await call([{ text: prompt }], { signal });
    const n = sceneTexts.length, idx = i => Math.max(0, Math.min(n - 1, parseInt(i) || 0));
    return {
      teaser: String(r.teaser || '').trim(),
      teaserScenes: (Array.isArray(r.teaserScenes) ? r.teaserScenes : []).map(idx).slice(0, 5),
      thumbTitle: String(r.thumbTitle || '').trim(),
      thumbScene: idx(r.thumbScene),
      thumbHighlight: String(r.thumbHighlight || '').trim(),
      thumbLayout: r.thumbLayout === 'vs' ? 'vs' : 'hero',
      thumbPrompt: String(r.thumbPrompt || '').trim(),
      ytTitle: String(r.ytTitle || '').trim(),
      description: String(r.description || '').trim(),
      tags: (Array.isArray(r.tags) ? r.tags : String(r.tags || '').split(/\s+/)).map(t => String(t).trim()).filter(Boolean).map(t => t.startsWith('#') ? t : '#' + t),
    };
  }

  /* يختار Gemini بالنظر أنسب صورة لكل مشهد، أو يرفض الكل.
     groups: [{text, subject, images:[base64 jpeg]}] → [رقم الصورة المختارة (يبدأ من 1) أو 0] */
  async function pickVisual(groups, { signal } = {}) {
    const s = Settings.get();
    const parts = [{ text: `You are the visual editor of a family-friendly YouTube channel about farm animals (${s.context}).
For each scene below you get the narration and candidate stock images (thumbnails of photos or videos).
Choose the ONE candidate that best illustrates the narration and clearly shows the scene subject.
Reject a candidate if it shows: smoking or cigarettes, alcohol, drugs, weapons, violence, blood, nudity or sexy content, parties or nightlife, people as the main subject when the scene is about animals, city/office/technology scenes, text-heavy graphics, or anything unrelated to farming, animals or rural life.
If no candidate is good, answer 0 for that scene.
Return only JSON: {"picks":[{"scene":1,"choice":2}]} with one item per scene, choice = candidate number (1-based) or 0.` }];
    groups.forEach((g, i) => {
      parts.push({ text: `\nScene ${i + 1} — subject: ${g.subject || 'farm animals'} — narration: ${String(g.text).slice(0, 220)}` });
      g.images.forEach((b64, k) => { parts.push({ text: `Scene ${i + 1} candidate ${k + 1}:` }); parts.push({ inline_data: { mime_type: 'image/jpeg', data: b64 } }); });
    });
    const r = await call(parts, { signal });
    const out = groups.map(() => 0);
    (r.picks || []).forEach(p => { const i = (parseInt(p.scene) || 0) - 1, c = parseInt(p.choice) || 0; if (i >= 0 && i < out.length && c >= 0 && c <= groups[i].images.length) out[i] = c; });
    return out;
  }

  /* توليد صورة بالذكاء الاصطناعي (خلفية الصورة المصغرة) ← Blob */
  function findImage(o, depth = 0) {
    if (!o || typeof o !== 'object' || depth > 8) return null;
    const m = String(o.mime_type || o.mimeType || '');
    if (typeof o.data === 'string' && o.data.length > 2000 && (/image/.test(m) || !m)) return { data: o.data, mime: m || 'image/jpeg' };
    for (const v of Array.isArray(o) ? o : Object.values(o)) { const r = findImage(v, depth + 1); if (r) return r; }
    return null;
  }
  async function image(prompt, { signal, aspect = '16:9' } = {}) {
    const s = Settings.get();
    if (!s.keys.gemini) throw new Error('أضف مفتاح Gemini من الإعدادات أولاً');
    const key = s.keys.gemini.trim(), headers = { 'Content-Type': 'application/json', 'x-goog-api-key': key };
    const models = [...new Set([s.imageModel || 'gemini-nano-banana-2.1', 'gemini-3.1-flash-lite-image', 'gemini-3.1-flash-image', 'gemini-2.5-flash-image'])];
    let lastErr = 'تعذّر توليد الصورة';
    for (const model of models) {
      for (let a = 0; a < 2; a++) {
        let r = await fetch(API.replace('models/', '') + 'interactions', { method: 'POST', signal, headers, body: JSON.stringify({
          model, input: [{ type: 'text', text: prompt }],
          response_format: { type: 'image', mime_type: 'image/jpeg', aspect_ratio: aspect, image_size: '1K' } }) });
        let d = await r.json().catch(() => ({}));
        if (!r.ok && (r.status === 400 || r.status === 404)) {
          r = await fetch(API + encodeURIComponent(model) + ':generateContent', { method: 'POST', signal, headers, body: JSON.stringify({
            contents: [{ role: 'user', parts: [{ text: prompt }] }],
            generationConfig: { responseModalities: ['IMAGE', 'TEXT'], imageConfig: { aspectRatio: aspect } } }) });
          d = await r.json().catch(() => ({}));
        }
        if (r.ok) {
          const im = findImage(d);
          if (im) { const bin = atob(im.data), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return new Blob([u], { type: im.mime }); }
          lastErr = 'لم يُرجع Gemini صورة (ربما رُفض الوصف)'; break;
        }
        if (r.status === 429 && a === 0) { await sleep(6000); continue; }
        lastErr = r.status === 429 ? 'تجاوزت حد توليد الصور حالياً، أو يحتاج حسابك تفعيل الفوترة في Google AI Studio'
          : r.status === 403 ? 'مفتاحك لا يملك صلاحية توليد الصور' : errMsg(r.status, d);
        break;
      }
    }
    throw new Error(lastErr);
  }

  async function test() {
    const r = await call([{ text: 'Return JSON {"ok":true}' }], { retries: 0 });
    return !!r;
  }

  const clean = k => [...new Set((Array.isArray(k) ? k : String(k || '').split(',')).map(x => String(x).trim()).filter(Boolean))].slice(0, 6);
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  return { transcribe, keywords, promo, pickVisual, image, test };
})();
