/* Fadi — طلبات الشبكة: في تطبيق أندرويد تمر عبر الطبقة الأصلية (بدون قيود CORS)، وفي المتصفح عبر fetch */
'use strict';
/* آيفون/آيباد (نسخة الويب): يحتاج طرقاً خاصة للحفظ والصوت وفتح الروابط */
const IOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

const Http = (() => {
  /* يرجع {status, data(نص أو base64), retryAfter} */
  async function request(url, { method = 'GET', headers = {}, body, binary = false, timeout = 120000, signal } = {}) {
    const payload = body == null ? undefined : (typeof body === 'string' ? body : JSON.stringify(body));
    if (NATIVE) {
      const p = capCall('FadiNative', 'httpRequest', { url, method, headers, body: payload, responseType: binary ? 'base64' : 'text', timeout });
      const r = await (signal ? Promise.race([p, new Promise((_, rej) => signal.addEventListener('abort', () => rej(Object.assign(new Error('أُلغي'), { name: 'AbortError' })), { once: true }))]) : p);
      return { status: r.status, data: r.data, retryAfter: parseFloat(r.retryAfter) || 0 };
    }
    // نسخة الحاسوب: الطلب يمر من البرنامج نفسه (بدون قيود المتصفح)
    if (window.fadiDesktop?.req) {
      const p = window.fadiDesktop.req({ url, method, headers, body: payload, binary, timeout });
      const r = await (signal ? Promise.race([p, new Promise((_, rej) => signal.addEventListener('abort', () => rej(Object.assign(new Error('أُلغي'), { name: 'AbortError' })), { once: true }))]) : p);
      if (r.status) return { status: r.status, data: r.data, retryAfter: r.retryAfter || 0 };
    }
    const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), timeout);
    signal?.addEventListener('abort', () => ctl.abort(), { once: true });
    try {
      const r = await fetch(url, { method, headers, body: payload, signal: ctl.signal });
      let data;
      if (binary && r.ok) { const b = new Uint8Array(await r.arrayBuffer()); let s = ''; for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000)); data = btoa(s); }
      else data = await r.text();
      return { status: r.status, data, retryAfter: parseFloat(r.headers.get('retry-after')) || 0 };
    } catch (e) {
      if (signal?.aborted) throw Object.assign(new Error('أُلغي'), { name: 'AbortError' });
      if (e.name === 'AbortError') throw new Error('انتهت مهلة الاتصال');
      throw new Error('تعذّر الاتصال (قد يكون المزوّد لا يسمح بالاتصال من المتصفح، جرّبه في تطبيق أندرويد)');
    } finally { clearTimeout(t); }
  }
  async function json(url, opts = {}) {
    const r = await request(url, { ...opts, headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) } });
    let d = {}; try { d = JSON.parse(r.data || '{}'); } catch {}
    return { status: r.status, d, retryAfter: r.retryAfter, raw: r.data };
  }
  const b64bytes = b64 => { const bin = atob(b64), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; };
  return { request, json, b64bytes };
})();
