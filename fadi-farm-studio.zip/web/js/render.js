/* Fadi Farm — تحميل الوسائط، الرسم على اللوحة، التشغيل والتصدير */
'use strict';

const Media = {
  MAX_BYTES: 150e6,

  /* ينزّل الملف كـ Blob (حتى يبقى التصدير ممكناً). يجرّب الروابط بالترتيب. */
  async fetchBlob(urls, { onProgress, signal } = {}) {
    let last = 'لا يوجد رابط للملف';
    for (const url of urls) {
      if (!url) continue;
      try {
        const r = await fetch(url, { signal, mode: 'cors', credentials: 'omit', referrerPolicy: 'no-referrer' });
        if (!r.ok) { last = `الخادم رفض الملف (${r.status})`; continue; }
        const total = +r.headers.get('content-length') || 0;
        if (total > this.MAX_BYTES) { last = 'الملف كبير جداً'; continue; }
        if (!r.body || !onProgress) { const b = await r.blob(); if (b.size > 500) return b; continue; }
        const reader = r.body.getReader(), parts = []; let got = 0;
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          parts.push(value); got += value.length;
          if (got > this.MAX_BYTES) { reader.cancel(); throw new Error('big'); }
          onProgress(total ? got / total : 0, got);
        }
        const b = new Blob(parts, { type: r.headers.get('content-type') || '' });
        if (b.size > 500) return b;
      } catch (e) {
        if (e.name === 'AbortError') throw e;
        last = e.message === 'big' ? 'الملف أكبر من 150MB' : 'المصدر يمنع التنزيل المباشر';
      }
    }
    throw new Error(last);
  },

  element(blob, type) {
    const url = URL.createObjectURL(blob);
    return new Promise((res, rej) => {
      if (type === 'video') {
        const v = document.createElement('video');
        Object.assign(v, { muted: true, loop: true, playsInline: true, preload: 'auto' });
        v.setAttribute('playsinline', '');
        v.onloadeddata = () => res(v);
        v.onerror = () => rej(new Error('صيغة الفيديو غير مدعومة على هذا الجهاز'));
        v.src = url;
      } else {
        const im = new Image();
        im.decoding = 'async';
        im.onload = () => res(im);
        im.onerror = () => rej(new Error('تعذّر فتح الصورة'));
        im.src = url;
      }
    });
  },
};

const Renderer = (() => {
  let cv, g, logoImg = null, logoSrc = '';
  const brand = new Image(); brand.src = 'icons/logo.png';

  function init(canvas) { cv = canvas; g = cv.getContext('2d', { alpha: false }); }

  function size(w, h) { cv.width = w; cv.height = h; }

  function timeline(scenes) {
    const st = []; let a = 0;
    scenes.forEach(s => { st.push(a); a += s.d; });
    return { st, total: a };
  }

  function sceneAt(t, scenes, st) {
    let i = 0;
    while (i < scenes.length - 1 && st[i + 1] <= t) i++;
    return i;
  }

  function transDur(s) { return Settings.get().transition === 'cut' ? 0 : Math.min(0.6, s.d / 3); }

  function cover(el, isVid, W, H, zoom = 1, pan = 0) {
    const w = isVid ? el.videoWidth : el.naturalWidth, h = isVid ? el.videoHeight : el.naturalHeight;
    if (!w || !h) return;
    const k = Math.max(W / w, H / h) * zoom;
    const dw = w * k, dh = h * k;
    const ox = (W - dw) / 2 + pan * (dw - W) / 2, oy = (H - dh) / 2;
    g.drawImage(el, ox, oy, dw, dh);
  }

  function drawScene(s, i, p, W, H) {
    if (s.el && s.type === 'video' && s.el.readyState >= 2) {
      cover(s.el, true, W, H);
    } else if (s.el && s.type === 'image') {
      const dir = i % 2 ? 1 : -1;
      cover(s.el, false, W, H, 1.02 + 0.09 * p, dir * (0.5 - p) * 0.8);
    } else {
      const gr = g.createLinearGradient(0, 0, W, H);
      gr.addColorStop(0, '#16261a'); gr.addColorStop(1, '#3a5a2c');
      g.fillStyle = gr; g.fillRect(0, 0, W, H);
      if (brand.complete && brand.naturalWidth) {
        const a = g.globalAlpha, bw = Math.min(W * 0.55, H * 0.9), bh = bw * brand.naturalHeight / brand.naturalWidth;
        g.globalAlpha = a * 0.9; g.drawImage(brand, (W - bw) / 2, H * 0.42 - bh / 2, bw, bh); g.globalAlpha = a;
      }
    }
  }

  function wrap(text, maxW) {
    const words = text.split(/\s+/), lines = []; let c = '';
    for (const w of words) {
      const x = c ? c + ' ' + w : w;
      if (g.measureText(x).width > maxW && c) { lines.push(c); c = w; } else c = x;
    }
    if (c) lines.push(c);
    return lines;
  }

  function captions(text, p, W, H) {
    const s = Settings.get();
    if (s.captions === 'off' || !text) return;
    const portrait = H > W;
    const fs = Math.round((portrait ? W / 17 : H / 20) * s.captionSize);
    const rtl = /[֐-ࣿ]/.test(text);
    g.font = `700 ${fs}px "IBM Plex Sans Arabic", Tahoma, sans-serif`;
    g.direction = rtl ? 'rtl' : 'ltr'; g.textAlign = 'center'; g.textBaseline = 'alphabetic';
    const lines = wrap(text, W * (portrait ? 0.84 : 0.78));
    const per = 2, pages = Math.ceil(lines.length / per);
    const pg = Math.min(pages - 1, Math.floor(p * pages));
    const show = lines.slice(pg * per, pg * per + per);
    const lh = fs * 1.38, baseY = H * (portrait ? 0.80 : 0.90);
    if (s.captions === 'box') {
      const bw = Math.max(...show.map(l => g.measureText(l).width)) + fs * 1.2;
      const bh = lh * show.length + fs * 0.5;
      const bx = (W - bw) / 2, by = baseY - lh * (show.length - 1) - fs * 1.1;
      g.fillStyle = 'rgba(8,12,8,.62)';
      g.beginPath(); g.roundRect ? g.roundRect(bx, by, bw, bh, fs * 0.35) : g.rect(bx, by, bw, bh); g.fill();
    }
    show.forEach((l, j) => {
      const y = baseY - lh * (show.length - 1 - j);
      if (s.captions === 'outline') { g.lineJoin = 'round'; g.lineWidth = fs / 5; g.strokeStyle = '#000'; g.strokeText(l, W / 2, y); }
      g.fillStyle = '#fff'; g.fillText(l, W / 2, y);
    });
  }

  function logo(W, H) {
    const s = Settings.get();
    if (!s.logo) return;
    if (logoSrc !== s.logo) { logoSrc = s.logo; logoImg = new Image(); logoImg.src = s.logo; }
    if (!logoImg.complete || !logoImg.naturalWidth) return;
    const m = Math.min(W, H), lh = m * 0.11, lw = lh * logoImg.naturalWidth / logoImg.naturalHeight, pad = m * 0.035;
    const x = s.logoPos[1] === 'l' ? pad : W - lw - pad, y = s.logoPos[0] === 't' ? pad : H - lh - pad;
    g.globalAlpha = s.logoOpacity; g.drawImage(logoImg, x, y, lw, lh); g.globalAlpha = 1;
  }

  /* يرسم إطاراً عند الزمن t (بالثواني) */
  function draw(t, scenes) {
    const W = cv.width, H = cv.height;
    g.globalAlpha = 1; g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
    if (!scenes.length) return;
    const { st } = timeline(scenes);
    const i = sceneAt(t, scenes, st), s = scenes[i];
    const local = t - st[i], p = Math.max(0, Math.min(1, local / s.d));
    drawScene(s, i, p, W, H);
    const nx = scenes[i + 1], T = nx ? transDur(s) : 0;
    if (T && local > s.d - T) {
      g.globalAlpha = (local - (s.d - T)) / T;
      drawScene(nx, i + 1, 0, W, H);
      g.globalAlpha = 1;
    }
    // تدرّج خفيف أسفل الصورة لقراءة أوضح
    const sh = g.createLinearGradient(0, H * 0.6, 0, H);
    sh.addColorStop(0, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(0,0,0,.35)');
    g.fillStyle = sh; g.fillRect(0, H * 0.6, W, H * 0.4);
    captions(s.text, p, W, H);
    logo(W, H);
  }

  /* يشغّل/يوقف الفيديوهات حسب الزمن */
  function syncVideos(t, scenes, playing) {
    const { st } = timeline(scenes);
    scenes.forEach((s, i) => {
      if (!s.el || s.type !== 'video') return;
      const v = s.el, T = scenes[i - 1] ? transDur(scenes[i - 1]) : 0;
      const active = t >= st[i] - T - 0.05 && t < st[i] + s.d;
      if (active && playing) {
        if (v.paused) {
          const dur = v.duration || 1;
          try { v.currentTime = Math.max(0, t - st[i]) % dur; } catch {}
          v.play().catch(() => {});
        }
      } else if (!v.paused) v.pause();
    });
  }

  function seekVideos(t, scenes, onReady) {
    const { st } = timeline(scenes);
    const i = sceneAt(t, scenes, st);
    [i, i + 1].forEach(k => {
      const s = scenes[k];
      if (s?.el && s.type === 'video') {
        const dur = s.el.duration || 1;
        try { s.el.currentTime = Math.max(0, t - st[k]) % dur; } catch {}
        s.el.onseeked = onReady;
      }
    });
  }

  return { init, size, draw, syncVideos, seekVideos, timeline, get canvas() { return cv; } };
})();

/* المشغّل: الصوت هو الساعة المرجعية، والتصدير يسجّل اللوحة مع الصوت */
const Player = (() => {
  let ctx, src, t0 = 0, from = 0, raf = 0, playing = false, rec = null, chunks = [], wake = null, onTick, onEnd;

  function audioCtx() { return ctx ??= new (window.AudioContext || window.webkitAudioContext)(); }

  function pickMime() {
    if (!window.MediaRecorder) return null;
    return ['video/mp4;codecs=avc1.640028,mp4a.40.2', 'video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4',
      'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'].find(m => MediaRecorder.isTypeSupported(m)) || null;
  }

  async function start({ buf, scenes, at = 0, record = false, tick, end }) {
    stop(true);
    onTick = tick; onEnd = end;
    const c = audioCtx(); await c.resume();
    src = c.createBufferSource(); src.buffer = buf; src.connect(c.destination);
    if (record) {
      const mime = pickMime();
      if (!mime) throw new Error('هذا المتصفح لا يدعم تسجيل الفيديو. استخدم Chrome.');
      const dest = c.createMediaStreamDestination(); src.connect(dest);
      const stream = Renderer.canvas.captureStream(Settings.get().fps);
      dest.stream.getAudioTracks().forEach(tr => stream.addTrack(tr));
      const px = Renderer.canvas.width * Renderer.canvas.height;
      rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: px >= 1920 * 1080 * 0.9 ? 10e6 : 6e6, audioBitsPerSecond: 192e3 });
      chunks = [];
      rec.ondataavailable = e => e.data.size && chunks.push(e.data);
      rec.start(1000);
      at = 0;
      try { wake = await navigator.wakeLock?.request('screen'); } catch {}
    }
    from = at; t0 = c.currentTime + 0.15;
    // ارسم الإطار الأول قبل بدء الصوت
    Renderer.syncVideos(at, scenes, true);
    Renderer.draw(at, scenes);
    src.start(t0, at);
    playing = true;
    const loop = () => {
      const t = from + Math.max(0, c.currentTime - t0);
      if (t >= buf.duration) { finish(); return; }
      Renderer.syncVideos(t, scenes, true);
      Renderer.draw(t, scenes);
      onTick?.(t);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    function finish() {
      const r = rec;
      stop(false, scenes);
      onTick?.(buf.duration);
      if (r) {
        r.onstop = () => onEnd?.(new Blob(chunks, { type: r.mimeType }));
        if (r.state !== 'inactive') r.stop();
      } else onEnd?.(null);
    }
  }

  function stop(silent = true, scenes) {
    cancelAnimationFrame(raf);
    try { src?.stop(); } catch {}
    src = null;
    if (silent && rec && rec.state !== 'inactive') { rec.onstop = null; rec.stop(); }
    if (silent) rec = null;
    playing = false;
    try { wake?.release(); } catch {}
    wake = null;
    (scenes || App.scenes || []).forEach(s => s.el && s.type === 'video' && !s.el.paused && s.el.pause());
    if (!silent) rec = null;
  }

  return { start, stop, audioCtx, pickMime, get playing() { return playing; }, get recording() { return !!rec; } };
})();
