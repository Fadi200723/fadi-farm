/* Fadi Farm — تحميل الوسائط، الرسم على اللوحة، التشغيل والتصدير */
'use strict';

const Media = {
  MAX_BYTES: 150e6,

  /* ينزّل الملف كـ Blob (حتى يبقى التصدير ممكناً). يجرّب الروابط بالترتيب. */
  async fetchBlob(urls, { onProgress, signal } = {}) {
    let last = 'لا يوجد رابط للملف';
    for (const url of urls) {
      if (!url) continue;
      try {
        const r = await fetch(url, { signal, mode: 'cors', credentials: 'omit', referrerPolicy: 'no-referrer' });
        if (!r.ok) { last = `الخادم رفض الملف (${r.status})`; continue; }
        const total = +r.headers.get('content-length') || 0;
        if (total > this.MAX_BYTES) { last = 'الملف كبير جداً'; continue; }
        if (!r.body || !onProgress) { const b = await r.blob(); if (b.size > 500) return b; continue; }
        const reader = r.body.getReader(), parts = []; let got = 0;
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          parts.push(value); got += value.length;
          if (got > this.MAX_BYTES) { reader.cancel(); throw new Error('big'); }
          onProgress(total ? got / total : 0, got);
        }
        const b = new Blob(parts, { type: r.headers.get('content-type') || '' });
        if (b.size > 500) return b;
      } catch (e) {
        if (e.name === 'AbortError') throw e;
        last = e.message === 'big' ? 'الملف أكبر من 150MB' : 'المصدر يمنع التنزيل المباشر';
      }
    }
    if (window.nativeFetchBlob) {
      for (const url of urls) {
        if (!url) continue;
        try { const b = await window.nativeFetchBlob(url); if (b && b.size > 500 && b.size <= this.MAX_BYTES) return b; } catch (e) { last = 'تعذّر تنزيل الملف'; }
      }
    }
    throw new Error(last);
  },

  element(blob, type) {
    const url = URL.createObjectURL(blob);
    return new Promise((res, rej) => {
      if (type === 'video') {
        const v = document.createElement('video');
        Object.assign(v, { muted: true, loop: true, playsInline: true, preload: 'auto' });
        v.setAttribute('playsinline', '');
        v.onloadeddata = () => res(v);
        v.onerror = () => rej(new Error('صيغة الفيديو غير مدعومة على هذا الجهاز'));
        v.src = url;
      } else {
        const im = new Image();
        im.decoding = 'async';
        im.onload = () => res(im);
        im.onerror = () => rej(new Error('تعذّر فتح الصورة'));
        im.src = url;
      }
    });
  },
};

const Renderer = (() => {
  let cv, g, logoImg = null, logoSrc = '';
  const brand = new Image(); brand.src = 'icons/logo.png';

  function init(canvas) { cv = canvas; g = cv.getContext('2d', { alpha: false }); }

  function size(w, h) { cv.width = w; cv.height = h; }

  function timeline(scenes) {
    const st = []; let a = 0;
    scenes.forEach(s => { st.push(a); a += s.d; });
    return { st, total: a };
  }

  function sceneAt(t, scenes, st) {
    let i = 0;
    while (i < scenes.length - 1 && st[i + 1] <= t) i++;
    return i;
  }

  function transDur(s) { return Settings.get().transition === 'cut' ? 0 : Math.min(0.6, s.d / 3); }

  function cover(el, isVid, W, H, zoom = 1, pan = 0) {
    const w = isVid ? el.videoWidth : el.naturalWidth, h = isVid ? el.videoHeight : el.naturalHeight;
    if (!w || !h) return;
    const k = Math.max(W / w, H / h) * zoom;
    const dw = w * k, dh = h * k;
    const ox = (W - dw) / 2 + pan * (dw - W) / 2, oy = (H - dh) / 2;
    g.drawImage(el, ox, oy, dw, dh);
  }

  function drawScene(s, i, p, W, H) {
    if (s.el && s.type === 'video' && s.el.readyState >= 2) {
      cover(s.el, true, W, H);
    } else if (s.el && s.type === 'image') {
      const dir = i % 2 ? 1 : -1;
      cover(s.el, false, W, H, 1.02 + 0.09 * p, dir * (0.5 - p) * 0.8);
    } else {
      const gr = g.createLinearGradient(0, 0, W, H);
      gr.addColorStop(0, '#16261a'); gr.addColorStop(1, '#3a5a2c');
      g.fillStyle = gr; g.fillRect(0, 0, W, H);
      if (brand.complete && brand.naturalWidth) {
        const a = g.globalAlpha, bw = Math.min(W * 0.55, H * 0.9), bh = bw * brand.naturalHeight / brand.naturalWidth;
        g.globalAlpha = a * 0.9; g.drawImage(brand, (W - bw) / 2, H * 0.42 - bh / 2, bw, bh); g.globalAlpha = a;
      }
    }
  }

  function wrap(text, maxW) {
    const words = text.split(/\s+/), lines = []; let c = '';
    for (const w of words) {
      const x = c ? c + ' ' + w : w;
      if (g.measureText(x).width > maxW && c) { lines.push(c); c = w; } else c = x;
    }
    if (c) lines.push(c);
    return lines;
  }

  function captions(text, p, W, H) {
    const s = Settings.get();
    if (s.captions === 'off' || !text) return;
    const portrait = H > W;
    const fs = Math.round((portrait ? W / 17 : H / 20) * s.captionSize);
    const rtl = /[֐-ࣿ]/.test(text);
    g.font = `700 ${fs}px "IBM Plex Sans Arabic", Tahoma, sans-serif`;
    g.direction = rtl ? 'rtl' : 'ltr'; g.textAlign = 'center'; g.textBaseline = 'alphabetic';
    const lines = wrap(text, W * (portrait ? 0.84 : 0.78));
    const per = 2, pages = Math.ceil(lines.length / per);
    const pg = Math.min(pages - 1, Math.floor(p * pages));
    const show = lines.slice(pg * per, pg * per + per);
    const lh = fs * 1.38, baseY = H * (portrait ? 0.80 : 0.90);
    if (s.captions === 'box') {
      const bw = Math.max(...show.map(l => g.measureText(l).width)) + fs * 1.2;
      const bh = lh * show.length + fs * 0.5;
      const bx = (W - bw) / 2, by = baseY - lh * (show.length - 1) - fs * 1.1;
      g.fillStyle = 'rgba(8,12,8,.62)';
      g.beginPath(); g.roundRect ? g.roundRect(bx, by, bw, bh, fs * 0.35) : g.rect(bx, by, bw, bh); g.fill();
    }
    show.forEach((l, j) => {
      const y = baseY - lh * (show.length - 1 - j);
      if (s.captions === 'outline') { g.lineJoin = 'round'; g.lineWidth = fs / 5; g.strokeStyle = '#000'; g.strokeText(l, W / 2, y); }
      g.fillStyle = '#fff'; g.fillText(l, W / 2, y);
    });
  }

  function logo(W, H) {
    const s = Settings.get();
    if (!s.logo) return;
    if (logoSrc !== s.logo) { logoSrc = s.logo; logoImg = new Image(); logoImg.src = s.logo; }
    if (!logoImg.complete || !logoImg.naturalWidth) return;
    const m = Math.min(W, H), lh = m * 0.11, lw = lh * logoImg.naturalWidth / logoImg.naturalHeight, pad = m * 0.035;
    const x = s.logoPos[1] === 'l' ? pad : W - lw - pad, y = s.logoPos[0] === 't' ? pad : H - lh - pad;
    g.globalAlpha = s.logoOpacity; g.drawImage(logoImg, x, y, lw, lh); g.globalAlpha = 1;
  }

  /* يرسم إطاراً عند الزمن t (بالثواني) */
  function draw(t, scenes) {
    const W = cv.width, H = cv.height;
    g.globalAlpha = 1; g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
    if (!scenes.length) return;
    const { st } = timeline(scenes);
    const i = sceneAt(t, scenes, st), s = scenes[i];
    const local = t - st[i], p = Math.max(0, Math.min(1, local / s.d));
    drawScene(s, i, p, W, H);
    const nx = scenes[i + 1], T = nx ? transDur(s) : 0;
    if (T && local > s.d - T) {
      g.globalAlpha = (local - (s.d - T)) / T;
      drawScene(nx, i + 1, 0, W, H);
      g.globalAlpha = 1;
    }
    // تدرّج خفيف أسفل الصورة لقراءة أوضح
    const sh = g.createLinearGradient(0, H * 0.6, 0, H);
    sh.addColorStop(0, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(0,0,0,.35)');
    g.fillStyle = sh; g.fillRect(0, H * 0.6, W, H * 0.4);
    captions(s.text, p, W, H);
    logo(W, H);
  }

  /* يشغّل/يوقف الفيديوهات حسب الزمن */
  function syncVideos(t, scenes, playing) {
    const { st } = timeline(scenes);
    scenes.forEach((s, i) => {
      if (!s.el || s.type !== 'video') return;
      const v = s.el, T = scenes[i - 1] ? transDur(scenes[i - 1]) : 0;
      const active = t >= st[i] - T - 0.05 && t < st[i] + s.d;
      if (active && playing) {
        if (v.paused) {
          const dur = v.duration || 1;
          try { v.currentTime = (Math.max(0, t - st[i]) + (s.offset || 0)) % dur; } catch {}
          v.play().catch(() => {});
        }
      } else if (!v.paused) v.pause();
    });
  }

  function seekVideos(t, scenes, onReady) {
    const { st } = timeline(scenes);
    const i = sceneAt(t, scenes, st);
    [i, i + 1].forEach(k => {
      const s = scenes[k];
      if (s?.el && s.type === 'video') {
        const dur = s.el.duration || 1;
        try { s.el.currentTime = (Math.max(0, t - st[k]) + (s.offset || 0)) % dur; } catch {}
        s.el.onseeked = onReady;
      }
    });
  }

  return { init, size, draw, syncVideos, seekVideos, timeline, get canvas() { return cv; } };
})();

/* المشغّل: الصوت هو الساعة المرجعية، والتصدير يسجّل اللوحة مع الصوت */
/* التصدير الاحترافي: WebCodecs ← ملف MP4 قياسي بالمدة الكاملة (يفتح في المعرض ويوتيوب) */
const Exporter = (() => {
  const ok = () => typeof VideoEncoder !== 'undefined' && typeof AudioEncoder !== 'undefined' && typeof VideoFrame !== 'undefined' && typeof AudioData !== 'undefined';
  const toU8 = d => d instanceof ArrayBuffer ? new Uint8Array(d.slice(0)) : new Uint8Array(d.buffer.slice(d.byteOffset, d.byteOffset + d.byteLength));
  const wait = ms => new Promise(r => setTimeout(r, ms));

  async function pickVideo(w, h) {
    const br = w * h >= 1920 * 1080 * 0.9 ? 9e6 : w * h >= 1280 * 720 ? 5e6 : 3e6;
    for (const codec of ['avc1.42002A', 'avc1.420028', 'avc1.42001F', 'avc1.4D0028', 'avc1.640028']) {
      for (const hw of ['prefer-hardware', 'no-preference']) {
        const c = { codec, width: w, height: h, bitrate: br, framerate: 30, latencyMode: 'realtime', hardwareAcceleration: hw, avc: { format: 'avc' } };
        try { const r = await VideoEncoder.isConfigSupported(c); if (r.supported) return c; } catch {}
      }
    }
    return null;
  }

  async function pickAudio(ch) {
    const opts = [
      ['aac', { codec: 'mp4a.40.2', sampleRate: 48000, numberOfChannels: ch, bitrate: 160000 }],
      ['aac', { codec: 'mp4a.40.2', sampleRate: 44100, numberOfChannels: ch, bitrate: 160000 }],
      ['opus', { codec: 'opus', sampleRate: 48000, numberOfChannels: ch, bitrate: 128000 }],
    ];
    for (const [kind, cfg] of opts) { try { const r = await AudioEncoder.isConfigSupported(cfg); if (r.supported) return { kind, cfg }; } catch {} }
    return null;
  }

  async function resample(buf, sr, ch) {
    if (buf.sampleRate === sr && buf.numberOfChannels === ch) return buf;
    const off = new OfflineAudioContext(ch, Math.ceil(buf.duration * sr), sr);
    const s = off.createBufferSource(); s.buffer = buf; s.connect(off.destination); s.start();
    return off.startRendering();
  }

  async function encodeAudio(buf, a, onP) {
    const pcm = await resample(buf, a.cfg.sampleRate, a.cfg.numberOfChannels);
    const samples = []; let desc = null, err = null;
    const enc = new AudioEncoder({
      output: (chunk, meta) => {
        const d = new Uint8Array(chunk.byteLength); chunk.copyTo(d);
        samples.push({ ts: chunk.timestamp, dur: chunk.duration, key: true, data: d });
        if (!desc && meta?.decoderConfig?.description) desc = toU8(meta.decoderConfig.description);
      },
      error: e => { err = e; },
    });
    enc.configure(a.cfg);
    const ch = pcm.numberOfChannels, sr = pcm.sampleRate, N = 4800;
    const planes = Array.from({ length: ch }, (_, c) => pcm.getChannelData(c));
    for (let o = 0, k = 0; o < pcm.length; o += N, k++) {
      if (err) throw err;
      const n = Math.min(N, pcm.length - o), data = new Float32Array(n * ch);
      for (let c = 0; c < ch; c++) data.set(planes[c].subarray(o, o + n), c * n);
      const ad = new AudioData({ format: 'f32-planar', sampleRate: sr, numberOfFrames: n, numberOfChannels: ch, timestamp: Math.round(o / sr * 1e6), data });
      enc.encode(ad); ad.close();
      while (enc.encodeQueueSize > 40) await wait(4);
      if (k % 40 === 0) { onP?.(o / pcm.length); await wait(0); }
    }
    await enc.flush(); enc.close();
    if (err) throw err;
    if (!samples.length) throw new Error('لم يُرمَّز الصوت');
    const out = { samples, asc: null, preSkip: 312, inputRate: buf.sampleRate };
    if (a.kind === 'aac') {
      if (desc && desc.length >= 2) out.asc = desc;
      else { const fi = { 96000: 0, 88200: 1, 64000: 2, 48000: 3, 44100: 4, 32000: 5, 24000: 6, 22050: 7, 16000: 8 }[sr] ?? 3; out.asc = new Uint8Array([(2 << 3) | (fi >> 1), ((fi & 1) << 7) | (ch << 3)]); }
    } else if (desc && desc.length >= 19 && String.fromCharCode(...desc.slice(0, 8)) === 'OpusHead') {
      const v = new DataView(desc.buffer, desc.byteOffset); out.preSkip = v.getUint16(10, true); out.inputRate = v.getUint32(12, true) || 48000;
    }
    return out;
  }

  /* يبدأ جلسة تصدير؛ يرجع null إذا كان الجهاز لا يدعم WebCodecs */
  async function begin(buf, canvas, onPrep) {
    if (!ok()) return null;
    const w = canvas.width, h = canvas.height;
    const vcfg = await pickVideo(w, h); if (!vcfg) return null;
    const a = await pickAudio(Math.min(2, buf.numberOfChannels)); if (!a) return null;
    const audio = await encodeAudio(buf, a, onPrep);
    const vs = []; let avcC = null, err = null, lastTs = -1, lastKey = -10, closed = false;
    const venc = new VideoEncoder({
      output: (chunk, meta) => {
        if (!avcC && meta?.decoderConfig?.description) avcC = toU8(meta.decoderConfig.description);
        const d = new Uint8Array(chunk.byteLength); chunk.copyTo(d);
        vs.push({ ts: chunk.timestamp, key: chunk.type === 'key', data: d });
      },
      error: e => { err = e; },
    });
    venc.configure(vcfg);
    const fps = 30;
    return {
      kind: 'mp4',
      frame(t) {
        if (closed || err) return;
        const ts = lastTs < 0 ? 0 : Math.round(t * 1e6);
        if (lastTs >= 0 && ts - lastTs < 1e6 / fps * 0.8) return;
        if (venc.encodeQueueSize > 6) return;                 // الجهاز مشغول: تخطَّ إطاراً بدل التأخير
        const key = lastTs < 0 || t - lastKey >= 2;
        const f = new VideoFrame(canvas, { timestamp: ts });
        try { venc.encode(f, { keyFrame: key }); } finally { f.close(); }
        if (key) lastKey = t;
        lastTs = ts;
      },
      async end(duration) {
        closed = true;
        await venc.flush(); venc.close();
        if (err) throw err;
        if (!vs.length || !avcC) throw new Error('لم تُسجَّل إطارات فيديو');
        vs.sort((x, y) => x.ts - y.ts);
        const lastDur = Math.min(5, Math.max(1 / fps, duration - vs[vs.length - 1].ts / 1e6));
        const as = audio.samples, la = as[as.length - 1];
        return MP4.build([
          { kind: 'video', samples: vs, width: w, height: h, avcC, timescale: 90000, lastDur },
          { kind: 'audio', codec: a.kind, samples: as, sampleRate: a.cfg.sampleRate, channels: a.cfg.numberOfChannels, asc: audio.asc, preSkip: audio.preSkip, inputRate: audio.inputRate, timescale: a.cfg.sampleRate, bitrate: a.cfg.bitrate, lastDur: (la.dur || 21333) / 1e6 },
        ]);
      },
      cancel() { closed = true; try { venc.close(); } catch {} },
    };
  }

  return { begin, supported: ok };
})();

/* المشغّل: الصوت هو الساعة المرجعية. عند الخروج من التطبيق أثناء التصدير يتوقف مؤقتاً ثم يكمل */
const Player = (() => {
  let ctx, src, t0 = 0, from = 0, raf = 0, playing = false, rec = null, chunks = [], wake = null, session = null, curScenes = null, paused = false;

  function audioCtx() { return ctx ??= new (window.AudioContext || window.webkitAudioContext)(); }

  function pickMime() {
    if (!window.MediaRecorder) return null;
    return ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4;codecs=avc1.640028,mp4a.40.2', 'video/mp4',
      'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'].find(m => MediaRecorder.isTypeSupported(m)) || null;
  }

  async function start({ buf, scenes, at = 0, record = false, tick, end, prep }) {
    stop(true);
    curScenes = scenes;
    const c = audioCtx(); await c.resume();
    if (record) {
      at = 0;
      try { session = await Exporter.begin(buf, Renderer.canvas, prep); } catch (e) { console.warn('WebCodecs export unavailable', e); session = null; }
      if (!session) {
        const mime = pickMime();
        if (!mime) throw new Error('هذا الجهاز لا يدعم تصدير الفيديو');
        const dest = c.createMediaStreamDestination();
        const stream = Renderer.canvas.captureStream(Settings.get().fps);
        const px = Renderer.canvas.width * Renderer.canvas.height;
        rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: px >= 1920 * 1080 * 0.9 ? 10e6 : 6e6, audioBitsPerSecond: 192e3 });
        rec._dest = dest; dest.stream.getAudioTracks().forEach(tr => stream.addTrack(tr));
        chunks = [];
        rec.ondataavailable = e => e.data.size && chunks.push(e.data);
      }
      try { wake = await navigator.wakeLock?.request('screen'); } catch {}
    }
    src = c.createBufferSource(); src.buffer = buf; src.connect(c.destination);
    if (rec) { src.connect(rec._dest); rec.start(1000); }
    from = at; t0 = c.currentTime + 0.15; paused = false;
    Renderer.syncVideos(at, scenes, true);
    Renderer.draw(at, scenes);
    session?.frame(at);
    src.start(t0, at);
    playing = true;
    const loop = () => {
      if (!playing) return;
      const t = from + Math.max(0, c.currentTime - t0);
      if (t >= buf.duration) { finish(); return; }
      if (!paused) {
        Renderer.syncVideos(t, scenes, true);
        Renderer.draw(t, scenes);
        session?.frame(t);
        tick?.(t);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    function finish() {
      const r = rec, s = session;
      rec = null; session = null;
      stop(false, scenes);
      tick?.(buf.duration);
      if (s) s.end(buf.duration).then(b => end?.(b), e => { console.error(e); end?.(null, e); });
      else if (r) {
        r.onstop = () => end?.(new Blob(chunks, { type: r.mimeType }));
        if (r.state !== 'inactive') r.stop();
      } else end?.(null);
    }
  }

  function stop(silent = true, scenes) {
    cancelAnimationFrame(raf);
    try { src?.stop(); } catch {}
    src = null;
    if (silent) {
      if (rec && rec.state !== 'inactive') { rec.onstop = null; rec.stop(); }
      rec = null;
      session?.cancel(); session = null;
    }
    playing = false; paused = false;
    try { wake?.release(); } catch {}
    wake = null;
    if (ctx && ctx.state === 'suspended') ctx.resume().catch(() => {});
    (scenes || curScenes || App.scenes || []).forEach(s => s.el && s.type === 'video' && !s.el.paused && s.el.pause());
  }

  // الخروج من التطبيق أثناء التصدير: إيقاف مؤقت للساعة والتسجيل، ثم المتابعة عند العودة
  document.addEventListener('visibilitychange', async () => {
    if (!playing || !(rec || session)) return;
    if (document.hidden) {
      paused = true;
      try { await ctx.suspend(); } catch {}
      if (rec?.state === 'recording') rec.pause();
      (curScenes || []).forEach(s => s.el && s.type === 'video' && s.el.pause());
    } else {
      try { await ctx.resume(); } catch {}
      if (rec?.state === 'paused') rec.resume();
      try { wake = await navigator.wakeLock?.request('screen'); } catch {}
      paused = false;
    }
  });

  return { start, stop, audioCtx, pickMime, get playing() { return playing; }, get recording() { return !!(rec || session); } };
})();
