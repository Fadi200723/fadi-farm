/* Fadi Farm — تحميل الوسائط، الرسم على اللوحة، التشغيل والتصدير */
'use strict';

const Media = {
  MAX_BYTES: 150e6,

  /* ينزّل الملف كـ Blob (حتى يبقى التصدير ممكناً). يجرّب الروابط بالترتيب. */
  async fetchBlob(urls, { onProgress, signal } = {}) {
    let last = 'لا يوجد رابط للملف';
    for (const url of urls) {
      if (!url) continue;
      try {
        const r = await fetch(url, { signal, mode: 'cors', credentials: 'omit', referrerPolicy: 'no-referrer' });
        if (!r.ok) { last = `الخادم رفض الملف (${r.status})`; continue; }
        const total = +r.headers.get('content-length') || 0;
        if (total > this.MAX_BYTES) { last = 'الملف كبير جداً'; continue; }
        if (!r.body || !onProgress) { const b = await r.blob(); if (b.size > 500) return b; continue; }
        const reader = r.body.getReader(), parts = []; let got = 0;
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          parts.push(value); got += value.length;
          if (got > this.MAX_BYTES) { reader.cancel(); throw new Error('big'); }
          onProgress(total ? got / total : 0, got);
        }
        const b = new Blob(parts, { type: r.headers.get('content-type') || '' });
        if (b.size > 500) return b;
      } catch (e) {
        if (e.name === 'AbortError') throw e;
        last = e.message === 'big' ? 'الملف أكبر من 150MB' : 'المصدر يمنع التنزيل المباشر';
      }
    }
    if (window.nativeFetchBlob) {
      for (const url of urls) {
        if (!url) continue;
        try { const b = await window.nativeFetchBlob(url); if (b && b.size > 500 && b.size <= this.MAX_BYTES) return b; } catch (e) { last = 'تعذّر تنزيل الملف'; }
      }
    }
    throw new Error(last);
  },

  element(blob, type) {
    const url = URL.createObjectURL(blob);
    return new Promise((res, rej) => {
      if (type === 'video') {
        const v = document.createElement('video');
        Object.assign(v, { muted: true, loop: true, playsInline: true, preload: 'auto' });
        v.setAttribute('playsinline', '');
        v.onloadeddata = () => res(v);
        v.onerror = () => rej(new Error('صيغة الفيديو غير مدعومة على هذا الجهاز'));
        v.src = url;
      } else {
        const im = new Image();
        im.decoding = 'async';
        im.onload = () => res(im);
        im.onerror = () => rej(new Error('تعذّر فتح الصورة'));
        im.src = url;
      }
    });
  },
};

const Renderer = (() => {
  let cv, g, logoImg = null, logoSrc = '';

  function init(canvas) { cv = canvas; g = cv.getContext('2d', { alpha: false }); }

  function size(w, h) { cv.width = w; cv.height = h; hasLast = false; }

  function timeline(scenes) {
    const st = []; let a = 0;
    scenes.forEach(s => { st.push(a); a += s.d; });
    return { st, total: a };
  }

  function sceneAt(t, scenes, st) {
    let i = 0;
    while (i < scenes.length - 1 && st[i + 1] <= t) i++;
    return i;
  }

  function transDur(s) { return Settings.get().transition === 'cut' ? 0 : Math.min(0.6, s.d / 3); }

  const strong = () => typeof Channel !== 'undefined' && Channel.cur.montage === 'strong';
  function cover(el, isVid, W, H, zoom = 1, pan = 0, panY = 0) {
    const w = isVid ? el.videoWidth : el.naturalWidth, h = isVid ? el.videoHeight : el.naturalHeight;
    if (!w || !h) return;
    const k = Math.max(W / w, H / h) * zoom;
    const dw = w * k, dh = h * k;
    const ox = (W - dw) / 2 + pan * (dw - W) / 2, oy = (H - dh) / 2 + panY * (dh - H) / 2;
    g.drawImage(el, ox, oy, dw, dh);
  }

  /* حركة كاميرا احترافية متنوعة لكل مشهد (مثل المونتير): تقريب، تبعيد، تحريك أفقي، قطري */
  const smooth = x => x * x * (3 - 2 * x);
  function motion(i, p, isVid) {
    const q = smooth(Math.min(1, Math.max(0, p)));
    const m = i % 5;
    if (isVid) return [1.0 + 0.045 * q * (m % 2 ? 1 : -1) + (m % 2 ? 0 : 0.045), 0, 0];   // فيديو: دفع خفيف للداخل أو للخارج
    switch (m) {
      case 0: return [1.04 + 0.1 * q, 0, 0];                 // تقريب
      case 1: return [1.14 - 0.1 * q, 0, 0];                 // تبعيد
      case 2: return [1.12, -0.8 + 1.6 * q, 0];              // تحريك من اليسار لليمين
      case 3: return [1.12, 0.8 - 1.6 * q, 0];               // من اليمين لليسار
      default: return [1.06 + 0.08 * q, 0.5 - q, -0.4 + 0.8 * q];   // قطري
    }
  }

  /* يرسم لقطة المشهد. يرجع false إذا لم تكن جاهزة بعد (فيديو يُحمَّل أو يُقدَّم) */
  function drawScene(s, i, p, W, H, z = 1) {
    if (s.el && s.type === 'video' && s.el.readyState >= 2 && s.el.videoWidth) { const [zm, px, py] = motion(i, p, true); cover(s.el, true, W, H, zm * z * (strong() ? 1 + 0.04 * p : 1), px, py); return true; }
    if (s.el && s.type === 'image' && s.el.naturalWidth) { const [zm, px, py] = motion(i, p, false); cover(s.el, false, W, H, zm * z, px, py); return true; }
    return false;
  }

  /* تظليل الأطراف (Vignette) يعطي مظهراً سينمائياً */
  let vig = null;
  function vignette(W, H) {
    if (!vig || vig.width !== W || vig.height !== H) {
      vig = document.createElement('canvas'); vig.width = W; vig.height = H; const x = vig.getContext('2d');
      const gr = x.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.35, W / 2, H / 2, Math.hypot(W, H) * 0.56);
      gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,.42)'); x.fillStyle = gr; x.fillRect(0, 0, W, H);
    }
    g.drawImage(vig, 0, 0);
  }

  /* آخر إطار سليم: يُعرض بدل أي فراغ أثناء انتقال أو تحميل، فلا يظهر شعار ولا شاشة فارغة */
  let last = null, lastCtx = null, hasLast = false;
  function keepLast(W, H) {
    if (!last || last.width !== W || last.height !== H) { last = document.createElement('canvas'); last.width = W; last.height = H; lastCtx = last.getContext('2d'); hasLast = false; }
    lastCtx.drawImage(cv, 0, 0); hasLast = true;
  }
  function holdLast(W, H) {
    if (hasLast && last && last.width === W && last.height === H) { g.drawImage(last, 0, 0); return; }
    // لا شاشة خضراء: خلفية داكنة متحركة بلون القناة
    const acc = typeof Channel !== 'undefined' ? Channel.cur.accent : '#FFD23F', tt = performance.now() / 1000;
    g.fillStyle = '#07090f'; g.fillRect(0, 0, W, H);
    const gr = g.createRadialGradient(W * (0.5 + 0.2 * Math.sin(tt * 0.4)), H * 0.45, 0, W * 0.5, H * 0.5, Math.max(W, H) * 0.7);
    gr.addColorStop(0, acc + '40'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr; g.fillRect(0, 0, W, H);
  }
  function resetLast() { hasLast = false; }

  function wrap(text, maxW) {
    const words = text.split(/\s+/), lines = []; let c = '';
    for (const w of words) {
      const x = c ? c + ' ' + w : w;
      if (g.measureText(x).width > maxW && c) { lines.push(c); c = w; } else c = x;
    }
    if (c) lines.push(c);
    return lines;
  }

  function captions(text, p, W, H) {
    const s = Settings.get();
    if (s.captions === 'off' || !text) return;
    const portrait = H > W;
    const fs = Math.round((portrait ? W / 17 : H / 20) * s.captionSize);
    const rtl = /[֐-ࣿ]/.test(text);
    g.font = `700 ${fs}px "IBM Plex Sans Arabic", Tahoma, sans-serif`;
    g.direction = rtl ? 'rtl' : 'ltr'; g.textAlign = 'center'; g.textBaseline = 'alphabetic';
    const lines = wrap(text, W * (portrait ? 0.84 : 0.78));
    const per = 2, pages = Math.ceil(lines.length / per);
    const pg = Math.min(pages - 1, Math.floor(p * pages));
    const show = lines.slice(pg * per, pg * per + per);
    const lh = fs * 1.38, baseY = H * (portrait ? 0.80 : 0.90);
    if (s.captions === 'box') {
      const bw = Math.max(...show.map(l => g.measureText(l).width)) + fs * 1.2;
      const bh = lh * show.length + fs * 0.5;
      const bx = (W - bw) / 2, by = baseY - lh * (show.length - 1) - fs * 1.1;
      g.fillStyle = 'rgba(8,12,8,.62)';
      g.beginPath(); g.roundRect ? g.roundRect(bx, by, bw, bh, fs * 0.35) : g.rect(bx, by, bw, bh); g.fill();
    }
    show.forEach((l, j) => {
      const y = baseY - lh * (show.length - 1 - j);
      if (s.captions === 'outline') { g.lineJoin = 'round'; g.lineWidth = fs / 5; g.strokeStyle = '#000'; g.strokeText(l, W / 2, y); }
      g.fillStyle = '#fff'; g.fillText(l, W / 2, y);
    });
  }

  const easeOut = x => 1 - Math.pow(1 - Math.min(1, Math.max(0, x)), 3);
  const rr = (x, y, w, h, r) => { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); };

  /* السؤال في المشهد (الجملة المنتهية بـ ؟) */
  function questionOf(text) {
    const m = String(text || '').match(/[^.!؟?…\n]*[؟?]/);
    return m ? m[0].trim().replace(/^[،,\s]+/, '') : '';
  }

  /* بطاقة سؤال متحركة أعلى الشاشة */
  function questionCard(q, local, d, W, H) {
    const show = Math.min(d, 4.2), a = local < 0.35 ? local / 0.35 : local > show - 0.3 ? Math.max(0, (show - local) / 0.3) : 1;
    if (a <= 0) return;
    const portrait = H > W, u = Math.min(W, H) / 1080;
    const fs = Math.round((portrait ? 58 : 54) * u * 1.0);
    g.save(); g.globalAlpha = a;
    g.font = `700 ${fs}px "IBM Plex Sans Arabic", Tahoma, sans-serif`; g.direction = 'rtl'; g.textAlign = 'right'; g.textBaseline = 'middle';
    const maxW = W * (portrait ? 0.8 : 0.62), lines = wrap(q, maxW).slice(0, 2);
    const tw = Math.max(...lines.map(l => g.measureText(l).width)), icon = fs * 1.5, pad = fs * 0.7;
    const bw = tw + icon + pad * 2.6, bh = Math.max(icon + pad, lines.length * fs * 1.35 + pad * 1.2);
    const x = (W - bw) / 2, y = H * (portrait ? 0.16 : 0.1) + (1 - easeOut(local / 0.35)) * -40 * u;
    g.shadowColor = 'rgba(0,0,0,.45)'; g.shadowBlur = 30 * u; g.shadowOffsetY = 8 * u;
    g.fillStyle = 'rgba(14,20,12,.86)'; rr(x, y, bw, bh, 22 * u); g.fill();
    g.shadowColor = 'transparent';
    g.fillStyle = '#FFD23F'; rr(x, y, 10 * u, bh, 5 * u); g.fill();
    // دائرة علامة الاستفهام (تنبض)
    const pulse = 1 + 0.08 * Math.sin(local * 8), cx = x + bw - pad - icon / 2, cy = y + bh / 2;
    g.beginPath(); g.arc(cx, cy, icon / 2 * pulse, 0, Math.PI * 2); g.fillStyle = '#FFD23F'; g.fill();
    g.fillStyle = '#111'; g.textAlign = 'center'; g.font = `900 ${Math.round(icon * 0.72)}px "Lalezar", "IBM Plex Sans Arabic", sans-serif`; g.fillText('؟', cx, cy + icon * 0.04);
    g.font = `700 ${fs}px "IBM Plex Sans Arabic", Tahoma, sans-serif`; g.textAlign = 'right'; g.fillStyle = '#fff';
    lines.forEach((l, i) => g.fillText(l, cx - icon / 2 - pad * 0.6, cy + (i - (lines.length - 1) / 2) * fs * 1.35));
    g.restore();
  }

  /* تذكير الاشتراك والجرس (يتحرك مثل فيديوهات يوتيوب) */
  function bell(cx, cy, r, ang, color) {
    g.save(); g.translate(cx, cy - r * 0.9); g.rotate(ang); g.translate(0, r * 0.9);
    g.fillStyle = color; g.beginPath();
    g.moveTo(-r * 0.75, r * 0.55); g.quadraticCurveTo(-r * 0.62, r * 0.35, -r * 0.62, -r * 0.05);
    g.quadraticCurveTo(-r * 0.62, -r * 0.8, 0, -r * 0.85); g.quadraticCurveTo(r * 0.62, -r * 0.8, r * 0.62, -r * 0.05);
    g.quadraticCurveTo(r * 0.62, r * 0.35, r * 0.75, r * 0.55); g.closePath(); g.fill();
    g.beginPath(); g.arc(0, r * 0.68, r * 0.18, 0, Math.PI * 2); g.fill();
    g.beginPath(); g.arc(0, -r * 0.92, r * 0.12, 0, Math.PI * 2); g.fill();
    g.restore();
  }

  function cursor(x, y, s, pressed) {
    g.save(); g.translate(x, y); g.scale(s * (pressed ? 0.85 : 1), s * (pressed ? 0.85 : 1));
    g.beginPath(); g.moveTo(0, 0); g.lineTo(0, 34); g.lineTo(9, 26); g.lineTo(15, 39); g.lineTo(21, 36); g.lineTo(15, 23); g.lineTo(26, 23); g.closePath();
    g.fillStyle = '#fff'; g.fill(); g.lineWidth = 2.5; g.strokeStyle = '#000'; g.stroke();
    g.restore();
  }

  function subscribeReminder(lt, W, H) {
    const D = 4.6; if (lt < 0 || lt > D) return;
    const u = Math.min(W, H) / 1080, s = Settings.get();
    const leftSide = (s.logo && s.logoPos?.[1] === 'l') ? false : true;
    const inA = easeOut(lt / 0.45), outA = lt > D - 0.45 ? easeOut((D - lt) / 0.45) : 1, k = Math.min(inA, outA);
    const bh = 96 * u, bw = 300 * u, bellR = 39 * u, gap = 20 * u, pad = 44 * u;
    const totalW = bw + gap + bellR * 2 + 20 * u;
    const x0 = leftSide ? pad - (1 - k) * (totalW + pad) : W - pad - totalW + (1 - k) * (totalW + pad);
    const y0 = pad + (H > W ? 60 * u : 0) + (tagOn && leftSide ? 96 * u : 0);
    const subscribed = lt > 1.55, belled = lt > 2.55;
    g.save(); g.globalAlpha = Math.min(1, k * 1.2);
    // زر الاشتراك
    const press = lt > 1.45 && lt < 1.65 ? 0.94 : 1;
    g.save(); g.translate(x0 + bw / 2, y0 + bh / 2); g.scale(press, press);
    g.shadowColor = 'rgba(0,0,0,.4)'; g.shadowBlur = 18 * u; g.shadowOffsetY = 5 * u;
    g.fillStyle = subscribed ? '#606060' : '#FF0000'; rr(-bw / 2, -bh / 2, bw, bh, bh / 2); g.fill();
    g.shadowColor = 'transparent';
    g.fillStyle = '#fff'; g.font = `700 ${Math.round(44 * u)}px "IBM Plex Sans Arabic", Tahoma, sans-serif`;
    g.textAlign = 'center'; g.textBaseline = 'middle'; g.direction = 'rtl';
    g.fillText(subscribed ? 'تم الاشتراك ✓' : 'اشترك', 0, 2 * u);
    g.restore();
    // الجرس
    const bx = x0 + bw + gap + bellR + 10 * u, by = y0 + bh / 2;
    g.beginPath(); g.arc(bx, by, bellR + 10 * u, 0, Math.PI * 2); g.fillStyle = belled ? '#FFD23F' : 'rgba(0,0,0,.55)'; g.fill();
    const ring = belled && lt < 3.7 ? Math.sin((lt - 2.55) * 28) * 0.45 * (1 - (lt - 2.55) / 1.15) : 0;
    bell(bx, by + 2 * u, bellR * 0.78, ring, belled ? '#111' : '#fff');
    if (belled && lt < 3.7) { g.strokeStyle = '#FFD23F'; g.lineWidth = 4 * u; [-1, 1].forEach(d => { g.beginPath(); g.arc(bx, by, bellR + 18 * u + (lt * 40 % 10) * u, -0.5 + (d > 0 ? 0 : Math.PI), 0.5 + (d > 0 ? 0 : Math.PI)); g.stroke(); }); }
    // المؤشر: يتحرك للزر ثم للجرس
    let cx, cy, pr = false;
    if (lt < 0.9) { cx = x0 + bw * 1.2; cy = y0 + bh * 2.2; }
    else if (lt < 1.45) { const q = easeOut((lt - 0.9) / 0.55); cx = x0 + bw * (1.2 - 0.6 * q); cy = y0 + bh * (2.2 - 1.6 * q); }
    else if (lt < 2.0) { cx = x0 + bw * 0.6; cy = y0 + bh * 0.6; pr = lt < 1.65; }
    else if (lt < 2.45) { const q = easeOut((lt - 2.0) / 0.45); cx = x0 + bw * 0.6 + (bx - x0 - bw * 0.6) * q; cy = y0 + bh * 0.6; }
    else { cx = bx; cy = by + 4 * u; pr = lt > 2.45 && lt < 2.65; }
    if (lt > 0.5 && lt < D - 0.5) cursor(cx, cy, 2.1 * u, pr);
    // تلميح نصي صغير
    if (belled) { g.fillStyle = '#fff'; g.font = `700 ${Math.round(34 * u)}px "IBM Plex Sans Arabic", Tahoma, sans-serif`; g.textAlign = leftSide ? 'left' : 'right'; g.direction = 'rtl'; g.lineWidth = 6 * u; g.strokeStyle = 'rgba(0,0,0,.7)'; const tx = leftSide ? x0 : x0 + totalW; g.strokeText('فعّل الجرس', tx, y0 + bh + 44 * u); g.fillText('فعّل الجرس', tx, y0 + bh + 44 * u); }
    g.restore();
  }

  /* بطاقة «لايك + اشتراك + جرس» الكبيرة: تظهر لحظة نطق جملة الاشتراك في بداية الفيديو */
  const CTA_RE = /اشترك|إشترك|لايك|اللايك|الجرس|سبسكرايب/;
  let ctaCache = { k: '', w: null };
  function ctaWin(scenes, st) {
    if (typeof App === 'undefined' || !App.buf) return null;
    const total = scenes.reduce((a, x) => a + x.d, 0), k = scenes.length + '|' + total.toFixed(2) + '|' + (scenes[0]?.id || '');
    if (ctaCache.k === k) return ctaCache.w;
    let w = null;
    for (let i = 0; i < scenes.length && st[i] < Math.min(total * 0.4, 120); i++) {
      const sent = (scenes[i].text.match(/[^.!؟?…]+[.!؟?…]*/g) || []).find(x => CTA_RE.test(x));
      if (!sent) continue;
      try { const tm = Align.forScene(scenes[i], st[i], sent, App.buf); w = { a: st[i] + tm.at, d: Math.max(4.8, tm.dur + 0.8) }; } catch { w = { a: st[i], d: 4.8 }; }
      break;
    }
    ctaCache = { k, w };
    return w;
  }
  function thumbUp(cx, cy, r, color) {
    g.save(); g.translate(cx, cy); g.fillStyle = color;
    rr(-r * 0.55, -r * 0.1, r * 1.05, r * 0.85, r * 0.22); g.fill();               // الكف
    rr(-r * 0.9, -r * 0.05, r * 0.28, r * 0.8, r * 0.08); g.fill();                // الكُم
    g.beginPath(); g.moveTo(-r * 0.35, -r * 0.05); g.lineTo(-r * 0.1, -r * 0.85); g.quadraticCurveTo(r * 0.12, -r * 0.95, r * 0.12, -r * 0.6); g.lineTo(r * 0.05, -r * 0.05); g.closePath(); g.fill();  // الإبهام
    g.restore();
  }
  function ctaCard(lt, D, W, H) {
    if (lt < 0 || lt > D) return;
    const u = Math.min(W, H) / 1080, portrait = H > W;
    // دخول انزلاقي ناعم من الأسفل وخروج للأسفل (أسلوب الـ Lower third)
    const inK = easeOut(lt / 0.5), outK = lt > D - 0.45 ? easeOut((D - lt) / 0.45) : 1, slide = (1 - Math.min(inK, outK)) * 90 * u, pop = 0.84;
    const a = Math.min(1, lt / 0.3, (D - lt) / 0.4);
    const liked = lt > 1.0, subbed = lt > 1.9, belled = lt > 2.8;
    const bh = 104 * u, lw = 250 * u, sw = 330 * u, br = 52 * u, gap = 26 * u;
    const tw = lw + sw + br * 2 + gap * 2, x0 = (W - tw) / 2, y0 = (H - bh) / 2 + H * 0.06;   // وسط الفيديو فوق اللقطة العادية
    g.save(); g.globalAlpha = Math.max(0, a);
    g.translate(W / 2, y0 + bh / 2 + slide); g.scale(pop, pop); g.translate(-W / 2, -(y0 + bh / 2));
    g.shadowColor = 'rgba(0,0,0,.45)'; g.shadowBlur = 30 * u; g.shadowOffsetY = 10 * u;
    g.fillStyle = 'rgba(12,14,22,.62)'; rr(x0 - 26 * u, y0 - 22 * u, tw + 52 * u, bh + 44 * u, 40 * u); g.fill();
    g.shadowColor = 'transparent'; g.lineWidth = 2 * u; g.strokeStyle = 'rgba(255,255,255,.18)'; g.stroke();
    g.fillStyle = typeof Channel !== 'undefined' ? Channel.cur.accent : '#FFD23F'; rr(x0 + tw * 0.3, y0 + bh + 18 * u, tw * 0.4 * inK, 4 * u, 2 * u); g.fill();
    g.direction = 'rtl'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = `800 ${Math.round(46 * u)}px "IBM Plex Sans Arabic", Tahoma, sans-serif`;
    // ترتيب من اليمين: لايك ← اشتراك ← جرس
    const lx = x0 + tw - lw, sx = lx - gap - sw, bx = sx - gap - br;
    const lp = lt > 0.9 && lt < 1.1 ? 0.92 : 1;
    g.save(); g.translate(lx + lw / 2, y0 + bh / 2); g.scale(lp, lp);
    g.fillStyle = liked ? '#1d6ff2' : '#fff'; rr(-lw / 2, -bh / 2, lw, bh, bh / 2); g.fill();
    thumbUp(lw * 0.22, 4 * u, 34 * u, liked ? '#fff' : '#111');
    g.fillStyle = liked ? '#fff' : '#111'; g.fillText('لايك', -lw * 0.13, 3 * u);
    g.restore();
    if (liked && lt < 1.6) { const q = (lt - 1) / 0.6; g.globalAlpha = Math.max(0, a * (1 - q)); g.fillStyle = '#1d6ff2'; g.font = `900 ${Math.round(54 * u)}px "IBM Plex Sans Arabic", sans-serif`; g.fillText('+1', lx + lw * 0.72, y0 - 30 * u - q * 70 * u); g.globalAlpha = Math.max(0, a); g.font = `800 ${Math.round(46 * u)}px "IBM Plex Sans Arabic", Tahoma, sans-serif`; }
    const sp = lt > 1.8 && lt < 2.0 ? 0.93 : 1;
    g.save(); g.translate(sx + sw / 2, y0 + bh / 2); g.scale(sp, sp);
    g.fillStyle = subbed ? '#5f5f5f' : '#FF0000'; rr(-sw / 2, -bh / 2, sw, bh, bh / 2); g.fill();
    g.fillStyle = '#fff'; g.fillText(subbed ? 'تم الاشتراك ✓' : 'اشترك', 0, 3 * u);
    g.restore();
    const by = y0 + bh / 2;
    g.beginPath(); g.arc(bx, by, br, 0, Math.PI * 2); g.fillStyle = belled ? '#FFD23F' : 'rgba(255,255,255,.18)'; g.fill();
    const ring = belled && lt < 3.9 ? Math.sin((lt - 2.8) * 28) * 0.45 * (1 - (lt - 2.8) / 1.1) : 0;
    bell(bx, by + 3 * u, br * 0.62, ring, belled ? '#111' : '#fff');
    // المؤشر
    let cx, cy, pr = false;
    if (lt < 0.6) { cx = lx + lw * 0.5; cy = y0 + bh * 2; }
    else if (lt < 1.2) { cx = lx + lw * 0.5; cy = y0 + bh * (2 - 1.4 * easeOut((lt - 0.6) / 0.3)); pr = lt > 0.9 && lt < 1.1; }
    else if (lt < 1.8) { const q = easeOut((lt - 1.2) / 0.5); cx = lx + lw * 0.5 + (sx + sw * 0.5 - lx - lw * 0.5) * q; cy = y0 + bh * 0.6; }
    else if (lt < 2.5) { cx = sx + sw * 0.5; cy = y0 + bh * 0.6; pr = lt < 2.0; }
    else { const q = easeOut((lt - 2.5) / 0.3); cx = sx + sw * 0.5 + (bx - sx - sw * 0.5) * q; cy = y0 + bh * 0.6; pr = lt > 2.75 && lt < 2.95; }
    if (lt > 0.3 && lt < D - 0.3) cursor(cx, cy, 2.2 * u, pr);
    g.restore();
  }

  /* ترجمة احترافية متزامنة كلمة بكلمة (مثل CapCut): مجموعة كلمات تظهر لحظة نطقها، والكلمة الحالية ملوّنة */
  function sceneWs(s, start) {
    const k = s.text + '|' + start.toFixed(2) + '|' + s.d.toFixed(2);
    if (s._wsk !== k) { try { s._ws = typeof App !== 'undefined' && App.buf ? Align.sceneWords(s, start, App.buf) : []; } catch { s._ws = []; } s._wsk = k; }
    return s._ws;
  }
  function wordCaptions(s, start, t, W, H) {
    const ws = sceneWs(s, start); if (!ws.length) return;
    let wi = ws.findIndex(w => t < w.t1);
    if (wi < 0) { if (t - ws[ws.length - 1].t1 < 0.3) wi = ws.length - 1; else return; }
    if (t < ws[wi].t0 - 0.08) { if (wi > 0 && t - ws[wi - 1].t1 < 0.35) wi--; else return; }
    // تقسيم ذكي: مجموعات حتى 5 كلمات لا تعبر نهاية جملة
    const groups = []; let cur = [];
    ws.forEach((w, i) => { cur.push(i); if (cur.length >= 5 || /[.!؟?…،,]$/.test(w.w)) { groups.push(cur); cur = []; } });
    if (cur.length) groups.push(cur);
    const grp = groups.find(gp => gp.includes(wi)); if (!grp) return;
    const portrait = H > W, u = Math.min(W, H) / 1080, fs = Math.round((portrait ? 70 : 60) * u * (Settings.get().captionSize || 1));
    g.save();
    g.font = `800 ${fs}px "IBM Plex Sans Arabic", Tahoma, sans-serif`; g.direction = 'rtl'; g.textAlign = 'right'; g.textBaseline = 'middle';
    const words = grp.map(i => ws[i].w.replace(/[.،,]$/, '')), sp = fs * 0.3, wd = words.map(w => g.measureText(w).width);
    const total = wd.reduce((a, b) => a + b, 0) + sp * (words.length - 1), y = H * (portrait ? 0.78 : 0.86);
    const age = t - ws[grp[0]].t0, ga = Math.min(1, Math.max(0, age / 0.15));
    // شريط خلفي زجاجي
    g.globalAlpha = 0.55 * ga; g.fillStyle = '#000'; rr(W / 2 - total / 2 - fs * 0.45, y - fs * 0.78, total + fs * 0.9, fs * 1.56, fs * 0.35); g.fill();
    let x = W / 2 + total / 2;
    const acc = typeof Channel !== 'undefined' ? Channel.cur.accent : '#FFD23F';
    grp.forEach((idx, k) => {
      const on = idx === wi, said = idx < wi, pop = on ? 1 + 0.08 * Math.max(0, 1 - (t - ws[idx].t0) / 0.18) : 1;
      g.save(); g.globalAlpha = ga * (said || on ? 1 : 0.78); g.translate(x - wd[k] / 2, y); g.scale(pop, pop);
      g.textAlign = 'center'; g.lineJoin = 'round'; g.lineWidth = fs * 0.14; g.strokeStyle = 'rgba(0,0,0,.85)'; g.strokeText(words[k], 0, 0);
      g.fillStyle = on ? acc : '#fff'; g.fillText(words[k], 0, 0);
      g.restore();
      x -= wd[k] + sp;
    });
    g.restore();
  }

  /* متى تظهر الجملة: لحظة نطقها في الصوت */
  function fxTiming(s, start) {
    if (typeof App === 'undefined' || !App.buf || !s.fx) return null;
    const k = s.fx.text + '|' + (s.fx.anchor || '') + '|' + start.toFixed(2) + '|' + s.d.toFixed(2);
    if (s._tmk !== k) { try { s._tm = Align.forScene(s, start, s.fx.text, App.buf, s.fx.anchor); } catch { s._tm = null; } s._tmk = k; }
    return s._tm;
  }

  /* إطار شفاف كامل (مثل لوغو مجرى 16:9): يُرسم كما هو فوق الفيديو بنفس المكان والحجم */
  let logoBox = null;
  function overlayBox(img) {
    if (logoBox?.img === img) return logoBox.box;
    let box = null;
    try {
      const w = 320, h = Math.round(320 * img.naturalHeight / img.naturalWidth), c = document.createElement('canvas'); c.width = w; c.height = h;
      const x = c.getContext('2d'); x.drawImage(img, 0, 0, w, h); const d = x.getImageData(0, 0, w, h).data;
      let x0 = w, y0 = h, x1 = 0, y1 = 0;
      for (let yy = 0; yy < h; yy++) for (let xx = 0; xx < w; xx++) if (d[(yy * w + xx) * 4 + 3] > 20) { x0 = Math.min(x0, xx); y0 = Math.min(y0, yy); x1 = Math.max(x1, xx); y1 = Math.max(y1, yy); }
      const k = img.naturalWidth / w;
      if (x1 > x0) box = { x: x0 * k, y: y0 * k, w: (x1 - x0 + 1) * k, h: (y1 - y0 + 1) * k };
    } catch {}
    logoBox = { img, box };
    return box;
  }
  function logo(W, H) {
    const s = Settings.get();
    if (!s.logo) return;
    if (logoSrc !== s.logo) { logoSrc = s.logo; logoImg = new Image(); logoImg.src = s.logo; }
    if (!logoImg.complete || !logoImg.naturalWidth) return;
    const iw = logoImg.naturalWidth, ih = logoImg.naturalHeight, ar = iw / ih;
    g.globalAlpha = s.logoOpacity ?? 1;
    if (ar > 1.6 && ar < 1.9 && iw >= 960) {
      if (W > H) { g.drawImage(logoImg, 0, 0, W, H); g.globalAlpha = 1; return; }       // أفقي: الإطار كما هو تماماً
      const b = overlayBox(logoImg);
      if (b) { const k = W / 1080 * (1920 / iw) * 0.9, bw = b.w * k, bh = b.h * k, pad = W * 0.04; g.drawImage(logoImg, b.x, b.y, b.w, b.h, W - bw - pad, pad + H * 0.03, bw, bh); }
      g.globalAlpha = 1; return;
    }
    const m = Math.min(W, H), lh = m * (ar > 2.2 ? 0.085 : 0.11), lw = lh * ar, pad = m * 0.035;
    const x = s.logoPos[1] === 'l' ? pad : W - lw - pad, y = s.logoPos[0] === 't' ? pad : H - lh - pad;
    g.drawImage(logoImg, x, y, lw, lh); g.globalAlpha = 1;
  }

  /* هاشتاغ الموضوع أعلى اليسار طوال الفيديو (اختياري) */
  let tagOn = false;
  function topicTag(t, W, H) {
    const set = Settings.get(), txt = (typeof App !== 'undefined' ? App.tag : '') || '';
    tagOn = set.topicTag === true && !!txt.replace('#', '').trim();
    if (!tagOn) return;
    const u = Math.min(W, H) / 1080, fs = Math.round(40 * u), label = '#' + txt.replace(/^#+/, '').trim().replace(/\s+/g, '_');
    const k = Math.min(1, t / 0.6), e = 1 - Math.pow(1 - k, 3);
    g.save(); g.font = `800 ${fs}px "IBM Plex Sans Arabic", Tahoma, sans-serif`; g.direction = 'rtl'; g.textAlign = 'center'; g.textBaseline = 'middle';
    const w = g.measureText(label).width + fs * 1.2, h = fs * 1.7, x = 44 * u - (1 - e) * (w + 60 * u), y = 44 * u + (H > W ? 60 * u : 0);
    const acc = typeof Channel !== 'undefined' ? Channel.cur.accent : '#2E8BFF';
    g.shadowColor = 'rgba(0,0,0,.4)'; g.shadowBlur = 16 * u; g.shadowOffsetY = 4 * u;
    g.fillStyle = 'rgba(10,12,20,.72)'; rr(x, y, w, h, h / 2); g.fill(); g.shadowColor = 'transparent';
    g.fillStyle = acc; rr(x, y, 8 * u, h, 4 * u); g.fill();
    g.fillStyle = '#fff'; g.fillText(label, x + w / 2 + 3 * u, y + h / 2 + 2 * u);
    g.restore();
  }

  /* يرسم إطاراً عند الزمن t (بالثواني) */
  function draw(t, scenes) {
    const W = cv.width, H = cv.height;
    g.globalAlpha = 1; g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
    if (!scenes.length) return;
    const { st } = timeline(scenes);
    const i = sceneAt(t, scenes, st), s = scenes[i];
    const local = t - st[i], p = Math.max(0, Math.min(1, local / s.d));
    // مونتاج قوي (مجرى): ضربة زووم قصيرة عند كل قطع
    const punch = strong() && local < 0.32 ? 1 + 0.1 * Math.pow(1 - local / 0.32, 2) : 1;
    let ok = drawScene(s, i, p, W, H, punch);
    if (!ok) {
      // مشهد بلا لقطة جاهزة: أقرب لقطة متاحة قبله، وإلا آخر إطار
      for (let k = 1; k < scenes.length && !ok; k++) {
        for (const pv of [scenes[i - k], scenes[i + k]]) if (!ok && pv && pv.el && (pv.type === 'image' || pv.el.readyState >= 2)) ok = drawScene(pv, i + 1, p, W, H);
      }
      if (!ok) holdLast(W, H);
    }
    const nx = scenes[i + 1], T = nx ? transDur(s) : 0;
    if (T && local > s.d - T && ok) {
      g.globalAlpha = (local - (s.d - T)) / T;
      drawScene(nx, i + 1, 0, W, H);       // إذا لم تجهز اللقطة التالية لا يُرسم شيء فوق الحالية
      g.globalAlpha = 1;
    }
    if (ok) keepLast(W, H);
    vignette(W, H);
    if (strong() && i > 0 && local < 0.09) { g.fillStyle = `rgba(255,255,255,${0.5 * (1 - local / 0.09)})`; g.fillRect(0, 0, W, H); }
    // تدرّج خفيف أسفل الصورة لقراءة أوضح
    const sh = g.createLinearGradient(0, H * 0.6, 0, H);
    sh.addColorStop(0, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(0,0,0,.35)');
    g.fillStyle = sh; g.fillRect(0, H * 0.6, W, H * 0.4);
    const set = Settings.get();
    const fxOn = set.questionCards !== false && !!s.fx && Fx.draw(g, s.fx, local, s.d, W, H, fxTiming(s, st[i]));
    // الترجمة: في الوضع الاحترافي تظهر الجمل المهمة فقط (المؤثرات)، وفي الأوضاع الأخرى تختفي أثناء المؤثر
    const every = set.subEvery || 30, total = scenes.reduce((a, x) => a + x.d, 0);
    const cw = set.subRemind !== false ? ctaWin(scenes, st) : null, inCta = cw && t >= cw.a && t <= cw.a + cw.d;
    if (set.captions === 'words') { if (!fxOn && !inCta) wordCaptions(s, st[i], t, W, H); }
    else if (set.captions !== 'smart' && !fxOn) captions(s.text, p, W, H);
    logo(W, H);
    topicTag(t, W, H);
    if (inCta) ctaCard(t - cw.a, cw.d, W, H);
    else if (set.subRemind !== false && t > every - 1 && t < total - 6 && !(cw && Math.abs(t - cw.a) < every)) subscribeReminder((t % every), W, H);
  }

  /* يشغّل/يوقف الفيديوهات حسب الزمن */
  function syncVideos(t, scenes, playing) {
    const { st } = timeline(scenes);
    scenes.forEach((s, i) => {
      if (!s.el || s.type !== 'video') return;
      const v = s.el, T = scenes[i - 1] ? transDur(scenes[i - 1]) : 0;
      const active = t >= st[i] - T - 0.05 && t < st[i] + s.d;
      if (active && playing) {
        if (v.paused) {
          const dur = v.duration || 1;
          try { v.currentTime = (Math.max(0, t - st[i]) + (s.offset || 0)) % dur; } catch {}
          v.play().catch(() => {});
        }
      } else if (!v.paused) v.pause();
    });
  }

  function seekVideos(t, scenes, onReady) {
    const { st } = timeline(scenes);
    const i = sceneAt(t, scenes, st);
    [i, i + 1].forEach(k => {
      const s = scenes[k];
      if (s?.el && s.type === 'video') {
        const dur = s.el.duration || 1;
        try { s.el.currentTime = (Math.max(0, t - st[k]) + (s.offset || 0)) % dur; } catch {}
        s.el.onseeked = onReady;
      }
    });
  }

  /* لقطة من الفيديو عند زمن t مرسومة على لوحة أخرى (لمعاينة المؤثرات) */
  function snapshot(t, scenes, target) {
    const W = cv.width, H = cv.height, tg = target.getContext('2d');
    if (target.height !== Math.round(target.width * H / W)) target.height = Math.round(target.width * H / W);
    draw(t, scenes);
    tg.drawImage(cv, 0, 0, target.width, target.height);
  }

  return { init, size, draw, snapshot, syncVideos, seekVideos, timeline, resetLast, ctaWin, get canvas() { return cv; } };
})();

/* المشغّل: الصوت هو الساعة المرجعية، والتصدير يسجّل اللوحة مع الصوت */
/* التصدير الاحترافي: WebCodecs ← ملف MP4 قياسي بالمدة الكاملة (يفتح في المعرض ويوتيوب) */
const Exporter = (() => {
  const ok = () => typeof VideoEncoder !== 'undefined' && typeof AudioEncoder !== 'undefined' && typeof VideoFrame !== 'undefined' && typeof AudioData !== 'undefined';
  const toU8 = d => d instanceof ArrayBuffer ? new Uint8Array(d.slice(0)) : new Uint8Array(d.buffer.slice(d.byteOffset, d.byteOffset + d.byteLength));
  const wait = ms => new Promise(r => setTimeout(r, ms));

  async function pickVideo(w, h) {
    const br = w * h >= 1920 * 1080 * 0.9 ? 9e6 : w * h >= 1280 * 720 ? 5e6 : 3e6;
    for (const codec of ['avc1.42002A', 'avc1.420028', 'avc1.42001F', 'avc1.4D0028', 'avc1.640028']) {
      for (const hw of ['prefer-hardware', 'no-preference']) {
        const c = { codec, width: w, height: h, bitrate: br, framerate: 30, latencyMode: 'realtime', hardwareAcceleration: hw, avc: { format: 'avc' } };
        try { const r = await VideoEncoder.isConfigSupported(c); if (r.supported) return c; } catch {}
      }
    }
    return null;
  }

  async function pickAudio(ch) {
    const opts = [
      ['aac', { codec: 'mp4a.40.2', sampleRate: 48000, numberOfChannels: ch, bitrate: 160000 }],
      ['aac', { codec: 'mp4a.40.2', sampleRate: 44100, numberOfChannels: ch, bitrate: 160000 }],
      ['opus', { codec: 'opus', sampleRate: 48000, numberOfChannels: ch, bitrate: 128000 }],
    ];
    for (const [kind, cfg] of opts) { try { const r = await AudioEncoder.isConfigSupported(cfg); if (r.supported) return { kind, cfg }; } catch {} }
    return null;
  }

  async function resample(buf, sr, ch) {
    if (buf.sampleRate === sr && buf.numberOfChannels === ch) return buf;
    const off = new OfflineAudioContext(ch, Math.ceil(buf.duration * sr), sr);
    const s = off.createBufferSource(); s.buffer = buf; s.connect(off.destination); s.start();
    return off.startRendering();
  }

  async function encodeAudio(buf, a, onP) {
    const pcm = await resample(buf, a.cfg.sampleRate, a.cfg.numberOfChannels);
    const samples = []; let desc = null, err = null;
    const enc = new AudioEncoder({
      output: (chunk, meta) => {
        const d = new Uint8Array(chunk.byteLength); chunk.copyTo(d);
        samples.push({ ts: chunk.timestamp, dur: chunk.duration, key: true, data: d });
        if (!desc && meta?.decoderConfig?.description) desc = toU8(meta.decoderConfig.description);
      },
      error: e => { err = e; },
    });
    enc.configure(a.cfg);
    const ch = pcm.numberOfChannels, sr = pcm.sampleRate, N = 4800;
    const planes = Array.from({ length: ch }, (_, c) => pcm.getChannelData(c));
    for (let o = 0, k = 0; o < pcm.length; o += N, k++) {
      if (err) throw err;
      const n = Math.min(N, pcm.length - o), data = new Float32Array(n * ch);
      for (let c = 0; c < ch; c++) data.set(planes[c].subarray(o, o + n), c * n);
      const ad = new AudioData({ format: 'f32-planar', sampleRate: sr, numberOfFrames: n, numberOfChannels: ch, timestamp: Math.round(o / sr * 1e6), data });
      enc.encode(ad); ad.close();
      while (enc.encodeQueueSize > 40) await wait(4);
      if (k % 40 === 0) { onP?.(o / pcm.length); await wait(0); }
    }
    await enc.flush(); enc.close();
    if (err) throw err;
    if (!samples.length) throw new Error('لم يُرمَّز الصوت');
    const out = { samples, asc: null, preSkip: 312, inputRate: buf.sampleRate };
    if (a.kind === 'aac') {
      if (desc && desc.length >= 2) out.asc = desc;
      else { const fi = { 96000: 0, 88200: 1, 64000: 2, 48000: 3, 44100: 4, 32000: 5, 24000: 6, 22050: 7, 16000: 8 }[sr] ?? 3; out.asc = new Uint8Array([(2 << 3) | (fi >> 1), ((fi & 1) << 7) | (ch << 3)]); }
    } else if (desc && desc.length >= 19 && String.fromCharCode(...desc.slice(0, 8)) === 'OpusHead') {
      const v = new DataView(desc.buffer, desc.byteOffset); out.preSkip = v.getUint16(10, true); out.inputRate = v.getUint32(12, true) || 48000;
    }
    return out;
  }

  /* يبدأ جلسة تصدير؛ يرجع null إذا كان الجهاز لا يدعم WebCodecs */
  async function begin(buf, canvas, onPrep) {
    if (!ok()) return null;
    const w = canvas.width, h = canvas.height;
    const vcfg = await pickVideo(w, h); if (!vcfg) return null;
    const a = await pickAudio(Math.min(2, buf.numberOfChannels)); if (!a) return null;
    const audio = await encodeAudio(buf, a, onPrep);
    const vs = []; let avcC = null, err = null, lastTs = -1, lastKey = -10, closed = false;
    const venc = new VideoEncoder({
      output: (chunk, meta) => {
        if (!avcC && meta?.decoderConfig?.description) avcC = toU8(meta.decoderConfig.description);
        const d = new Uint8Array(chunk.byteLength); chunk.copyTo(d);
        vs.push({ ts: chunk.timestamp, key: chunk.type === 'key', data: d });
      },
      error: e => { err = e; },
    });
    venc.configure(vcfg);
    const fps = 30;
    return {
      kind: 'mp4',
      frame(t) {
        if (closed || err) return;
        const ts = lastTs < 0 ? 0 : Math.round(t * 1e6);
        if (lastTs >= 0 && ts - lastTs < 1e6 / fps * 0.8) return;
        if (venc.encodeQueueSize > 6) return;                 // الجهاز مشغول: تخطَّ إطاراً بدل التأخير
        const key = lastTs < 0 || t - lastKey >= 2;
        const f = new VideoFrame(canvas, { timestamp: ts });
        try { venc.encode(f, { keyFrame: key }); } finally { f.close(); }
        if (key) lastKey = t;
        lastTs = ts;
      },
      async end(duration) {
        closed = true;
        await venc.flush(); venc.close();
        if (err) throw err;
        if (!vs.length || !avcC) throw new Error('لم تُسجَّل إطارات فيديو');
        vs.sort((x, y) => x.ts - y.ts);
        const lastDur = Math.min(5, Math.max(1 / fps, duration - vs[vs.length - 1].ts / 1e6));
        const as = audio.samples, la = as[as.length - 1];
        return MP4.build([
          { kind: 'video', samples: vs, width: w, height: h, avcC, timescale: 90000, lastDur },
          { kind: 'audio', codec: a.kind, samples: as, sampleRate: a.cfg.sampleRate, channels: a.cfg.numberOfChannels, asc: audio.asc, preSkip: audio.preSkip, inputRate: audio.inputRate, timescale: a.cfg.sampleRate, bitrate: a.cfg.bitrate, lastDur: (la.dur || 21333) / 1e6 },
        ]);
      },
      cancel() { closed = true; try { venc.close(); } catch {} },
    };
  }

  return { begin, supported: ok };
})();

/* المشغّل: الصوت هو الساعة المرجعية. عند الخروج من التطبيق أثناء التصدير يتوقف مؤقتاً ثم يكمل */
const Player = (() => {
  let ctx, src, t0 = 0, from = 0, raf = 0, playing = false, rec = null, chunks = [], wake = null, session = null, curScenes = null, paused = false, gen = 0;

  function audioCtx() { return ctx ??= new (window.AudioContext || window.webkitAudioContext)(); }

  function pickMime() {
    if (!window.MediaRecorder) return null;
    return ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4;codecs=avc1.640028,mp4a.40.2', 'video/mp4',
      'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'].find(m => MediaRecorder.isTypeSupported(m)) || null;
  }

  async function start({ buf, scenes, at = 0, record = false, tick, end, prep, frame }) {
    stop(true);
    const my = ++gen;
    curScenes = scenes;
    const c = audioCtx(); await c.resume();
    if (my !== gen) return;               // ضُغط «إيقاف» أثناء التحضير
    if (record) {
      at = 0;
      try { session = await Exporter.begin(buf, Renderer.canvas, prep); } catch (e) { console.warn('WebCodecs export unavailable', e); session = null; }
      if (!session) {
        const mime = pickMime();
        if (!mime) throw new Error('هذا الجهاز لا يدعم تصدير الفيديو');
        const dest = c.createMediaStreamDestination();
        const stream = Renderer.canvas.captureStream(Settings.get().fps);
        const px = Renderer.canvas.width * Renderer.canvas.height;
        rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: px >= 1920 * 1080 * 0.9 ? 10e6 : 6e6, audioBitsPerSecond: 192e3 });
        rec._dest = dest; dest.stream.getAudioTracks().forEach(tr => stream.addTrack(tr));
        chunks = [];
        rec.ondataavailable = e => e.data.size && chunks.push(e.data);
      }
      try { wake = await navigator.wakeLock?.request('screen'); } catch {}
    }
    if (my !== gen) { session?.cancel?.(); session = null; return; }
    src = c.createBufferSource(); src.buffer = buf;
    // أثناء التصدير: الصوت يُسجَّل في الفيديو فقط ولا يخرج من سماعة الهاتف (الساعة تبقى تعمل)
    if (record) { const mute = c.createGain(); mute.gain.value = 0; src.connect(mute); mute.connect(c.destination); }
    else src.connect(c.destination);
    if (rec) { src.connect(rec._dest); rec.start(1000); }
    from = at; t0 = c.currentTime + 0.15; paused = false;
    if (frame) frame(at); else { Renderer.syncVideos(at, scenes, true); Renderer.draw(at, scenes); }
    session?.frame(at);
    src.start(t0, at);
    playing = true;
    const loop = () => {
      if (!playing) return;
      const t = from + Math.max(0, c.currentTime - t0);
      if (t >= buf.duration) { finish(); return; }
      if (!paused) {
        if (frame) frame(t); else { Renderer.syncVideos(t, scenes, true); Renderer.draw(t, scenes); }
        session?.frame(t);
        tick?.(t);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    function finish() {
      const r = rec, s = session;
      rec = null; session = null;
      stop(false, scenes);
      tick?.(buf.duration);
      if (s) s.end(buf.duration).then(b => end?.(b), e => { console.error(e); end?.(null, e); });
      else if (r) {
        r.onstop = () => end?.(new Blob(chunks, { type: r.mimeType }));
        if (r.state !== 'inactive') r.stop();
      } else end?.(null);
    }
  }

  function stop(silent = true, scenes) {
    gen++;
    cancelAnimationFrame(raf);
    try { src?.stop(); } catch {}
    src = null;
    if (silent) {
      if (rec && rec.state !== 'inactive') { rec.onstop = null; rec.stop(); }
      rec = null;
      session?.cancel(); session = null;
    }
    playing = false; paused = false;
    try { wake?.release(); } catch {}
    wake = null;
    if (ctx && ctx.state === 'suspended') ctx.resume().catch(() => {});
    (scenes || curScenes || App.scenes || []).forEach(s => s.el && s.type === 'video' && !s.el.paused && s.el.pause());
  }

  // الخروج من التطبيق أثناء التصدير: إيقاف مؤقت للساعة والتسجيل، ثم المتابعة عند العودة
  document.addEventListener('visibilitychange', async () => {
    if (!playing || !(rec || session)) return;
    if (document.hidden) {
      paused = true;
      try { await ctx.suspend(); } catch {}
      if (rec?.state === 'recording') rec.pause();
      (curScenes || []).forEach(s => s.el && s.type === 'video' && s.el.pause());
    } else {
      try { await ctx.resume(); } catch {}
      if (rec?.state === 'paused') rec.resume();
      try { wake = await navigator.wakeLock?.request('screen'); } catch {}
      paused = false;
    }
  });

  return { start, stop, audioCtx, pickMime, get playing() { return playing; }, get recording() { return !!(rec || session); } };
})();
