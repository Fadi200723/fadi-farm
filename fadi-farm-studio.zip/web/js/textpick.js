/* Fadi — اختيار النص الذي يظهر على الصورة المصغرة أو غلاف الريل قبل نسخ الوصف وفتح Google Flow.
   اقتراحات بأسلوب القناة، بعضها يذكر المقدّم (مثلاً «صحفي مغربي…» أو «سائح منبهر…») */
'use strict';

const TextPick = (() => {
  /* الاسم القصير للمقدّم بالعربية + وصفه بالإنجليزية للصورة */
  const NOUN = { journalist: 'صحفي', tourist: 'سائح', local: 'ابن البلد', expert: 'خبير', storyteller: 'حكواتي', doctor: 'طبيب', teacher: 'معلّم', chef: 'شيف', tech: 'خبير تقنية', sports: 'معلّق', breeder: 'مربّي', vet: 'طبيب بيطري' };
  const EN = { journalist: 'journalist holding a microphone', tourist: 'amazed tourist with a backpack and a camera', local: 'local man from the place of the story', expert: 'expert', storyteller: 'storyteller', doctor: 'doctor in a white coat', teacher: 'teacher', chef: 'chef in a chef uniform', tech: 'tech reviewer', sports: 'sports commentator', breeder: 'farmer and animal breeder', vet: 'veterinarian in a vet coat' };
  const persona = () => { const p = Settings.get().persona; return p && p !== 'none' && NOUN[p] ? p : ''; };
  /* «صحفي مغربي» / «سائح مصري» */
  const who = () => { const p = persona(); return p ? `${NOUN[p]} ${Channel.dialect.nat}` : ''; };
  const whoEn = () => { const p = persona(); return p ? `a ${Channel.dialect.who} ${EN[p]}` : ''; };

  const topic = () => (Publish.promo?.ytTitle || App.projName || App.scenes[0]?.text || '').trim();
  function local() {
    const w = who(), t = (Publish.promo?.thumbTitle || App.projName || '').trim(), short = t.split(/\s+/).slice(0, 4).join(' ');
    const out = [];
    if (short) out.push(short);
    if (w) out.push(`${w} مصدوم!`, `${w} يكشف السر`, `${w} منبهر`, `${w} لا يصدّق`);
    else out.push('لن تصدّق!', 'السر الحقيقي', 'الحقيقة كاملة');
    return [...new Set(out)];
  }
  let cache = { k: '', list: [] };
  async function suggest() {
    const k = topic() + '|' + who() + '|' + Channel.id;
    if (cache.k === k && cache.list.length) return cache.list;
    let list = local();
    if (typeof LLM !== 'undefined' && LLM.available().length && topic()) {
      try {
        const w = who();
        const r = await AI.call([{ text: `You write the big text on a YouTube thumbnail for the channel "${Channel.cur.name}" (${Channel.cur.niche}).
Video topic: "${topic().slice(0, 200)}". Language: ${Channel.lang}.
Write 7 different thumbnail texts, each 2 to 5 Arabic words, punchy, curiosity-driven, no emojis, no hashtags.
${w ? `At least 4 of them must mention the narrator "${w}" and his reaction or point of view (examples of the style: "${w} مصدوم من…", "${w} يكشف…", "${w} في …", "${w} منبهر"), adapted to the topic.` : 'Some can mention a person reacting (e.g. a shocked journalist, an amazed tourist) if it fits the topic.'}
Return JSON: {"texts":["",""]}` }], { fast: true });
        const got = (r.texts || []).map(x => String(x).replace(/["«»#]/g, '').trim()).filter(x => x && x.split(/\s+/).length <= 7);
        if (got.length) list = [...new Set([...got, ...list])].slice(0, 9);
      } catch {}
    }
    cache = { k, list };
    return list;
  }

  /* يفتح النافذة ويرجع النص المختار، '' = بدون نص، null = إلغاء */
  function open({ title = 'النص على الصورة', current = '' } = {}) {
    const d = $('#textPickDlg'), inp = $('#tpText'), box = $('#tpSugg');
    $('#tpTitle').textContent = title;
    inp.value = current || '';
    box.innerHTML = '<span class="muted small">جاري تجهيز الاقتراحات…</span>';
    const fill = list => { box.innerHTML = list.map(t => `<button class="chip-btn" type="button" data-t="${esc(t)}">${esc(t)}</button>`).join(''); if (!inp.value && list[0]) inp.value = list[0]; };
    fill(local());
    suggest().then(list => { if (d.open) fill(list); }).catch(() => {});
    box.onclick = e => { const b = e.target.closest('[data-t]'); if (b) { inp.value = b.dataset.t; inp.focus(); } };
    return new Promise(res => {
      d.onclose = () => res(d.returnValue === 'ok' ? inp.value.trim() : d.returnValue === 'none' ? '' : null);
      d.returnValue = ''; d.showModal();
    });
  }

  /* يضع النص المختار داخل وصف الصورة (بدل الجملة العربية الموجودة بين علامتي تنصيص) */
  function inject(prompt, text) {
    if (!text) return prompt.replace(/Text:[^.]*\.|Include ONE short bold Arabic phrase[^.]*\./gi, '') + ' No text at all.';
    // لا تعارض: نحذف أي طلب «بدون نص» من الوصف قبل إضافة النص
    prompt = prompt.replace(/\s*No text at all\.?/gi, '').replace(/\s*Leave the top third calmer for a title added later\.?/gi, '').replace(/,?\s*no other text/gi, '');
    const re = /"[^"]*[؀-ۿ][^"]*"/;
    return re.test(prompt) ? prompt.replace(re, `"${text}"`) : prompt + ` Write the Arabic text "${text}" exactly once in huge bold Arabic letters, white fill with a thick black outline, perfectly legible and spelled exactly.`;
  }

  return { open, inject, who, whoEn, suggest };
})();
