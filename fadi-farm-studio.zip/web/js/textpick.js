/* Fadi — اختيار النص الذي يظهر على الصورة المصغرة أو غلاف الريل قبل نسخ الوصف وفتح Google Flow.
   اقتراحات بأسلوب القناة، بعضها يذكر المقدّم (مثلاً «صحفي مغربي…» أو «سائح منبهر…») */
'use strict';

const TextPick = (() => {
  /* الاسم القصير للمقدّم بالعربية + وصفه بالإنجليزية للصورة */
  const NOUN = { journalist: 'صحفي', tourist: 'سائح', local: 'ابن البلد', expert: 'خبير', storyteller: 'حكواتي', doctor: 'طبيب', teacher: 'معلّم', chef: 'شيف', tech: 'خبير تقنية', sports: 'معلّق', breeder: 'مربّي', vet: 'طبيب بيطري' };
  const EN = { journalist: 'journalist holding a microphone', tourist: 'amazed tourist with a backpack and a camera', local: 'local man from the place of the story', expert: 'expert', storyteller: 'storyteller', doctor: 'doctor in a white coat', teacher: 'teacher', chef: 'chef in a chef uniform', tech: 'tech reviewer', sports: 'sports commentator', breeder: 'farmer and animal breeder', vet: 'veterinarian in a vet coat' };
  const persona = () => { const p = Settings.get().persona; return p && p !== 'none' && NOUN[p] ? p : ''; };
  /* «صحفي مغربي» / «سائح مصري» */
  const who = () => { const p = persona(); return p ? `${NOUN[p]} ${Channel.dialect.nat}` : ''; };
  const whoEn = () => { const p = persona(); return p ? `a ${Channel.dialect.who} ${EN[p]}` : ''; };

  const topic = () => (Publish.promo?.ytTitle || App.projName || App.scenes[0]?.text || '').trim();
  function local() {
    const w = who(), t = (Publish.promo?.thumbTitle || App.projName || '').trim(), short = t.split(/\s+/).slice(0, 4).join(' ');
    const out = [];
    if (short) out.push(short);
    if (w) out.push(`${w} مصدوم!`, `${w} يكشف السر`, `${w} منبهر`, `${w} لا يصدّق`);
    else out.push('لن تصدّق!', 'السر الحقيقي', 'الحقيقة كاملة');
    return [...new Set(out)];
  }
  let cache = { k: '', list: [] };
  async function suggest() {
    const k = topic() + '|' + who() + '|' + Channel.id;
    if (cache.k === k && cache.list.length) return cache.list;
    let list = local();
    if (typeof LLM !== 'undefined' && LLM.available().length && topic()) {
      try {
        const w = who();
        const r = await AI.call([{ text: `You write the big text on a YouTube thumbnail for the channel "${Channel.cur.name}" (${Channel.cur.niche}).
Video topic: "${topic().slice(0, 200)}". Language: ${Channel.lang}.
Write 7 different thumbnail texts, each 2 to 5 Arabic words, punchy, curiosity-driven, no emojis, no hashtags.
${w ? `At least 4 of them must mention the narrator "${w}" and his reaction or point of view (examples of the style: "${w} مصدوم من…", "${w} يكشف…", "${w} في …", "${w} منبهر"), adapted to the topic.` : 'Some can mention a person reacting (e.g. a shocked journalist, an amazed tourist) if it fits the topic.'}
Return JSON: {"texts":["",""]}` }], { fast: true });
        const got = (r.texts || []).map(x => String(x).replace(/["«»#]/g, '').trim()).filter(x => x && x.split(/\s+/).length <= 7);
        if (got.length) list = [...new Set([...got, ...list])].slice(0, 9);
      } catch {}
    }
    cache = { k, list };
    return list;
  }

  /* يفتح النافذة ويرجع النص المختار، '' = بدون نص، null = إلغاء */
  function open({ title = 'النص على الصورة', current = '' } = {}) {
    const d = $('#textPickDlg'), inp = $('#tpText'), box = $('#tpSugg');
    $('#tpTitle').textContent = title;
    inp.value = current || '';
    // نصوص إضافية (حتى 3 نصوص على الصورة)
    const extra = $('#tpExtra'); extra.innerHTML = '';
    let focused = inp;
    const addExtra = (v = '') => { if (extra.children.length >= 2) return null; const x = document.createElement('input'); x.type = 'text'; x.value = v; x.placeholder = extra.children.length ? 'نص ثالث صغير (شارة أو رقم)' : 'نص ثانٍ (سطر أصغر)'; x.onfocus = () => focused = x; extra.appendChild(x); $('#tpAdd').hidden = extra.children.length >= 2; return x; };
    (TextPick.lastAll || []).slice(1).forEach(v => { if (current) addExtra(v); });
    $('#tpAdd').hidden = extra.children.length >= 2;
    $('#tpAdd').onclick = () => { const x = addExtra(); x?.focus(); };
    inp.onfocus = () => focused = inp;
    box.innerHTML = '<span class="muted small">جاري تجهيز الاقتراحات…</span>';
    const fill = list => { box.innerHTML = list.map(t => `<button class="chip-btn" type="button" data-t="${esc(t)}">${esc(t)}</button>`).join(''); if (!inp.value && list[0]) inp.value = list[0]; };
    fill(local());
    suggest().then(list => { if (d.open) fill(list); }).catch(() => {});
    box.onclick = e => { const b = e.target.closest('[data-t]'); if (b) { focused.value = b.dataset.t; focused.focus(); } };
    return new Promise(res => {
      d.onclose = () => {
        if (d.returnValue !== 'ok') { if (d.returnValue === 'none') TextPick.lastAll = []; return res(d.returnValue === 'none' ? '' : null); }
        const all = [inp.value, ...[...extra.querySelectorAll('input')].map(x => x.value)].map(x => x.trim()).filter(Boolean);
        TextPick.lastAll = all; res(all[0] || '');
      };
      d.returnValue = ''; d.showModal();
    });
  }

  /* يضع النصوص المختارة في وصف الصورة: يحذف أولاً كل نص قديم (حتى لا يظهر نصّان متعارضان)، ثم يوزّع النصوص الجديدة */
  function inject(prompt, text, all = null) { return Channel.loc0(inject0(prompt, text, all)); }
  function inject0(prompt, text, all = null) {
    const texts = (all && all.length ? all : [text]).map(x => String(x || '').trim()).filter(Boolean);
    // حذف كل جملة فيها نص عربي بين علامات تنصيص، أو تعليمات كتابة نص قديمة
    const OLD = /("[^"]*[؀-ۿ][^"]*"|«[^»]*»|^\s*Text:|Include ONE short bold Arabic phrase|Write the Arabic text|TEXT ON IMAGE|No text at all|Leave the top third calmer for a title)/i;
    prompt = prompt.split(/(?<=[.!?])\s+/).filter(x => !OLD.test(x)).join(' ').replace(/,?\s*no other text/gi, '').trim();
    if (!texts.length) return prompt + ' No text at all on the image.';
    const majra = typeof Channel !== 'undefined' && Channel.id === 'majra', banner = majra ? 'solid red (#D62828)' : 'solid bright yellow';
    if (texts.length === 1) return prompt + ` TEXT ON IMAGE (exactly this and nothing else): the Arabic headline "${texts[0]}" written exactly once in very large heavy bold Arabic letters, white with a thick black outline, perfectly legible and spelled exactly. No other text, letters or numbers anywhere.`;
    const roles = [
      `1) "${texts[0]}" = the MAIN headline, the largest text, very heavy bold Arabic letters, white with a thick black outline`,
      `2) "${texts[1]}" = second line, smaller, white bold letters inside a ${banner} banner right under or next to the headline`,
      texts[2] ? `3) "${texts[2]}" = a small badge or label (like a sticker or price/number tag) placed near the related subject` : '',
    ].filter(Boolean);
    return prompt + ` TEXT ON IMAGE (exactly these ${texts.length} texts and nothing else, each written exactly once and spelled exactly): ${roles.join('; ')}. Arrange them where they fit the composition best for this video, without covering the main face or subject, all perfectly legible. No other text, letters or numbers anywhere.`;
  }

  return { open, inject, who, whoEn, suggest, lastAll: [] };
})();
