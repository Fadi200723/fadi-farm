/* Fadi — قفل القنوات: كلمة سر و/أو بصمة / Face ID لكل قناة وحدها، تُطلب في كل مرة تدخل فيها للقناة.
   البصمة: أندرويد (BiometricPrompt)، ويندوز (Windows Hello)، الآيفون والمتصفح (Face ID / Touch ID عبر WebAuthn). */
'use strict';

const Bio = (() => {
  const b64 = u8 => btoa(String.fromCharCode(...new Uint8Array(u8)));
  const ub64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
  const rnd = n => crypto.getRandomValues(new Uint8Array(n));
  const webOk = () => !!(window.PublicKeyCredential && location.protocol === 'https:');

  async function available() {
    try {
      if (NATIVE) return !!(await capCall('FadiNative', 'bioAvailable', {}))?.ok;
      if (window.fadiDesktop?.bioAvailable) return !!(await window.fadiDesktop.bioAvailable());
      return webOk() && await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
    } catch { return false; }
  }
  /* تسجيل البصمة لقناة ← قيمة تُحفظ (true أو معرّف المفتاح في الآيفون/المتصفح) */
  async function enroll(label) {
    if (NATIVE || window.fadiDesktop?.bioAuth) return (await verify(true, 'تسجيل البصمة لـ ' + label)) ? true : null;
    const cred = await navigator.credentials.create({ publicKey: {
      challenge: rnd(32), rp: { name: 'Fadi', id: location.hostname },
      user: { id: rnd(16), name: 'fadi-' + label, displayName: label },
      pubKeyCredParams: [{ type: 'public-key', alg: -7 }, { type: 'public-key', alg: -257 }],
      authenticatorSelection: { authenticatorAttachment: 'platform', userVerification: 'required', residentKey: 'discouraged' }, timeout: 60000,
    } });
    return cred ? b64(cred.rawId) : null;
  }
  /* التحقق ← true/false */
  async function verify(saved, reason) {
    try {
      if (NATIVE) return !!(await capCall('FadiNative', 'bioAuth', { title: reason || 'Fadi', subtitle: 'ضع إصبعك أو انظر للكاميرا' }))?.ok;
      if (window.fadiDesktop?.bioAuth) return !!(await window.fadiDesktop.bioAuth(reason || 'Fadi'));
      if (typeof saved !== 'string') return false;
      const a = await navigator.credentials.get({ publicKey: { challenge: rnd(32), allowCredentials: [{ type: 'public-key', id: ub64(saved) }], userVerification: 'required', timeout: 60000, rpId: location.hostname } });
      return !!a;
    } catch { return false; }
  }
  const name = () => NATIVE ? 'البصمة / الوجه' : window.fadiDesktop ? 'Windows Hello (البصمة / الوجه / رمز PIN)' : 'Face ID / Touch ID';
  return { available, enroll, verify, name };
})();

const ChLock = (() => {
  const all = () => { try { return JSON.parse(localStorage.getItem('ff.chLock') || 'null') || migrate(); } catch { return {}; } };
  function migrate() {     // من النسخة السابقة (كلمة سر فقط)
    let o = {}; try { const old = JSON.parse(localStorage.getItem('ff.chPass') || '{}') || {}; for (const k in old) o[k] = { pass: old[k] }; } catch {}
    return o;
  }
  const save = o => localStorage.setItem('ff.chLock', JSON.stringify(o));
  const get = id => all()[id] || {};
  const set = (id, v) => { const o = all(); o[id] = { ...get(id), ...v }; if (!o[id].pass && !o[id].bio) delete o[id]; save(o); };
  const hash = (id, p) => AppId.hash('ch|' + id + '|' + p);
  const locked = id => { const l = get(id); return !!(l.pass || l.bio); };
  const label = id => Channel.LIST[id]?.name || '';

  async function askPass(id, title) {
    const p = await AppId.askPass(title || `كلمة سر قناة ${label(id)}`); if (p == null) return false;
    if ((await hash(id, p)) !== get(id).pass) { toast('كلمة السر غير صحيحة', 'err'); return false; }
    return true;
  }
  /* الدخول للقناة: البصمة أولاً إن كانت مفعّلة، وإلا (أو عند فشلها) كلمة السر */
  async function check(id) {
    const l = get(id); if (!l.pass && !l.bio) return true;
    if (l.bio && await Bio.verify(l.bio, `الدخول إلى ${label(id)}`)) return true;
    if (l.pass) return askPass(id);
    toast('لم يتم التحقق من البصمة', 'err'); return false;
  }
  /* تأكيد صاحب القناة قبل أي تغيير في القفل */
  async function owner(id) { const l = get(id); if (!l.pass && !l.bio) return true; if (l.pass) return askPass(id, `كلمة السر الحالية لقناة ${label(id)}`); return Bio.verify(l.bio, `تأكيد صاحب ${label(id)}`); }

  async function newPass() {
    const a = await AppId.askPass('كلمة السر الجديدة للقناة'); if (!a) return null;
    if (a.trim().length < 4) { toast('كلمة السر قصيرة جداً (4 أحرف على الأقل)', 'err'); return null; }
    const b = await AppId.askPass('أعد كتابة كلمة السر'); if (b == null) return null;
    if (a.trim().toLowerCase() !== b.trim().toLowerCase()) { toast('الكلمتان غير متطابقتين', 'err'); return null; }
    return a;
  }

  /* نافذة القفل (من الضغط المطوّل على القناة) */
  let cur = null;
  async function render() {
    const l = get(cur), bioOk = await Bio.available();
    $('#lkH').textContent = 'قفل قناة ' + label(cur);
    $('#lkState').textContent = (l.pass ? '🔒 كلمة سر' : '🔓 بدون كلمة سر') + ' · ' + (l.bio ? '✋ ' + Bio.name() + ' مفعّلة' : 'البصمة غير مفعّلة');
    $('#lkPassAdd').hidden = !!l.pass; $('#lkPassChange').hidden = !l.pass; $('#lkPassOff').hidden = !l.pass;
    $('#lkBioOn').hidden = !!l.bio || !bioOk; $('#lkBioOff').hidden = !l.bio;
    $('#lkBioOn').textContent = 'تفعيل ' + Bio.name();
    $('#lkBioNa').hidden = bioOk || !!l.bio;
  }
  async function open(id) { cur = id; await render(); $('#lockModal').hidden = false; }
  function bind() {
    $('#lkClose').onclick = () => { $('#lockModal').hidden = true; };
    $('#lkPassAdd').onclick = async () => { if (!(await owner(cur))) return; const p = await newPass(); if (p == null) return; set(cur, { pass: await hash(cur, p) }); render(); toast('أُضيفت كلمة سر للقناة ✓'); };
    $('#lkPassChange').onclick = async () => { if (!(await askPass(cur, 'كلمة السر الحالية للقناة'))) return; const p = await newPass(); if (p == null) return; set(cur, { pass: await hash(cur, p) }); render(); toast('تغيّرت كلمة سر القناة ✓'); };
    $('#lkPassOff').onclick = async () => { if (!(await askPass(cur, 'كلمة السر الحالية للقناة'))) return; set(cur, { pass: null }); render(); toast('أُلغيت كلمة سر القناة'); };
    $('#lkBioOn').onclick = async () => {
      if (!(await owner(cur))) return;
      try { const v = await Bio.enroll(label(cur)); if (!v) return toast('لم يتم تسجيل البصمة', 'err'); set(cur, { bio: v }); render(); toast(Bio.name() + ' مفعّلة لهذه القناة ✓'); }
      catch (e) { toast('تعذّر تفعيل البصمة: ' + (e.message || e), 'err', 7000); }
    };
    $('#lkBioOff').onclick = async () => { if (!(await owner(cur))) return; set(cur, { bio: null }); render(); toast('أُلغيت البصمة لهذه القناة'); };
  }
  /* للنقل لجهاز آخر: كلمات السر فقط (البصمة خاصة بكل جهاز) */
  const exportPass = () => { const o = all(), r = {}; for (const k in o) if (o[k].pass) r[k] = o[k].pass; return r; };
  const importPass = m => { if (!m) return; const o = all(); for (const k in m) o[k] = { ...(o[k] || {}), pass: m[k] }; save(o); };
  return { check, locked, open, bind, exportPass, importPass, get, set };
})();
