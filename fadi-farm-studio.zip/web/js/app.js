/* Fadi Farm Studio — منطق الواجهة */
'use strict';

const VERSION = '3.0.0';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = t => { t = Math.max(0, t || 0); const m = Math.floor(t / 60), s = Math.floor(t % 60); return `${m}:${String(s).padStart(2, '0')}`; };
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);

function toast(msg, kind = '', ms = 3800) {
  const el = document.createElement('div');
  el.className = 'toast ' + kind; el.textContent = msg;
  $('#toasts').append(el);
  setTimeout(() => el.remove(), ms);
}

function confirmBox(text, okLabel = 'تأكيد') {
  const d = $('#confirmDlg');
  $('#confirmText').textContent = text;
  d.querySelector('button[value=yes]').textContent = okLabel;
  return new Promise(res => { d.onclose = () => res(d.returnValue === 'yes'); d.returnValue = ''; d.showModal(); });
}

function setProgress(box, frac, text) {
  box.hidden = false;
  box.querySelector('.bar i').style.width = Math.round(Math.max(0, Math.min(1, frac)) * 100) + '%';
  box.querySelector('span').textContent = text;
}

/* ---------- تطبيق أندرويد (Capacitor) ---------- */
const NATIVE = !!(window.Capacitor && (window.Capacitor.isNativePlatform ? window.Capacitor.isNativePlatform() : window.Capacitor.platform !== 'web'));
const capPlugins = {};
function capCall(plugin, method, opts) {
  const C = window.Capacitor;
  let P = C?.Plugins?.[plugin];
  if (!(P && typeof P[method] === 'function') && C?.registerPlugin) P = capPlugins[plugin] ??= C.registerPlugin(plugin);
  if (P && typeof P[method] === 'function') return P[method](opts);
  if (C?.nativePromise) return C.nativePromise(plugin, method, opts);
  return Promise.reject(new Error('ميزة غير متاحة في هذه النسخة'));
}
const blobB64 = b => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1] || ''); r.onerror = rej; r.readAsDataURL(b); });

/* يحفظ ملفاً: تنزيل عادي في المتصفح، أو مجلد Documents/FadiFarm في تطبيق أندرويد */
async function saveFile(blob, name, { share = false } = {}) {
  if (!NATIVE) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 60000);
    return;
  }
  const CH = 3 * 1024 * 1024;
  const write = async dir => {
    const path = (dir === 'DOCUMENTS' ? 'FadiFarm/' : '') + name;
    for (let o = 0; o < blob.size; o += CH) {
      const data = await blobB64(blob.slice(o, o + CH));
      if (o === 0) await capCall('Filesystem', 'writeFile', { path, data, directory: dir, recursive: true });
      else await capCall('Filesystem', 'appendFile', { path, data, directory: dir });
    }
    return (await capCall('Filesystem', 'getUri', { path, directory: dir })).uri;
  };
  let uri, where;
  try { uri = await write('DOCUMENTS'); where = 'Documents/FadiFarm'; }
  catch { uri = await write('CACHE'); where = ''; }
  if (where) toast(`حُفظ في ${where}/${name}`, '', 5000);
  if (share || !where) await capCall('Share', 'share', { title: name, files: [uri], dialogTitle: 'حفظ أو مشاركة' }).catch(() => {});
}

/* تنزيل الوسائط عبر أندرويد مباشرة (يتجاوز قيود المتصفح على بعض المواقع) */
window.nativeFetchBlob = NATIVE ? async url => {
  const path = 'dl/' + Date.now() + '-' + Math.random().toString(36).slice(2, 8);
  await capCall('Filesystem', 'downloadFile', { url, path, directory: 'CACHE', recursive: true });
  try {
    const { uri } = await capCall('Filesystem', 'getUri', { path, directory: 'CACHE' });
    const r = await fetch(window.Capacitor.convertFileSrc(uri));
    if (!r.ok) throw new Error('read');
    return await r.blob();
  } finally { capCall('Filesystem', 'deleteFile', { path, directory: 'CACHE' }).catch(() => {}); }
} : null;

/* ---------- الحالة ---------- */
const App = {
  scenes: [], buf: null, audioName: '', projName: '', sel: 0,
  view: 'project',
  get dims() { const [w, h] = Settings.get().ratio.split('x').map(Number); return { w, h }; },
  get orientation() { const { w, h } = this.dims; return w > h ? 'landscape' : w < h ? 'portrait' : 'square'; },
  get minDim() { const { w, h } = this.dims; const m = Math.min(w, h); return Settings.get().dlQuality === 'high' ? m : Math.min(720, m); },
};

function newScene(text, d, kw = [], kind = 'video') {
  return { id: uid(), text, d, kw, kind, asset: null, blobKey: null, thumbData: '', el: null, type: '', busy: false };
}

/* ---------- الحفظ ---------- */
let saveTimer;
function save() {
  $('#saveState').textContent = 'يحفظ…';
  clearTimeout(saveTimer);
  saveTimer = setTimeout(async () => {
    try {
      await Store.set('project', {
        v: 2, name: App.projName, audioName: App.audioName, sel: App.sel,
        scenes: App.scenes.map(s => ({ id: s.id, text: s.text, d: s.d, kw: s.kw, kind: s.kind, ai: s.ai, offset: s.offset, asset: s.asset, blobKey: s.blobKey, thumbData: s.thumbData })),
      });
      $('#saveState').textContent = 'محفوظ';
    } catch { $('#saveState').textContent = 'لم يُحفظ'; }
  }, 500);
}

async function restore() {
  try {
    const p = await Store.get('project');
    if (!p) return;
    App.projName = p.name || ''; App.audioName = p.audioName || ''; App.sel = p.sel || 0;
    App.scenes = (p.scenes || []).map(s => Object.assign(newScene(s.text, s.d, s.kw, s.kind), s, { el: null, busy: false }));
    $('#projName').value = App.projName;
    const audio = await Store.getBlob('audio');
    if (audio) await loadAudio(audio, App.audioName, { keepScenes: true, silent: true });
  } catch (e) { console.warn(e); }
}

/* ---------- الوسائط الحيّة (تحميل كسول لتوفير ذاكرة الهاتف) ---------- */
const Live = {
  ensure(s) {
    if (s.el || !s.blobKey) return Promise.resolve();
    return s._loading ??= (async () => {
      const b = await Store.getBlob(s.blobKey);
      if (!b) { s.blobKey = null; s.asset = null; return; }
      s.el = await Media.element(b, s.asset.type);
      s.type = s.asset.type;
    })().catch(e => console.warn(e)).finally(() => { s._loading = null; });
  },
  release(s) {
    if (!s.el) return;
    const url = s.el.src;
    if (s.type === 'video') { s.el.pause(); s.el.removeAttribute('src'); s.el.load(); }
    URL.revokeObjectURL(url);
    s.el = null;
  },
  windowAt(i, back = 1, ahead = 3) {
    App.scenes.forEach((s, k) => {
      if (k >= i - back && k <= i + ahead) this.ensure(s);
      else if (k !== App.sel || App.view !== 'scenes') this.release(s);
    });
  },
};

function thumbOf(el, type) {
  try {
    const w = 320, ew = type === 'video' ? el.videoWidth : el.naturalWidth, eh = type === 'video' ? el.videoHeight : el.naturalHeight;
    if (!ew) return '';
    const c = document.createElement('canvas'); c.width = w; c.height = Math.round(w * 9 / 16);
    const x = c.getContext('2d'), k = Math.max(c.width / ew, c.height / eh);
    x.drawImage(el, (c.width - ew * k) / 2, (c.height - eh * k) / 2, ew * k, eh * k);
    return c.toDataURL('image/jpeg', 0.7);
  } catch { return ''; }
}

/* ---------- التنقل ---------- */
function go(view) {
  if (!['project', 'scenes', 'export', 'publish', 'settings'].includes(view)) view = 'project';
  if (Player.playing) stopPlayback();
  $$('#editor video').forEach(v => v.pause());
  App.view = view;
  $$('.view').forEach(v => v.hidden = v.dataset.view !== view);
  $$('.tabs button').forEach(b => b.classList.toggle('on', b.dataset.go === view));
  if (view === 'scenes') renderScenes();
  if (view === 'export') enterExport();
  if (view === 'settings') renderSettings();
  if (view === 'publish') Publish.enter();
  if (view === 'project') renderProject();
  scrollTo({ top: 0 });
  if (location.hash.slice(1) !== view) history.replaceState(null, '', '#' + view);
}

/* ---------- الصوت ---------- */
async function loadAudio(blob, name, { keepScenes = false, silent = false } = {}) {
  if (blob.size > 200e6) { toast('الملف أكبر من 200MB', 'err'); return; }
  $('#audioName').textContent = name || 'ملف صوتي';
  $('#audioMeta').textContent = 'جارٍ القراءة…';
  try {
    App.buf = await Player.audioCtx().decodeAudioData(await blob.arrayBuffer());
  } catch {
    $('#audioMeta').textContent = 'تعذّرت قراءة الملف';
    toast('تعذّرت قراءة الصوت. جرّب MP3 أو M4A أو WAV.', 'err');
    return;
  }
  App.audioName = name;
  $('#audioMeta').textContent = `${fmt(App.buf.duration)} دقيقة · ${(blob.size / 1e6).toFixed(1)} MB`;
  drawWave();
  if (!silent) {
    try { await Store.putBlob('audio', blob); } catch { toast('لم يُحفظ الصوت على الجهاز (مساحة غير كافية)', 'err'); }
  }
  if (App.scenes.length && keepScenes) fitDurations();
  if (!silent && App.scenes.length && !keepScenes) {
    if (await confirmBox('يوجد مشاهد من صوت سابق. هل تريد حذفها والبدء من جديد؟', 'ابدأ من جديد')) await clearScenes();
    else fitDurations();
  }
  save(); renderProject();
}

function drawWave() {
  const c = $('#wave'), x = c.getContext('2d');
  c.width = c.clientWidth * devicePixelRatio || 1200;
  const W = c.width, H = c.height, d = App.buf.getChannelData(0), step = Math.floor(d.length / W);
  x.clearRect(0, 0, W, H);
  x.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#2f6b3a';
  for (let i = 0; i < W; i++) {
    let m = 0; const o = i * step;
    for (let j = 0; j < step; j += 16) { const v = Math.abs(d[o + j] || 0); if (v > m) m = v; }
    const h = Math.max(1, m * H * 0.92);
    x.fillRect(i, (H - h) / 2, 1, h);
  }
  // حدود المشاهد
  if (App.scenes.length) {
    x.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--wheat').trim() || '#b07a12';
    let a = 0;
    App.scenes.forEach(s => { a += s.d; x.fillRect(Math.round(a / App.buf.duration * W), 0, 2, H); });
  }
}

function fitDurations() {
  if (!App.buf || !App.scenes.length) return;
  const tot = App.scenes.reduce((a, s) => a + s.d, 0) || 1;
  App.scenes.forEach(s => s.d *= App.buf.duration / tot);
}

async function clearScenes() {
  for (const s of App.scenes) { Live.release(s); if (s.blobKey) await Store.delBlob(s.blobKey).catch(() => {}); }
  App.scenes = []; App.sel = 0;
}

/* ---------- التعليق الصوتي بالذكاء الاصطناعي ---------- */
function fillVoices() {
  const s = Settings.get();
  const opts = TTS.MALE.map(([id, d]) => `<option value="${id}">${id} — ${d}</option>`).join('') +
    (s.extraVoices?.length ? `<optgroup label="أصوات مصرية من المكتبة">${s.extraVoices.map(v => `<option value="${esc(v.id)}">${esc(v.name)}${v.desc ? ' — ' + esc(v.desc) : ''}</option>`).join('')}</optgroup>` : '');
  ['#ttsVoice', '#ttsVoiceQuick'].forEach(sel => { const el = $(sel); if (el) { el.innerHTML = opts; el.value = s.ttsVoice; if (!el.value) el.selectedIndex = 0; } });
  ['#ttsPace', '#ttsPaceQuick'].forEach(sel => { const el = $(sel); if (el) el.value = s.ttsPace; });
}

/* يقسّم كل مقطع صوتي إلى مشاهد حسب طول الجمل داخله (توقيت دقيق لأن الصوت مولَّد من النص نفسه) */
function scenesFromSegments(segs, total) {
  const target = Settings.get().sceneTarget, out = [];
  segs.forEach((g, gi) => {
    const dur = g.end - g.start, cps = g.text.length / Math.max(0.1, dur);
    const parts = g.text.split(/(?<=[.!؟?…])\s+|(?<=[،,؛])\s+/).map(x => x.trim()).filter(Boolean);
    const groups = []; let c = '';
    for (const x of parts) { c = c ? c + ' ' + x : x; if (c.length / cps >= target) { groups.push(c); c = ''; } }
    if (c) { if (groups.length && c.length / cps < target / 2) groups[groups.length - 1] += ' ' + c; else groups.push(c); }
    const L = groups.reduce((a, x) => a + x.length, 0) || 1;
    groups.forEach(t => out.push(newScene(t, dur * t.length / L, localKeywords(t))));
    const gapAfter = (segs[gi + 1]?.start ?? total) - g.end;
    if (out.length) out[out.length - 1].d += Math.max(0, gapAfter);
  });
  if (out.length) out[0].d += segs[0].start;
  return out;
}

let ttsAbort;
async function makeVoiceover() {
  const text = $('#ttsText').value.trim();
  if (!text) return toast('اكتب أو الصق النص أولاً', 'err');
  if (!Settings.get().keys.gemini) { go('settings'); return toast('أضف مفتاح Gemini أولاً، فهو يُستخدم للصوت أيضاً', 'err'); }
  if (App.scenes.length && !(await confirmBox('سيُستبدل المشروع الحالي بفيديو جديد من هذا النص.', 'ابدأ'))) return;
  const box = $('#ttsProgress'); ttsAbort = new AbortController();
  $('#btnTTS').disabled = true;
  try {
    const { buffer, segs } = await TTS.speak(text, { signal: ttsAbort.signal, onProgress: (t, f) => setProgress(box, f * 0.9, t) });
    setProgress(box, 0.95, 'تجهيز المشاهد…');
    const wavBlob = TTS.wav(buffer);
    await clearScenes(); Publish.reset();
    App.buf = buffer; App.audioName = 'تعليق صوتي مصري (AI)';
    if (!App.projName) { App.projName = text.split(/\s+/).slice(0, 6).join(' '); $('#projName').value = App.projName; }
    try { await Store.putBlob('audio', wavBlob); } catch { toast('لم يُحفظ الصوت على الجهاز (مساحة غير كافية)', 'err'); }
    $('#audioName').textContent = App.audioName;
    $('#audioMeta').textContent = `${fmt(buffer.duration)} دقيقة · صوت ${Settings.get().ttsVoice}`;
    App.scenes = scenesFromSegments(segs, buffer.duration);
    $('#manualText').value = text;
    const au = $('#ttsAudio'); au.hidden = false; au.src = URL.createObjectURL(wavBlob);
    save(); drawWave(); renderProject();
    toast(`التعليق جاهز (${fmt(buffer.duration)}) · ${App.scenes.length} مشهد. جارٍ جلب اللقطات…`);
    setTimeout(() => autoFetch(), 300);
  } catch (e) {
    if (e.name !== 'AbortError') toast(e.message, 'err', 7000);
  } finally { box.hidden = true; $('#btnTTS').disabled = false; ttsAbort = null; }
}

async function previewVoice() {
  if (!Settings.get().keys.gemini) return toast('أضف مفتاح Gemini أولاً', 'err');
  const t = ($('#ttsText').value.trim() || 'أهلاً بيكم يا جماعة في قناة فادي فارم، النهارده هنتكلم عن تربية الفراخ البلدي.').slice(0, 220);
  const b = $('#btnTTSPreview'); b.disabled = true; b.textContent = 'جارٍ التسجيل…';
  try {
    const { buffer } = await TTS.speak(t.split(/(?<=[.!؟?])\s/)[0]);
    const au = $('#ttsAudio'); au.hidden = false; au.src = URL.createObjectURL(TTS.wav(buffer)); au.play().catch(() => {});
  } catch (e) { toast(e.message, 'err', 6000); }
  b.disabled = false; b.textContent = 'جرّب الصوت';
}

/* ---------- بناء المشاهد ---------- */
let trAbort;
async function transcribe() {
  if (!App.buf) return toast('اختر ملف الصوت أولاً', 'err');
  if (!Settings.get().keys.gemini) { go('settings'); return toast('أضف مفتاح Gemini أولاً', 'err'); }
  if (App.scenes.length && !(await confirmBox('سيُستبدل المشاهد الحالية بنتيجة التفريغ الجديدة.', 'متابعة'))) return;
  const box = $('#trProgress'); trAbort = new AbortController();
  $('#btnTranscribe').disabled = true;
  try {
    const res = await AI.transcribe(App.buf, { target: Settings.get().sceneTarget, signal: trAbort.signal, onProgress: (t, f) => setProgress(box, f, t) });
    await clearScenes(); Publish.reset();
    App.scenes = res.map(r => Object.assign(newScene(r.text, r.d, r.kw, r.kind), { ai: true }));
    $('#manualText').value = res.map(r => r.text).join('\n');
    toast(`تم التفريغ: ${App.scenes.length} مشهد. جارٍ جلب اللقطات…`);
    save(); drawWave(); renderProject();
    setTimeout(() => autoFetch(), 300);
  } catch (e) {
    if (e.name !== 'AbortError') toast(e.message, 'err', 6000);
  } finally {
    box.hidden = true; $('#btnTranscribe').disabled = false; trAbort = null;
  }
}

async function splitManual() {
  if (!App.buf) return toast('اختر ملف الصوت أولاً، المدة تُحسب منه', 'err');
  const t = $('#manualText').value.trim();
  if (!t) return toast('الصق النص أولاً', 'err');
  if (App.scenes.length && !(await confirmBox('سيُستبدل المشاهد الحالية.', 'متابعة'))) return;
  const target = Settings.get().sceneTarget, cps = t.length / App.buf.duration;
  const parts = t.split(/(?<=[.!؟?۔…\n])\s*|(?<=[،,؛;])\s+/).map(x => x.trim()).filter(Boolean);
  const out = []; let c = '';
  for (const x of parts) {
    c = c ? c + ' ' + x : x;
    if (c.length / cps >= target) { out.push(c); c = ''; }
  }
  if (c) { if (out.length && c.length / cps < target / 2) out[out.length - 1] += ' ' + c; else out.push(c); }
  const L = out.reduce((a, x) => a + x.length, 0);
  await clearScenes();
  App.scenes = out.map(x => newScene(x, App.buf.duration * x.length / L, localKeywords(x)));
  save(); drawWave(); renderProject();
  if (Settings.get().keys.gemini) {
    const box = $('#trProgress');
    setProgress(box, 0.3, 'Gemini يقترح كلمات بحث بصرية…');
    try {
      const kws = await AI.keywords(App.scenes.map(s => s.text));
      App.scenes.forEach((s, i) => { if (kws[i]?.kw.length) { s.kw = kws[i].kw; s.kind = kws[i].kind; s.ai = true; } });
      save(); toast('أُضيفت كلمات البحث');
    } catch (e) { toast(e.message, 'err'); }
    box.hidden = true;
  }
  renderProject();
  autoFetch();
}

function localKeywords(n) {
  return FarmDict.translate(n).slice(0, 4);
}

/* ---------- واجهة المشروع ---------- */
function renderProject() {
  const s = Settings.get();
  $('#sceneTarget').value = s.sceneTarget; $('#sceneTargetOut').textContent = s.sceneTarget + ' ث';
  $('#geminiHint').hidden = !!s.keys.gemini;
  const n = App.scenes.length, miss = App.scenes.filter(x => !x.blobKey).length;
  $('#nextStep').hidden = !n;
  if (n) {
    $('#nextTitle').textContent = miss ? `${n} مشهد جاهز` : 'كل المشاهد لها وسائط';
    $('#nextText').textContent = miss ? `الخطوة التالية: جلب لقطة لكل مشهد (${miss} متبقٍ) من مصادر الفيديو والصور.` : 'انتقل إلى التصدير لمعاينة الفيديو.';
    $('#btnAutoAll').textContent = miss ? 'اجلب اللقطات الآن' : 'افتح المعاينة';
  }
  $('#scenesDot').hidden = !miss || !n;
}

/* ---------- واجهة المشاهد ---------- */
const searchState = { q: '', kind: 'video', only: '', items: [], status: {}, loading: false, forScene: null };

function renderScenes() {
  const n = App.scenes.length;
  const miss = App.scenes.filter(s => !s.blobKey).length;
  $('#scenesSummary').textContent = n ? `${n} مشهد · ${fmt(App.buf?.duration || App.scenes.reduce((a, s) => a + s.d, 0))} · ${miss ? miss + ' بدون وسائط' : 'كلها جاهزة'}` : 'لا توجد مشاهد بعد. ابدأ من قسم المشروع.';
  $('#btnAutoAll2').disabled = $('#btnReAll').disabled = !n;
  { const k = Settings.get().keys, on = id => Settings.get().providers.find(p => p.id === id)?.on; $('#keysBanner').hidden = !n || ((k.pexels || !on('pexels')) && (k.pixabay || !on('pixabay'))); }
  renderStrip();
  renderEditor();
  renderProject();
}

function renderStrip() {
  const { st } = Renderer.timeline(App.scenes);
  $('#strip').innerHTML = App.scenes.map((s, i) => {
    const th = s.thumbData || s.asset?.thumb;
    return `<button class="scene-card${i === App.sel ? ' on' : ''}" role="option" aria-selected="${i === App.sel}" data-i="${i}" type="button">
      <span class="thumb">${s.busy ? '<i class="busy"></i>' : th ? `<img src="${esc(th)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : '<span class="miss">بدون وسائط</span>'}
        <span class="n num">${i + 1}</span><span class="t num">${fmt(st[i])}</span></span>
      <p>${esc(s.text)}</p></button>`;
  }).join('');
  $('#strip .on')?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
}

function renderEditor() {
  const s = App.scenes[App.sel], E = $('#editor');
  if (!s) { E.innerHTML = App.scenes.length ? '' : '<div class="empty">ارفع الصوت وفرّغه أو الصق النص في قسم المشروع، وستظهر المشاهد هنا.</div>'; return; }
  const { st } = Renderer.timeline(App.scenes);
  const a = s.asset, P = a && PROVIDERS[a.provider];
  if (searchState.forScene !== s.id) {
    searchState.forScene = s.id; searchState.items = []; searchState.status = {};
    searchState.q = s.kw.find(w => !isArabic(w)) || FarmDict.translate(s.text)[0] || projectSubjects()[0] || '';
    searchState.kind = s.kind || 'video';
  }
  E.innerHTML = `
  <div class="panel">
    <div class="panel-head"><h2>المشهد ${App.sel + 1}</h2><span class="muted num">${fmt(st[App.sel])} → ${fmt(st[App.sel] + s.d)}</span></div>
    <div class="cur-media" id="curMedia">${s.busy ? 'جارٍ التنزيل…' : s.blobKey ? '' : 'لم تُختر صورة أو فيديو'}</div>
    ${a ? `<p class="credit"><b>${esc(a.title || '')}</b><br>${a.creator ? 'المؤلف: ' + (a.creatorUrl ? `<a href="${esc(a.creatorUrl)}" target="_blank" rel="noopener">${esc(a.creator)}</a>` : esc(a.creator)) + ' · ' : ''}${esc(P?.name || 'من جهازك')} · ${a.licenseUrl ? `<a href="${esc(a.licenseUrl)}" target="_blank" rel="noopener">${esc(a.license)}</a>` : esc(a.license || '')}${a.pageUrl ? ` · <a href="${esc(a.pageUrl)}" target="_blank" rel="noopener">صفحة المصدر</a>` : ''}</p>` : ''}
    <label class="field"><span>النص</span><textarea id="sText" rows="3">${esc(s.text)}</textarea></label>
    <div class="row">
      <label class="field"><span>المدة (ثانية)</span><input id="sDur" type="number" step="0.1" min="0.5" value="${s.d.toFixed(1)}" inputmode="decimal"></label>
      <label class="field"><span>كلمات البحث</span><input id="sKw" type="text" dir="auto" value="${esc(s.kw.join(', '))}"></label>
    </div>
    <p class="muted small">تغيير المدة يأخذ الوقت من المشهد التالي، فيبقى الصوت متزامناً.</p>
    <div class="actions">
      <button class="btn ghost sm" data-op="prev" type="button">السابق</button>
      <button class="btn ghost sm" data-op="next" type="button">التالي</button>
      <button class="btn ghost sm" data-op="split" type="button">قسّم</button>
      <button class="btn ghost sm" data-op="merge" type="button">ادمج مع التالي</button>
      <button class="btn ghost sm" data-op="clear" type="button" ${s.blobKey ? '' : 'disabled'}>أزل الوسائط</button>
      <button class="btn danger sm" data-op="del" type="button">احذف</button>
    </div>
  </div>
  <div class="panel">
    <div class="panel-head"><h2>ابحث عن لقطة</h2>
      <div class="seg" role="group" aria-label="النوع"><button data-kind="video" class="${searchState.kind === 'video' ? 'on' : ''}" type="button">فيديو</button><button data-kind="image" class="${searchState.kind === 'image' ? 'on' : ''}" type="button">صورة</button></div>
    </div>
    <form class="searchbar" id="searchForm">
      <input id="q" type="search" dir="auto" value="${esc(searchState.q)}" placeholder="بالإنجليزية أفضل: goat farm, sunrise field">
      <button class="btn primary" type="submit">بحث</button>
      <input id="localFile" type="file" accept="image/*,video/*" hidden>
      <button class="btn" id="btnLocal" type="button">من جهازك</button>
    </form>
    <div class="pchips" id="pchips"></div>
    <div class="results" id="results"></div>
    <div class="status-line" id="sStatus"></div>
  </div>`;
  renderChips(); renderResults(); showCurrentMedia();
  if (!searchState.items.length && searchState.q && !searchState.loading) runSearch();
}

async function showCurrentMedia() {
  const s = App.scenes[App.sel], box = $('#curMedia');
  if (!s || !box || !s.blobKey) return;
  await Live.ensure(s);
  if (!s.el || App.scenes[App.sel] !== s) return;
  box.innerHTML = '';
  if (s.type === 'video') {
    const v = document.createElement('video');
    Object.assign(v, { src: s.el.src, muted: true, loop: true, playsInline: true, autoplay: true, controls: false });
    box.append(v);
  } else {
    const im = document.createElement('img'); im.src = s.el.src; im.alt = s.asset?.title || ''; box.append(im);
  }
}

function renderChips() {
  const k = searchState.kind, en = Settings.get().providers.filter(p => p.on && PROVIDERS[p.id].kinds.includes(k));
  $('#pchips').innerHTML = `<button data-only="" class="${!searchState.only ? 'on' : ''}" type="button">كل المصادر</button>` +
    en.map(p => `<button data-only="${p.id}" class="${searchState.only === p.id ? 'on' : ''}" type="button">${esc(PROVIDERS[p.id].name.split(' ')[0])}</button>`).join('');
}

function renderResults() {
  const R = $('#results'); if (!R) return;
  const used = new Set(App.scenes.map(s => s.asset?.uid).filter(Boolean));
  if (searchState.loading) { R.innerHTML = '<div class="empty" style="grid-column:1/-1">جارٍ البحث…</div>'; }
  else if (!searchState.items.length) { R.innerHTML = `<div class="empty" style="grid-column:1/-1">${searchState.q ? 'لا نتائج. جرّب كلمات إنجليزية أبسط أو نوعاً آخر.' : 'اكتب كلمة بحث.'}</div>`; }
  else R.innerHTML = searchState.items.map((it, i) => `<button class="res" data-r="${i}" type="button" title="${esc(it.title)}">
      <img src="${esc(it.thumb)}" alt="${esc(it.title)}" loading="lazy" referrerpolicy="no-referrer">
      ${used.has(it.uid) ? '<span class="used">مستخدم</span>' : ''}
      <span class="meta"><span>${esc(PROVIDERS[it.provider].name.split(' ')[0])}</span><span class="num">${it.duration ? fmt(it.duration) : it.type === 'image' ? 'صورة' : ''}</span></span></button>`).join('');
  const st = searchState.status;
  $('#sStatus').innerHTML = Object.keys(st).map(id => {
    const n = PROVIDERS[id].name, m = String(st[id]).replace(/^[^:]+:\s*/, '');
    return `<span>${esc(n)}: ${esc(m)}</span>`;
  }).join('');
}

let searchSeq = 0;
async function runSearch() {
  const q = searchState.q.trim(); if (!q) return renderResults();
  const my = ++searchSeq;
  searchState.loading = true; renderResults();
  const r = await searchProviders(q, searchState.kind, { only: searchState.only, orientation: App.orientation, minDim: App.minDim });
  if (my !== searchSeq) return;
  searchState.loading = false; searchState.items = r.items; searchState.status = r.status;
  renderResults();
}

/* تطبيق عنصر من نتائج البحث على مشهد */
async function applyItem(s, it, { quiet = false, signal } = {}) {
  s.busy = true; if (!quiet) { renderStrip(); const b = $('#curMedia'); if (b && App.scenes[App.sel] === s) b.textContent = 'جارٍ التنزيل…'; }
  try {
    let urls = it.urls;
    if (it.resolve) urls = [...(await it.resolve()), ...urls];
    if (!urls.length) throw new Error('لم يُعثر على ملف قابل للتنزيل');
    const blob = await Media.fetchBlob(urls, {
      signal,
      onProgress: quiet ? null : (f, got) => { const b = $('#curMedia'); if (b && App.scenes[App.sel] === s) b.textContent = f ? `جارٍ التنزيل ${Math.round(f * 100)}%` : `جارٍ التنزيل ${(got / 1e6).toFixed(1)}MB`; },
    });
    const el = await Media.element(blob, it.type);
    const key = 'a-' + s.id + '-' + uid();
    await Store.putBlob(key, blob);
    const old = s.blobKey;
    Live.release(s);
    s.el = el; s.type = it.type; s.blobKey = key;
    s.asset = { uid: it.uid, provider: it.provider, type: it.type, title: it.title, thumb: it.thumb, creator: it.creator, creatorUrl: it.creatorUrl, license: it.license, licenseUrl: it.licenseUrl, pageUrl: it.pageUrl };
    s.thumbData = thumbOf(el, it.type);
    if (old) Store.delBlob(old).catch(() => {});
    it.onUse?.();
    save();
    return true;
  } catch (e) {
    if (e.name === 'AbortError') throw e;
    if (!quiet) toast(`${e.message}. جرّب نتيجة أخرى.`, 'err');
    return false;
  } finally {
    s.busy = false;
    if (!quiet && App.view === 'scenes') { renderStrip(); if (App.scenes[App.sel] === s) renderEditor(); }
  }
}

async function applyLocal(s, file) {
  if (!file) return;
  const type = file.type.startsWith('video') ? 'video' : 'image';
  try {
    const el = await Media.element(file, type);
    const key = 'a-' + s.id + '-' + uid();
    await Store.putBlob(key, file);
    const old = s.blobKey; Live.release(s);
    s.el = el; s.type = type; s.blobKey = key;
    s.asset = { uid: 'local-' + key, provider: 'local', type, title: file.name, thumb: '', creator: '', license: 'ملفك الخاص', licenseUrl: '', pageUrl: '' };
    s.thumbData = thumbOf(el, type);
    if (old) Store.delBlob(old).catch(() => {});
    save(); renderScenes();
  } catch (e) { toast(e.message, 'err'); }
}

/* ---------- الجلب التلقائي ---------- */
let autoAbort;
const isArabic = w => /[؀-ۿ]/.test(w);

/* الموضوع الغالب في المشروع (مثلاً chicken) لاستخدامه كاحتياطي */
function projectSubjects() {
  const c = new Map();
  App.scenes.forEach(x => [...x.kw.filter(w => !isArabic(w)), ...FarmDict.translate(x.text)].forEach((w, i) => c.set(w, (c.get(w) || 0) + (i === 0 ? 2 : 1))));
  const top = [...c.entries()].sort((a, b) => b[1] - a[1]).map(e => e[0]).slice(0, 3);
  const ctx = FarmDict.translate(Settings.get().context);
  return [...new Set([...top, ...ctx, 'chickens farm', 'farm animals'])];
}

function sceneQueries(sc, subjects) {
  const kw = sc.kw.filter(w => !isArabic(w));
  const dict = FarmDict.translate(sc.text);
  const q = [kw[0], kw[1], dict[0] && dict[1] ? dict[0] + ' ' + dict[1] : '', dict[0], kw[2], kw[kw.length - 1], dict[1], ...subjects];
  return [...new Set(q.filter(Boolean).map(x => x.trim().toLowerCase()))].slice(0, 9);
}

async function autoFetch({ all = false } = {}) {
  if (!App.scenes.length || autoAbort) return;
  const s = Settings.get();
  const usable = s.providers.filter(p => p.on && (!PROVIDERS[p.id].needsKey || s.keys[p.id]));
  if (!usable.length) { go('settings'); return toast('فعّل مصدراً واحداً على الأقل', 'err'); }
  const targets = App.scenes.filter(x => all || !x.blobKey);
  if (!targets.length) return toast('كل المشاهد لها وسائط');
  if (all && !(await confirmBox(`سيُعاد جلب الوسائط لكل ${targets.length} مشهد.`, 'متابعة'))) return;
  if (App.view !== 'scenes') go('scenes');

  const box = $('#autoProgress'); autoAbort = new AbortController();
  const btns = [$('#btnAutoAll'), $('#btnAutoAll2'), $('#btnReAll')]; btns.forEach(b => b.disabled = true);

  // كلمات بحث إنجليزية من Gemini للمشاهد التي ليس لها كلمات إنجليزية
  const noKw = targets.filter(x => !x.ai);
  if (noKw.length && s.keys.gemini) {
    setProgress(box, 0.02, 'Gemini يحلّل المشاهد ويقترح لقطات مناسبة…');
    try { const k = await AI.keywords(noKw.map(x => x.text), { signal: autoAbort.signal }); noKw.forEach((x, i) => { if (k[i]?.kw.length) { x.kw = k[i].kw; x.kind = k[i].kind; x.ai = true; } }); save(); }
    catch (e) { if (e.name === 'AbortError') { box.hidden = true; autoAbort = null; btns.forEach(b => b.disabled = false); return; } toast(e.message, 'err'); }
  }

  const subjects = projectSubjects();
  const cache = new Map(), blocked = new Set(), pending = new Map();
  const used = new Set(App.scenes.filter(x => !targets.includes(x)).map(x => x.asset?.uid).filter(Boolean));
  const pool = [];           // كل النتائج الصالحة، للاستخدام الاحتياطي
  const byProv = {};
  let done = 0, ok = 0, reused = 0;

  async function search(p, kind, q) {
    const ck = p.id + '|' + kind + '|' + q;
    if (cache.has(ck)) return cache.get(ck);
    if (pending.has(ck)) return pending.get(ck);
    const pr = (async () => {
      let items = [];
      try { items = await PROVIDERS[p.id].search(q, kind, { key: s.keys[p.id], orientation: App.orientation, minDim: App.minDim }); }
      catch (e) { if (e.code === 'rate' || e.code === 'key') { if (!blocked.has(p.id)) toast(e.message, 'err'); blocked.add(p.id); } }
      cache.set(ck, items); pending.delete(ck);
      items.slice(0, 6).forEach(it => pool.push(it));
      return items;
    })();
    pending.set(ck, pr);
    return pr;
  }

  async function tryItems(sc, items, max) {
    for (const it of items.filter(i => !used.has(i.uid)).slice(0, max)) {
      if (autoAbort.signal.aborted) return true;
      used.add(it.uid);
      if (await applyItem(sc, it, { quiet: true, signal: autoAbort.signal })) { ok++; byProv[it.provider] = (byProv[it.provider] || 0) + 1; return true; }
    }
    return false;
  }

  async function forScene(sc) {
    const kinds = s.prefKind === 'image' ? ['image', 'video'] : s.prefKind === 'auto' ? [sc.kind, sc.kind === 'video' ? 'image' : 'video'] : ['video', 'image'];
    const queries = sceneQueries(sc, subjects);
    sc.busy = true; if (App.view === 'scenes') renderStrip();
    try {
      // 1) كلمات المشهد نفسه، بكل المصادر، فيديو ثم صورة
      for (const kind of kinds) for (const q of queries.slice(0, 5)) {
        const ps = usable.filter(p => PROVIDERS[p.id].kinds.includes(kind) && !blocked.has(p.id));
        const res = await Promise.all(ps.map(p => search(p, kind, q)));   // كل المصادر في نفس الوقت
        for (const items of res) if (await tryItems(sc, items, 2)) return;
      }
      // 2) موضوع القناة العام (مثلاً دجاج المزرعة)
      for (const kind of kinds) for (const q of queries.slice(5)) for (const p of usable) {
        if (!PROVIDERS[p.id].kinds.includes(kind) || blocked.has(p.id)) continue;
        if (await tryItems(sc, await search(p, kind, q), 2)) return;
      }
      // 3) آخر حل: لقطة سبق استخدامها، تبدأ من جزء مختلف حتى لا يتكرر المشهد نفسه
      const cands = [...pool].sort(() => Math.random() - 0.5);
      for (const it of cands.slice(0, 4)) {
        if (autoAbort.signal.aborted) return;
        if (await applyItem(sc, it, { quiet: true, signal: autoAbort.signal })) { sc.offset = 1 + Math.random() * 8; ok++; reused++; return; }
      }
    } finally { sc.busy = false; }
  }

  try {
    const queue = [...targets];
    const worker = async () => {
      while (queue.length && !autoAbort.signal.aborted) {
        const sc = queue.shift();
        await forScene(sc).catch(e => { if (e.name !== 'AbortError') console.warn(e); });
        done++;
        setProgress(box, done / targets.length, `المشهد ${done} من ${targets.length} · وُجدت لقطات لـ ${ok}`);
        if (App.view === 'scenes') renderStrip();
      }
    };
    setProgress(box, 0, `البحث عن لقطات لـ ${targets.length} مشهد…`);
    await Promise.all(Array.from({ length: 5 }, worker));
    if (autoAbort.signal.aborted) toast('أُوقف الجلب');
    else {
      const src = Object.entries(byProv).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${PROVIDERS[k]?.name.split(' ')[0]} ${v}`).join('، ');
      const miss = targets.length - ok;
      toast(miss ? `اكتمل ${ok} من ${targets.length}. ${miss} مشهد بلا نتيجة، تحقق من الإنترنت أو أضف مفاتيح Pexels وPixabay.` : `اكتمل: كل المشاهد لها لقطات${src ? ' (' + src + ')' : ''}${reused ? `، ${reused} منها مكرّرة بجزء مختلف` : ''}`, miss ? 'err' : '', 7000);
    }
  } finally {
    box.hidden = true; autoAbort = null; btns.forEach(b => b.disabled = false);
    save(); if (App.view === 'scenes') renderScenes(); else renderProject();
  }
}

/* ---------- عمليات المشهد ---------- */
async function sceneOp(op) {
  const i = App.sel, s = App.scenes[i]; if (!s) return;
  if (op === 'prev') App.sel = Math.max(0, i - 1);
  if (op === 'next') App.sel = Math.min(App.scenes.length - 1, i + 1);
  if (op === 'split') {
    const m = s.text.indexOf(' ', Math.floor(s.text.length / 2));
    if (m < 0) return toast('النص قصير جداً للتقسيم');
    const a = s.text.slice(0, m), b = s.text.slice(m + 1), r = a.length / s.text.length;
    const n = newScene(b, s.d * (1 - r), s.kw, s.kind);
    s.text = a; s.d *= r;
    App.scenes.splice(i + 1, 0, n);
  }
  if (op === 'merge') {
    const x = App.scenes[i + 1]; if (!x) return toast('لا يوجد مشهد تالٍ');
    s.text += ' ' + x.text; s.d += x.d;
    if (!s.blobKey && x.blobKey) { Object.assign(s, { asset: x.asset, blobKey: x.blobKey, thumbData: x.thumbData, el: x.el, type: x.type }); }
    else { Live.release(x); if (x.blobKey) Store.delBlob(x.blobKey).catch(() => {}); }
    App.scenes.splice(i + 1, 1);
  }
  if (op === 'clear') { Live.release(s); if (s.blobKey) Store.delBlob(s.blobKey).catch(() => {}); s.blobKey = null; s.asset = null; s.thumbData = ''; }
  if (op === 'del') {
    if (!(await confirmBox('حذف هذا المشهد؟ ستُضاف مدته إلى المشهد المجاور.', 'احذف'))) return;
    const nb = App.scenes[i + 1] || App.scenes[i - 1];
    if (nb) nb.d += s.d;
    Live.release(s); if (s.blobKey) Store.delBlob(s.blobKey).catch(() => {});
    App.scenes.splice(i, 1); App.sel = Math.max(0, Math.min(i, App.scenes.length - 1));
  }
  save(); renderScenes(); if (App.buf) drawWave();
}

function setDuration(i, v) {
  const s = App.scenes[i], nb = App.scenes[i + 1] || App.scenes[i - 1];
  if (!s || !nb) return;
  v = Math.max(0.5, Math.min(s.d + nb.d - 0.5, +v || s.d));
  nb.d -= v - s.d; s.d = v;
  save(); renderStrip();
}

/* ---------- المعاينة والتصدير ---------- */
let curT = 0;
function enterExport() {
  const { w, h } = App.dims;
  if (Renderer.canvas.width !== w || Renderer.canvas.height !== h) Renderer.size(w, h);
  const s = Settings.get();
  $('#ratio').value = s.ratio; $('#transition').value = s.transition; $('#captions').value = s.captions;
  $('#capSize').value = s.captionSize; $('#capSizeOut').textContent = Math.round(s.captionSize * 100) + '%';
  const dur = App.buf?.duration || 0;
  $('#scrub').max = dur; curT = Math.min(curT, dur);
  const n = App.scenes.length, miss = App.scenes.filter(x => !x.blobKey).length;
  $('#exportCheck').textContent = !App.buf ? 'ارفع ملف الصوت أولاً.' : !n ? 'لا توجد مشاهد بعد.' :
    miss ? `${n} مشهد، منها ${miss} بدون وسائط (ستظهر بخلفية Fadi Farm). المدة ${fmt(dur)}.` : `${n} مشهد جاهز. المدة ${fmt(dur)}، والتصدير يستغرق نفس مدة الفيديو تقريباً.`;
  $('#btnExport').disabled = !App.buf || !n;
  $('#btnPlay').disabled = !App.buf || !n;
  seekTo(curT);
}

function seekTo(t) {
  curT = t;
  $('#scrub').value = t;
  $('#clock').textContent = `${fmt(t)} / ${fmt(App.buf?.duration)}`;
  if (!App.scenes.length) { Renderer.draw(0, []); return; }
  const { st } = Renderer.timeline(App.scenes);
  let i = 0; while (i < App.scenes.length - 1 && st[i + 1] <= t) i++;
  Live.windowAt(i, 0, 1);
  Promise.all([Live.ensure(App.scenes[i]), App.scenes[i + 1] && Live.ensure(App.scenes[i + 1])]).then(() => {
    Renderer.seekVideos(t, App.scenes, () => Renderer.draw(curT, App.scenes));
    Renderer.draw(curT, App.scenes);
  });
}

let lastIdx = -1;
function tickWindow(t) {
  const { st } = Renderer.timeline(App.scenes);
  let i = 0; while (i < App.scenes.length - 1 && st[i + 1] <= t) i++;
  if (i !== lastIdx) { lastIdx = i; Live.windowAt(i, 1, 3); }
}

async function togglePlay() {
  if (Player.playing) return stopPlayback();
  if (!App.buf || !App.scenes.length) return;
  lastIdx = -1;
  const at = curT >= App.buf.duration - 0.2 ? 0 : curT;
  $('#btnPlay').textContent = '❚❚'; $('#btnPlay').setAttribute('aria-label', 'إيقاف مؤقت');
  await Player.start({
    buf: App.buf, scenes: App.scenes, at,
    tick: t => { curT = t; tickWindow(t); $('#scrub').value = t; $('#clock').textContent = `${fmt(t)} / ${fmt(App.buf.duration)}`; },
    end: () => { stopPlayback(); curT = 0; },
  });
}

function stopPlayback() {
  Player.stop(true, App.scenes);
  $('#btnPlay').textContent = '▶'; $('#btnPlay').setAttribute('aria-label', 'تشغيل');
}

let lastExport = null;
async function exportVideo() {
  if (Player.recording) return;
  if (!App.buf || !App.scenes.length) return;
  const mime = Player.pickMime();
  if (!mime) return toast('هذا المتصفح لا يدعم التصدير. استخدم Chrome أو Edge.', 'err');
  stopPlayback();
  const box = $('#exProgress');
  $('#exResult').hidden = true; $('#btnExport').disabled = true; $('#btnPlay').disabled = true;
  setProgress(box, 0, 'تجهيز الوسائط…');
  await Promise.all(App.scenes.slice(0, 4).map(s => Live.ensure(s)));
  lastIdx = -1;
  const dur = App.buf.duration;
  try {
    await Player.start({
      buf: App.buf, scenes: App.scenes, record: true,
      tick: t => { curT = t; tickWindow(t); $('#scrub').value = t; setProgress(box, t / dur, `جارٍ التصدير ${fmt(t)} من ${fmt(dur)} · أبقِ الشاشة مفتوحة`); },
      end: blob => {
        box.hidden = true; $('#btnExport').disabled = false; $('#btnPlay').disabled = false;
        if (!blob || !blob.size) return toast('فشل التصدير، أعد المحاولة', 'err');
        showResult(blob);
      },
    });
  } catch (e) {
    box.hidden = true; $('#btnExport').disabled = false; $('#btnPlay').disabled = false;
    toast(e.message, 'err');
  }
}

function cancelExport() {
  Player.stop(true, App.scenes);
  $('#exProgress').hidden = true; $('#btnExport').disabled = false; $('#btnPlay').disabled = false;
  toast('أُلغي التصدير');
}

function safeName() { return (App.projName || 'fadi-farm').replace(/[\\/:*?"<>|]+/g, ' ').trim().slice(0, 60) || 'fadi-farm'; }

function showResult(blob) {
  if (lastExport) URL.revokeObjectURL(lastExport.url);
  const ext = blob.type.includes('mp4') ? 'mp4' : 'webm';
  const url = URL.createObjectURL(blob), name = `${safeName()}.${ext}`;
  lastExport = { url, blob, name };
  const R = $('#exResult'); R.hidden = false;
  R.innerHTML = `<b>الفيديو جاهز · ${(blob.size / 1e6).toFixed(1)} MB · ${ext.toUpperCase()}</b>
    <video src="${url}" controls playsinline></video>
    <div class="actions">${NATIVE ? '<button class="btn primary" id="btnSaveNative" type="button">حفظ في الهاتف</button><button class="btn" id="btnShareNative" type="button">مشاركة</button>' : `<a class="btn primary" href="${url}" download="${esc(name)}">تنزيل</a>${navigator.canShare?.({ files: [new File([blob], name, { type: blob.type })] }) ? '<button class="btn" id="btnShare" type="button">مشاركة</button>' : ''}`}</div>
    ${ext === 'webm' ? '<p class="muted small">هذا المتصفح يصدّر WebM، ويوتيوب يقبله مباشرة.</p>' : ''}`;
  $('#btnShare')?.addEventListener('click', async () => {
    try { await navigator.share({ files: [new File([blob], name, { type: blob.type })], title: App.projName || 'Fadi Farm' }); } catch {}
  });
  const busy = async (btn, fn) => { btn.disabled = true; const t = btn.textContent; btn.textContent = 'جارٍ الحفظ…'; try { await fn(); } catch (e) { toast(e.message || 'تعذّر الحفظ', 'err'); } btn.disabled = false; btn.textContent = t; };
  $('#btnSaveNative')?.addEventListener('click', e => busy(e.currentTarget, () => saveFile(blob, name)));
  $('#btnShareNative')?.addEventListener('click', e => busy(e.currentTarget, () => saveFile(blob, name, { share: true })));
  toast('اكتمل التصدير');
  if (NATIVE) saveFile(blob, name).catch(() => {});
}

function creditsText() {
  const seen = new Set(), lines = [];
  App.scenes.forEach(s => {
    const a = s.asset; if (!a || a.provider === 'local' || seen.has(a.uid)) return; seen.add(a.uid);
    lines.push(`• ${a.title || 'بدون عنوان'}${a.creator ? ' — ' + a.creator : ''} — ${PROVIDERS[a.provider]?.name || a.provider} — ${a.license || ''}${a.pageUrl ? ' — ' + a.pageUrl : ''}`);
  });
  return lines.length ? `مصادر الصور والفيديو:\n${lines.join('\n')}` : '';
}

async function copyCredits() {
  const t = creditsText();
  if (!t) return toast('لا توجد وسائط من مصادر خارجية بعد');
  try { await navigator.clipboard.writeText(t); toast('نُسخت الحقوق، الصقها في وصف الفيديو'); }
  catch { toast('تعذّر النسخ التلقائي', 'err'); }
}

function downloadJson() {
  const { st } = Renderer.timeline(App.scenes);
  const data = { project: App.projName, audio: App.audioName, duration: App.buf?.duration, ratio: Settings.get().ratio,
    scenes: App.scenes.map((s, i) => ({ id: i + 1, start: +st[i].toFixed(2), end: +(st[i] + s.d).toFixed(2), narration: s.text, keywords: s.kw, media: s.asset })) };
  saveFile(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }), `${safeName()}-scenes.json`).catch(e => toast(e.message, 'err'));
}

/* ---------- الإعدادات ---------- */
function renderSettings() {
  const s = Settings.get();
  $('#k-gemini').value = s.keys.gemini;
  $('#gemModel').value = s.geminiModel;
  $('#context').value = s.context;
  $('#prefKind').value = s.prefKind;
  $('#dlQuality').value = s.dlQuality;
  $('#ttsModel').value = s.ttsModel;
  fillVoices();
  $('#logoPos').value = s.logoPos; $('#logoOpacity').value = s.logoOpacity;
  $('#logoPrev').style.backgroundImage = s.logo ? `url("${s.logo}")` : '';
  const gs = $('#gemState'); gs.textContent = s.keys.gemini ? 'مضاف' : 'غير مضاف'; gs.className = 'chip ' + (s.keys.gemini ? 'ok' : 'warn');
  $('#ver').textContent = VERSION;
  $('#providers').innerHTML = s.providers.map((p, i) => {
    const P = PROVIDERS[p.id], hasKey = !P.needsKey || s.keys[p.id];
    return `<li class="prov${p.on ? '' : ' off'}" data-p="${p.id}">
      <div class="prov-head">
        <label class="switch" title="تفعيل"><input type="checkbox" data-toggle="${p.id}" ${p.on ? 'checked' : ''} aria-label="تفعيل ${esc(P.name)}"><i></i></label>
        <b>${esc(P.name)}</b>
        <span class="kinds">${P.kinds.map(k => `<span class="chip">${k === 'video' ? 'فيديو' : 'صور'}</span>`).join('')}</span>
        <span class="chip ${P.needsKey ? (hasKey ? 'ok' : 'warn') : 'ok'}">${P.needsKey ? (hasKey ? 'المفتاح مضاف' : 'يحتاج مفتاح') : 'بدون مفتاح'}</span>
        <span class="order"><button type="button" data-up="${i}" aria-label="أعلى" ${i ? '' : 'disabled'}>↑</button><button type="button" data-down="${i}" aria-label="أسفل" ${i < s.providers.length - 1 ? '' : 'disabled'}>↓</button></span>
      </div>
      <p class="muted small">${esc(P.note)}</p>
      ${P.needsKey || P.optionalKey ? `<div class="keyrow">
        <input id="k-${p.id}" type="password" autocomplete="off" spellcheck="false" dir="ltr" placeholder="${P.optionalKey ? 'مفتاح API (اختياري)' : 'مفتاح API'}" value="${esc(s.keys[p.id] || '')}" data-key="${p.id}">
        <button class="btn ghost sm" data-eye="k-${p.id}" type="button">إظهار</button>
        <button class="btn sm" data-test="${p.id}" type="button">اختبار</button>
        <a class="btn ghost sm" href="${P.keyUrl}" target="_blank" rel="noopener">احصل على مفتاح</a>
      </div>` : `<div class="actions"><button class="btn sm" data-test="${p.id}" type="button">اختبار الاتصال</button></div>`}
    </li>`;
  }).join('');
}

async function testKey(id, btn) {
  const t = btn.textContent; btn.disabled = true; btn.textContent = '…';
  try {
    if (id === 'gemini') { await AI.test(); toast('Gemini يعمل'); }
    else { const n = await testProvider(id); toast(`${PROVIDERS[id].name} يعمل · ${n} نتيجة تجريبية`); }
  } catch (e) { toast(e.message, 'err', 6000); }
  finally { btn.disabled = false; btn.textContent = t; }
}

function readLogo(file) {
  if (!file) return;
  const im = new Image();
  im.onload = () => {
    const m = 320, k = Math.min(1, m / Math.max(im.width, im.height));
    const c = document.createElement('canvas'); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
    c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
    Settings.set({ logo: c.toDataURL('image/png') }); renderSettings(); toast('حُفظ الشعار');
    URL.revokeObjectURL(im.src);
  };
  im.onerror = () => toast('تعذّر فتح الصورة', 'err');
  im.src = URL.createObjectURL(file);
}

/* ---------- الأحداث ---------- */
function bind() {
  document.addEventListener('click', e => {
    const g = e.target.closest('[data-go]');
    if (g) { e.preventDefault(); go(g.dataset.go); }
  });

  // المشروع
  $('#projName').addEventListener('input', e => { App.projName = e.target.value; save(); });
  $('#audioPick').onclick = () => $('#audioInput').click();
  $('#audioInput').onchange = e => { const f = e.target.files[0]; if (f) loadAudio(f, f.name); e.target.value = ''; };
  const drop = $('#audioDrop');
  drop.addEventListener('dragover', e => { e.preventDefault(); drop.classList.add('over'); });
  drop.addEventListener('dragleave', () => drop.classList.remove('over'));
  drop.addEventListener('drop', e => { e.preventDefault(); drop.classList.remove('over'); const f = e.dataTransfer.files[0]; if (f) loadAudio(f, f.name); });
  $('#sceneTarget').oninput = e => { Settings.set({ sceneTarget: +e.target.value }); $('#sceneTargetOut').textContent = e.target.value + ' ث'; };
  $('#btnTranscribe').onclick = transcribe;
  $('#btnTTS').onclick = makeVoiceover;
  $('#btnTTSPreview').onclick = previewVoice;
  $('#ttsCancel').onclick = () => ttsAbort?.abort();
  $('#ttsVoiceQuick').onchange = e => { Settings.set({ ttsVoice: e.target.value }); fillVoices(); };
  $('#ttsPaceQuick').onchange = e => { Settings.set({ ttsPace: e.target.value }); fillVoices(); };
  $('#ttsText').addEventListener('input', e => { try { localStorage.setItem('ff.ttsDraft', e.target.value); } catch {} });
  $('#trCancel').onclick = () => trAbort?.abort();
  $('#btnSplit').onclick = splitManual;
  $('#btnAutoAll').onclick = () => { const miss = App.scenes.some(s => !s.blobKey); go(miss ? 'scenes' : 'export'); if (miss) autoFetch(); };

  // المشاهد
  $('#btnAutoAll2').onclick = () => autoFetch();
  $('#btnReAll').onclick = () => autoFetch({ all: true });
  $('#autoCancel').onclick = () => autoAbort?.abort();
  $('#strip').addEventListener('click', e => {
    const c = e.target.closest('.scene-card'); if (!c) return;
    App.sel = +c.dataset.i; save(); renderStrip(); renderEditor();
  });
  const ed = $('#editor');
  ed.addEventListener('input', e => {
    const s = App.scenes[App.sel]; if (!s) return;
    if (e.target.id === 'sText') { s.text = e.target.value; save(); }
    if (e.target.id === 'sKw') { s.kw = e.target.value.split(/[,،]/).map(x => x.trim()).filter(Boolean); s.ai = true; save(); }
    if (e.target.id === 'q') searchState.q = e.target.value;
  });
  ed.addEventListener('change', e => {
    if (e.target.id === 'sDur') setDuration(App.sel, e.target.value);
    if (e.target.id === 'sText') renderStrip();
    if (e.target.id === 'localFile') { applyLocal(App.scenes[App.sel], e.target.files[0]); e.target.value = ''; }
  });
  ed.addEventListener('submit', e => { e.preventDefault(); if (e.target.id === 'searchForm') { searchState.q = $('#q').value; runSearch(); } });
  ed.addEventListener('click', e => {
    const t = e.target.closest('button'); if (!t) return;
    if (t.dataset.op) sceneOp(t.dataset.op);
    else if (t.dataset.kind) { searchState.kind = t.dataset.kind; searchState.only = ''; $$('.seg button', ed).forEach(b => b.classList.toggle('on', b === t)); renderChips(); runSearch(); }
    else if ('only' in t.dataset) { searchState.only = t.dataset.only; renderChips(); runSearch(); }
    else if (t.dataset.r != null) {
      const it = searchState.items[+t.dataset.r], s = App.scenes[App.sel];
      if (it && s && !s.busy) { t.classList.add('loading'); applyItem(s, it); }
    }
    else if (t.id === 'btnLocal') $('#localFile').click();
  });

  // التصدير
  $('#btnPlay').onclick = togglePlay;
  $('#scrub').oninput = e => { if (Player.playing) stopPlayback(); seekTo(+e.target.value); };
  $('#ratio').onchange = e => { Settings.set({ ratio: e.target.value }); searchState.forScene = null; enterExport(); };
  $('#transition').onchange = e => { Settings.set({ transition: e.target.value }); seekTo(curT); };
  $('#captions').onchange = e => { Settings.set({ captions: e.target.value }); seekTo(curT); };
  $('#capSize').oninput = e => { Settings.set({ captionSize: +e.target.value }); $('#capSizeOut').textContent = Math.round(e.target.value * 100) + '%'; seekTo(curT); };
  $('#btnExport').onclick = exportVideo;
  $('#exCancel').onclick = cancelExport;
  $('#btnCopyCredits').onclick = copyCredits;
  $('#btnJson').onclick = downloadJson;

  // الإعدادات
  const sv = $('#v-settings');
  sv.addEventListener('input', e => {
    const s = Settings.get();
    if (e.target.dataset.key) { s.keys[e.target.dataset.key] = e.target.value.trim(); Settings.save(); }
    if (e.target.id === 'k-gemini') { s.keys.gemini = e.target.value.trim(); Settings.save(); const gs = $('#gemState'); gs.textContent = s.keys.gemini ? 'مضاف' : 'غير مضاف'; gs.className = 'chip ' + (s.keys.gemini ? 'ok' : 'warn'); }
    if (e.target.id === 'gemModel') Settings.set({ geminiModel: e.target.value.trim() || DEFAULT_SETTINGS.geminiModel });
    if (e.target.id === 'context') Settings.set({ context: e.target.value });
    if (e.target.id === 'ttsModel') Settings.set({ ttsModel: e.target.value.trim() || DEFAULT_SETTINGS.ttsModel });
    if (e.target.id === 'logoOpacity') Settings.set({ logoOpacity: +e.target.value });
  });
  sv.addEventListener('change', e => {
    const s = Settings.get();
    if (e.target.dataset.toggle) { s.providers.find(p => p.id === e.target.dataset.toggle).on = e.target.checked; Settings.save(); renderSettings(); }
    if (e.target.dataset.key) renderSettings();
    if (e.target.id === 'prefKind') Settings.set({ prefKind: e.target.value });
    if (e.target.id === 'dlQuality') Settings.set({ dlQuality: e.target.value });
    if (e.target.id === 'ttsVoice') { Settings.set({ ttsVoice: e.target.value }); fillVoices(); }
    if (e.target.id === 'ttsPace') { Settings.set({ ttsPace: e.target.value }); fillVoices(); }
    if (e.target.id === 'logoPos') Settings.set({ logoPos: e.target.value });
    if (e.target.id === 'logoInput') { readLogo(e.target.files[0]); e.target.value = ''; }
    if (e.target.id === 'restoreInput') restoreSettings(e.target.files[0]);
  });
  sv.addEventListener('click', async e => {
    const b = e.target.closest('button'); if (!b) return;
    const s = Settings.get();
    if (b.dataset.eye) { const i = $('#' + b.dataset.eye); i.type = i.type === 'password' ? 'text' : 'password'; b.textContent = i.type === 'password' ? 'إظهار' : 'إخفاء'; }
    if (b.dataset.test) testKey(b.dataset.test, b);
    if (b.id === 'testGemini') testKey('gemini', b);
    if (b.dataset.up || b.dataset.down) {
      const i = +(b.dataset.up ?? b.dataset.down), j = b.dataset.up ? i - 1 : i + 1;
      [s.providers[i], s.providers[j]] = [s.providers[j], s.providers[i]]; Settings.save(); renderSettings();
    }
    if (b.id === 'btnVoices') {
      b.disabled = true;
      try { const v = await TTS.listVoices(); Settings.set({ extraVoices: v }); fillVoices(); toast(v.length ? `أُضيف ${v.length} صوت مصري` : 'لم تُعثر على أصوات إضافية، الأصوات الأساسية تتكلم مصري أيضاً'); }
      catch (e) { toast(e.message, 'err'); }
      b.disabled = false;
    }
    if (b.id === 'logoPick') $('#logoInput').click();
    if (b.id === 'logoClear') { Settings.set({ logo: '' }); renderSettings(); }
    if (b.id === 'logoDefault') { Settings.set({ logo: 'icons/logo.png' }); renderSettings(); }
    if (b.id === 'btnNewProject') {
      if (!(await confirmBox('بدء مشروع جديد؟ سيُحذف الصوت والمشاهد الحالية (الإعدادات والمفاتيح تبقى).', 'مشروع جديد'))) return;
      await clearScenes(); Publish.reset(); App.buf = null; App.audioName = ''; App.projName = '';
      await Store.delBlob('audio').catch(() => {}); await Store.set('project', null);
      $('#projName').value = ''; $('#manualText').value = ''; $('#audioName').textContent = 'لم يُختر ملف بعد'; $('#audioMeta').textContent = 'MP3، WAV، M4A، OGG أو فيديو، حتى 200MB';
      $('#wave').getContext('2d').clearRect(0, 0, 99999, 999); go('project');
    }
    if (b.id === 'btnBackup') {
      saveFile(new Blob([JSON.stringify(Settings.get(), null, 2)], { type: 'application/json' }), 'fadi-farm-settings.json').catch(e => toast(e.message, 'err'));
    }
    if (b.id === 'btnRestore') $('#restoreInput').click();
    if (b.id === 'btnWipe') {
      if (!(await confirmBox('مسح كل البيانات من هذا الجهاز؟ يشمل المفاتيح والمشروع والوسائط المنزّلة.', 'امسح كل شيء'))) return;
      await Store.clearAll().catch(() => {}); localStorage.removeItem('ff.settings'); location.reload();
    }
    if (b.id === 'btnInstall' && deferredInstall) { deferredInstall.prompt(); await deferredInstall.userChoice; deferredInstall = null; b.hidden = true; }
  });

  addEventListener('online', () => $('#netState').hidden = true);
  addEventListener('offline', () => $('#netState').hidden = false);
  $('#netState').hidden = navigator.onLine;
  addEventListener('hashchange', () => { const v = location.hash.slice(1); if (v && v !== App.view) go(v); });
  addEventListener('resize', () => { if (App.buf && App.view === 'project') drawWave(); });
  document.addEventListener('visibilitychange', () => { if (document.hidden && Player.recording) toast('أبقِ التطبيق مفتوحاً حتى ينتهي التصدير', 'err', 6000); });
}

async function restoreSettings(file) {
  if (!file) return;
  try {
    const d = JSON.parse(await file.text());
    if (!d || typeof d !== 'object' || !d.providers) throw 0;
    localStorage.setItem('ff.settings', JSON.stringify(d)); location.reload();
  } catch { toast('ملف الإعدادات غير صالح', 'err'); }
}

/* ---------- التثبيت (PWA) ---------- */
let deferredInstall = null;
addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferredInstall = e; const b = $('#btnInstall'); if (b) b.hidden = false; });
addEventListener('appinstalled', () => { toast('ثُبّت Fadi Farm على جهازك'); $('#btnInstall').hidden = true; });

/* ---------- البدء ---------- */
(async function boot() {
  Settings.get();
  Renderer.init($('#cv'));
  bind();
  Publish.bind();
  fillVoices();
  try { $('#ttsText').value = localStorage.getItem('ff.ttsDraft') || ''; } catch {}
  if (NATIVE || matchMedia('(display-mode: standalone)').matches) $('#installText').textContent = 'التطبيق مثبّت ويعمل كتطبيق مستقل.';
  if (!NATIVE && 'serviceWorker' in navigator && location.protocol !== 'file:') navigator.serviceWorker.register('sw.js').catch(() => {});
  if (navigator.storage?.persist) navigator.storage.persist().catch(() => {});
  await restore();
  await Publish.loadPromo();
  go(location.hash.slice(1) || (App.scenes.length ? 'scenes' : 'project'));
})();
