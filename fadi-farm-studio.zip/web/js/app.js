/* Fadi Farm Studio — منطق الواجهة */
'use strict';

const VERSION = '5.9.0';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = t => { t = Math.max(0, t || 0); const m = Math.floor(t / 60), s = Math.floor(t % 60); return `${m}:${String(s).padStart(2, '0')}`; };
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);

function toast(msg, kind = '', ms = 3800) {
  const el = document.createElement('div');
  el.className = 'toast ' + kind; el.textContent = msg;
  $('#toasts').append(el);
  setTimeout(() => el.remove(), ms);
}

function confirmBox(text, okLabel = 'تأكيد') {
  const d = $('#confirmDlg');
  $('#confirmText').textContent = text;
  d.querySelector('button[value=yes]').textContent = okLabel;
  return new Promise(res => { d.onclose = () => res(d.returnValue === 'yes'); d.returnValue = ''; d.showModal(); });
}

function setProgress(box, frac, text) {
  box.hidden = false;
  box.querySelector('.bar i').style.width = Math.round(Math.max(0, Math.min(1, frac)) * 100) + '%';
  box.querySelector('span').textContent = text;
}

/* ---------- تطبيق أندرويد (Capacitor) ---------- */
const NATIVE = !!(window.Capacitor && (window.Capacitor.isNativePlatform ? window.Capacitor.isNativePlatform() : window.Capacitor.platform !== 'web'));
const DESKTOP = /Electron/i.test(navigator.userAgent);   // نسخة الحاسوب (Windows): بدون قيود CORS
const capPlugins = {};
function capCall(plugin, method, opts) {
  const C = window.Capacitor;
  let P = C?.Plugins?.[plugin];
  if (!(P && typeof P[method] === 'function') && C?.registerPlugin) P = capPlugins[plugin] ??= C.registerPlugin(plugin);
  if (P && typeof P[method] === 'function') return P[method](opts);
  if (C?.nativePromise) return C.nativePromise(plugin, method, opts);
  return Promise.reject(new Error('ميزة غير متاحة في هذه النسخة'));
}
const blobB64 = b => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1] || ''); r.onerror = rej; r.readAsDataURL(b); });

/* يحفظ ملفاً: تنزيل عادي في المتصفح، أو في معرض الهاتف (Movies/FadiFarm أو Pictures/FadiFarm) في تطبيق أندرويد.
   الملف يُنقل على دفعات صغيرة ويُتحقق من حجمه كاملاً قبل إضافته للمعرض. */
const savedUris = new WeakMap();
let saveQueue = Promise.resolve();
const mimeOf = (blob, name) => (blob.type || '').split(';')[0] || (/\.mp4$/i.test(name) ? 'video/mp4' : /\.webm$/i.test(name) ? 'video/webm' : /\.jpe?g$/i.test(name) ? 'image/jpeg' : /\.png$/i.test(name) ? 'image/png' : /\.json$/i.test(name) ? 'application/json' : 'application/octet-stream');

function saveFile(blob, name, { share = false, onProgress } = {}) {
  if (!NATIVE) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 60000);
    return Promise.resolve();
  }
  const mime = mimeOf(blob, name);
  const run = async () => {
    let uri = savedUris.get(blob);
    if (!uri) {
      const id = uid(), CH = 1024 * 1024;
      await capCall('FadiNative', 'begin', { id });
      let size = 0;
      for (let o = 0; o < blob.size; o += CH) {
        const r = await capCall('FadiNative', 'append', { id, data: await blobB64(blob.slice(o, o + CH)) });
        size = r?.size ?? (o + CH);
        onProgress?.(Math.min(1, (o + CH) / blob.size));
      }
      if (size !== blob.size) throw new Error(`تعذّر حفظ الملف كاملاً (${(size / 1e6).toFixed(1)} من ${(blob.size / 1e6).toFixed(1)} MB). تحقق من مساحة الهاتف`);
      const r = await capCall('FadiNative', 'finish', { id, name: name.replace(/(\.\w+)$/, `-${Date.now().toString(36)}$1`), mime });
      uri = r.uri; savedUris.set(blob, uri);
      toast(`حُفظ في المعرض: ${r.folder || 'FadiFarm'}`, '', 5000);
    }
    if (share) await capCall('FadiNative', 'share', { uri, mime, title: name });
    return uri;
  };
  const p = saveQueue.then(run, run);
  saveQueue = p.catch(() => {});
  return p;
}

/* يختار صورة أو فيديو من معرض الهاتف ويرجعه كـ File */
async function pickFromGallery(kind = 'image') {
  if (!NATIVE) return null;
  let r;
  try { r = await capCall('FadiNative', 'pick', { kind }); }
  catch (e) { if (/cancel/i.test(e?.message || '') || e?.code === 'CANCELLED') return null; throw new Error('تعذّر فتح المعرض'); }
  const res = await fetch(window.Capacitor.convertFileSrc('file://' + r.path));
  if (!res.ok) throw new Error('تعذّرت قراءة الملف المختار');
  const b = await res.blob();
  return new File([b], r.name || 'media', { type: r.mime || b.type });
}

/* صندوق نتيجة الفيديو: معاينة + حفظ تلقائي في المعرض + مشاركة */
function resultBox(R, blob, base, title, { auto = true } = {}) {
  const ext = blob.type.includes('mp4') ? 'mp4' : 'webm', name = `${base}.${ext}`, url = URL.createObjectURL(blob);
  const dur = el => el.duration && isFinite(el.duration) ? ` · ${fmt(el.duration)}` : '';
  R.hidden = false;
  R.innerHTML = `<b data-head>${esc(title)} · ${(blob.size / 1e6).toFixed(1)} MB · ${ext.toUpperCase()}</b>
    <video src="${url}" controls playsinline preload="metadata"></video>
    <div class="actions"><button class="btn primary" data-save type="button">${NATIVE ? 'حفظ في المعرض' : 'تنزيل'}</button><button class="btn" data-share type="button">مشاركة</button></div>
    <p class="muted small" data-state></p>`;
  const v = R.querySelector('video'), st = R.querySelector('[data-state]'), sv = R.querySelector('[data-save]');
  v.onloadedmetadata = () => { R.querySelector('[data-head]').textContent += dur(v); };
  const save = async share => {
    sv.disabled = true;
    try {
      await saveFile(blob, name, { share, onProgress: f => { st.textContent = `جارٍ الحفظ في المعرض ${Math.round(f * 100)}%`; } });
      if (NATIVE) { st.textContent = 'محفوظ في المعرض داخل ألبوم FadiFarm'; sv.textContent = 'محفوظ ✓'; }
    } catch (e) { st.textContent = ''; toast(e.message || 'تعذّر الحفظ', 'err', 7000); }
    sv.disabled = false;
  };
  sv.onclick = () => save(false);
  R.querySelector('[data-share]').onclick = async () => {
    if (NATIVE) return save(true);
    try { await navigator.share({ files: [new File([blob], name, { type: blob.type })], title }); } catch { saveFile(blob, name); }
  };
  if (NATIVE && auto) save(false);   // حفظ تلقائي في المعرض (الفيديو الأساسي فقط)
  return url;
}

/* تنزيل الوسائط عبر أندرويد مباشرة (يتجاوز قيود المتصفح على بعض المواقع) */
window.nativeFetchBlob = NATIVE ? async url => {
  const path = 'dl/' + Date.now() + '-' + Math.random().toString(36).slice(2, 8);
  await capCall('Filesystem', 'downloadFile', { url, path, directory: 'CACHE', recursive: true });
  try {
    const { uri } = await capCall('Filesystem', 'getUri', { path, directory: 'CACHE' });
    const r = await fetch(window.Capacitor.convertFileSrc(uri));
    if (!r.ok) throw new Error('read');
    return await r.blob();
  } finally { capCall('Filesystem', 'deleteFile', { path, directory: 'CACHE' }).catch(() => {}); }
} : null;

/* ---------- الحالة ---------- */
const App = {
  scenes: [], buf: null, audioName: '', projName: '', sel: 0, tag: '',
  view: 'project',
  get dims() { const [w, h] = Settings.get().ratio.split('x').map(Number); return { w, h }; },
  get orientation() { const { w, h } = this.dims; return w > h ? 'landscape' : w < h ? 'portrait' : 'square'; },
  get minDim() { const { w, h } = this.dims; const m = Math.min(w, h); return Settings.get().dlQuality === 'high' ? m : Math.min(720, m); },
};

function newScene(text, d, kw = [], kind = 'video') {
  return { id: uid(), text, d, kw, kind, asset: null, blobKey: null, thumbData: '', el: null, type: '', busy: false };
}

/* ---------- الحفظ ---------- */
let saveTimer;
function projectData() {
  return {
    v: 3, name: App.projName, tag: App.tag, audioName: App.audioName, sel: App.sel, text: $('#ttsText')?.value || '', manual: $('#manualText')?.value || '',
    scenes: App.scenes.map(s => ({ id: s.id, text: s.text, d: s.d, kw: s.kw, kind: s.kind, ai: s.ai, offset: s.offset, rej: s.rej, fx: s.fx || null, wt: s.wt || null, wtk: s.wtk || '', asset: s.asset, blobKey: s.blobKey, thumbData: s.thumbData })),
  };
}
function saveNow() { clearTimeout(saveTimer); if (App.switching || !App.loaded) return Promise.resolve(); return Store.set('project', projectData()).then(() => { $('#saveState').textContent = 'محفوظ'; }).catch(() => { $('#saveState').textContent = 'لم يُحفظ'; }); }
function save() {
  $('#saveState').textContent = 'يحفظ…';
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveNow, 500);
}

async function restore() {
  try {
    const p = await Store.get('project');
    if (!p) return;
    App.projName = p.name || ''; App.tag = p.tag || ''; App.audioName = p.audioName || ''; App.sel = p.sel || 0;
    if (p.text && !$('#ttsText').value) $('#ttsText').value = p.text;
    if (p.manual && !$('#manualText').value) $('#manualText').value = p.manual;
    App.scenes = (p.scenes || []).map(s => Object.assign(newScene(s.text, s.d, s.kw, s.kind), s, { el: null, busy: false }));
    $('#projName').value = App.projName;
    const audio = await Store.getBlob('audio');
    if (audio) await loadAudio(audio, App.audioName, { keepScenes: true, silent: true });
  } catch (e) { console.warn(e); }
}

/* ---------- الوسائط الحيّة (تحميل كسول لتوفير ذاكرة الهاتف) ---------- */
const Live = {
  ensure(s) {
    if (s.el || !s.blobKey) return Promise.resolve();
    return s._loading ??= (async () => {
      const b = await Store.getBlob(s.blobKey);
      if (!b) { s.blobKey = null; s.asset = null; return; }
      s.el = await Media.element(b, s.asset.type);
      s.type = s.asset.type;
    })().catch(e => console.warn(e)).finally(() => { s._loading = null; });
  },
  release(s) {
    if (!s.el) return;
    const url = s.el.src;
    if (s.type === 'video') { s.el.pause(); s.el.removeAttribute('src'); s.el.load(); }
    URL.revokeObjectURL(url);
    s.el = null;
  },
  windowAt(i, back = 1, ahead = 3) {
    App.scenes.forEach((s, k) => {
      if (k >= i - back && k <= i + ahead) this.ensure(s);
      else if (k !== App.sel || App.view !== 'scenes') this.release(s);
    });
  },
};

function thumbOf(el, type) {
  try {
    const w = 320, ew = type === 'video' ? el.videoWidth : el.naturalWidth, eh = type === 'video' ? el.videoHeight : el.naturalHeight;
    if (!ew) return '';
    const c = document.createElement('canvas'); c.width = w; c.height = Math.round(w * 9 / 16);
    const x = c.getContext('2d'), k = Math.max(c.width / ew, c.height / eh);
    x.drawImage(el, (c.width - ew * k) / 2, (c.height - eh * k) / 2, ew * k, eh * k);
    return c.toDataURL('image/jpeg', 0.7);
  } catch { return ''; }
}

/* ---------- التنقل ---------- */
function go(view) {
  if (!['project', 'scenes', 'export', 'publish', 'settings'].includes(view)) view = 'project';
  if (Player.playing) stopPlayback();
  $$('#editor video').forEach(v => v.pause());
  App.view = view;
  $$('.view').forEach(v => v.hidden = v.dataset.view !== view);
  $$('.tabs button').forEach(b => b.classList.toggle('on', b.dataset.go === view));
  if (view === 'scenes') renderScenes();
  if (view === 'export') enterExport();
  if (view === 'settings') renderSettings();
  if (view === 'publish') Publish.enter();
  if (view === 'project') { renderProject(); Trends.enter(); Script.enter(); }
  scrollTo({ top: 0 });
  if (location.hash.slice(1) !== view) history.replaceState(null, '', '#' + view);
  try { localStorage.setItem(Channel.key('ff.view'), view); } catch {}
}

/* ---------- الصوت ---------- */
async function loadAudio(blob, name, { keepScenes = false, silent = false } = {}) {
  if (blob.size > 200e6) { toast('الملف أكبر من 200MB', 'err'); return; }
  $('#audioName').textContent = name || 'ملف صوتي';
  $('#audioMeta').textContent = 'جارٍ القراءة…';
  try {
    App.buf = await Player.audioCtx().decodeAudioData(await blob.arrayBuffer());
  } catch {
    $('#audioMeta').textContent = 'تعذّرت قراءة الملف';
    toast('تعذّرت قراءة الصوت. جرّب MP3 أو M4A أو WAV.', 'err');
    return;
  }
  App.audioName = name;
  $('#audioMeta').textContent = `${fmt(App.buf.duration)} دقيقة · ${(blob.size / 1e6).toFixed(1)} MB`;
  drawWave();
  if (!silent) {
    try { await Store.putBlob('audio', blob); } catch { toast('لم يُحفظ الصوت على الجهاز (مساحة غير كافية)', 'err'); }
  }
  if (App.scenes.length && keepScenes) fitDurations();
  if (!silent && App.scenes.length && !keepScenes) {
    if (await confirmBox('يوجد مشاهد من صوت سابق. هل تريد حذفها والبدء من جديد؟', 'ابدأ من جديد')) await clearScenes();
    else fitDurations();
  }
  save(); renderProject();
}

function drawWave() {
  const c = $('#wave'), x = c.getContext('2d');
  c.width = c.clientWidth * devicePixelRatio || 1200;
  const W = c.width, H = c.height, d = App.buf.getChannelData(0), step = Math.floor(d.length / W);
  x.clearRect(0, 0, W, H);
  x.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#2f6b3a';
  for (let i = 0; i < W; i++) {
    let m = 0; const o = i * step;
    for (let j = 0; j < step; j += 16) { const v = Math.abs(d[o + j] || 0); if (v > m) m = v; }
    const h = Math.max(1, m * H * 0.92);
    x.fillRect(i, (H - h) / 2, 1, h);
  }
  // حدود المشاهد
  if (App.scenes.length) {
    x.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--wheat').trim() || '#b07a12';
    let a = 0;
    App.scenes.forEach(s => { a += s.d; x.fillRect(Math.round(a / App.buf.duration * W), 0, 2, H); });
  }
}

function fitDurations() {
  if (!App.buf || !App.scenes.length) return;
  const tot = App.scenes.reduce((a, s) => a + s.d, 0) || 1;
  App.scenes.forEach(s => s.d *= App.buf.duration / tot);
}

async function clearScenes() {
  for (const s of App.scenes) { Live.release(s); if (s.blobKey) await Store.delBlob(s.blobKey).catch(() => {}); }
  App.scenes = []; App.sel = 0;
}

/* ---------- التعليق الصوتي بالذكاء الاصطناعي ---------- */
function fillVoices() {
  const s = Settings.get(), eng = s.ttsEngine || 'auto', d = Channel.dialect;
  const active = eng === 'auto' ? (TTS.order()[0] || 'gemini') : eng;
  const gem = TTS.MALE.map(([id, ds]) => `<option value="${id}">${id} — ${ds}</option>`).join('') +
    (s.extraVoices?.length ? `<optgroup label="أصوات من مكتبة Gemini">${s.extraVoices.map(v => `<option value="${esc(v.id)}">${esc(v.name)}${v.desc ? ' — ' + esc(v.desc) : ''}</option>`).join('')}</optgroup>` : '');
  const az = d.voices.map(([id, n]) => `<option value="${id}">${n} — ${d.name}</option>`).join('');
  const q = $('#ttsVoiceQuick');
  if (q) {
    if (active === 'azure') { q.innerHTML = az; q.value = d.voices.some(v => v[0] === s.azureVoice) ? s.azureVoice : d.voices[0][0]; q.dataset.engine = 'azure'; q.disabled = false; }
    else if (active === 'device') {
      q.dataset.engine = 'device'; q.disabled = false;
      q.innerHTML = '<option value="">تلقائي (أفضل صوت عربي في الهاتف)</option>';
      TTS.phoneVoices().then(vs => { if (q.dataset.engine !== 'device') return; q.innerHTML = '<option value="">تلقائي (أفضل صوت عربي في الهاتف)</option>' + vs.map(v => `<option value="${esc(v.name)}">${esc(v.name)} — ${esc(v.locale)}${v.network ? ' (إنترنت)' : ''}</option>`).join(''); q.value = s.deviceVoice || ''; if (NATIVE && !vs.length) toast('لا توجد أصوات عربية في الهاتف: ثبّت «خدمات النطق من Google» وأضف العربية من إعدادات الهاتف ← تحويل النص إلى كلام', 'err', 9000); });
    }
    else if (active === 'openai') { q.innerHTML = TTS.OAI_VOICES.map(([id, n]) => `<option value="${id}">${n}</option>`).join(''); q.value = s.openaiVoice || 'onyx'; q.dataset.engine = 'openai'; q.disabled = false; }
    else if (active === 'eleven') { q.innerHTML = `<option>${esc(s.elevenVoice || 'الصوت الافتراضي')} (من الإعدادات)</option>`; q.dataset.engine = 'eleven'; q.disabled = true; }
    else { q.innerHTML = gem; q.value = s.ttsVoice; if (!q.value) q.selectedIndex = 0; q.dataset.engine = 'gemini'; q.disabled = false; }
  }
  const sv = $('#ttsVoice'); if (sv) { sv.innerHTML = gem; sv.value = s.ttsVoice; if (!sv.value) sv.selectedIndex = 0; }
  ['#ttsPace', '#ttsPaceQuick'].forEach(sel => { const el = $(sel); if (el) el.value = s.ttsPace; });
  const e = $('#ttsEngine'); if (e) e.value = eng;
  const dl = $('#ttsDialect'), ids = Channel.cur.dialects || ['eg'];
  if (dl) { dl.innerHTML = ids.map(i => `<option value="${i}">${Channel.DIALECTS[i].name}</option>`).join(''); dl.value = Channel.dialectId; $('#ttsDialectWrap').hidden = ids.length < 2; }
  const h = $('#ttsEngineHint');
  if (h) {
    const avail = TTS.order().map(id => TTS.ENGINES[id].name);
    h.textContent = avail.length ? `المحركات المتاحة بالترتيب: ${avail.join(' ← ')}${avail.length < 2 && !NATIVE ? ' · أضف مفتاح Microsoft Azure في الإعدادات كمحرك احتياطي حتى لا يتوقف التسجيل' : ''}` : 'أضف مفتاح Gemini أو Microsoft Azure أو ChatGPT في الإعدادات (في تطبيق أندرويد يوجد صوت الهاتف المجاني).';
    h.classList.toggle('err', avail.length < 1);
  }
}

/* نقاط الصمت في الصوت (وقفات الكلام): مراكز فترات صمت ≥ 180ms */
function findPauses(data, sr) {
  const hop = Math.round(sr * 0.02), n = Math.floor(data.length / hop), rms = new Float32Array(n);
  for (let i = 0; i < n; i++) { let e = 0; for (let k = i * hop; k < (i + 1) * hop; k += 2) e += data[k] * data[k]; rms[i] = Math.sqrt(e / (hop / 2)); }
  const sorted = Array.from(rms).sort((x, y) => x - y), floor = sorted[Math.floor(n * 0.1)] || 0, speech = sorted[Math.floor(n * 0.6)] || 0.05;
  const thr = Math.max(0.006, floor * 2.5, speech * 0.12);
  const out = []; let run = 0;
  for (let i = 0; i <= n; i++) {
    if (i < n && rms[i] < thr) run++;
    else { if (run >= 9) out.push({ t: (i - run / 2) * hop / sr, len: run * hop / sr }); run = 0; }
  }
  return out;
}

/* يقسّم كل مقطع صوتي إلى مشاهد. الحدود تُقدَّر من طول النص ثم تُلصق بأقرب وقفة حقيقية في الصوت */
/* توقيت كلمات كل مجموعة نصية داخل بيانات صوت (ثوانٍ من بداية البيانات) */
function wordGroups(groups, data, sr) {
  const m = Align.mono16(data, sr), ws = Align.fromData(m.data, m.sr, groups.join(' '));
  let i = 0;
  return groups.map(t => { const n = t.split(/\s+/).filter(Boolean).length, r = ws.slice(i, i + n); i += n; return r; });
}

function scenesFromSegments(segs, total) {
  const target = Settings.get().sceneTarget, out = [];
  segs.forEach((g, gi) => {
    const dur = g.end - g.start, cps = g.text.length / Math.max(0.1, dur);
    const parts = g.text.split(/(?<=[.!؟?…])\s+|(?<=[،,؛])\s+/).map(x => x.trim()).filter(Boolean);
    const groups = []; let c = '';
    for (const x of parts) { c = c ? c + ' ' + x : x; if (c.length / cps >= target) { groups.push(c); c = ''; } }
    if (c) { if (groups.length && c.length / cps < target / 2) groups[groups.length - 1] += ' ' + c; else groups.push(c); }
    const L = groups.reduce((a, x) => a + x.length, 0) || 1;
    let bounds, gw = null;
    if (g.data && g.sr) {
      // مزامنة على مستوى الكلمة: كل مشهد يبدأ لحظة نطق أول كلمة فيه
      gw = wordGroups(groups, g.data, g.sr);
      bounds = [0]; groups.slice(1).forEach((t, k) => { const w0 = gw[k + 1][0]; bounds.push(Math.max(bounds[k] + 0.5, w0 ? w0.t0 - 0.08 : bounds[k] + dur * t.length / L)); });
      bounds.push(dur);
    } else { let acc = 0; bounds = [0, ...groups.slice(0, -1).map(t => (acc += dur * t.length / L)), dur]; }
    groups.forEach((t, k) => {
      const sc = newScene(t, Math.max(0.5, bounds[k + 1] - bounds[k]), localKeywords(t));
      if (gw?.[k]?.length) { sc.wt = gw[k].map(w => [+(g.start + w.t0).toFixed(3), +(g.start + w.t1).toFixed(3)]); sc.wtk = t; }
      out.push(sc);
    });
    const gapAfter = (segs[gi + 1]?.start ?? total) - g.end;
    if (out.length) out[out.length - 1].d += Math.max(0, gapAfter);
  });
  if (out.length) out[0].d += segs[0].start;
  const sum = out.reduce((a, x) => a + x.d, 0); if (sum && Math.abs(sum - total) > 0.05) out[out.length - 1].d += total - sum;
  return out;
}

let ttsAbort;
async function makeVoiceover() {
  const text = $('#ttsText').value.trim();
  if (!text) return toast('اكتب أو الصق النص أولاً', 'err');
  if (!TTS.order().length) { go('settings'); return toast('أضف مفتاح Gemini أو Microsoft Azure للصوت أولاً', 'err'); }
  if (App.scenes.length && !(await confirmBox('سيُستبدل المشروع الحالي بفيديو جديد من هذا النص.', 'ابدأ'))) return;
  const box = $('#ttsProgress'); ttsAbort = new AbortController();
  $('#btnTTS').disabled = true;
  try {
    const { buffer, segs, engine } = await TTS.speak(text, { signal: ttsAbort.signal, onProgress: (t, f) => setProgress(box, f * 0.9, t) });
    setProgress(box, 0.95, 'تجهيز المشاهد…');
    await finishVoice(buffer, segs, text, `تعليق صوتي باللهجة ${Channel.dialect.name} (${engine})`, `محرك ${engine}`);
  } catch (e) {
    if (e.name !== 'AbortError') toast(e.message, 'err', 7000);
  } finally { box.hidden = true; $('#btnTTS').disabled = false; ttsAbort = null; }
}

/* بعد تجهيز الصوت (من Gemini أو Google Vids): المشاهد ثم جلب اللقطات تلقائياً */
async function finishVoice(buffer, segs, text, label, meta) {
  const wavBlob = TTS.wav(buffer);
  await clearScenes(); Publish.reset();
  Store.delBlob('out-main').catch(() => {}); $('#exResult').hidden = true; lastExport = null;
  App.buf = buffer; App.audioName = label;
  if (!App.projName) { App.projName = text.split(/\s+/).slice(0, 6).join(' '); $('#projName').value = App.projName; }
  try { await Store.putBlob('audio', wavBlob); } catch { toast('لم يُحفظ الصوت على الجهاز (مساحة غير كافية)', 'err'); }
  $('#audioName').textContent = App.audioName;
  $('#audioMeta').textContent = `${fmt(buffer.duration)} دقيقة · ${meta}`;
  App.scenes = scenesFromSegments(segs, buffer.duration);
  $('#manualText').value = text;
  const au = $('#ttsAudio'); au.hidden = false; au.src = URL.createObjectURL(wavBlob);
  save(); drawWave(); renderProject();
  autoFx({ quiet: true }).catch(() => {});     // نصوص الشاشة والأسئلة فوراً (لا تنتظر جلب اللقطات)
  if (Settings.get().mediaMode === 'own') { toast(`التعليق جاهز · ${App.scenes.length} مشهد. أضف صورك وفيديوهاتك من صفحة المشاهد`, '', 7000); go('scenes'); return; }
  toast(`التعليق جاهز (${fmt(buffer.duration)}) · ${App.scenes.length} مشهد. جارٍ جلب اللقطات…`);
  setTimeout(() => autoFetch(), 300);
}

/* ---------- Google Vids: أجزاء أقل من 2500 حرف ثم جمعها ---------- */
const VIDS_MAX = 2400;
const Vids = { parts: [], pending: -1 };
const CTA_DEFAULT = 'ولو عايز تعرف الحكاية كاملة، الفيديو كامل تحت. ادخل شوفه دلوقتي!';
const ctaLine = () => (Settings.get().reelCta || CTA_DEFAULT).trim();
/* أجزاء النص + جزء أخير قصير لجملة نهاية الريل (لا يدخل في الفيديو الأساسي) */
const vidsMakeParts = text => [...vidsChunks(text).map(t => ({ text: t, key: null, dur: 0, name: '' })), { text: ctaLine(), key: null, dur: 0, name: '', cta: true }];
const mainParts = () => Vids.parts.filter(p => !p.cta);

function vidsChunks(text, max = VIDS_MAX) {
  const sents = text.replace(/[ \t]+/g, ' ').split(/(?<=[.!؟?…\n])\s*/).map(x => x.trim()).filter(Boolean);
  const pieces = [];
  for (const s of sents) {
    if (s.length <= max) { pieces.push(s); continue; }
    let rest = s;
    while (rest.length > max) {
      let cut = Math.max(rest.lastIndexOf('،', max), rest.lastIndexOf(',', max));
      if (cut < max * 0.5) cut = rest.lastIndexOf(' ', max);
      if (cut < 1) cut = max;
      pieces.push(rest.slice(0, cut + 1).trim()); rest = rest.slice(cut + 1).trim();
    }
    if (rest) pieces.push(rest);
  }
  const out = []; let c = '';
  for (const p of pieces) { if (c && (c + ' ' + p).length > max) { out.push(c); c = p; } else c = c ? c + ' ' + p : p; }
  if (c) out.push(c);
  return out;
}

const vidsSave = () => App.switching ? Promise.resolve() : Store.set('vids', { parts: Vids.parts.map(({ text, key, dur, name, cta }) => ({ text, key, dur, name, cta })) }).catch(() => {});
async function vidsLoad() { try { const v = await Store.get('vids'); if (v?.parts) Vids.parts = v.parts; } catch {} if (Vids.parts.length && !Vids.parts.some(p => p.cta)) Vids.parts.push({ text: ctaLine(), key: null, dur: 0, name: '', cta: true }); renderVids(); }

function renderVids() {
  const L = $('#vidsParts'); if (!L) return;
  L.innerHTML = Vids.parts.map((p, i) => `<li class="part${p.key ? ' done' : ''}">
    <div><b>${p.cta ? 'جملة نهاية الريل' : 'الجزء ' + (i + 1)}</b> <span class="muted small num">${p.text.length.toLocaleString('en')} حرف</span> ${p.key ? `<span class="chip ok">✓ ${fmt(p.dur)}</span>` : '<span class="chip warn">ينتظر الصوت</span>'}<p>${esc(p.text)}</p></div>
    <div class="actions"><button class="btn sm" data-vcopy="${i}" type="button">نسخ</button><button class="btn ${p.key ? 'ghost' : 'primary'} sm" data-vadd="${i}" type="button">${p.key ? 'غيّر الصوت' : 'أضف الصوت'}</button></div></li>`).join('');
  const mp = mainParts(), all = mp.length && mp.every(p => p.key);
  $('#btnVidsBuild').hidden = !Vids.parts.length;
  $('#btnVidsBuild').disabled = !all;
  $('#btnVidsBuild').textContent = all ? `اجمع الأجزاء (${mp.length}) واصنع الفيديو` : `أضف صوت كل الأجزاء (${mp.filter(p => p.key).length} من ${mp.length})`;
}

async function vidsSplit() {
  const text = $('#ttsText').value.trim();
  if (!text) return toast('الصق النص أولاً', 'err');
  if (Vids.parts.some(p => p.key) && !(await confirmBox('سيُعاد تقسيم النص وتُحذف أصوات الأجزاء المضافة.', 'أعد التقسيم'))) return;
  for (const p of Vids.parts) if (p.key) await Store.delBlob(p.key).catch(() => {});
  Vids.parts = vidsMakeParts(text);
  vidsSave(); renderVids();
  toast(Vids.parts.length === 1 ? 'النص جزء واحد. انسخه إلى Google Vids' : `قُسّم النص إلى ${Vids.parts.length} أجزاء`);
}

async function copyText(t) {
  try { await navigator.clipboard.writeText(t); return true; }
  catch {
    const ta = document.createElement('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.append(ta); ta.select(); let ok = false; try { ok = document.execCommand('copy'); } catch {} ta.remove(); return ok;
  }
}

async function vidsAddAudio(i, file) {
  const p = Vids.parts[i]; if (!p || !file) return;
  try {
    const buf = await Player.audioCtx().decodeAudioData(await file.arrayBuffer());
    if (buf.duration < 1) throw new Error('short');
    const key = 'vids-' + i + '-' + uid();
    await Store.putBlob(key, file);
    if (p.key) Store.delBlob(p.key).catch(() => {});
    Object.assign(p, { key, dur: buf.duration, name: file.name });
    if (p.cta) {   // جملة نهاية الريل: تُحفظ فوراً بدون الصمت
      const m = new Float32Array(buf.length); for (let c = 0; c < buf.numberOfChannels; c++) { const d = buf.getChannelData(c); for (let k = 0; k < d.length; k++) m[k] += d[k] / buf.numberOfChannels; }
      const tr = trimSilence(m, buf.sampleRate), ob = Player.audioCtx().createBuffer(1, tr.length, buf.sampleRate); ob.getChannelData(0).set(tr);
      await Store.putBlob('reel-cta', TTS.wav(ob)).catch(() => {});
    }
    vidsSave(); renderVids();
    const next = Vids.parts.findIndex(x => !x.key);
    toast(next < 0 ? 'كل الأجزاء جاهزة. اضغط «اجمع الأجزاء»' : `أُضيف صوت الجزء ${i + 1}. التالي: الجزء ${next + 1}`);
  } catch { toast('تعذّرت قراءة الصوت من هذا الملف. نزّل الفيديو من Google Vids بصيغة MP4 وجرّب مرة أخرى', 'err', 7000); }
}

function trimSilence(ch, sr) {
  const thr = 0.01; let a = 0, b = ch.length - 1;
  while (a < b && Math.abs(ch[a]) < thr) a++;
  while (b > a && Math.abs(ch[b]) < thr) b--;
  return ch.subarray(Math.max(0, a - Math.round(sr * 0.08)), Math.min(ch.length, b + Math.round(sr * 0.2)));
}

async function vidsBuild() {
  const parts = mainParts();
  if (!parts.length || parts.some(p => !p.key)) return;
  if (App.scenes.length && !(await confirmBox('سيُستبدل المشروع الحالي بفيديو جديد من أجزاء Google Vids.', 'ابدأ'))) return;
  const box = $('#ttsProgress'); $('#btnVidsBuild').disabled = true;
  try {
    const ctx = Player.audioCtx(), sr = ctx.sampleRate, gap = Math.round(sr * 0.3), datas = [];
    for (let i = 0; i < parts.length; i++) {
      setProgress(box, i / parts.length * 0.9, `قراءة صوت الجزء ${i + 1} من ${parts.length}…`);
      const b = await Store.getBlob(parts[i].key);
      if (!b) throw new Error(`صوت الجزء ${i + 1} غير موجود، أضفه مرة أخرى`);
      const buf = await ctx.decodeAudioData(await b.arrayBuffer());
      const mono = new Float32Array(buf.length);
      for (let c = 0; c < buf.numberOfChannels; c++) { const d = buf.getChannelData(c); for (let k = 0; k < d.length; k++) mono[k] += d[k] / buf.numberOfChannels; }
      datas.push(trimSilence(mono, buf.sampleRate));
    }
    const total = datas.reduce((a, d) => a + d.length, 0) + gap * (datas.length - 1);
    const out = ctx.createBuffer(1, total, sr), o = out.getChannelData(0), segs = [];
    let pos = 0;
    datas.forEach((d, i) => { o.set(d, pos); segs.push({ text: parts[i].text, start: pos / sr, end: (pos + d.length) / sr, data: d, sr }); pos += d.length + gap; });
    // جملة نهاية الريل بنفس الصوت
    const cta = Vids.parts.find(p => p.cta && p.key);
    if (cta) { try { const cb = await ctx.decodeAudioData(await (await Store.getBlob(cta.key)).arrayBuffer()); const m = new Float32Array(cb.length); for (let c = 0; c < cb.numberOfChannels; c++) { const d = cb.getChannelData(c); for (let k = 0; k < d.length; k++) m[k] += d[k] / cb.numberOfChannels; } const tr = trimSilence(m, cb.sampleRate); const ob = ctx.createBuffer(1, tr.length, cb.sampleRate); ob.getChannelData(0).set(tr); await Store.putBlob('reel-cta', TTS.wav(ob)); } catch {} }
    setProgress(box, 0.95, 'تجهيز المشاهد…');
    await finishVoice(out, segs, parts.map(p => p.text).join(' '), 'تعليق صوتي (Google Vids)', `${parts.length} أجزاء من Google Vids`);
  } catch (e) { toast(e.message || 'تعذّر جمع الأجزاء', 'err', 7000); }
  finally { box.hidden = true; renderVids(); }
}

async function vidsOnFound(i, f) {
  if (App.view !== 'project') go('project');
  await vidsAddAudio(i, f);
  if (!Vids.parts[i]?.key) return;
  if (Vids.parts.every(p => p.key)) { toast('اكتملت الأجزاء. أجمعها الآن…'); setTimeout(vidsBuild, 800); }
  else { const nx = Vids.parts.findIndex(p => !p.key); Capture.countdown(4, Vids.parts[nx].cta ? 'نسخ جملة نهاية الريل وفتح Google Vids' : `نسخ الجزء ${nx + 1} وفتح Google Vids`, vidsAuto); }
}

/* التسجيل التلقائي: جزء ← Google Vids ← التقاط التنزيل ← الجزء التالي ← الجمع */
async function vidsAuto() {
  const text = $('#ttsText').value.trim();
  if (!Vids.parts.length || mainParts().map(p => p.text).join(' ').replace(/\s+/g, ' ') !== text.replace(/\s+/g, ' ')) {
    if (!text) return toast('الصق النص أولاً', 'err');
    if (Vids.parts.some(p => p.key) && !(await confirmBox('النص تغيّر. سيُعاد التقسيم وتُحذف الأصوات السابقة.', 'متابعة'))) return;
    for (const p of Vids.parts) if (p.key) await Store.delBlob(p.key).catch(() => {});
    Vids.parts = vidsMakeParts(text); vidsSave(); renderVids();
  }
  const i = Vids.parts.findIndex(p => !p.key);
  if (i < 0) return vidsBuild();
  if (!(await Capture.prepare())) return;
  Capture.start({
    kind: 'video', action: 'vids', meta: { i }, label: Vids.parts[i].cta ? 'صوت جملة نهاية الريل من Google Vids' : `صوت الجزء ${i + 1} من ${mainParts().length} من Google Vids`,
    onFound: f => vidsOnFound(i, f),
  });
  await Capture.copyOpen(Vids.parts[i].text, 'vids');
  toast(`نُسخ ${Vids.parts[i].cta ? 'جملة نهاية الريل' : 'الجزء ' + (i + 1)}. في Google Vids: الصقه كتعليق صوتي، أنشئه، ثم نزّل MP4`, '', 8000);
}

function setVoiceMode(m) {
  Settings.set({ voiceMode: m });
  $$('#voiceMode button').forEach(b => b.classList.toggle('on', b.dataset.mode === m));
  $('#modeVids').hidden = m !== 'vids'; $('#modeGemini').hidden = m !== 'gemini';
  if (m === 'gemini') fillVoices();
}

async function previewVoice() {
  if (!TTS.order().length) return toast('أضف مفتاح Gemini أو Microsoft Azure أولاً', 'err');
  const t = ($('#ttsText').value.trim() || (Channel.id === 'farm' ? 'أهلاً بيكم يا جماعة في قناة فادي فارم، النهارده هنتكلم عن تربية الفراخ البلدي.' : 'أهلاً بيكم في قناة مجرى، النهارده عندنا قصة غريبة جداً.')).slice(0, 220);
  const b = $('#btnTTSPreview'); b.disabled = true; b.textContent = 'جارٍ التسجيل…';
  try {
    const { buffer } = await TTS.speak(t.split(/(?<=[.!؟?])\s/)[0]);
    const au = $('#ttsAudio'); au.hidden = false; au.src = URL.createObjectURL(TTS.wav(buffer)); au.play().catch(() => {});
  } catch (e) { toast(e.message, 'err', 6000); }
  b.disabled = false; b.textContent = 'جرّب الصوت';
}

/* ---------- بناء المشاهد ---------- */
let trAbort;
async function transcribe() {
  if (!App.buf) return toast('اختر ملف الصوت أولاً', 'err');
  if (!Settings.get().keys.gemini) { go('settings'); return toast('أضف مفتاح Gemini أولاً', 'err'); }
  if (App.scenes.length && !(await confirmBox('سيُستبدل المشاهد الحالية بنتيجة التفريغ الجديدة.', 'متابعة'))) return;
  const box = $('#trProgress'); trAbort = new AbortController();
  $('#btnTranscribe').disabled = true;
  try {
    const res = await AI.transcribe(App.buf, { target: Settings.get().sceneTarget, signal: trAbort.signal, onProgress: (t, f) => setProgress(box, f, t) });
    await clearScenes(); Publish.reset();
    App.scenes = res.map(r => Object.assign(newScene(r.text, r.d, r.kw, r.kind), { ai: true }));
    $('#manualText').value = res.map(r => r.text).join('\n');
    toast(`تم التفريغ: ${App.scenes.length} مشهد. جارٍ جلب اللقطات…`);
    save(); drawWave(); renderProject();
    autoFx({ quiet: true }).catch(() => {});
    if (Settings.get().mediaMode !== 'own') setTimeout(() => autoFetch(), 300); else go('scenes');
  } catch (e) {
    if (e.name !== 'AbortError') toast(e.message, 'err', 6000);
  } finally {
    box.hidden = true; $('#btnTranscribe').disabled = false; trAbort = null;
  }
}

async function splitManual() {
  if (!App.buf) return toast('اختر ملف الصوت أولاً، المدة تُحسب منه', 'err');
  const t = $('#manualText').value.trim();
  if (!t) return toast('الصق النص أولاً', 'err');
  if (App.scenes.length && !(await confirmBox('سيُستبدل المشاهد الحالية.', 'متابعة'))) return;
  const target = Settings.get().sceneTarget, cps = t.length / App.buf.duration;
  const parts = t.split(/(?<=[.!؟?۔…\n])\s*|(?<=[،,؛;])\s+/).map(x => x.trim()).filter(Boolean);
  const out = []; let c = '';
  for (const x of parts) {
    c = c ? c + ' ' + x : x;
    if (c.length / cps >= target) { out.push(c); c = ''; }
  }
  if (c) { if (out.length && c.length / cps < target / 2) out[out.length - 1] += ' ' + c; else out.push(c); }
  const L = out.reduce((a, x) => a + x.length, 0), D = App.buf.duration;
  await clearScenes();
  let gw = null; try { const m = Align.monoBuf(App.buf); gw = wordGroups(out, m.data, m.sr); } catch (e) { console.warn(e); }
  const bounds = [0];
  out.slice(1).forEach((x, k) => { const w0 = gw?.[k + 1]?.[0]; bounds.push(Math.max(bounds[k] + 0.5, w0 ? w0.t0 - 0.08 : bounds[k] + D * out[k].length / L)); });
  bounds.push(D);
  App.scenes = out.map((x, k) => { const sc = newScene(x, Math.max(0.5, bounds[k + 1] - bounds[k]), localKeywords(x)); if (gw?.[k]?.length) { sc.wt = gw[k].map(w => [+w.t0.toFixed(3), +w.t1.toFixed(3)]); sc.wtk = x; } return sc; });
  save(); drawWave(); renderProject();
  if (LLM.available().length) {
    const box = $('#trProgress');
    setProgress(box, 0.3, 'الذكاء الاصطناعي يقترح كلمات بحث بصرية…');
    try {
      const kws = await AI.keywords(App.scenes.map(s => s.text));
      App.scenes.forEach((s, i) => { if (kws[i]?.kw.length) { s.kw = kws[i].kw; s.kind = kws[i].kind; s.ai = true; } });
      save(); toast('أُضيفت كلمات البحث');
    } catch (e) { toast(e.message, 'err'); }
    box.hidden = true;
  }
  renderProject();
  autoFx({ quiet: true }).catch(() => {});
  if (Settings.get().mediaMode === 'own') { go('scenes'); return toast('أضف صورك وفيديوهاتك من صفحة المشاهد', '', 6000); }
  autoFetch();
}

function localKeywords(n) {
  if (!Channel.cur.topicFilter) return [];
  return FarmDict.translate(n).slice(0, 4);
}

/* ---------- واجهة المشروع ---------- */
function renderProject() {
  const s = Settings.get();
  $('#sceneTarget').value = s.sceneTarget; $('#sceneTargetOut').textContent = s.sceneTarget + ' ث';
  $('#geminiHint').hidden = !!s.keys.gemini;
  const n = App.scenes.length, miss = App.scenes.filter(x => !x.blobKey).length;
  $('#nextStep').hidden = !n;
  if (n) {
    $('#nextTitle').textContent = miss ? `${n} مشهد جاهز` : 'كل المشاهد لها وسائط';
    $('#nextText').textContent = miss ? `الخطوة التالية: جلب لقطة لكل مشهد (${miss} متبقٍ) من مصادر الفيديو والصور.` : 'انتقل إلى التصدير لمعاينة الفيديو.';
    $('#btnAutoAll').textContent = miss ? 'اجلب اللقطات الآن' : 'افتح المعاينة';
  }
  $('#scenesDot').hidden = !miss || !n;
}

/* ---------- واجهة المشاهد ---------- */
const searchState = { q: '', kind: 'video', only: '', items: [], status: {}, loading: false, forScene: null };

function renderScenes() {
  const n = App.scenes.length;
  const miss = App.scenes.filter(s => !s.blobKey).length;
  $('#scenesSummary').textContent = n ? `${n} مشهد · ${fmt(App.buf?.duration || App.scenes.reduce((a, s) => a + s.d, 0))} · ${miss ? miss + ' بدون وسائط' : 'كلها جاهزة'}` : 'لا توجد مشاهد بعد. ابدأ من قسم المشروع.';
  $('#btnAutoAll2').disabled = $('#btnReAll').disabled = !n;
  { const k = Settings.get().keys, on = id => Settings.get().providers.find(p => p.id === id)?.on; $('#keysBanner').hidden = !n || ((k.pexels || !on('pexels')) && (k.pixabay || !on('pixabay'))); }
  renderStrip();
  renderEditor();
  renderProject();
}

function renderStrip() {
  const { st } = Renderer.timeline(App.scenes);
  $('#strip').innerHTML = App.scenes.map((s, i) => {
    const th = s.thumbData || s.asset?.thumb;
    return `<button class="scene-card${i === App.sel ? ' on' : ''}" role="option" aria-selected="${i === App.sel}" data-i="${i}" type="button">
      <span class="thumb">${s.busy ? '<i class="busy"></i>' : th ? `<img src="${esc(th)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : '<span class="miss">بدون وسائط</span>'}
        <span class="n num">${i + 1}</span><span class="t num">${fmt(st[i])}</span>${s.fx ? `<span class="fxb fx-${s.fx.type}">${Fx.TYPES[s.fx.type]?.name || ''}</span>` : ''}</span>
      <p>${esc(s.text)}</p></button>`;
  }).join('');
  $('#strip .on')?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
}

function renderEditor() {
  const s = App.scenes[App.sel], E = $('#editor');
  if (!s) { E.innerHTML = App.scenes.length ? '' : '<div class="empty">ارفع الصوت وفرّغه أو الصق النص في قسم المشروع، وستظهر المشاهد هنا.</div>'; return; }
  const { st } = Renderer.timeline(App.scenes);
  const a = s.asset, P = a && PROVIDERS[a.provider];
  if (searchState.forScene !== s.id) {
    searchState.forScene = s.id; searchState.items = []; searchState.status = {};
    searchState.q = s.kw.find(w => !isArabic(w)) || FarmDict.translate(s.text)[0] || projectSubjects()[0] || '';
    searchState.kind = s.kind || 'video';
  }
  E.innerHTML = `
  <div class="panel">
    <div class="panel-head"><h2>المشهد ${App.sel + 1}</h2><span class="muted num">${fmt(st[App.sel])} → ${fmt(st[App.sel] + s.d)}</span></div>
    <div class="cur-media" id="curMedia">${s.busy ? 'جارٍ التنزيل…' : s.blobKey ? '' : 'لم تُختر صورة أو فيديو'}</div>
    ${a ? `<p class="credit"><b>${esc(a.title || '')}</b><br>${a.creator ? 'المؤلف: ' + (a.creatorUrl ? `<a href="${esc(a.creatorUrl)}" target="_blank" rel="noopener">${esc(a.creator)}</a>` : esc(a.creator)) + ' · ' : ''}${esc(P?.name || 'من جهازك')} · ${a.licenseUrl ? `<a href="${esc(a.licenseUrl)}" target="_blank" rel="noopener">${esc(a.license)}</a>` : esc(a.license || '')}${a.pageUrl ? ` · <a href="${esc(a.pageUrl)}" target="_blank" rel="noopener">صفحة المصدر</a>` : ''}</p>` : ''}
    <label class="field"><span>النص</span><textarea id="sText" rows="3">${esc(s.text)}</textarea></label>
    <div class="row">
      <label class="field"><span>المدة (ثانية)</span><input id="sDur" type="number" step="0.1" min="0.5" value="${s.d.toFixed(1)}" inputmode="decimal"></label>
      <label class="field"><span>كلمات البحث</span><input id="sKw" type="text" dir="auto" value="${esc(s.kw.join(', '))}"></label>
    </div>
    <p class="muted small">تغيير المدة يأخذ الوقت من المشهد التالي، فيبقى الصوت متزامناً.</p>
    <div class="fxbox">
      <div class="panel-head"><h3>نص على الشاشة</h3>${s.fx ? `<span class="chip ${s.fx.manual ? 'ok' : ''}">${s.fx.manual ? 'معدّل يدوياً' : 'اقتراح تلقائي'}</span>` : ''}</div>
      <div class="row">
        <label class="field"><span>النوع</span><select id="fxType"><option value="">بدون</option>${Object.entries(Fx.TYPES).map(([k, v]) => `<option value="${k}" ${s.fx?.type === k ? 'selected' : ''}>${v.name}</option>`).join('')}</select></label>
        <label class="field"><span>النص (قصير)</span><input id="fxText" type="text" value="${esc(s.fx?.text || '')}" placeholder="مثال: سر البيض الكتير"></label>
      </div>
      <div class="row" ${s.fx ? '' : 'hidden'} id="fxMore">
        <label class="field" ${s.fx?.type === 'key' ? '' : 'hidden'}><span>الكلمة المميزة</span><input id="fxEmph" type="text" value="${esc(s.fx?.emph || '')}"></label>
        <label class="field" ${s.fx?.type === 'number' ? '' : 'hidden'}><span>وصف تحت الرقم</span><input id="fxSub" type="text" value="${esc(s.fx?.sub || '')}"></label>
        <label class="field"><span>المكان على الشاشة</span><select id="fxPos">${s.fx ? ['auto', ...(Fx.ZONES[s.fx.type] || [])].map(z => `<option value="${z}" ${(s.fx.pos || 'auto') === z ? 'selected' : ''}>${Fx.POS[z]}</option>`).join('') : ''}</select></label>
      </div>
      <div class="fx-prev"><canvas id="fxPrev" width="640" height="360"></canvas><button class="btn ghost sm" id="fxPlay" type="button">▶ معاينة الحركة</button></div>
    </div>
    <div class="actions">
      <button class="btn ghost sm" data-op="prev" type="button">السابق</button>
      <button class="btn ghost sm" data-op="next" type="button">التالي</button>
      <button class="btn ghost sm" data-op="split" type="button">قسّم</button>
      <button class="btn ghost sm" data-op="merge" type="button">ادمج مع التالي</button>
      <button class="btn sm" data-op="another" type="button">لقطة أخرى</button>
      <button class="btn ghost sm" data-op="clear" type="button" ${s.blobKey ? '' : 'disabled'}>أزل الوسائط</button>
      <button class="btn danger sm" data-op="del" type="button">احذف</button>
    </div>
  </div>
  <div class="panel">
    <div class="panel-head"><h2>ابحث عن لقطة</h2>
      <div class="seg" role="group" aria-label="النوع"><button data-kind="video" class="${searchState.kind === 'video' ? 'on' : ''}" type="button">فيديو</button><button data-kind="image" class="${searchState.kind === 'image' ? 'on' : ''}" type="button">صورة</button></div>
    </div>
    <form class="searchbar" id="searchForm">
      <input id="q" type="search" dir="auto" value="${esc(searchState.q)}" placeholder="بالإنجليزية أفضل: goat farm, sunrise field">
      <button class="btn primary" type="submit">بحث</button>
      <input id="localFile" type="file" accept="image/*,video/*" hidden>
      ${NATIVE ? '<button class="btn" id="btnGalImg" type="button">صورة من المعرض</button><button class="btn" id="btnGalVid" type="button">فيديو من المعرض</button>' : '<button class="btn" id="btnLocal" type="button">من جهازك</button>'}
    </form>
    <div class="pchips" id="pchips"></div>
    <div class="results" id="results"></div>
    <div class="status-line" id="sStatus"></div>
  </div>`;
  renderChips(); renderResults(); showCurrentMedia(); fxPreview();
  if (!searchState.items.length && searchState.q && !searchState.loading) runSearch();
}

async function showCurrentMedia() {
  const s = App.scenes[App.sel], box = $('#curMedia');
  if (!s || !box || !s.blobKey) return;
  await Live.ensure(s);
  if (!s.el || App.scenes[App.sel] !== s) return;
  box.innerHTML = '';
  if (s.type === 'video') {
    const v = document.createElement('video');
    Object.assign(v, { src: s.el.src, muted: true, loop: true, playsInline: true, autoplay: true, controls: false });
    box.append(v);
  } else {
    const im = document.createElement('img'); im.src = s.el.src; im.alt = s.asset?.title || ''; box.append(im);
  }
}

function renderChips() {
  const k = searchState.kind, en = Settings.get().providers.filter(p => p.on && PROVIDERS[p.id].kinds.includes(k));
  $('#pchips').innerHTML = `<button data-only="" class="${!searchState.only ? 'on' : ''}" type="button">كل المصادر</button>` +
    en.map(p => `<button data-only="${p.id}" class="${searchState.only === p.id ? 'on' : ''}" type="button">${esc(PROVIDERS[p.id].name.split(' ')[0])}</button>`).join('');
}

function renderResults() {
  const R = $('#results'); if (!R) return;
  const used = new Set(App.scenes.map(s => s.asset?.uid).filter(Boolean));
  if (searchState.loading) { R.innerHTML = '<div class="empty" style="grid-column:1/-1">جارٍ البحث…</div>'; }
  else if (!searchState.items.length) { R.innerHTML = `<div class="empty" style="grid-column:1/-1">${searchState.q ? 'لا نتائج. جرّب كلمات إنجليزية أبسط أو نوعاً آخر.' : 'اكتب كلمة بحث.'}</div>`; }
  else R.innerHTML = searchState.items.map((it, i) => `<button class="res" data-r="${i}" type="button" title="${esc(it.title)}">
      <img src="${esc(it.thumb)}" alt="${esc(it.title)}" loading="lazy" referrerpolicy="no-referrer">
      ${used.has(it.uid) ? '<span class="used">مستخدم</span>' : ''}
      <span class="meta"><span>${esc(PROVIDERS[it.provider].name.split(' ')[0])}</span><span class="num">${it.duration ? fmt(it.duration) : it.type === 'image' ? 'صورة' : ''}</span></span></button>`).join('');
  const st = searchState.status;
  $('#sStatus').innerHTML = Object.keys(st).map(id => {
    const n = PROVIDERS[id].name, m = String(st[id]).replace(/^[^:]+:\s*/, '');
    return `<span>${esc(n)}: ${esc(m)}</span>`;
  }).join('');
}

let searchSeq = 0;
async function runSearch() {
  const q = searchState.q.trim(); if (!q) return renderResults();
  const my = ++searchSeq;
  searchState.loading = true; renderResults();
  const r = await searchProviders(q, searchState.kind, { only: searchState.only, orientation: App.orientation, minDim: App.minDim });
  if (my !== searchSeq) return;
  searchState.loading = false; searchState.status = r.status;
  searchState.items = r.items.filter(it => !Relevance.blocked(it)).map((it, i) => ({ it, s: Relevance.score(it, q, []) - i * 0.01 })).sort((a, b) => b.s - a.s).map(x => x.it);
  renderResults();
}

/* تطبيق عنصر من نتائج البحث على مشهد */
async function applyItem(s, it, { quiet = false, signal } = {}) {
  s.busy = true; if (!quiet) { renderStrip(); const b = $('#curMedia'); if (b && App.scenes[App.sel] === s) b.textContent = 'جارٍ التنزيل…'; }
  try {
    let urls = it.urls;
    if (it.resolve) urls = [...(await it.resolve()), ...urls];
    if (!urls.length) throw new Error('لم يُعثر على ملف قابل للتنزيل');
    const blob = await Media.fetchBlob(urls, {
      signal,
      onProgress: quiet ? null : (f, got) => { const b = $('#curMedia'); if (b && App.scenes[App.sel] === s) b.textContent = f ? `جارٍ التنزيل ${Math.round(f * 100)}%` : `جارٍ التنزيل ${(got / 1e6).toFixed(1)}MB`; },
    });
    const el = await Media.element(blob, it.type);
    const key = 'a-' + s.id + '-' + uid();
    await Store.putBlob(key, blob);
    const old = s.blobKey;
    Live.release(s);
    s.el = el; s.type = it.type; s.blobKey = key;
    s.asset = { uid: it.uid, provider: it.provider, type: it.type, title: it.title, thumb: it.thumb, creator: it.creator, creatorUrl: it.creatorUrl, license: it.license, licenseUrl: it.licenseUrl, pageUrl: it.pageUrl };
    s.thumbData = thumbOf(el, it.type);
    if (s.fx) delete s.fx._z;
    if (old && !App.scenes.some(x => x !== s && x.blobKey === old)) Store.delBlob(old).catch(() => {});
    it.onUse?.();
    save();
    return true;
  } catch (e) {
    if (e.name === 'AbortError') throw e;
    if (!quiet) toast(`${e.message}. جرّب نتيجة أخرى.`, 'err');
    return false;
  } finally {
    s.busy = false;
    if (!quiet && App.view === 'scenes') { renderStrip(); if (App.scenes[App.sel] === s) renderEditor(); }
  }
}

async function applyLocal(s, file) {
  if (!file) return;
  const type = file.type.startsWith('video') ? 'video' : 'image';
  try {
    const el = await Media.element(file, type);
    const key = 'a-' + s.id + '-' + uid();
    await Store.putBlob(key, file);
    const old = s.blobKey; Live.release(s);
    s.el = el; s.type = type; s.blobKey = key;
    s.asset = { uid: 'local-' + key, provider: 'local', type, title: file.name, thumb: '', creator: '', license: 'ملفك الخاص', licenseUrl: '', pageUrl: '' };
    s.thumbData = thumbOf(el, type);
    if (old && !App.scenes.some(x => x !== s && x.blobKey === old)) Store.delBlob(old).catch(() => {});
    save(); renderScenes();
  } catch (e) { toast(e.message, 'err'); }
}

/* صوري وفيديوهاتي: توزيع عدة ملفات على المشاهد بالترتيب (الملف الواحد قد يغطي عدة مشاهد بمقاطع مختلفة) */
async function bulkOwn(files) {
  files = [...files].filter(f => /^(image|video)\//.test(f.type));
  if (!files.length || !App.scenes.length) return toast(App.scenes.length ? 'لم تُختر صور أو فيديوهات' : 'جهّز التعليق الصوتي والمشاهد أولاً', 'err');
  const box = $('#autoProgress'), N = files.length, M = App.scenes.length, keys = [];
  try {
    for (let k = 0; k < N; k++) { setProgress(box, k / N * 0.5, `حفظ ملفاتك ${k + 1} من ${N}…`); const key = 'u-' + uid(); await Store.putBlob(key, files[k]); keys.push(key); }
    const uses = new Map();
    for (let i = 0; i < M; i++) {
      setProgress(box, 0.5 + i / M * 0.5, `توزيع على المشاهد ${i + 1} من ${M}…`);
      const s = App.scenes[i], fi = Math.min(N - 1, Math.floor(i * N / M)), f = files[fi], type = f.type.startsWith('video') ? 'video' : 'image';
      const n = uses.get(fi) || 0; uses.set(fi, n + 1);
      const old = s.blobKey; Live.release(s);
      const el = await Media.element(f, type).catch(() => null); if (!el) continue;
      s.el = el; s.type = type; s.blobKey = keys[fi]; s.offset = type === 'video' ? n * 4 : 0;
      s.asset = { uid: 'local-' + keys[fi], provider: 'local', type, title: f.name, thumb: '', creator: '', license: 'ملفك الخاص', licenseUrl: '', pageUrl: '' };
      s.thumbData = thumbOf(el, type);
      if (old && !old.startsWith('u-') && !App.scenes.some(x => x !== s && x.blobKey === old)) Store.delBlob(old).catch(() => {});
    }
    save(); renderScenes();
    if (!App.scenes.some(x => x.fx)) autoFx({ quiet: true }).catch(() => {});
    toast(`وُزّعت ${N} ${N > 2 ? 'ملفات' : 'ملف'} على ${M} مشهد. افتح التصدير للمعاينة`, '', 6000);
  } catch (e) { toast(e.message, 'err'); }
  finally { box.hidden = true; }
}
function setMediaMode(m) {
  Settings.set({ mediaMode: m });
  $$('#mediaMode button').forEach(b => b.classList.toggle('on', b.dataset.m === m));
  $('#btnAutoAll2').hidden = $('#btnReAll').hidden = m === 'own';
}

/* ---------- الجلب التلقائي ---------- */
let autoAbort;
const isArabic = w => /[؀-ۿ]/.test(w);

/* الموضوع الغالب في المشروع (مثلاً chicken) لاستخدامه كاحتياطي */
function projectSubjects() {
  const c = new Map();
  App.scenes.forEach(x => [...x.kw.filter(w => !isArabic(w)), ...FarmDict.translate(x.text)].forEach((w, i) => c.set(w, (c.get(w) || 0) + (i === 0 ? 2 : 1))));
  const top = [...c.entries()].sort((a, b) => b[1] - a[1]).map(e => e[0]).slice(0, 3);
  const ctx = FarmDict.translate(Settings.get().context);
  return [...new Set([...top, ...ctx, ...(Channel.cur.topicFilter ? ['chickens farm', 'farm animals'] : Channel.cur.custom ? ['lifestyle', 'nature landscape'] : ['breaking news', 'city crowd'])])];
}

function sceneQueries(sc, subjects) {
  const kw = sc.kw.filter(w => !isArabic(w));
  const dict = FarmDict.translate(sc.text);
  const q = [kw[0], kw[1], dict[0] && dict[1] ? dict[0] + ' ' + dict[1] : '', dict[0], kw[2], kw[kw.length - 1], dict[1], ...subjects];
  return [...new Set(q.filter(Boolean).map(x => x.trim().toLowerCase()))].slice(0, 9);
}

function mainSubject(subjects) {
  if (!Channel.cur.topicFilter) return subjects.find(w => !isArabic(w)) || (Channel.cur.custom ? 'lifestyle' : 'city street');
  return subjects.find(w => !isArabic(w) && Relevance.tokens(w).some(Relevance.isAnimal)) || 'farm animals';
}
const useVision = () => Settings.get().smartPick !== false && !!(Settings.get().keys.gemini || Settings.get().keys.openai);

/* محرك البحث عن لقطات: يجمع لكل مشهد مرشحين مفلترين ومرتبين حسب الصلة */
function makeFinder({ orientation, minDim } = {}) {
  const s = Settings.get();
  const usable = s.providers.filter(p => p.on && (!PROVIDERS[p.id].needsKey || s.keys[p.id]));
  const subjects = projectSubjects(), main = mainSubject(subjects);
  const cache = new Map(), pending = new Map(), blockedProv = new Set();
  async function search(p, kind, q) {
    const ck = p.id + '|' + kind + '|' + q;
    if (cache.has(ck)) return cache.get(ck);
    if (pending.has(ck)) return pending.get(ck);
    const pr = (async () => {
      let items = [];
      try { items = await Promise.race([PROVIDERS[p.id].search(q, kind, { key: s.keys[p.id], orientation: orientation || App.orientation, minDim: minDim || App.minDim }), new Promise((_, r) => setTimeout(() => r(new Error('timeout')), 9000))]); }
      catch (e) { if (e.code === 'rate' || e.code === 'key') { if (!blockedProv.has(p.id)) toast(e.message, 'err'); blockedProv.add(p.id); } }
      cache.set(ck, items); pending.delete(ck);
      return items;
    })();
    pending.set(ck, pr);
    return pr;
  }
  async function candidates(sc, { need = 4, exclude = new Set(), lenient = useVision(), kind = null, idx: at = null } = {}) {
    // نوع اللقطات: فيديو فقط / صور فقط / مزيج (مشهد فيديو ومشهد صورة بالتناوب)
    const mode = kind || s.prefKind || 'mix', idx = at ?? Math.max(0, App.scenes.indexOf(sc));
    const kinds = mode === 'image' ? ['image'] : mode === 'video' ? ['video'] : idx % 2 ? ['image', 'video'] : ['video', 'image'];
    const queries = [...new Set(sceneQueries(sc, subjects).map(q => Relevance.anchor(q, main)))];
    const subj = [main, sc.kw.find(w => !isArabic(w)) || ''];
    const rej = new Set(sc.rej || []), seen = new Set(), out = [];
    for (const kind of kinds) {
      for (const q of queries) {
        const ps = usable.filter(p => PROVIDERS[p.id].kinds.includes(kind) && !blockedProv.has(p.id));
        const res = await Promise.all(ps.map(p => search(p, kind, q)));
        res.forEach(items => items.forEach((it, rank) => {
          if (seen.has(it.uid) || exclude.has(it.uid) || rej.has(it.uid)) return;
          seen.add(it.uid);
          const sco = Relevance.score(it, q, subj);
          if (sco < 0 || (sco < 1 && !(lenient && sco >= 0.5))) return;   // مرفوض: محتوى ممنوع أو لا علاقة له بالموضوع
          out.push({ it, sco: sco + (kind === kinds[0] ? 3 : 0) - rank * 0.05 });
        }));
        if (out.length >= need * 2) break;
      }
      if (out.length >= need) break;
    }
    // احتياطي حتى لا يبقى مشهد بلا لقطة: بحث أوسع بالموضوع الرئيسي للمشروع ثم بعالم القناة
    if (!out.length) {
      const wide = [...new Set([sc.kw.find(w => !isArabic(w)), main, ...(Channel.id === 'farm' ? ['farm animals', 'countryside farm'] : Channel.cur.custom ? ['lifestyle', 'nature landscape'] : ['city street', 'world map news'])].filter(Boolean))];
      for (const q of wide) {
        const ps = usable.filter(p => !blockedProv.has(p.id));
        const res = await Promise.all(ps.flatMap(p => PROVIDERS[p.id].kinds.filter(k => kinds.includes(k)).map(k => search(p, k, q))));
        const got = new Set(out.map(x => x.it.uid)); res.forEach(items => items.forEach((it, rank) => { if (got.has(it.uid) || exclude.has(it.uid) || rej.has(it.uid) || Relevance.blocked(it)) return; got.add(it.uid); out.push({ it, sco: 0.5 - rank * 0.05 }); }));
        if (out.length >= need) break;
      }
    }
    return out.sort((x, y) => y.sco - x.sco).map(x => x.it);
  }
  return { candidates, usable, main, subjects };
}

/* صورة مصغرة صغيرة (base64) ليراها Gemini */
async function thumbB64(it) {
  try {
    const b = await Promise.race([Media.fetchBlob([it.thumb]), new Promise((_, r) => setTimeout(() => r(new Error('timeout')), 9000))]);
    const bmp = await createImageBitmap(b);
    const w = 320, h = Math.max(1, Math.round(w * bmp.height / bmp.width));
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    c.getContext('2d').drawImage(bmp, 0, 0, w, h); bmp.close?.();
    return c.toDataURL('image/jpeg', 0.72).split(',')[1];
  } catch { return null; }
}

/* يرتّب المرشحين بعد أن يشاهدهم Gemini: المختار أولاً، أو [] إذا رفض الكل. null = تعذّر الفحص */
async function visualCheck(list, signal) {
  // list: [{sc, cands}]
  const groups = await Promise.all(list.map(async ({ sc, cands }) => {
    const top = cands.slice(0, 4), imgs = await Promise.all(top.map(thumbB64));
    const keep = top.map((it, i) => ({ it, img: imgs[i] })).filter(x => x.img);
    return { sc, keep, rest: cands.slice(4) };
  }));
  const ask = groups.filter(g => g.keep.length);
  if (!ask.length) return list.map(x => x.cands);
  const picks = await AI.pickVisual(ask.map(g => ({ text: g.sc.text, subject: g.sc.kw.find(w => !isArabic(w)) || '', images: g.keep.map(k => k.img) })), { signal });
  return groups.map(g => {
    const i = ask.indexOf(g);
    if (i < 0) return g.keep.map(k => k.it).concat(g.rest);
    const c = picks[i];
    if (!c) { (g.sc.rej ||= []).push(...g.keep.map(k => k.it.uid)); return []; }
    return [g.keep[c - 1].it];
  });
}

async function autoFetch({ all = false } = {}) {
  if (!App.scenes.length || autoAbort) return;
  const s = Settings.get();
  const finder = makeFinder();
  if (!finder.usable.length) { go('settings'); return toast('فعّل مصدراً واحداً على الأقل', 'err'); }
  const targets = App.scenes.filter(x => all || !x.blobKey);
  if (!targets.length) return toast('كل المشاهد لها وسائط');
  if (all && !(await confirmBox(`سيُعاد جلب الوسائط لكل ${targets.length} مشهد.`, 'متابعة'))) return;
  if (App.view !== 'scenes') go('scenes');

  const box = $('#autoProgress'), ctl = autoAbort = new AbortController();
  const signal = ctl.signal;
  const btns = [$('#btnAutoAll'), $('#btnAutoAll2'), $('#btnReAll')]; btns.forEach(b => b.disabled = true);

  const noKw = targets.filter(x => !x.ai);
  if (noKw.length && LLM.available().length) {
    setProgress(box, 0.02, 'Gemini يحلّل المشاهد ويقترح لقطات مناسبة…');
    try { const k = await AI.keywords(noKw.map(x => x.text), { signal }); noKw.forEach((x, i) => { if (k[i]?.kw.length) { x.kw = k[i].kw; x.kind = k[i].kind; x.ai = true; } }); save(); }
    catch (e) { if (e.name === 'AbortError') { if (autoAbort === ctl) { box.hidden = true; autoAbort = null; btns.forEach(b => b.disabled = false); } return; } toast(e.message, 'err'); }
  }

  let vision = useVision();
  const used = new Set(App.scenes.filter(x => !targets.includes(x)).map(x => x.asset?.uid).filter(Boolean));
  const approved = App.scenes.filter(x => !targets.includes(x) && x.asset && x.asset.provider !== 'local').map(x => x.asset);
  let done = 0, ok = 0, reused = 0, checked = 0;

  async function applyFirst(sc, list) {
    for (const it of list.filter(i => !used.has(i.uid)).slice(0, 3)) {
      if (signal.aborted) return false;
      used.add(it.uid);
      if (await applyItem(sc, it, { quiet: true, signal })) { approved.push(it); sc._alts = list.filter(x => x !== it && !used.has(x.uid)); return true; }
    }
    return false;
  }

  async function runBatch(batch) {
    batch.forEach(sc => { sc.busy = true; sc.rej = []; });
    if (App.view === 'scenes') renderStrip();
    try {
      let list = await Promise.all(batch.map(async sc => ({ sc, cands: await finder.candidates(sc, { need: 4, exclude: used }) })));
      for (let round = 0; round < 1 && list.length; round++) {
        let ordered = list.map(x => x.cands);
        if (vision) {
          try { ordered = await Promise.race([visualCheck(list, signal), new Promise((_, r) => setTimeout(() => r(new Error('بطيء جداً، أكملت بدونه')), 25000))]); checked += list.length; }
          catch (e) { if (e.name === 'AbortError') throw e; vision = false; toast('تعذّر الفحص البصري بـ Gemini (' + e.message + '). أكمل بفلتر الكلمات فقط', 'err', 6000); }
        }
        const retry = [];
        for (let i = 0; i < list.length; i++) {
          const { sc } = list[i];
          if (await applyFirst(sc, ordered[i])) { ok++; continue; }
          if (round === 0) retry.push(sc);
        }
        // مشاهد بلا لقطة: بدون فحص بصري نجرّب مرشحين جدداً بسرعة، ومع الفحص نعيد استعمال لقطة مقبولة (أكثر أماناً)
        for (const sc of retry) {
          if (signal.aborted) break;
          if (!vision) { const c = await finder.candidates(sc, { need: 3, exclude: used }); if (await applyFirst(sc, c)) { ok++; continue; } }
          if (!sc.blobKey) await reuse(sc);
        }
        list = [];
      }
      for (const sc of batch) if (!sc.blobKey && !signal.aborted) await reuse(sc);
    } finally { batch.forEach(sc => sc.busy = false); }
  }

  // آخر حل: لقطة سبق قبولها لمشهد آخر، من جزء مختلف (مضمونة الصلة بالموضوع)
  async function reuse(sc) {
    if (sc.blobKey || !approved.length) return;
    const it = approved[Math.floor(Math.random() * approved.length)];
    const src = App.scenes.find(x => x.asset?.uid === it.uid && x.blobKey);
    if (src) {
      Object.assign(sc, { asset: { ...src.asset }, thumbData: src.thumbData, offset: 2 + Math.random() * 8 });
      const b = await Store.getBlob(src.blobKey); if (!b) return;
      const key = 'a-' + sc.id + '-' + uid(); await Store.putBlob(key, b); sc.blobKey = key; sc.el = null;
      ok++; reused++;
    }
  }

  try {
    const B = vision ? 4 : 5, queue = [...targets];
    setProgress(box, 0, vision ? `البحث وفحص اللقطات بصرياً لـ ${targets.length} مشهد…` : `البحث عن لقطات لـ ${targets.length} مشهد…`);
    const worker = async () => {
      while (queue.length && !signal.aborted) {
        const batch = queue.splice(0, B);
        await runBatch(batch).catch(e => { if (e.name !== 'AbortError') console.warn(e); });
        done += batch.length;
        if (!signal.aborted) setProgress(box, done / targets.length, `المشهد ${Math.min(done, targets.length)} من ${targets.length} · وُجدت لقطات لـ ${ok}${vision ? ' · فحص Gemini ✓' : ''}`);
        if (App.view === 'scenes') renderStrip();
        save();
      }
    };
    await Promise.all([worker(), worker()]);
    if (!signal.aborted && !App.scenes.some(s => s.fx)) await autoFx({ quiet: true });
    if (signal.aborted) { /* أُوقف من الزر */ }
    else {
      const miss = targets.length - ok;
      toast(miss ? `اكتمل ${ok} من ${targets.length}. ${miss} مشهد بلا لقطة مناسبة، اختر لها يدوياً.` : `اكتمل: كل المشاهد لها لقطات${checked ? '، وفحصها Gemini بصرياً' : ''}${reused ? `. ${reused} مكرّرة من جزء مختلف` : ''}`, miss ? 'err' : '', 7000);
    }
  } finally {
    if (autoAbort === ctl) { box.hidden = true; autoAbort = null; btns.forEach(b => b.disabled = false); }
    save(); if (App.view === 'scenes') renderScenes(); else renderProject();
  }
}

/* ---------- نصوص الشاشة الاحترافية ---------- */
async function autoFx({ quiet = false } = {}) {
  if (!App.scenes.length) return 0;
  const b = $('#btnFxAuto'); if (b) { b.disabled = true; b.textContent = 'المونتير يراجع الفيديو…'; }
  let n = 0;
  try {
    if (LLM.available().length) {
      try {
        const list = await AI.editorial(App.scenes);
        App.scenes.forEach(s => { if (!s.fx?.manual) s.fx = null; });
        list.forEach(f => { const s = App.scenes[f.scene]; if (s && !s.fx) { s.fx = { type: f.type, text: f.text, emph: f.emph, sub: f.sub, anchor: f.anchor }; n++; } });
      } catch (e) { if (!quiet) toast('Gemini: ' + e.message + '. استخدمت الاقتراح المحلي', 'err', 6000); n = Fx.auto(App.scenes); }
    } else n = Fx.auto(App.scenes);
    save();
    if (App.view === 'scenes') renderScenes();
    toast(n ? `أُضيف ${n} نص احترافي في اللحظات المهمة. عدّل أي واحد من صفحة المشهد` : 'لم أجد لحظات مناسبة لنصوص الشاشة');
  } finally { if (b) { b.disabled = false; b.textContent = 'نصوص الشاشة: اقتراح تلقائي'; } }
  return n;
}

/* معاينة نص الشاشة للمشهد المحدد (ثابتة أو متحركة) */
let fxAnim = 0;
async function fxPreview(animate = false) {
  const s = App.scenes[App.sel], cv = $('#fxPrev'); if (!s || !cv) return;
  cancelAnimationFrame(fxAnim);
  const { w, h } = App.dims; if (Renderer.canvas.width !== w || Renderer.canvas.height !== h) Renderer.size(w, h);
  await Live.ensure(s);
  const { st } = Renderer.timeline(App.scenes), t0 = st[App.sel];
  let tm = null; if (s.fx && App.buf) { try { tm = Align.forScene(s, t0, s.fx.text, App.buf, s.fx.anchor); } catch {} }
  const at = tm ? tm.at : 0.25, D = (tm ? tm.dur : Fx.dur(s.d)) + at + 0.4;
  if (s.fx) delete s.fx._z;
  if (!animate) { Renderer.snapshot(t0 + Math.min(s.d - 0.05, at + 1.2), App.scenes, cv); return; }
  const start = performance.now();
  const loop = () => {
    const el = (performance.now() - start) / 1000;
    if (el > Math.min(D, s.d) || App.scenes[App.sel] !== s) { Renderer.snapshot(t0 + Math.min(s.d - 0.05, at + 1.2), App.scenes, cv); return; }
    Renderer.snapshot(t0 + el, App.scenes, cv);
    fxAnim = requestAnimationFrame(loop);
  };
  loop();
}

function fxEdit(field, value) {
  const s = App.scenes[App.sel]; if (!s) return;
  if (field === 'type') {
    if (!value) s.fx = null;
    else {
      const def = s.text.split(/(?<=[.!؟?])\s+/)[0].split(/\s+/).slice(0, 7).join(' ');
      s.fx = { ...(s.fx || {}), type: value, text: s.fx?.text || (value === 'question' ? def.replace(/[.،]*$/, '؟') : def), manual: true };
    }
    renderEditor(); renderStrip(); save(); return;
  }
  if (!s.fx) return;
  s.fx[field] = value; s.fx.manual = true;
  clearTimeout(fxEdit.t); fxEdit.t = setTimeout(() => { fxPreview(); renderStrip(); save(); }, 250);
}

/* «لقطة أخرى»: يرفض الحالية ويضع أفضل بديل */
async function nextShot(sc) {
  if (!sc || sc.busy) return;
  if (sc.asset?.uid) (sc.rej ||= []).push(sc.asset.uid);
  sc.busy = true; renderStrip(); const b = $('#curMedia'); if (b) b.textContent = 'أبحث عن لقطة أنسب…';
  try {
    const finder = makeFinder();
    const usedNow = new Set(App.scenes.map(x => x.asset?.uid).filter(Boolean));
    let cands = (sc._alts || []).filter(it => !sc.rej.includes(it.uid) && !usedNow.has(it.uid));
    if (cands.length < 3) cands = await finder.candidates(sc, { need: 6, exclude: usedNow });
    if (useVision() && cands.length > 1) { try { const r = await visualCheck([{ sc, cands }]); if (r[0].length) cands = [...r[0], ...cands.filter(x => !r[0].includes(x))]; } catch {} }
    for (const it of cands.slice(0, 4)) {
      if (await applyItem(sc, it, { quiet: true })) { sc._alts = cands.filter(x => x !== it); save(); toast('وُضعت لقطة أخرى'); return; }
    }
    toast('لم أجد لقطة أخرى مناسبة. جرّب كلمات بحث مختلفة أو اختر من المعرض', 'err', 6000);
  } finally { sc.busy = false; renderScenes(); }
}

/* ---------- عمليات المشهد ---------- */
async function sceneOp(op) {
  const i = App.sel, s = App.scenes[i]; if (!s) return;
  if (op === 'prev') App.sel = Math.max(0, i - 1);
  if (op === 'next') App.sel = Math.min(App.scenes.length - 1, i + 1);
  if (op === 'split') {
    const m = s.text.indexOf(' ', Math.floor(s.text.length / 2));
    if (m < 0) return toast('النص قصير جداً للتقسيم');
    const a = s.text.slice(0, m), b = s.text.slice(m + 1), r = a.length / s.text.length;
    const n = newScene(b, s.d * (1 - r), s.kw, s.kind);
    s.text = a; s.d *= r;
    App.scenes.splice(i + 1, 0, n);
  }
  if (op === 'merge') {
    const x = App.scenes[i + 1]; if (!x) return toast('لا يوجد مشهد تالٍ');
    s.text += ' ' + x.text; s.d += x.d;
    if (!s.blobKey && x.blobKey) { Object.assign(s, { asset: x.asset, blobKey: x.blobKey, thumbData: x.thumbData, el: x.el, type: x.type }); }
    else { Live.release(x); if (x.blobKey) Store.delBlob(x.blobKey).catch(() => {}); }
    App.scenes.splice(i + 1, 1);
  }
  if (op === 'another') return nextShot(s);
  if (op === 'clear') { Live.release(s); if (s.blobKey) Store.delBlob(s.blobKey).catch(() => {}); s.blobKey = null; s.asset = null; s.thumbData = ''; }
  if (op === 'del') {
    if (!(await confirmBox('حذف هذا المشهد؟ ستُضاف مدته إلى المشهد المجاور.', 'احذف'))) return;
    const nb = App.scenes[i + 1] || App.scenes[i - 1];
    if (nb) nb.d += s.d;
    Live.release(s); if (s.blobKey) Store.delBlob(s.blobKey).catch(() => {});
    App.scenes.splice(i, 1); App.sel = Math.max(0, Math.min(i, App.scenes.length - 1));
  }
  save(); renderScenes(); if (App.buf) drawWave();
}

function setDuration(i, v) {
  const s = App.scenes[i], nb = App.scenes[i + 1] || App.scenes[i - 1];
  if (!s || !nb) return;
  v = Math.max(0.5, Math.min(s.d + nb.d - 0.5, +v || s.d));
  nb.d -= v - s.d; s.d = v;
  save(); renderStrip();
}

/* ---------- المعاينة والتصدير ---------- */
let curT = 0;
function enterExport() {
  const { w, h } = App.dims;
  if (Renderer.canvas.width !== w || Renderer.canvas.height !== h) Renderer.size(w, h);
  const s = Settings.get();
  $('#ratio').value = s.ratio; $('#transition').value = s.transition; $('#captions').value = s.captions;
  $('#capSize').value = s.captionSize;
  if ($('#exResult').hidden && !lastExport) Store.getBlob('out-main').then(b => { if (b && b.size && $('#exResult').hidden) showResult(b, true); }).catch(() => {});
  $('#topicTag').checked = s.topicTag === true;
  $('#tagStyle').value = s.tagStyle || 'box';
  $('#commentCard').checked = s.commentCard !== false;
  $('#exportFast').checked = s.exportFast !== false;
  if (!App.tag) App.tag = (Publish.promo?.tags?.[0] || '').replace(/^#/, '') || (App.projName || '').split(/\s+/).slice(0, 3).join('_');
  $('#tagText').value = App.tag ? '#' + App.tag.replace(/^#+/, '') : '';
  $('#questionCards').checked = s.questionCards !== false; $('#subRemind').checked = s.subRemind !== false; $('#subEvery').value = s.subEvery || 30; $('#capSizeOut').textContent = Math.round(s.captionSize * 100) + '%';
  const dur = App.buf?.duration || 0;
  $('#scrub').max = dur; curT = Math.min(curT, dur);
  const n = App.scenes.length, miss = App.scenes.filter(x => !x.blobKey).length;
  $('#exportCheck').textContent = !App.buf ? 'ارفع ملف الصوت أولاً.' : !n ? 'لا توجد مشاهد بعد.' :
    miss ? `${n} مشهد، منها ${miss} بدون وسائط (ستظهر بخلفية Fadi Farm). المدة ${fmt(dur)}.` : `${n} مشهد جاهز. المدة ${fmt(dur)}، والتصدير يستغرق نفس مدة الفيديو تقريباً.`;
  $('#btnExport').disabled = !App.buf || !n;
  $('#btnPlay').disabled = !App.buf || !n;
  seekTo(curT);
}

function seekTo(t) {
  curT = t;
  $('#scrub').value = t;
  $('#clock').textContent = `${fmt(t)} / ${fmt(App.buf?.duration)}`;
  if (!App.scenes.length) { Renderer.draw(0, []); return; }
  const { st } = Renderer.timeline(App.scenes);
  let i = 0; while (i < App.scenes.length - 1 && st[i + 1] <= t) i++;
  Live.windowAt(i, 0, 1);
  Promise.all([Live.ensure(App.scenes[i]), App.scenes[i + 1] && Live.ensure(App.scenes[i + 1])]).then(() => {
    Renderer.seekVideos(t, App.scenes, () => Renderer.draw(curT, App.scenes));
    Renderer.draw(curT, App.scenes);
  });
}

let lastIdx = -1;
function tickWindow(t) {
  const { st } = Renderer.timeline(App.scenes);
  let i = 0; while (i < App.scenes.length - 1 && st[i + 1] <= t) i++;
  if (i !== lastIdx) { lastIdx = i; Live.windowAt(i, 1, 3); }
}

async function togglePlay() {
  if (Player.playing || togglePlay.busy) { togglePlay.busy = false; return stopPlayback(); }
  togglePlay.busy = true; setTimeout(() => { togglePlay.busy = false; }, 1500);
  if (!App.buf || !App.scenes.length) return;
  lastIdx = -1;
  const at = curT >= App.buf.duration - 0.2 ? 0 : curT;
  $('#btnPlay').textContent = '❚❚'; $('#btnPlay').setAttribute('aria-label', 'إيقاف مؤقت');
  await Player.start({
    buf: App.buf, scenes: App.scenes, at,
    tick: t => { curT = t; tickWindow(t); $('#scrub').value = t; $('#clock').textContent = `${fmt(t)} / ${fmt(App.buf.duration)}`; },
    end: () => { stopPlayback(); curT = 0; },
  });
}

function stopPlayback() {
  Player.stop(true, App.scenes);
  $('#btnPlay').textContent = '▶'; $('#btnPlay').setAttribute('aria-label', 'تشغيل');
}

let lastExport = null;
async function exportVideo() {
  if (Player.recording) return;
  if (!App.buf || !App.scenes.length) return;
  stopPlayback();
  const box = $('#exProgress');
  $('#exResult').hidden = true; $('#btnExport').disabled = true; $('#btnPlay').disabled = true;
  setProgress(box, 0, 'تجهيز الوسائط…');
  await Promise.all(App.scenes.slice(0, 4).map(s => Live.ensure(s)));
  // انتظر أول اللقطات حتى تجهز، فلا يبدأ الفيديو بشاشة فارغة
  await Promise.all(App.scenes.slice(0, 3).map(s => s.el && s.type === 'video' && s.el.readyState < 2 ? new Promise(r => { s.el.addEventListener('loadeddata', r, { once: true }); setTimeout(r, 6000); }) : null));
  lastIdx = -1;
  const dur = App.buf.duration;
  try {
    await Player.start({
      buf: App.buf, scenes: App.scenes, record: true,
      prep: f => setProgress(box, 0, `تجهيز الصوت ${Math.round(f * 100)}%…`),
      tick: t => { curT = t; tickWindow(t); $('#scrub').value = t; setProgress(box, t / dur, `جارٍ التصدير ${fmt(t)} من ${fmt(dur)} · إذا خرجت من التطبيق يتوقف مؤقتاً ويكمل عند عودتك`); },
      end: (blob, err) => {
        box.hidden = true; $('#btnExport').disabled = false; $('#btnPlay').disabled = false;
        if (!blob || !blob.size) return toast('فشل التصدير' + (err?.message ? ': ' + err.message : '') + '. أعد المحاولة', 'err', 7000);
        showResult(blob);
      },
    });
  } catch (e) {
    box.hidden = true; $('#btnExport').disabled = false; $('#btnPlay').disabled = false;
    toast(e.message, 'err');
  }
}

function cancelExport() {
  Player.stop(true, App.scenes);
  $('#exProgress').hidden = true; $('#btnExport').disabled = false; $('#btnPlay').disabled = false;
  toast('أُلغي التصدير');
}

function safeName() { return (App.projName || 'fadi-farm').replace(/[\\/:*?"<>|]+/g, ' ').trim().slice(0, 60) || 'fadi-farm'; }

function showResult(blob, restored) {
  if (!restored) Store.putBlob('out-main', blob).catch(() => {});      // الفيديو المصدَّر يبقى بعد الخروج من التطبيق
  if (lastExport) URL.revokeObjectURL(lastExport.url);
  const url = resultBox($('#exResult'), blob, safeName(), 'الفيديو جاهز', { auto: !restored });
  lastExport = { url, blob };
  if (!restored) toast('اكتمل التصدير');
}

function creditsText() {
  const seen = new Set(), lines = [];
  App.scenes.forEach(s => {
    const a = s.asset; if (!a || a.provider === 'local' || seen.has(a.uid)) return; seen.add(a.uid);
    lines.push(`• ${a.title || 'بدون عنوان'}${a.creator ? ' — ' + a.creator : ''} — ${PROVIDERS[a.provider]?.name || a.provider} — ${a.license || ''}${a.pageUrl ? ' — ' + a.pageUrl : ''}`);
  });
  return lines.length ? `مصادر الصور والفيديو:\n${lines.join('\n')}` : '';
}

async function copyCredits() {
  const t = creditsText();
  if (!t) return toast('لا توجد وسائط من مصادر خارجية بعد');
  try { await navigator.clipboard.writeText(t); toast('نُسخت الحقوق، الصقها في وصف الفيديو'); }
  catch { toast('تعذّر النسخ التلقائي', 'err'); }
}

function downloadJson() {
  const { st } = Renderer.timeline(App.scenes);
  const data = { project: App.projName, audio: App.audioName, duration: App.buf?.duration, ratio: Settings.get().ratio,
    scenes: App.scenes.map((s, i) => ({ id: i + 1, start: +st[i].toFixed(2), end: +(st[i] + s.d).toFixed(2), narration: s.text, keywords: s.kw, media: s.asset })) };
  saveFile(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }), `${safeName()}-scenes.json`).catch(e => toast(e.message, 'err'));
}

/* ---------- الإعدادات ---------- */
function renderSettings() {
  const s = Settings.get();
  $('#k-gemini').value = s.keys.gemini;
  $$('#aiBackup [data-key]').forEach(i => { if (document.activeElement !== i) i.value = s.keys[i.dataset.key] || ''; });
  $('#elevenVoice').value = s.elevenVoice || '';
  $('#textPref').value = s.textPref || 'auto';
  $('#gemModel').value = s.geminiModel;
  $('#context').value = s.context;
  $('#prefKind').value = s.prefKind;
  $('#dlQuality').value = s.dlQuality;
  $('#smartPick').checked = s.smartPick !== false;
  $('#blockWords').value = s.blockWords || '';
  $('#ttsModel').value = s.ttsModel;
  fillVoices();
  $('#logoPos').value = s.logoPos; $('#logoOpacity').value = s.logoOpacity;
  $('#logoPrev').style.backgroundImage = s.logo ? `url("${s.logo}")` : '';
  const gs = $('#gemState'); gs.textContent = s.keys.gemini ? 'مضاف' : 'غير مضاف'; gs.className = 'chip ' + (s.keys.gemini ? 'ok' : 'warn');
  $('#ver').textContent = VERSION;
  $('#providers').innerHTML = s.providers.map((p, i) => {
    const P = PROVIDERS[p.id], hasKey = !P.needsKey || s.keys[p.id];
    return `<li class="prov${p.on ? '' : ' off'}" data-p="${p.id}">
      <div class="prov-head">
        <label class="switch" title="تفعيل"><input type="checkbox" data-toggle="${p.id}" ${p.on ? 'checked' : ''} aria-label="تفعيل ${esc(P.name)}"><i></i></label>
        <b>${esc(P.name)}</b>
        <span class="kinds">${P.kinds.map(k => `<span class="chip">${k === 'video' ? 'فيديو' : 'صور'}</span>`).join('')}</span>
        <span class="chip ${P.needsKey ? (hasKey ? 'ok' : 'warn') : 'ok'}">${P.needsKey ? (hasKey ? 'المفتاح مضاف' : 'يحتاج مفتاح') : 'بدون مفتاح'}</span>
        <span class="order"><button type="button" data-up="${i}" aria-label="أعلى" ${i ? '' : 'disabled'}>↑</button><button type="button" data-down="${i}" aria-label="أسفل" ${i < s.providers.length - 1 ? '' : 'disabled'}>↓</button></span>
      </div>
      <p class="muted small">${esc(P.note)}</p>
      ${P.needsKey || P.optionalKey ? `<div class="keyrow">
        <input id="k-${p.id}" type="password" autocomplete="off" spellcheck="false" dir="ltr" placeholder="${P.optionalKey ? 'مفتاح API (اختياري)' : 'مفتاح API'}" value="${esc(s.keys[p.id] || '')}" data-key="${p.id}">
        <button class="btn ghost sm" data-paste="k-${p.id}" type="button">لصق</button><button class="btn ghost sm" data-eye="k-${p.id}" type="button">إظهار</button>
        <button class="btn sm" data-test="${p.id}" type="button">اختبار</button>
        <a class="btn ghost sm" href="${P.keyUrl}" target="_blank" rel="noopener">احصل على مفتاح</a>
      </div>` : `<div class="actions"><button class="btn sm" data-test="${p.id}" type="button">اختبار الاتصال</button></div>`}
    </li>`;
  }).join('');
}

async function testKey(id, btn) {
  const t = btn.textContent; btn.disabled = true; btn.textContent = '…';
  try {
    if (id === 'gemini') { const m = await AI.test(); toast(`Gemini يعمل ✓ (النموذج: ${m})`); }
    else { const n = await testProvider(id); toast(`${PROVIDERS[id].name} يعمل · ${n} نتيجة تجريبية`); }
  } catch (e) { toast(e.message, 'err', 6000); }
  finally { btn.disabled = false; btn.textContent = t; }
}

function readLogo(file) {
  if (!file) return;
  const im = new Image();
  im.onload = () => {
    const m = 320, k = Math.min(1, m / Math.max(im.width, im.height));
    const c = document.createElement('canvas'); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
    c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
    Settings.set({ logo: c.toDataURL('image/png') }); renderSettings(); toast('حُفظ الشعار');
    URL.revokeObjectURL(im.src);
  };
  im.onerror = () => toast('تعذّر فتح الصورة', 'err');
  im.src = URL.createObjectURL(file);
}

/* ---------- الأحداث ---------- */
function bind() {
  document.addEventListener('click', e => {
    const g = e.target.closest('[data-go]');
    if (g) { e.preventDefault(); go(g.dataset.go); }
  });

  // المشروع
  $('#projName').addEventListener('input', e => { App.projName = e.target.value; save(); });
  $('#audioPick').onclick = () => $('#audioInput').click();
  $('#audioInput').onchange = e => { const f = e.target.files[0]; if (f) loadAudio(f, f.name); e.target.value = ''; };
  const drop = $('#audioDrop');
  drop.addEventListener('dragover', e => { e.preventDefault(); drop.classList.add('over'); });
  drop.addEventListener('dragleave', () => drop.classList.remove('over'));
  drop.addEventListener('drop', e => { e.preventDefault(); drop.classList.remove('over'); const f = e.dataTransfer.files[0]; if (f) loadAudio(f, f.name); });
  $('#sceneTarget').oninput = e => { Settings.set({ sceneTarget: +e.target.value }); $('#sceneTargetOut').textContent = e.target.value + ' ث'; };
  $('#btnTranscribe').onclick = transcribe;
  $('#btnWipeProject').onclick = wipeProject;
  $('#btnTTS').onclick = makeVoiceover;
  $('#voiceMode').addEventListener('click', e => { const b = e.target.closest('[data-mode]'); if (b) setVoiceMode(b.dataset.mode); });
  $('#btnVidsSplit').onclick = vidsSplit;
  $('#btnVidsAuto').onclick = vidsAuto;
  Capture.bind();
  $('#btnVidsBuild').onclick = vidsBuild;
  $('#vidsParts').addEventListener('click', async e => {
    const c = e.target.closest('[data-vcopy]'), a = e.target.closest('[data-vadd]');
    if (c) { const i = +c.dataset.vcopy; if (await copyText(Vids.parts[i].text)) toast(`نُسخ الجزء ${i + 1}. الصقه في Google Vids`); else toast('تعذّر النسخ', 'err'); }
    if (a) { Vids.pending = +a.dataset.vadd; $('#vidsFile').click(); }
  });
  $('#vidsFile').onchange = e => { const f = e.target.files[0]; if (f && Vids.pending >= 0) vidsAddAudio(Vids.pending, f); e.target.value = ''; };
  $('#btnTTSPreview').onclick = previewVoice;
  $('#ttsCancel').onclick = () => ttsAbort?.abort();
  $('#ttsVoiceQuick').onchange = e => { const en = e.target.dataset.engine; Settings.set(en === 'azure' ? { azureVoice: e.target.value } : en === 'openai' ? { openaiVoice: e.target.value } : en === 'device' ? { deviceVoice: e.target.value } : { ttsVoice: e.target.value }); fillVoices(); };
  $('#ttsEngine').onchange = e => { Settings.set({ ttsEngine: e.target.value }); fillVoices(); };
  $('#ttsDialect').onchange = e => { Settings.set({ dialect: e.target.value }); fillVoices(); };
  $('#ttsPaceQuick').onchange = e => { Settings.set({ ttsPace: e.target.value }); fillVoices(); };
  $('#manualText').addEventListener('input', () => save());
  $('#ttsText').addEventListener('input', e => { try { localStorage.setItem(Channel.key('ff.ttsDraft'), e.target.value); } catch {} save(); });
  $('#trCancel').onclick = () => trAbort?.abort();
  $('#btnSplit').onclick = splitManual;
  $('#btnAutoAll').onclick = () => { const miss = App.scenes.some(s => !s.blobKey); go(miss ? 'scenes' : 'export'); if (miss) autoFetch(); };

  // المشاهد
  $('#btnAutoAll2').onclick = () => autoFetch();
  $('#btnReAll').onclick = () => autoFetch({ all: true });
  $('#btnFxAuto').onclick = () => autoFx();
  $('#kindMode').onclick = e => { const b = e.target.closest('[data-k]'); if (!b) return; Settings.set({ prefKind: b.dataset.k }); $$('#kindMode button').forEach(x => x.classList.toggle('on', x === b)); toast('سيُطبّق عند الجلب القادم. اضغط «إعادة جلب الكل» لتطبيقه الآن'); };
  $$('#kindMode button').forEach(x => x.classList.toggle('on', x.dataset.k === (Settings.get().prefKind === 'auto' ? 'mix' : Settings.get().prefKind || 'mix')));
  $('#mediaMode').onclick = e => { const b = e.target.closest('[data-m]'); if (b) setMediaMode(b.dataset.m); };
  $('#btnOwnBulk').onclick = () => { $('#ownInput').value = ''; $('#ownInput').click(); };
  $('#ownInput').onchange = e => bulkOwn(e.target.files);
  setMediaMode(Settings.get().mediaMode || 'auto');
  $('#autoCancel').onclick = () => {
    autoAbort?.abort(); autoAbort = null;
    $('#autoProgress').hidden = true; [$('#btnAutoAll'), $('#btnAutoAll2'), $('#btnReAll')].forEach(b => b && (b.disabled = false));
    App.scenes.forEach(s => s.busy = false); if (App.view === 'scenes') renderStrip();
    toast('أُوقف الجلب');
  };
  $('#strip').addEventListener('click', e => {
    const c = e.target.closest('.scene-card'); if (!c) return;
    App.sel = +c.dataset.i; save(); renderStrip(); renderEditor();
  });
  const ed = $('#editor');
  ed.addEventListener('input', e => {
    const s = App.scenes[App.sel]; if (!s) return;
    if (e.target.id === 'sText') { s.text = e.target.value; save(); }
    if (e.target.id === 'sKw') { s.kw = e.target.value.split(/[,،]/).map(x => x.trim()).filter(Boolean); s.ai = true; save(); }
    if (e.target.id === 'q') searchState.q = e.target.value;
    if (e.target.id === 'fxText') fxEdit('text', e.target.value);
    if (e.target.id === 'fxEmph') fxEdit('emph', e.target.value);
    if (e.target.id === 'fxSub') fxEdit('sub', e.target.value);
  });
  ed.addEventListener('change', e => {
    if (e.target.id === 'sDur') setDuration(App.sel, e.target.value);
    if (e.target.id === 'fxType') fxEdit('type', e.target.value);
    if (e.target.id === 'fxPos') { fxEdit('pos', e.target.value); }
    if (e.target.id === 'sText') renderStrip();
    if (e.target.id === 'localFile') { applyLocal(App.scenes[App.sel], e.target.files[0]); e.target.value = ''; }
  });
  ed.addEventListener('submit', e => { e.preventDefault(); if (e.target.id === 'searchForm') { searchState.q = $('#q').value; runSearch(); } });
  ed.addEventListener('click', e => {
    const t = e.target.closest('button'); if (!t) return;
    if (t.dataset.op) sceneOp(t.dataset.op);
    else if (t.dataset.kind) { searchState.kind = t.dataset.kind; searchState.only = ''; $$('.seg button', ed).forEach(b => b.classList.toggle('on', b === t)); renderChips(); runSearch(); }
    else if ('only' in t.dataset) { searchState.only = t.dataset.only; renderChips(); runSearch(); }
    else if (t.dataset.r != null) {
      const it = searchState.items[+t.dataset.r], s = App.scenes[App.sel];
      if (it && s && !s.busy) { t.classList.add('loading'); applyItem(s, it); }
    }
    else if (t.id === 'btnLocal') $('#localFile').click();
    else if (t.id === 'fxPlay') fxPreview(true);
    else if (t.id === 'btnGalImg' || t.id === 'btnGalVid') {
      const sc = App.scenes[App.sel];
      pickFromGallery(t.id === 'btnGalVid' ? 'video' : 'image').then(f => f && applyLocal(sc, f)).catch(e => toast(e.message, 'err'));
    }
  });

  // التصدير
  $('#btnPlay').onclick = togglePlay;
  $('#scrub').oninput = e => { if (Player.playing) stopPlayback(); seekTo(+e.target.value); };
  $('#ratio').onchange = e => { Settings.set({ ratio: e.target.value }); searchState.forScene = null; enterExport(); };
  $('#transition').onchange = e => { Settings.set({ transition: e.target.value }); seekTo(curT); };
  $('#captions').onchange = e => { Settings.set({ captions: e.target.value }); seekTo(curT); };
  $('#capSize').oninput = e => { Settings.set({ captionSize: +e.target.value }); $('#capSizeOut').textContent = Math.round(e.target.value * 100) + '%'; seekTo(curT); };
  $('#btnExport').onclick = exportVideo;
  $('#questionCards').onchange = e => { Settings.set({ questionCards: e.target.checked }); seekTo(curT); };
  $('#subRemind').onchange = e => { Settings.set({ subRemind: e.target.checked }); seekTo(curT); };
  $('#topicTag').onchange = e => { Settings.set({ topicTag: e.target.checked }); seekTo(curT); };
  $('#tagStyle').onchange = e => { Settings.set({ tagStyle: e.target.value }); seekTo(curT); };
  $('#commentCard').onchange = e => { Settings.set({ commentCard: e.target.checked }); seekTo(curT); };
  $('#exportFast').onchange = e => Settings.set({ exportFast: e.target.checked });
  $('#tagText').addEventListener('input', e => { App.tag = e.target.value.replace(/^#+/, '').trim(); save(); seekTo(curT); });
  $('#subEvery').onchange = e => { Settings.set({ subEvery: Math.max(15, Math.min(180, +e.target.value || 30)) }); };
  $('#exCancel').onclick = cancelExport;
  $('#btnCopyCredits').onclick = copyCredits;
  $('#btnJson').onclick = downloadJson;

  // الإعدادات
  const sv = $('#v-settings');
  sv.addEventListener('input', e => {
    const s = Settings.get();
    if (e.target.dataset.key) { s.keys[e.target.dataset.key] = e.target.value.trim(); Settings.save(); }
    if (e.target.id === 'k-gemini') { s.keys.gemini = e.target.value.trim(); Settings.save(); const gs = $('#gemState'); gs.textContent = s.keys.gemini ? 'مضاف' : 'غير مضاف'; gs.className = 'chip ' + (s.keys.gemini ? 'ok' : 'warn'); }
    if (e.target.id === 'textPref') Settings.set({ textPref: e.target.value });
    if (e.target.id === 'elevenVoice') Settings.set({ elevenVoice: e.target.value.trim() });
    if (e.target.dataset.key) fillVoices();
    if (e.target.id === 'gemModel') Settings.set({ geminiModel: e.target.value.trim() || DEFAULT_SETTINGS.geminiModel });
    if (e.target.id === 'context') Settings.set({ context: e.target.value });
    if (e.target.id === 'blockWords') Settings.set({ blockWords: e.target.value });
    if (e.target.id === 'ttsModel') Settings.set({ ttsModel: e.target.value.trim() || DEFAULT_SETTINGS.ttsModel });
    if (e.target.id === 'logoOpacity') Settings.set({ logoOpacity: +e.target.value });
  });
  sv.addEventListener('change', e => {
    const s = Settings.get();
    if (e.target.dataset.toggle) { s.providers.find(p => p.id === e.target.dataset.toggle).on = e.target.checked; Settings.save(); renderSettings(); }
    if (e.target.dataset.key) renderSettings();
    if (e.target.id === 'prefKind') Settings.set({ prefKind: e.target.value });
    if (e.target.id === 'dlQuality') Settings.set({ dlQuality: e.target.value });
    if (e.target.id === 'smartPick') Settings.set({ smartPick: e.target.checked });
    if (e.target.id === 'ttsVoice') { Settings.set({ ttsVoice: e.target.value }); fillVoices(); }
    if (e.target.id === 'ttsPace') { Settings.set({ ttsPace: e.target.value }); fillVoices(); }
    if (e.target.id === 'logoPos') Settings.set({ logoPos: e.target.value });
    if (e.target.id === 'logoInput') { readLogo(e.target.files[0]); e.target.value = ''; }
    if (e.target.id === 'restoreInput') restoreSettings(e.target.files[0]);
  });
  sv.addEventListener('click', async e => {
    const b = e.target.closest('button'); if (!b) return;
    const s = Settings.get();
    if (b.dataset.paste) {
      const i = $('#' + b.dataset.paste); let t = '';
      try { if (NATIVE) t = (await capCall('FadiNative', 'pasteText', {}))?.text || ''; } catch {}
      if (!t) { try { t = await navigator.clipboard.readText(); } catch {} }
      t = String(t || '').trim();
      if (!t) return toast('لم أستطع قراءة الحافظة. اضغط مطولاً داخل الخانة واختر «لصق»', 'err', 6000);
      i.value = t; i.dispatchEvent(new Event('input', { bubbles: true })); i.dispatchEvent(new Event('change', { bubbles: true })); toast('لُصق ✓');
    }
    if (b.dataset.eye) { const i = $('#' + b.dataset.eye); i.type = i.type === 'password' ? 'text' : 'password'; b.textContent = i.type === 'password' ? 'إظهار' : 'إخفاء'; }
    if (b.dataset.test) testKey(b.dataset.test, b);
    if (b.id === 'testGemini') testKey('gemini', b);
    if (b.id === 'btnTestAll') testAllKeys(b);
    if (b.id === 'btnKeysCopy') {
      const k = Object.fromEntries(Object.entries(Settings.get().keys).filter(([, v]) => v));
      const code = 'FADI1.' + btoa(unescape(encodeURIComponent(JSON.stringify(k))));
      if (await copyText(code)) toast(`نُسخ رمز ${Object.keys(k).length} مفتاح. ألصقه في الجهاز الآخر`);
    }
    if (b.id === 'btnKeysPaste') {
      try {
        const c = $('#keysCode').value.trim(); if (!c.startsWith('FADI1.')) throw 0;
        const k = JSON.parse(decodeURIComponent(escape(atob(c.slice(6)))));
        Object.assign(Settings.get().keys, k); Settings.save(); $('#keysCode').value = '';
        renderSettings(); fillVoices(); toast(`استُورد ${Object.keys(k).length} مفتاح ✓`);
      } catch { toast('الرمز غير صالح، انسخه من جديد', 'err'); }
    }
    if (b.dataset.up || b.dataset.down) {
      const i = +(b.dataset.up ?? b.dataset.down), j = b.dataset.up ? i - 1 : i + 1;
      [s.providers[i], s.providers[j]] = [s.providers[j], s.providers[i]]; Settings.save(); renderSettings();
    }
    if (b.id === 'btnVoices') {
      b.disabled = true;
      try { const v = await TTS.listVoices(); Settings.set({ extraVoices: v }); fillVoices(); toast(v.length ? `أُضيف ${v.length} صوت مصري` : 'لم تُعثر على أصوات إضافية، الأصوات الأساسية تتكلم مصري أيضاً'); }
      catch (e) { toast(e.message, 'err'); }
      b.disabled = false;
    }
    if (b.id === 'logoPick') {
      if (NATIVE) pickFromGallery('image').then(f => f && readLogo(f)).catch(e => toast(e.message, 'err'));
      else $('#logoInput').click();
    }
    if (b.id === 'logoClear') { Settings.set({ logo: '' }); renderSettings(); }
    if (b.id === 'logoDefault') { Settings.set({ logo: Channel.cur.logo }); renderSettings(); }
    if (b.id === 'btnNewProject') wipeProject();
    if (b.id === 'btnBackup') {
      saveFile(new Blob([JSON.stringify(Settings.get(), null, 2)], { type: 'application/json' }), 'fadi-farm-settings.json').catch(e => toast(e.message, 'err'));
    }
    if (b.id === 'btnRestore') $('#restoreInput').click();
    if (b.id === 'btnWipe') {
      if (!(await confirmBox('مسح كل البيانات من هذا الجهاز؟ يشمل المفاتيح والمشروع والوسائط المنزّلة.', 'امسح كل شيء'))) return;
      await Store.clearAll().catch(() => {}); localStorage.removeItem('ff.settings'); location.reload();
    }
    if (b.id === 'btnInstall' && deferredInstall) { deferredInstall.prompt(); await deferredInstall.userChoice; deferredInstall = null; b.hidden = true; }
  });

  document.addEventListener('visibilitychange', () => { if (document.hidden) { saveNow(); vidsSave(); } });
  addEventListener('pagehide', () => { saveNow(); });
  addEventListener('online', () => $('#netState').hidden = true);
  addEventListener('offline', () => $('#netState').hidden = false);
  $('#netState').hidden = navigator.onLine;
  addEventListener('hashchange', () => { const v = location.hash.slice(1); if (v && v !== App.view) go(v); });
  addEventListener('resize', () => { if (App.buf && App.view === 'project') drawWave(); });
  document.addEventListener('visibilitychange', () => { if (document.hidden && Player.recording) toast('أبقِ التطبيق مفتوحاً حتى ينتهي التصدير', 'err', 6000); });
}

async function restoreSettings(file) {
  if (!file) return;
  try {
    const d = JSON.parse(await file.text());
    if (!d || typeof d !== 'object' || !d.providers) throw 0;
    localStorage.setItem('ff.settings', JSON.stringify(d)); location.reload();
  } catch { toast('ملف الإعدادات غير صالح', 'err'); }
}

/* ---------- التثبيت (PWA) ---------- */
let deferredInstall = null;
addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferredInstall = e; const b = $('#btnInstall'); if (b) b.hidden = false; });
addEventListener('appinstalled', () => { toast('ثُبّت Fadi Farm على جهازك'); $('#btnInstall').hidden = true; });

/* ---------- مشروع جديد: حذف كل شيء من المشروع السابق ---------- */
async function wipeProject() {
  if (!(await confirmBox('حذف المشروع الحالي بالكامل؟ يُحذف الصوت والنص والمشاهد واللقطات المنزّلة والصورة المصغرة والريل وأجزاء Google Vids. تبقى إعداداتك ومفاتيحك فقط.', 'احذف وابدأ من جديد'))) return;
  try { Capture.stop(); } catch {}
  if (Player.playing) stopPlayback();
  App.scenes.forEach(s => Live.release(s));
  try { for (const k of await Store.blobKeys()) await Store.delBlob(k); } catch {}
  for (const k of ['project', 'promo', 'vids', 'reel-plan', 'reel-flow']) await Store.set(k, null).catch(() => {});
  try { localStorage.removeItem(Channel.key('ff.ttsDraft')); localStorage.removeItem('ff.consumed'); } catch {}
  try { const est = await navigator.storage?.estimate?.(); console.log('storage after wipe', est); } catch {}
  history.replaceState(null, '', '#project');
  location.reload();
}

/* ---------- البدء ---------- */
/* اختبار كل مفاتيح الكتابة والصوت دفعة واحدة */
async function testAllKeys(btn) {
  const k = Settings.get().keys, box = $('#testAll'), jobs = [];
  const chip = (name, ok, msg) => `<span class="chip ${ok ? 'ok' : 'warn'}">${name}: ${ok ? 'يعمل ✓' + (msg ? ' · ' + esc(msg) : '') : esc((msg || 'لا يعمل').slice(0, 140))}</span>`;
  ['gemini', 'openai', 'groq', 'openrouter'].filter(id => k[id]).forEach(id => jobs.push(LLM.test(id).then(() => chip(LLM.NAMES[id], true), e => chip(LLM.NAMES[id], false, e.message))));
  if (k.azure) jobs.push(TTS.ENGINES.azure.chunk('مرحبا', { pace: 'normal' }).then(() => chip('Azure صوت', true), e => chip('Azure صوت', false, e.message)));
  if (k.youtube) jobs.push(Script.fetchChannel(Settings.get().ytHandle || Channel.cur.yt || '@youtube').then(v => chip('YouTube', true, v.items.length + ' فيديو'), e => chip('YouTube', false, e.message)));
  if (!jobs.length) { box.innerHTML = '<span class="muted">لم تُضف مفاتيح بعد</span>'; return; }
  btn.disabled = true; box.innerHTML = '<span class="muted">جاري الاختبار…</span>';
  box.innerHTML = (await Promise.all(jobs)).join('');
  btn.disabled = false;
}

/* ---------- شاشة الترحيب واختيار القناة ---------- */
function applyChannel() {
  const c = Channel.cur, root = document.documentElement;
  document.body.dataset.channel = c.id;
  root.style.setProperty('--ch', c.accent);
  $('#brandLogo').src = c.id === 'farm' ? c.logo : c.tile; $('#brandLogo').alt = c.name;
  $('#brandSub').textContent = c.id === 'farm' ? 'استوديو المشاهد' : c.id === 'majra' ? 'مجرى · استوديو الترندات' : c.name + ' · استوديو';
  $('#ttsText').placeholder = c.id === 'farm' ? 'الصق نص الفيديو هنا باللهجة المصرية…' : 'الصق نص الفيديو هنا، أو اختر موضوعاً من الترندات أو ابحث بالأعلى…';
  if (c.custom) {   // ألوان القناة المضافة
    document.body.style.setProperty('--accent', c.accent);
    document.body.style.setProperty('--accent-soft', c.accent + '2e');
    const L = (h => { const n = parseInt(h.slice(1), 16); return ((n >> 16) * 0.3 + ((n >> 8) & 255) * 0.59 + (n & 255) * 0.11) / 255; })(c.accent);
    document.body.style.setProperty('--accent-fg', L > 0.6 ? '#111' : '#fff');
  }
  document.title = 'Fadi · ' + c.name;
}
function welcome(show) {
  const w = $('#welcome');
  if (!show) {
    try { sessionStorage.setItem('ff.welcomed', '1'); } catch {}
    w.classList.add('out'); setTimeout(() => { w.hidden = true; w.classList.remove('out'); document.documentElement.classList.add('welcomed'); }, 450); return;
  }
  if (Player.playing) stopPlayback();
  saveNow();
  document.documentElement.classList.remove('welcomed');
  w.hidden = false;
  $$('.wl-tile', w).forEach(b => b.classList.toggle('cur', b.dataset.ch === Channel.id));
}
/* شاشة الترحيب: قنواتي + القنوات المضافة + خانة «إضافة قناة» (الضغط المطوّل على قناة مضافة: تعديل أو حذف) */
function renderTiles() {
  const box = $('#wlTiles'), L = Channel.LIST;
  const tile = c => `<button class="wl-tile ${c.id === 'farm' ? 'farm' : c.id === 'majra' ? 'majra' : 'custom'}${c.id === Channel.id ? ' cur' : ''}" data-ch="${c.id}" type="button"><img src="${esc(c.tile)}" alt=""><b>${esc(c.name)}</b><small>${c.id === 'farm' ? 'المزرعة والحيوانات' : c.id === 'majra' ? 'ترندات الجزائر والعالم' : esc((Channel.customs.find(x => x.id === c.id)?.desc || '').slice(0, 40))}</small></button>`;
  box.innerHTML = [L.farm, L.majra, ...Channel.customs.map(c => L[c.id]).filter(Boolean)].map(tile).join('') +
    `<button class="wl-tile add" data-add="1" type="button"><span class="plus">+</span><b>إضافة قناة</b><small>أي محتوى: صحة، طبخ، تقنية…</small></button>`;
  $('.wl-hint').hidden = !Channel.customs.length;
}
let chEditing = null, chLogo = '';
function openChannelForm(c) {
  chEditing = c || null; chLogo = c?.logo || '';
  $('#chH').textContent = c ? 'تعديل القناة' : 'قناة جديدة';
  $('#chName').value = c?.name || ''; $('#chDesc').value = c?.desc || ''; $('#chYt').value = c?.yt || '';
  $('#chAccent').value = c?.accent || '#8B5CF6'; $('#chMontage').value = c?.montage || 'calm';
  $('#chDialect').innerHTML = Object.entries(Channel.DIALECTS).map(([k, d]) => `<option value="${k}">${d.name}</option>`).join('');
  $('#chDialect').value = c?.dialect || 'eg';
  $('#chLogoPrev').src = chLogo || 'icons/icon-192.png';
  $('#chModal').hidden = false;
}
async function readLogoSmall(file) {
  const bmp = await createImageBitmap(file), k = Math.min(1, 384 / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas'); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  return c.toDataURL('image/png');
}
function bindWelcome() {
  renderTiles();
  let hold = null, held = false;
  const tiles = $('#wlTiles');
  tiles.addEventListener('pointerdown', e => {
    const b = e.target.closest('.wl-tile.custom'); if (!b) return;
    held = false; b.classList.add('holding');
    hold = setTimeout(() => { held = true; b.classList.remove('holding'); const c = Channel.customs.find(x => x.id === b.dataset.ch); if (!c) return; $('#chMenuName').textContent = c.name; $('#chMenu').dataset.id = c.id; $('#chMenu').hidden = false; navigator.vibrate?.(30); }, 650);
  });
  ['pointerup', 'pointerleave', 'pointercancel'].forEach(t => tiles.addEventListener(t, () => { clearTimeout(hold); $$('.wl-tile.holding').forEach(x => x.classList.remove('holding')); }));
  tiles.addEventListener('contextmenu', e => { const b = e.target.closest('.wl-tile.custom'); if (!b) return; e.preventDefault(); clearTimeout(hold); const c = Channel.customs.find(x => x.id === b.dataset.ch); if (c) { $('#chMenuName').textContent = c.name; $('#chMenu').dataset.id = c.id; $('#chMenu').hidden = false; } });
  $('#welcome').addEventListener('click', async e => {
    if (held) { held = false; return; }
    if (e.target.closest('[data-add]')) return openChannelForm();
    const b = e.target.closest('[data-ch]'); if (!b) return;
    if (b.dataset.ch === Channel.id) return welcome(false);
    b.classList.add('pick');
    // احفظ مشروع القناة الحالية في مساحتها أولاً، ثم انتقل (لا يُكتب أي شيء بعدها حتى لا يختلط المشروعان)
    await saveNow(); await vidsSave();
    App.switching = true;
    try { Capture.stop(); } catch {}
    try { sessionStorage.setItem('ff.welcomed', '1'); localStorage.setItem('ff.channel', b.dataset.ch); } catch {}
    setTimeout(() => { history.replaceState(null, '', location.pathname); location.reload(); }, 300);
  });
  $('#chClose').onclick = () => { $('#chModal').hidden = true; };
  $('#chLogoPick').onclick = () => { $('#chLogoInput').value = ''; $('#chLogoInput').click(); };
  $('#chLogoInput').onchange = async e => { const f = e.target.files[0]; if (!f) return; try { chLogo = await readLogoSmall(f); $('#chLogoPrev').src = chLogo; } catch { toast('تعذّرت قراءة الصورة', 'err'); } };
  $('#chSave').onclick = () => {
    const name = $('#chName').value.trim(); if (!name) return toast('اكتب اسم القناة', 'err');
    try {
      const id = Channel.saveCustom({ ...(chEditing || {}), name, desc: $('#chDesc').value.trim(), logo: chLogo, accent: $('#chAccent').value, dialect: $('#chDialect').value, montage: $('#chMontage').value, yt: $('#chYt').value.trim() });
      $('#chModal').hidden = true; renderTiles();
      toast(chEditing ? 'حُفظت التعديلات' : `أُضيفت قناة «${name}». اضغط عليها للبدء`);
      if (chEditing && chEditing.id === Channel.id) { applyChannel(); }
      chEditing = null; return id;
    } catch (err) { toast(err.message, 'err'); }
  };
  $('#chMenuClose').onclick = () => { $('#chMenu').hidden = true; };
  $('#chEdit').onclick = () => { const c = Channel.customs.find(x => x.id === $('#chMenu').dataset.id); $('#chMenu').hidden = true; if (c) openChannelForm(c); };
  $('#chDelete').onclick = async () => {
    const id = $('#chMenu').dataset.id, c = Channel.customs.find(x => x.id === id); $('#chMenu').hidden = true;
    if (!c || !(await confirmBox(`حذف قناة «${c.name}» مع مشروعها وملفاتها من هذا الجهاز؟`, 'احذف القناة'))) return;
    const wasCur = id === Channel.id;
    await Store.clearNS(id).catch(() => {});
    Channel.removeCustom(id); renderTiles(); toast('حُذفت القناة');
    if (wasCur) { App.switching = true; setTimeout(() => location.reload(), 300); }
  };
  $('#brandHome').onclick = () => welcome(true);
  $('#btnHome').onclick = () => welcome(true);
}

/* إصلاح 5.0: مشروع المزرعة نُسخ بالخطأ إلى مساحة مجرى عند التبديل — يُحذف من مجرى فقط */
async function fixLeak() {
  try {
    if (localStorage.getItem('ff.fix51')) return;
    localStorage.setItem('ff.fix51', '1');
    if (Channel.id !== 'majra') return;
    const farm = await Store.getRaw('project'), mine = await Store.get('project');
    const sig = p => p && JSON.stringify([p.name, p.text?.slice(0, 200), (p.scenes || []).map(x => x.id).slice(0, 5)]);
    if (mine && farm && sig(mine) === sig(farm)) {
      for (const k of ['project', 'promo', 'vids', 'reel-plan', 'reel-flow', 'thumb-prompt', 'cover-prompt']) await Store.set(k, null).catch(() => {});
      localStorage.removeItem(Channel.key('ff.ttsDraft'));
    }
  } catch {}
}

(async function boot() {
  Settings.get();
  applyChannel();
  bindWelcome();
  let welcomed = false; try { welcomed = !!sessionStorage.getItem('ff.welcomed'); } catch {}
  $('#welcome').hidden = welcomed;
  $$('.wl-tile').forEach(b => b.classList.toggle('cur', b.dataset.ch === Channel.id));
  await fixLeak();
  Settings.recoverKeys().then(n => { if (n) toast(`استُرجعت ${n} مفاتيح محفوظة`); });
  Renderer.init($('#cv'));
  bind();
  Trends.bind();
  Script.bind();
  Publish.bind();
  fillVoices();
  try { $('#ttsText').value = localStorage.getItem(Channel.key('ff.ttsDraft')) || ''; } catch {}
  if (NATIVE || matchMedia('(display-mode: standalone)').matches) $('#installText').textContent = 'التطبيق مثبّت ويعمل كتطبيق مستقل.';
  if (!NATIVE && 'serviceWorker' in navigator && location.protocol !== 'file:') navigator.serviceWorker.register('sw.js').catch(() => {});
  if (navigator.storage?.persist) navigator.storage.persist().catch(() => {});
  await restore();
  App.loaded = true;
  await Publish.loadPromo();
  Capture.register('vids', (f, it, meta) => vidsOnFound(meta?.i ?? Vids.parts.findIndex(p => !p.key), f));
  await vidsLoad();
  setVoiceMode(Settings.get().voiceMode || 'vids');
  let last = ''; try { last = localStorage.getItem(Channel.key('ff.view')) || ''; } catch {}
  go(location.hash.slice(1) || last || (App.scenes.length ? 'scenes' : 'project'));
  // إذا كان التطبيق ينتظر ملفاً من Google Vids أو Flow قبل إغلاقه: يكمل الانتظار
  if (Capture.resume()) toast('أكمل من حيث توقفت: في انتظار الملف المنزّل…', '', 5000);
})();
