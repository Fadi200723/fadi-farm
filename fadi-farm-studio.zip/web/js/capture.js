/* Fadi Farm — الالتقاط التلقائي: ينسخ النص، يفتح Google Vids أو Google Flow،
   ثم يراقب التنزيلات الجديدة في الهاتف ويستورد الملف تلقائياً عند رجوعك للتطبيق. */
'use strict';

const Capture = (() => {
  const URLS = { vids: 'https://docs.google.com/videos/create', flow: 'https://labs.google/fx/tools/flow' };
  let watch = null, timer = 0;
  const consumed = new Set((() => { try { return JSON.parse(localStorage.getItem('ff.consumed') || '[]'); } catch { return []; } })());
  const persist = () => { try { localStorage.setItem('ff.consumed', JSON.stringify([...consumed].slice(-300))); } catch {} };

  const recent = (kind, sinceMs) => capCall('FadiNative', 'recent', { kind, since: Math.floor(sinceMs / 1000) - 3, limit: 8 }).then(r => r?.items || []);

  async function importItem(it) {
    const r = await capCall('FadiNative', 'importUri', { uri: it.uri });
    const res = await fetch(window.Capacitor.convertFileSrc('file://' + r.path));
    if (!res.ok) throw new Error('تعذّرت قراءة الملف المنزّل');
    const b = await res.blob();
    return new File([b], r.name || it.name || 'media', { type: r.mime || it.mime || b.type });
  }

  /* يطلب صلاحية قراءة المعرض مرة واحدة قبل الخروج للموقع */
  async function prepare() {
    if (!NATIVE) return false;
    try { await recent('any', Date.now()); return true; }
    catch (e) { toast('اسمح للتطبيق بالوصول للصور والفيديو حتى يلتقط الملفات المنزّلة تلقائياً', 'err', 7000); return false; }
  }

  function bar(text, actions = true) {
    const b = $('#watchBar');
    b.hidden = !text;
    if (text) { $('#watchText').textContent = text; $('#watchStop').hidden = !actions; }
  }

  async function check() {
    if (!watch || watch.busy || document.hidden) return;
    watch.busy = true;
    try {
      const items = (await recent(watch.kind, watch.since)).filter(i => !consumed.has(i.uri) && (i.size || 0) > 2000);
      if (!items.length) return;
      const it = items.sort((a, b) => b.date - a.date)[0];
      consumed.add(it.uri); persist();
      const w = watch; stop();
      bar(`جارٍ استيراد ${it.name}…`, false);
      try { const f = await importItem(it); bar(''); await w.onFound(f, it); }
      catch (e) { bar(''); toast(e.message, 'err'); }
    } catch (e) {
      if (/denied|DENIED/i.test(e?.message || e?.code || '')) { stop(); toast('رُفضت صلاحية المعرض. أضف الملف يدوياً', 'err'); }
    } finally { if (watch) watch.busy = false; }
  }

  const handlers = {};
  function register(action, fn) { handlers[action] = fn; }
  const saveWatch = w => { try { w ? localStorage.setItem(Channel.key('ff.watch'), JSON.stringify({ kind: w.kind, label: w.label, since: w.since, action: w.action, meta: w.meta })) : localStorage.removeItem(Channel.key('ff.watch')); } catch {} };

  /* بعد إغلاق التطبيق وفتحه: يكمل انتظار الملف من حيث توقف */
  function resume() {
    let w = null; try { w = JSON.parse(localStorage.getItem(Channel.key('ff.watch')) || 'null'); } catch {}
    if (!w || !w.action || !handlers[w.action] || Date.now() - w.since > 3 * 3600e3) { saveWatch(null); return false; }
    start({ ...w, onFound: (f, it) => handlers[w.action](f, it, w.meta), keepSince: w.since });
    setTimeout(check, 1200);
    return true;
  }

  function start({ kind, label, onFound, action, meta, keepSince }) {
    stop();
    watch = { kind, label, onFound, action, meta, since: keepSince || Date.now(), busy: false };
    saveWatch(watch);
    bar(`في انتظار ${label}… نزّله وارجع للتطبيق، وسأضيفه تلقائياً`);
    timer = setInterval(check, 2500);
  }

  function stop() { clearInterval(timer); timer = 0; watch = null; bar(''); saveWatch(null); }

  async function copyOpen(text, where) {
    let ok = false;
    if (NATIVE) { try { await capCall('FadiNative', 'copyText', { text }); ok = true; } catch {} }
    if (!ok) ok = await copyText(text);
    let url = URLS[where] || where;
    if (where === 'vids') url += (url.includes('?') ? '&' : '?') + 'usp=fadifarm&n=' + Date.now();   // صفحة جديدة تماماً كل مرة
    if (NATIVE) { try { await capCall('FadiNative', 'open', { url, newTab: true }); return ok; } catch {} }
    window.open(url, '_blank', 'noopener');
    return ok;
  }

  /* عدّ تنازلي قبل خطوة تلقائية تالية، مع إمكانية الإيقاف */
  function countdown(sec, text, fn) {
    let n = sec; stop();
    const tick = () => {
      if (n <= 0) { clearInterval(timer); timer = 0; bar(''); fn(); return; }
      bar(`${text} خلال ${n}…`); n--;
    };
    tick(); timer = setInterval(tick, 1000);
  }

  document.addEventListener('visibilitychange', () => { if (!document.hidden) setTimeout(check, 800); });

  function bind() { $('#watchStop').onclick = () => { stop(); toast('أُوقف الالتقاط التلقائي'); }; }

  return { start, stop, prepare, copyOpen, countdown, bind, register, resume, URLS, get active() { return !!watch; } };
})();
