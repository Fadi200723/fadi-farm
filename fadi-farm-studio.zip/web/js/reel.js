/* Fadi Farm — الريل التشويقي: مونتاج سريع بلقطات جديدة عمودية، قطع مع زووم وفلاش،
   عنوان خطّاف، ترجمة متحركة كلمة بكلمة متزامنة مع الصوت، شريط تقدّم، وبطاقة نهاية */
'use strict';

const Reel = (() => {
  const W = 1080, H = 1920;
  const st = { plan: null, flow: [], busy: false, shots: [], words: [], dur: 0, hook: '', cta: '', cur: -1 };
  const FONT = (n, w = 400) => `${w} ${n}px "Lalezar", "IBM Plex Sans Arabic", sans-serif`;
  const ease = x => 1 - Math.pow(1 - Math.min(1, Math.max(0, x)), 3);
  const spring = x => x >= 1 ? 1 : 1 + Math.sin(x * Math.PI * 1.5) * (1 - x) * 0.35 - (1 - ease(x)) * 0.6;

  /* ---------- الخطة ---------- */
  function fallbackPlan() {
    let a = 0, acc = 0, b = 0;
    for (let i = 0; i < App.scenes.length; i++) { acc += App.scenes[i].d; b = i; if (acc >= 11) break; }
    return {
      start: a, end: b, hook: (App.projName || 'شوف ده').split(/\s+/).slice(0, 4).join(' '), cta: 'الفيديو كامل على القناة',
      shots: App.scenes.slice(0, 6).map(s => ({ keywords: s.kw.filter(w => /^[a-z ]+$/i.test(w)).slice(0, 2).concat(['chicken farm']).slice(0, 2), flowPrompt: '' })),
    };
  }

  async function ensurePlan(force = false) {
    if (st.plan && !force) return st.plan;
    try { st.plan = await Store.get('reel-plan'); } catch {}
    if (st.plan && !force) return st.plan;
    st.plan = Settings.get().keys.gemini ? await AI.reelPlan(App.scenes).catch(() => fallbackPlan()) : fallbackPlan();
    // تأكد أن المدة بين 8 و 16 ثانية
    const { st: starts } = Renderer.timeline(App.scenes);
    const len = p => starts[p.end] + App.scenes[p.end].d - starts[p.start];
    while (len(st.plan) < 8 && st.plan.end < App.scenes.length - 1) st.plan.end++;
    while (len(st.plan) > 17 && st.plan.end > st.plan.start) st.plan.end--;
    if (!st.plan.shots.length) st.plan.shots = fallbackPlan().shots;
    Store.set('reel-plan', st.plan).catch(() => {});
    renderPlan();
    return st.plan;
  }

  function renderPlan() {
    const p = st.plan, box = $('#rlPlan'); if (!box) return;
    if (!p || !App.scenes.length) { box.innerHTML = ''; return; }
    if (!$('#rlHook').value) $('#rlHook').value = p.hook;
    const text = App.scenes.slice(p.start, p.end + 1).map(s => s.text).join(' ');
    box.innerHTML = `<p class="small muted">المقطع المختار من التعليق (المشاهد ${p.start + 1} إلى ${p.end + 1}):</p><p class="quote">${esc(text)}</p>`;
    $('#rlFlowCount').textContent = st.flow.length ? `${st.flow.length} لقطة من Flow جاهزة` : '';
  }

  /* ---------- الصوت والكلمات ---------- */
  function audioSlice(p) {
    const { st: starts } = Renderer.timeline(App.scenes);
    const a = starts[p.start], b = Math.min(App.buf.duration, starts[p.end] + App.scenes[p.end].d);
    const ctx = Player.audioCtx(), sr = App.buf.sampleRate, i0 = Math.floor(a * sr), i1 = Math.floor(b * sr), tail = Math.floor(sr * 0.6);
    const out = ctx.createBuffer(1, i1 - i0 + tail, sr), o = out.getChannelData(0);
    for (let c = 0; c < App.buf.numberOfChannels; c++) { const d = App.buf.getChannelData(c); for (let k = i0; k < i1; k++) o[k - i0] += d[k] / App.buf.numberOfChannels; }
    const fi = Math.floor(sr * 0.03), fo = Math.floor(sr * 0.35), n = i1 - i0;
    for (let k = 0; k < fi; k++) o[k] *= k / fi;
    for (let k = 0; k < fo; k++) o[n - 1 - k] *= k / fo;
    // توقيت كل كلمة: موزّع حسب طول الكلمات داخل مدة كل مشهد
    const words = []; let t = 0;
    for (let i = p.start; i <= p.end; i++) {
      const sc = App.scenes[i], ws = sc.text.split(/\s+/).filter(Boolean), L = ws.reduce((x, w) => x + w.length + 1, 0) || 1;
      let tt = t; ws.forEach(w => { const d = sc.d * (w.length + 1) / L; words.push({ w, t0: tt, t1: tt + d }); tt += d; });
      t += sc.d;
    }
    return { buf: out, words, dur: out.duration };
  }

  /* ---------- اللقطات ---------- */
  async function gatherShots(p, n, onP) {
    const shots = [], used = new Set(App.scenes.map(s => s.asset?.uid).filter(Boolean));
    // 1) لقطات Google Flow
    for (const k of st.flow) { const b = await Store.getBlob(k).catch(() => null); if (b) shots.push({ blob: b, type: b.type.startsWith('image') ? 'image' : 'video' }); }
    // 2) لقطات جديدة عمودية من المصادر
    if (shots.length < n) {
      const finder = makeFinder({ orientation: 'portrait', minDim: 720 });
      const wants = p.shots.slice(0, n - shots.length).map((x, i) => ({ id: 'r' + i, text: x.keywords.join(' '), kw: x.keywords, kind: 'video', rej: [] }));
      let lists = await Promise.all(wants.map(async sc => ({ sc, cands: await finder.candidates(sc, { need: 3, exclude: used }).catch(() => []) })));
      if (useVision()) { try { const ord = await visualCheck(lists); lists = lists.map((l, i) => ({ sc: l.sc, cands: ord[i].length ? [...ord[i], ...l.cands.filter(c => !ord[i].includes(c))] : l.cands })); } catch {} }
      let k = 0;
      for (const { cands } of lists) {
        onP?.(k++ / lists.length);
        for (const it of cands.filter(c => !used.has(c.uid)).slice(0, 3)) {
          try {
            let urls = it.urls; if (it.resolve) urls = [...(await it.resolve()), ...urls];
            const b = await Media.fetchBlob(urls); used.add(it.uid);
            shots.push({ blob: b, type: it.type, uid: it.uid }); break;
          } catch {}
        }
      }
    }
    // 3) احتياطي: لقطات الفيديو الأساسي
    const own = App.scenes.filter(s => s.blobKey);
    for (let i = 0; shots.length < n && own.length && i < n * 2; i++) {
      const s = own[(p.start + i) % own.length]; const b = await Store.getBlob(s.blobKey).catch(() => null);
      if (b) shots.push({ blob: b, type: s.asset.type, off: 1 + (i % 3) * 2 });
    }
    for (const s of shots) { s.el = await Media.element(s.blob, s.type).catch(() => null); }
    return shots.filter(s => s.el);
  }

  /* ---------- الرسم ---------- */
  function cover(g, el, zoom, panX, panY) {
    const ew = el.videoWidth || el.naturalWidth, eh = el.videoHeight || el.naturalHeight; if (!ew) return false;
    const k = Math.max(W / ew, H / eh) * zoom, dw = ew * k, dh = eh * k;
    g.drawImage(el, (W - dw) / 2 + panX * (dw - W) / 2, (H - dh) / 2 + panY * (dh - H) / 2, dw, dh);
    return true;
  }

  function strokeFill(g, text, x, y, fs, fill) {
    g.lineJoin = 'round'; g.lineWidth = fs * 0.22; g.strokeStyle = '#000'; g.strokeText(text, x, y);
    g.fillStyle = fill; g.fillText(text, x, y);
  }

  let lastShot = -1;
  function frame(t) {
    const cv = Renderer.canvas, g = cv.getContext('2d');
    const n = st.shots.length, seg = (st.dur - 2) / Math.max(1, n);       // آخر ثانيتين لبطاقة النهاية
    const i = Math.min(n - 1, Math.floor(Math.min(t, st.dur - 2.01) / seg)), local = t - i * seg, p = local / seg;
    const sh = st.shots[i];
    // تشغيل فيديو اللقطة الحالية فقط
    if (i !== lastShot) {
      st.shots.forEach((s, k) => { if (k !== i && s.type === 'video' && !s.el.paused) s.el.pause(); });
      if (sh?.type === 'video') { try { sh.el.currentTime = (sh.off || 0.6) % Math.max(1, (sh.el.duration || 4) - seg); } catch {} sh.el.play().catch(() => {}); }
      lastShot = i;
    }
    g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
    if (sh) {
      const punch = local < 0.18 ? (0.18 - local) / 0.18 * 0.09 : 0;   // ضربة زووم عند القطع
      const zoom = 1.04 + 0.12 * ease(p) + punch, dir = i % 2 ? 1 : -1;
      g.save(); g.filter = 'saturate(1.3) contrast(1.12) brightness(1.03)';
      cover(g, sh.el, zoom, dir * (p - 0.5) * 0.5, (i % 3 - 1) * 0.15);
      g.restore();
    }
    // فلاش أبيض عند كل قطع
    if (i > 0 && local < 0.12) { g.fillStyle = `rgba(255,255,255,${(1 - local / 0.12) * 0.55})`; g.fillRect(0, 0, W, H); }
    // تظليل أعلى وأسفل لقراءة النص
    let gr = g.createLinearGradient(0, 0, 0, H * 0.32); gr.addColorStop(0, 'rgba(0,0,0,.55)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(0, 0, W, H * 0.32);
    gr = g.createLinearGradient(0, H * 0.5, 0, H); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,.6)'); g.fillStyle = gr; g.fillRect(0, H * 0.5, W, H * 0.5);

    g.direction = 'rtl'; g.textAlign = 'center'; g.textBaseline = 'middle';
    const accent = '#FFD23F';

    // شريط التقدّم
    g.fillStyle = 'rgba(255,255,255,.25)'; g.fillRect(0, 0, W, 14);
    g.fillStyle = accent; g.fillRect(W - W * Math.min(1, t / st.dur), 0, W * Math.min(1, t / st.dur), 14);

    // عنوان الخطّاف (أول ثانيتين)
    if (t < 2.3 && st.hook) {
      const a = t < 2 ? 1 : 1 - (t - 2) / 0.3, sc = spring(t / 0.45);
      g.save(); g.globalAlpha = a; g.translate(W / 2, H * 0.24); g.scale(sc, sc); g.rotate(-0.035);
      let fs = 120; g.font = FONT(fs); while (g.measureText(st.hook).width > W * 0.82 && fs > 60) { fs -= 4; g.font = FONT(fs); }
      const w = g.measureText(st.hook).width + 70, h = fs * 1.35;
      g.shadowColor = 'rgba(0,0,0,.5)'; g.shadowBlur = 30; g.fillStyle = accent;
      g.beginPath(); g.roundRect ? g.roundRect(-w / 2, -h / 2, w, h, 22) : g.rect(-w / 2, -h / 2, w, h); g.fill();
      g.shadowColor = 'transparent'; g.lineWidth = 8; g.strokeStyle = '#000'; g.stroke();
      g.fillStyle = '#111'; g.fillText(st.hook, 0, fs * 0.05);
      g.restore();
    }

    // ترجمة كلمة بكلمة (3 كلمات في السطر، الكلمة الحالية مميزة)
    const end = st.dur - 2;
    if (t < end) {
      const wi = Math.max(0, st.words.findIndex(w => t < w.t1));
      const g0 = Math.floor(wi / 3) * 3, grp = st.words.slice(g0, g0 + 3);
      const fs = 96; g.font = FONT(fs);
      const sp = 26, widths = grp.map(w => g.measureText(w.w).width), total = widths.reduce((a, b) => a + b, 0) + sp * (grp.length - 1);
      let x = W / 2 + total / 2; const y = H * 0.7;
      grp.forEach((w, k) => {
        const cx = x - widths[k] / 2, curW = g0 + k === wi, age = t - w.t0;
        g.save(); g.translate(cx, y);
        const s = curW ? 1.0 + 0.16 * spring(Math.min(1, age / 0.25)) - 0.02 : (g0 + k < wi ? 1 : 0.96);
        g.scale(s, s);
        if (g0 + k > wi) g.globalAlpha = 0.85;
        strokeFill(g, w.w, 0, 0, fs, curW ? accent : '#fff');
        g.restore();
        x -= widths[k] + sp;
      });
    }

    // بطاقة النهاية
    if (t >= end) {
      const q = Math.min(1, (t - end) / 0.35);
      g.fillStyle = `rgba(0,0,0,${0.55 * q})`; g.fillRect(0, 0, W, H);
      g.save(); g.globalAlpha = q; g.translate(W / 2, H * 0.45); const s = spring(q); g.scale(s, s);
      const lines = splitTwo(st.cta);
      let fs = 112; g.font = FONT(fs); while (Math.max(...lines.map(l => g.measureText(l).width)) > W * 0.86 && fs > 60) { fs -= 4; g.font = FONT(fs); }
      lines.forEach((l, k) => strokeFill(g, l, 0, (k - (lines.length - 1) / 2) * fs * 1.25, fs, k === lines.length - 1 ? accent : '#fff'));
      g.restore();
      // سهم يتحرك لأسفل
      const bob = Math.sin(t * 9) * 18, ax = W / 2, ay = H * 0.66 + bob;
      g.save(); g.globalAlpha = q; g.fillStyle = accent; g.strokeStyle = '#000'; g.lineWidth = 8;
      g.beginPath(); g.moveTo(ax - 70, ay); g.lineTo(ax + 70, ay); g.lineTo(ax, ay + 90); g.closePath(); g.fill(); g.stroke();
      g.fillRect(ax - 24, ay - 90, 48, 92); g.strokeRect(ax - 24, ay - 90, 48, 92);
      g.beginPath(); g.moveTo(ax - 70, ay); g.lineTo(ax + 70, ay); g.lineTo(ax, ay + 90); g.closePath(); g.fill();
      g.restore();
    }
  }

  function splitTwo(t) { const w = t.split(/\s+/); if (w.length < 4) return [t]; const m = Math.ceil(w.length / 2); return [w.slice(0, m).join(' '), w.slice(m).join(' ')]; }

  /* ---------- الصنع ---------- */
  async function make() {
    if (st.busy) return;
    if (!App.buf || !App.scenes.length) return toast('جهّز الفيديو الأساسي أولاً', 'err');
    const box = $('#shProgress'), btn = $('#btnShort'); st.busy = true; btn.disabled = true;
    try {
      setProgress(box, 0.03, 'Gemini يختار أقوى مقطع ويخطط المونتاج…');
      const p = await ensurePlan();
      const a = audioSlice(p);
      st.dur = a.dur; st.words = a.words;
      st.hook = ($('#rlHook').value || p.hook || '').trim(); st.cta = p.cta;
      const n = Math.max(5, Math.min(9, Math.round((a.dur - 2) / 1.6)));
      setProgress(box, 0.1, 'البحث عن لقطات جديدة للريل…');
      st.shots = await gatherShots(p, n, f => setProgress(box, 0.1 + f * 0.35, `تنزيل لقطات الريل ${Math.round(f * 100)}%`));
      if (!st.shots.length) throw new Error('لم أجد لقطات للريل. تحقق من الإنترنت');
      for (const s of st.shots) if (s.type === 'video') await new Promise(r => { if (s.el.readyState >= 2) r(); else { s.el.oncanplay = r; setTimeout(r, 4000); } });
      try { await document.fonts.load(FONT(100)); } catch {}
      setProgress(box, 0.5, 'مونتاج الريل وتصديره (9:16)…');
      const cv = Renderer.canvas, ow = cv.width, oh = cv.height; Renderer.size(W, H); lastShot = -1;
      const blob = await new Promise((res, rej) => {
        Player.start({
          buf: a.buf, scenes: [], record: true, frame,
          prep: f => setProgress(box, 0.5, `تجهيز الصوت ${Math.round(f * 100)}%`),
          tick: t => setProgress(box, 0.5 + 0.5 * t / a.dur, `تصدير الريل ${Math.round(t / a.dur * 100)}%`),
          end: (b, err) => { Renderer.size(ow, oh); b && b.size ? res(b) : rej(new Error('فشل تصدير الريل' + (err?.message ? ': ' + err.message : ''))); },
        }).catch(e => { Renderer.size(ow, oh); rej(e); });
      });
      st.shots.forEach(s => { if (s.type === 'video') s.el.pause(); URL.revokeObjectURL(s.el.src); });
      resultBox($('#shResult'), blob, `${safeName()}-reel`, 'الريل جاهز');
      toast(`الريل جاهز · ${Math.round(a.dur)} ثانية · ${st.shots.length} لقطة`);
    } catch (e) { toast(e.message, 'err', 7000); }
    finally { box.hidden = true; st.busy = false; btn.disabled = false; }
  }

  /* ---------- لقطات Google Flow (اختياري) ---------- */
  async function flowShots() {
    if (!App.scenes.length) return toast('جهّز الفيديو الأساسي أولاً', 'err');
    const p = await ensurePlan();
    const i = st.flow.length, shot = p.shots[i];
    if (!shot) return toast('اكتملت لقطات Flow المقترحة');
    const prompt = (shot.flowPrompt || `Cinematic vertical shot of ${shot.keywords.join(', ')} on a rural Egyptian farm, photorealistic, golden hour`) + ' Vertical 9:16 portrait video, 1080x1920, 8 seconds, no text.';
    if (!NATIVE) { await copyText(prompt); window.open(Capture.URLS.flow, '_blank'); return toast('نُسخ وصف اللقطة. بعد التنزيل أضفها من «لقطة من المعرض»', '', 7000); }
    if (!(await Capture.prepare())) return;
    Capture.start({ kind: 'video', label: `لقطة ${i + 1} من Google Flow`, onFound: async f => {
      const key = 'reel-flow-' + uid(); await Store.putBlob(key, f); st.flow.push(key); saveFlow(); renderPlan();
      if (st.flow.length < Math.min(3, p.shots.length)) Capture.countdown(4, `نسخ وصف اللقطة ${st.flow.length + 1} وفتح Flow`, flowShots);
      else toast('أُضيفت لقطات Flow. اضغط «اصنع الريل»');
    } });
    await Capture.copyOpen(prompt, 'flow');
    toast(`نُسخ وصف اللقطة ${i + 1} (فيديو عمودي 9:16). اصنعها في Flow ونزّلها`, '', 8000);
  }
  const saveFlow = () => Store.set('reel-flow', st.flow).catch(() => {});
  async function clearFlow() { for (const k of st.flow) await Store.delBlob(k).catch(() => {}); st.flow = []; saveFlow(); renderPlan(); }
  async function addFromGallery() {
    const f = NATIVE ? await pickFromGallery('video').catch(() => null) : await new Promise(r => { const i = document.createElement('input'); i.type = 'file'; i.accept = 'video/*,image/*'; i.onchange = () => r(i.files[0] || null); i.click(); });
    if (!f) return; const key = 'reel-flow-' + uid(); await Store.putBlob(key, f); st.flow.push(key); saveFlow(); renderPlan(); toast('أُضيفت اللقطة للريل');
  }

  async function enter() {
    try { st.flow = (await Store.get('reel-flow')) || []; } catch {}
    if (App.scenes.length && Settings.get().keys.gemini) ensurePlan().catch(() => {}); else renderPlan();
  }
  async function reset() { st.plan = null; await clearFlow(); Store.set('reel-plan', null).catch(() => {}); if ($('#rlHook')) $('#rlHook').value = ''; renderPlan(); }

  function bind() {
    $('#btnShort').onclick = make;
    $('#btnReelFlow').onclick = flowShots;
    $('#btnReelGallery').onclick = addFromGallery;
    $('#btnReelFlowClear').onclick = clearFlow;
    $('#btnReelReplan').onclick = async () => { $('#rlHook').value = ''; st.plan = null; await Store.set('reel-plan', null).catch(() => {}); await ensurePlan(true); toast('خطة جديدة للريل'); };
  }

  return { make, enter, reset, bind };
})();
