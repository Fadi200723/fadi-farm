/* Fadi Farm — الريل التشويقي: مقطع كامل الجمل من تعليقك، لقطة مناسبة لكل جملة،
   مونتاج خفيف بانتقالات ناعمة، ترجمة متزامنة، وفي النهاية جملة «الفيديو كامل تحت» بصوتك مع سهم */
'use strict';

window.Reel = null;
const Reel = (() => {
  const W = 1080, H = 1920;
  const st = { plan: null, flow: [], busy: false, shots: [], words: [], dur: 0, ctaAt: 0, hook: '', cta: '', cur: -1 };
  const FONT = (n, w = 400) => `${w} ${n}px "Lalezar", "IBM Plex Sans Arabic", sans-serif`;
  const CAP = n => `700 ${n}px "IBM Plex Sans Arabic", Tahoma, sans-serif`;
  const ease = x => 1 - Math.pow(1 - Math.min(1, Math.max(0, x)), 3);
  const easeIO = x => { x = Math.min(1, Math.max(0, x)); return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2; };

  /* ---------- الخطة ---------- */
  function fallbackPlan() {
    let acc = 0, b = 0;
    for (let i = 0; i < App.scenes.length; i++) { acc += App.scenes[i].d; b = i; if (acc >= 14) break; }
    return { start: 0, end: b, hook: (App.projName || 'شوف ده').split(/\s+/).slice(0, 4).join(' '), cta: 'الفيديو كامل تحت، ادخل شوفه' };
  }

  function fixRange(p) {
    const { st: starts } = Renderer.timeline(App.scenes);
    const len = () => starts[p.end] + App.scenes[p.end].d - starts[p.start];
    while (len() < 12 && p.end < App.scenes.length - 1) p.end++;
    while (len() > 32 && p.end > p.start) p.end--;
    return p;
  }

  async function ensurePlan(force = false) {
    if (!force) { if (st.plan) return st.plan; try { st.plan = await Store.get('reel-plan'); } catch {} if (st.plan && st.plan.end < App.scenes.length) return renderPlan(), st.plan; }
    st.plan = fixRange(Settings.get().keys.gemini ? await AI.reelPlan(App.scenes).catch(e => { toast('Gemini: ' + e.message + '. استخدمت بداية الفيديو', 'err', 6000); return fallbackPlan(); }) : fallbackPlan());
    Store.set('reel-plan', st.plan).catch(() => {});
    renderPlan();
    return st.plan;
  }

  async function renderPlan() {
    const p = st.plan, box = $('#rlPlan'); if (!box) return;
    if (!p || !App.scenes.length) { box.innerHTML = ''; return; }
    if (!$('#rlHook').value) $('#rlHook').value = p.hook;
    const text = App.scenes.slice(p.start, p.end + 1).map(s => s.text).join(' ');
    const { st: starts } = Renderer.timeline(App.scenes), dur = starts[p.end] + App.scenes[p.end].d - starts[p.start];
    const cta = await Store.getBlob('reel-cta').catch(() => null);
    box.innerHTML = `<p class="small muted">المقطع المختار (${Math.round(dur)} ثانية، المشاهد ${p.start + 1} إلى ${p.end + 1}). يمكنك تغييره:</p>
      <div class="row"><label class="field"><span>من المشهد</span><input id="rlFrom" type="number" min="1" max="${App.scenes.length}" value="${p.start + 1}"></label>
      <label class="field"><span>إلى المشهد</span><input id="rlTo" type="number" min="1" max="${App.scenes.length}" value="${p.end + 1}"></label></div>
      <p class="quote">${esc(text)}</p>
      <p class="small ${cta ? '' : 'muted'}">${cta ? '✓ جملة النهاية بصوتك جاهزة: «' + esc(Settings.get().reelCta || 'الفيديو كامل تحت') + '»' : 'جملة النهاية بالصوت: تُسجَّل كجزء أخير قصير في Google Vids. بدونها تظهر مكتوبة فقط.'}</p>`;
    $('#rlFlowCount').textContent = st.flow.length ? `${st.flow.length} لقطة مضافة` : '';
  }

  /* ---------- الصوت ---------- */
  function mono(buf, a, b) {
    const sr = buf.sampleRate, i0 = Math.max(0, Math.floor(a * sr)), i1 = Math.min(buf.length, Math.floor(b * sr)), o = new Float32Array(Math.max(0, i1 - i0));
    for (let c = 0; c < buf.numberOfChannels; c++) { const d = buf.getChannelData(c); for (let k = i0; k < i1; k++) o[k - i0] += d[k] / buf.numberOfChannels; }
    return o;
  }
  /* أقرب وقفة حقيقية في الكلام حول الزمن t */
  function snap(t, win, prefer = 0) {
    const a = Math.max(0, t - win), d = mono(App.buf, a, Math.min(App.buf.duration, t + win)), ps = findPauses(d, App.buf.sampleRate);
    if (!ps.length) return t;
    ps.sort((x, y) => (Math.abs(x.t + a - t) - x.len * 0.8 - (prefer && Math.sign(x.t + a - t) === prefer ? 0.3 : 0)) - (Math.abs(y.t + a - t) - y.len * 0.8 - (prefer && Math.sign(y.t + a - t) === prefer ? 0.3 : 0)));
    return ps[0].t + a;
  }

  async function buildAudio(p) {
    const { st: starts } = Renderer.timeline(App.scenes);
    let a = starts[p.start], b = starts[p.end] + App.scenes[p.end].d;
    a = p.start === 0 ? 0 : snap(a, 0.9, -1); b = Math.min(App.buf.duration, snap(b, 1.3, 1));
    const sr = App.buf.sampleRate, main = mono(App.buf, a, b);
    const fi = Math.floor(sr * 0.04), fo = Math.floor(sr * 0.12);
    for (let k = 0; k < fi && k < main.length; k++) main[k] *= k / fi;
    for (let k = 0; k < fo && k < main.length; k++) main[main.length - 1 - k] *= k / fo;
    // جملة النهاية بصوتك (من Google Vids)
    let cta = null;
    const cb = await Store.getBlob('reel-cta').catch(() => null);
    if (cb) { try { const cbuf = await Player.audioCtx().decodeAudioData(await cb.arrayBuffer()); cta = mono(cbuf, 0, cbuf.duration); if (cbuf.sampleRate !== sr) cta = resample(cta, cbuf.sampleRate, sr); } catch {} }
    const gap = Math.floor(sr * 0.35), ctaLen = cta ? cta.length : Math.floor(sr * 2.4), tail = Math.floor(sr * 0.6);
    const out = Player.audioCtx().createBuffer(1, main.length + gap + ctaLen + tail, sr), o = out.getChannelData(0);
    o.set(main, 0); if (cta) o.set(cta, main.length + gap);
    // توقيت الكلمات من الصوت نفسه (فترات الكلام الفعلية)، فتظهر الكتابة مع الكلام بدون تأخير
    const range = App.scenes.slice(p.start, p.end + 1);
    const words = Align.fromData(main, sr, range.map(sc => sc.text).join(' '));
    // بداية كل مشهد = لحظة نطق أول كلمة فيه
    const sceneTimes = []; let wi = 0;
    range.forEach((sc, k) => {
      const n = sc.text.split(/\s+/).filter(Boolean).length, first = words[wi], last = words[Math.min(words.length - 1, wi + n - 1)];
      sceneTimes.push({ sc, t0: k === 0 ? 0 : (first ? first.t0 - 0.1 : 0), t1: last ? last.t1 : main.length / sr });
      wi += n;
    });
    sceneTimes.forEach((x, k) => { if (sceneTimes[k + 1]) x.t1 = sceneTimes[k + 1].t0; else x.t1 = main.length / sr; });
    return { buf: out, words, dur: out.duration, ctaAt: (main.length + gap * 0.5) / sr, sceneTimes };
  }
  function resample(d, from, to) { const k = from / to, n = Math.floor(d.length / k), r = new Float32Array(n); for (let i = 0; i < n; i++) r[i] = d[Math.min(d.length - 1, Math.round(i * k))]; return r; }

  /* ---------- اللقطات: لقطة مناسبة لكل جملة ---------- */
  async function gatherShots(sceneTimes, onP) {
    // كل مشهد طويل (> 6 ثوانٍ) يُقسم للقطتين حتى لا يملّ المشاهد
    const slots = [];
    sceneTimes.forEach(x => { const d = x.t1 - x.t0; if (d <= 0.2) return; if (d > 6) { slots.push({ ...x, t1: x.t0 + d / 2 }, { ...x, t0: x.t0 + d / 2, second: true }); } else slots.push(x); });
    const used = new Set(), finder = makeFinder({ orientation: 'portrait', minDim: 720 });
    // لقطات Flow أو المعرض المضافة يدوياً تأخذ أول الأماكن
    for (let i = 0; i < st.flow.length && i < slots.length; i++) { const b = await Store.getBlob(st.flow[i]).catch(() => null); if (b) slots[i].blob = b, slots[i].type = b.type.startsWith('image') ? 'image' : 'video'; }
    const need = slots.filter(s => !s.blob);
    let lists = await Promise.all(need.map(async s => ({ sc: { id: 'r', text: s.sc.text, kw: s.sc.kw, kind: 'video', rej: [] }, cands: await finder.candidates({ text: s.sc.text, kw: s.sc.kw, kind: 'video', rej: [] }, { need: 3, exclude: used }).catch(() => []) })));
    if (useVision() && lists.length) { try { const ord = await visualCheck(lists); lists = lists.map((l, i) => ({ ...l, cands: ord[i].length ? [...ord[i], ...l.cands.filter(c => !ord[i].includes(c))] : l.cands.slice(0, 0) })); } catch {} }
    let k = 0;
    for (let i = 0; i < need.length; i++) {
      onP?.(k++ / need.length);
      const s = need[i];
      for (const it of (lists[i]?.cands || []).filter(c => !used.has(c.uid)).slice(0, 3)) {
        try { let urls = it.urls; if (it.resolve) urls = [...(await it.resolve()), ...urls]; s.blob = await Media.fetchBlob(urls); s.type = it.type; used.add(it.uid); break; } catch {}
      }
      // احتياطي: لقطة نفس المشهد من الفيديو الأساسي (مطابقة للكلام)
      if (!s.blob && s.sc.blobKey) { s.blob = await Store.getBlob(s.sc.blobKey).catch(() => null); s.type = s.sc.asset?.type; s.off = (s.sc.offset || 0) + (s.second ? 3 : 0.5); }
    }
    for (const s of slots) if (s.blob) s.el = await Media.element(s.blob, s.type).catch(() => null);
    // أي فراغ: يأخذ لقطة المكان السابق
    slots.forEach((s, i) => { if (!s.el) { const pv = slots.slice(0, i).reverse().find(x => x.el) || slots.find(x => x.el); if (pv) Object.assign(s, { el: pv.el, type: pv.type, off: (pv.off || 0) + 2 }); } });
    return slots.filter(s => s.el);
  }

  /* ---------- الرسم ---------- */
  function cover(g, el, zoom, panX, panY) {
    const ew = el.videoWidth || el.naturalWidth, eh = el.videoHeight || el.naturalHeight; if (!ew) return false;
    const k = Math.max(W / ew, H / eh) * zoom, dw = ew * k, dh = eh * k;
    g.drawImage(el, (W - dw) / 2 + panX * (dw - W) / 2, (H - dh) / 2 + panY * (dh - H) / 2, dw, dh);
    return true;
  }
  function strokeFill(g, text, x, y, fs, fill, lw = 0.2) { g.lineJoin = 'round'; g.lineWidth = fs * lw; g.strokeStyle = 'rgba(0,0,0,.9)'; g.strokeText(text, x, y); g.fillStyle = fill; g.fillText(text, x, y); }

  const playing = new Set();
  function syncShot(s, local) {
    if (s.type !== 'video') return;
    if (!playing.has(s)) { try { s.el.currentTime = ((s.off || 0.4) + Math.max(0, local)) % Math.max(1, (s.el.duration || 5) - 0.2); } catch {} s.el.play().catch(() => {}); playing.add(s); }
  }
  function stopOthers(keep) { playing.forEach(s => { if (!keep.includes(s)) { s.el.pause(); playing.delete(s); } }); }

  function drawShot(g, s, i, t) {
    const d = s.t1 - s.t0, p = (t - s.t0) / Math.max(0.5, d);
    const punch = Channel.cur.montage === 'strong' && t - s.t0 < 0.3 ? 0.1 * Math.pow(1 - (t - s.t0) / 0.3, 2) : 0;
    const zoom = 1.06 + 0.07 * easeIO(p) + punch, dir = i % 2 ? 1 : -1;
    g.save(); g.filter = 'saturate(1.18) contrast(1.06)';
    cover(g, s.el, zoom, dir * (p - 0.5) * 0.25, 0);
    g.restore();
  }

  function frame(t) {
    const g = Renderer.canvas.getContext('2d'), accent = Channel.cur.accent, strongM = Channel.cur.montage === 'strong';
    g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
    const shots = st.shots, end = st.ctaAt;
    // اللقطة الحالية (آخر لقطة تستمر خلف بطاقة النهاية)
    let i = shots.findIndex(s => t < s.t1); if (i < 0) i = shots.length - 1;
    const s = shots[i], nx = shots[i + 1], X = strongM ? 0 : 0.4;
    const keep = [s]; syncShot(s, t - s.t0);
    drawShot(g, s, i, t);
    if (strongM && i > 0 && t - s.t0 < 0.1) { g.fillStyle = `rgba(255,255,255,${0.5 * (1 - (t - s.t0) / 0.1)})`; g.fillRect(0, 0, W, H); }
    if (nx && t > nx.t0 - X && t < end) {                      // انتقال ناعم (تلاشي)
      keep.push(nx); syncShot(nx, t - nx.t0);
      g.save(); g.globalAlpha = easeIO((t - (nx.t0 - X)) / X); drawShot(g, nx, i + 1, t); g.restore();
    }
    stopOthers(keep);
    // تظليل خفيف لقراءة النص
    let gr = g.createLinearGradient(0, H * 0.55, 0, H); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,.55)'); g.fillStyle = gr; g.fillRect(0, H * 0.55, W, H * 0.45);
    gr = g.createLinearGradient(0, 0, 0, H * 0.25); gr.addColorStop(0, 'rgba(0,0,0,.35)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(0, 0, W, H * 0.25);
    g.direction = 'rtl'; g.textAlign = 'center'; g.textBaseline = 'middle';

    // عنوان الخطّاف
    if (t < 2.8 && st.hook) {
      const a = t < 0.35 ? ease(t / 0.35) : t > 2.4 ? Math.max(0, (2.8 - t) / 0.4) : 1;
      g.save(); g.globalAlpha = a; g.translate(W / 2, H * 0.2 + (1 - a) * -30);
      let fs = 104; g.font = FONT(fs); while (g.measureText(st.hook).width > W * 0.82 && fs > 56) { fs -= 4; g.font = FONT(fs); }
      const w = g.measureText(st.hook).width + 72, h = fs * 1.3;
      g.shadowColor = 'rgba(0,0,0,.45)'; g.shadowBlur = 26; g.fillStyle = accent;
      g.beginPath(); g.roundRect ? g.roundRect(-w / 2, -h / 2, w, h, 26) : g.rect(-w / 2, -h / 2, w, h); g.fill();
      g.shadowColor = 'transparent'; g.fillStyle = accent === '#FFD23F' ? '#111' : '#fff'; g.fillText(st.hook, 0, fs * 0.05);
      g.restore();
    }

    // ترجمة هادئة: حتى 4 كلمات، الكلمة المنطوقة بلون مميز
    if (t < end - 0.1) {
      let wi = st.words.findIndex(w => t < w.t1);
      // أثناء الوقفات: لا تظهر الجملة التالية قبل نطقها
      if (wi >= 0 && t < st.words[wi].t0 - 0.1) wi = wi > 0 && t - st.words[wi - 1].t1 < 0.35 ? wi - 1 : -1;
      if (wi >= 0) {
        const g0 = Math.floor(wi / 4) * 4, grp = st.words.slice(g0, g0 + 4);
        const fs = 78; g.font = CAP(fs);
        const sp = 22, widths = grp.map(w => g.measureText(w.w).width), total = widths.reduce((a, b) => a + b, 0) + sp * (grp.length - 1);
        let x = W / 2 + Math.min(total, W * 0.9) / 2; const y = H * 0.74;
        const groupAge = t - grp[0].t0, ga = Math.min(1, groupAge / 0.18);
        grp.forEach((w, k) => {
          const cx = x - widths[k] / 2, on = g0 + k === wi;
          g.save(); g.globalAlpha = ga; g.translate(cx, y + (1 - ga) * 14);
          strokeFill(g, w.w, 0, 0, fs, on ? accent : '#fff', 0.18);
          g.restore();
          x -= widths[k] + sp;
        });
      }
    }

    // النهاية: «الفيديو كامل تحت» + سهم
    if (t >= end) {
      const q = ease((t - end) / 0.45);
      g.fillStyle = `rgba(0,0,0,${0.5 * q})`; g.fillRect(0, 0, W, H);
      g.save(); g.globalAlpha = q; g.translate(W / 2, H * 0.42 + (1 - q) * 40);
      const lines = splitTwo(st.cta);
      let fs = 104; g.font = FONT(fs); while (Math.max(...lines.map(l => g.measureText(l).width)) > W * 0.86 && fs > 56) { fs -= 4; g.font = FONT(fs); }
      lines.forEach((l, k) => strokeFill(g, l, 0, (k - (lines.length - 1) / 2) * fs * 1.3, fs, k === lines.length - 1 ? accent : '#fff', 0.16));
      g.restore();
      const bob = Math.sin((t - end) * 6) * 22, ax = W / 2, ay = H * 0.6 + bob;
      g.save(); g.globalAlpha = q; g.fillStyle = accent; g.strokeStyle = 'rgba(0,0,0,.85)'; g.lineWidth = 8; g.lineJoin = 'round';
      g.beginPath(); g.moveTo(ax - 26, ay - 110); g.lineTo(ax + 26, ay - 110); g.lineTo(ax + 26, ay); g.lineTo(ax + 72, ay); g.lineTo(ax, ay + 90); g.lineTo(ax - 72, ay); g.lineTo(ax - 26, ay); g.closePath();
      g.stroke(); g.fill(); g.restore();
    }
  }

  function splitTwo(t) { const w = t.split(/\s+/); if (w.length < 4) return [t]; const m = Math.ceil(w.length / 2); return [w.slice(0, m).join(' '), w.slice(m).join(' ')]; }

  /* ---------- الصنع ---------- */
  async function make() {
    if (st.busy) return;
    if (!App.buf || !App.scenes.length) return toast('جهّز الفيديو الأساسي أولاً', 'err');
    const box = $('#shProgress'), btn = $('#btnShort'); st.busy = true; btn.disabled = true;
    try {
      setProgress(box, 0.03, 'اختيار أقوى مقطع من تعليقك…');
      const p = await ensurePlan();
      const from = parseInt($('#rlFrom')?.value) - 1, to = parseInt($('#rlTo')?.value) - 1;
      if (from >= 0 && to >= from && to < App.scenes.length) { p.start = from; p.end = to; Store.set('reel-plan', p).catch(() => {}); }
      const a = await buildAudio(p);
      st.dur = a.dur; st.words = a.words; st.ctaAt = a.ctaAt;
      st.hook = ($('#rlHook').value || p.hook || '').trim(); st.cta = Settings.get().reelCtaText || p.cta;
      setProgress(box, 0.1, 'لقطة مناسبة لكل جملة…');
      st.shots = await gatherShots(a.sceneTimes, f => setProgress(box, 0.1 + f * 0.35, `تجهيز لقطات الريل ${Math.round(f * 100)}%`));
      if (!st.shots.length) throw new Error('لم أجد لقطات للريل. اجلب لقطات الفيديو الأساسي أولاً');
      for (const s of st.shots) if (s.type === 'video') await new Promise(r => { if (s.el.readyState >= 2) r(); else { s.el.oncanplay = r; setTimeout(r, 4000); } });
      try { await document.fonts.load(FONT(100)); await document.fonts.load(CAP(78)); } catch {}
      setProgress(box, 0.5, 'مونتاج الريل وتصديره (9:16)…');
      const cv = Renderer.canvas, ow = cv.width, oh = cv.height; Renderer.size(W, H); playing.clear();
      const blob = await new Promise((res, rej) => {
        Player.start({
          buf: a.buf, scenes: [], record: true, frame,
          prep: f => setProgress(box, 0.5, `تجهيز الصوت ${Math.round(f * 100)}%`),
          tick: t => setProgress(box, 0.5 + 0.5 * t / a.dur, `تصدير الريل ${Math.round(t / a.dur * 100)}%`),
          end: (b, err) => { Renderer.size(ow, oh); b && b.size ? res(b) : rej(new Error('فشل تصدير الريل' + (err?.message ? ': ' + err.message : ''))); },
        }).catch(e => { Renderer.size(ow, oh); rej(e); });
      });
      playing.forEach(s => s.el.pause()); playing.clear();
      new Set(st.shots.map(s => s.el)).forEach(el => URL.revokeObjectURL(el.src));
      resultBox($('#shResult'), blob, `${safeName()}-reel`, 'الريل جاهز');
      toast(`الريل جاهز · ${Math.round(a.dur)} ثانية`);
    } catch (e) { toast(e.message, 'err', 7000); }
    finally { box.hidden = true; st.busy = false; btn.disabled = false; }
  }

  /* ---------- لقطات من Google Flow أو المعرض (اختياري) ---------- */
  async function flowShots() {
    if (!App.scenes.length) return toast('جهّز الفيديو الأساسي أولاً', 'err');
    const p = await ensurePlan(), sc = App.scenes[p.start + st.flow.length] || App.scenes[p.start];
    const subject = sc.kw.filter(w => /^[a-z ]+$/i.test(w)).join(', ') || 'chickens on a farm';
    const prompt = `Cinematic vertical 9:16 video, 8 seconds, photorealistic. ${subject} on a rural Egyptian farm, matching this narration: "${sc.text.slice(0, 160)}". Smooth slow camera push-in, natural golden-hour light, shallow depth of field, vivid but natural colors, 1080x1920, no text, no watermark.`;
    if (!NATIVE) { await copyText(prompt); window.open(Capture.URLS.flow, '_blank'); return toast('نُسخ وصف اللقطة. بعد التنزيل أضفها من «لقطة من المعرض»', '', 7000); }
    if (!(await Capture.prepare())) return;
    Capture.start({ kind: 'video', label: `لقطة ${st.flow.length + 1} من Google Flow`, action: 'reelflow', onFound: async f => addClip(f) });
    await Capture.copyOpen(prompt, 'flow');
    toast('نُسخ وصف اللقطة (فيديو عمودي 9:16). اصنعها في Flow ونزّلها', '', 8000);
  }
  async function addClip(f) { const key = 'reel-flow-' + uid(); await Store.putBlob(key, f); st.flow.push(key); saveFlow(); renderPlan(); toast('أُضيفت اللقطة للريل'); }
  const saveFlow = () => Store.set('reel-flow', st.flow).catch(() => {});
  async function clearFlow() { for (const k of st.flow) await Store.delBlob(k).catch(() => {}); st.flow = []; saveFlow(); renderPlan(); }
  async function addFromGallery() {
    const f = NATIVE ? await pickFromGallery('video').catch(() => null) : await new Promise(r => { const i = document.createElement('input'); i.type = 'file'; i.accept = 'video/*,image/*'; i.onchange = () => r(i.files[0] || null); i.click(); });
    if (f) addClip(f);
  }

  async function enter() {
    try { st.flow = (await Store.get('reel-flow')) || []; } catch {}
    if (App.scenes.length) ensurePlan().catch(() => {}); else renderPlan();
  }
  async function reset() { st.plan = null; await clearFlow(); Store.set('reel-plan', null).catch(() => {}); if ($('#rlHook')) $('#rlHook').value = ''; renderPlan(); }

  function bind() {
    Capture.register('reelflow', f => { if (App.view !== 'publish') go('publish'); addClip(f); });
    $('#btnShort').onclick = make;
    $('#btnReelFlow').onclick = flowShots;
    $('#btnReelGallery').onclick = addFromGallery;
    $('#btnReelFlowClear').onclick = clearFlow;
    $('#btnReelReplan').onclick = async () => { $('#rlHook').value = ''; await ensurePlan(true); toast('اختير مقطع آخر للريل'); };
  }

  return { make, enter, reset, bind, addClip, get plan() { return st.plan; } };
})();
