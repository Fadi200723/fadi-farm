/* Fadi Farm — الريل التشويقي: مقطع كامل الجمل من تعليقك، لقطة مناسبة لكل جملة،
   مونتاج خفيف بانتقالات ناعمة، ترجمة متزامنة، وفي النهاية جملة «الفيديو كامل تحت» بصوتك مع سهم */
'use strict';

window.Reel = null;
const Reel = (() => {
  const W = 1080, H = 1920, COVER_T = 0.066;   // الغلاف إطاران فقط (مثل CapCut): يكفي لاختياره صورة مصغرة ولا يراه المشاهد
  const st = { cover: null, plan: null, flow: [], busy: false, shots: [], words: [], dur: 0, ctaAt: 0, hook: '', cta: '', cur: -1 };
  const FONT = (n, w = 400) => `${w} ${n}px "Lalezar", "IBM Plex Sans Arabic", sans-serif`;
  const CAP = n => `700 ${n}px "IBM Plex Sans Arabic", Tahoma, sans-serif`;
  const ease = x => 1 - Math.pow(1 - Math.min(1, Math.max(0, x)), 3);
  const easeIO = x => { x = Math.min(1, Math.max(0, x)); return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2; };

  /* ---------- الخطة ---------- */
  function fallbackPlan() {
    let acc = 0, b = 0;
    for (let i = 0; i < App.scenes.length; i++) { acc += App.scenes[i].d; b = i; if (acc >= 14) break; }
    return { start: 0, end: b, hook: (App.projName || 'شوف ده').split(/\s+/).slice(0, 4).join(' '), cta: 'الفيديو كامل تحت، ادخل شوفه' };
  }

  function fixRange(p) {
    const { st: starts } = Renderer.timeline(App.scenes);
    const len = () => starts[p.end] + App.scenes[p.end].d - starts[p.start];
    while (len() < 12 && p.end < App.scenes.length - 1) p.end++;
    while (len() > 32 && p.end > p.start) p.end--;
    return p;
  }

  async function ensurePlan(force = false) {
    if (!force) { if (st.plan) return st.plan; try { st.plan = await Store.get('reel-plan'); } catch {} if (st.plan && st.plan.end < App.scenes.length) return renderPlan(), st.plan; }
    st.plan = fixRange(Settings.get().keys.gemini ? await AI.reelPlan(App.scenes).catch(e => { toast('Gemini: ' + e.message + '. استخدمت بداية الفيديو', 'err', 6000); return fallbackPlan(); }) : fallbackPlan());
    Store.set('reel-plan', st.plan).catch(() => {});
    renderPlan();
    return st.plan;
  }

  async function renderPlan() {
    const p = st.plan, box = $('#rlPlan'); if (!box) return;
    if (!p || !App.scenes.length) { box.innerHTML = ''; return; }
    if (!$('#rlHook').value) $('#rlHook').value = p.hook;
    const text = App.scenes.slice(p.start, p.end + 1).map(s => s.text).join(' ');
    const { st: starts } = Renderer.timeline(App.scenes), dur = starts[p.end] + App.scenes[p.end].d - starts[p.start];
    const cta = await Store.getBlob('reel-cta').catch(() => null);
    box.innerHTML = `<p class="small muted">المقطع المختار (${Math.round(dur)} ثانية، المشاهد ${p.start + 1} إلى ${p.end + 1}). يمكنك تغييره:</p>
      <div class="row"><label class="field"><span>من المشهد</span><input id="rlFrom" type="number" min="1" max="${App.scenes.length}" value="${p.start + 1}"></label>
      <label class="field"><span>إلى المشهد</span><input id="rlTo" type="number" min="1" max="${App.scenes.length}" value="${p.end + 1}"></label></div>
      <p class="quote">${esc(text)}</p>
      <p class="small ${cta ? '' : 'muted'}">${cta ? '✓ جملة النهاية بصوتك جاهزة: «' + esc(Settings.get().reelCta || 'الفيديو كامل تحت') + '»' : 'جملة النهاية بالصوت: تُسجَّل كجزء أخير قصير في Google Vids. بدونها تظهر مكتوبة فقط.'}</p>`;
    $('#rlFlowCount').textContent = st.flow.length ? `${st.flow.length} لقطة مضافة` : '';
  }

  /* ---------- الصوت ---------- */
  function mono(buf, a, b) {
    const sr = buf.sampleRate, i0 = Math.max(0, Math.floor(a * sr)), i1 = Math.min(buf.length, Math.floor(b * sr)), o = new Float32Array(Math.max(0, i1 - i0));
    for (let c = 0; c < buf.numberOfChannels; c++) { const d = buf.getChannelData(c); for (let k = i0; k < i1; k++) o[k - i0] += d[k] / buf.numberOfChannels; }
    return o;
  }
  /* أقرب وقفة حقيقية في الكلام حول الزمن t */
  function snap(t, win, prefer = 0) {
    const a = Math.max(0, t - win), d = mono(App.buf, a, Math.min(App.buf.duration, t + win)), ps = findPauses(d, App.buf.sampleRate);
    if (!ps.length) return t;
    ps.sort((x, y) => (Math.abs(x.t + a - t) - x.len * 0.8 - (prefer && Math.sign(x.t + a - t) === prefer ? 0.3 : 0)) - (Math.abs(y.t + a - t) - y.len * 0.8 - (prefer && Math.sign(y.t + a - t) === prefer ? 0.3 : 0)));
    return ps[0].t + a;
  }

  async function buildAudio(p) {
    const { st: starts } = Renderer.timeline(App.scenes);
    let a = starts[p.start], b = starts[p.end] + App.scenes[p.end].d;
    a = p.start === 0 ? 0 : snap(a, 0.9, -1); b = Math.min(App.buf.duration, snap(b, 1.3, 1));
    const sr = App.buf.sampleRate, main = mono(App.buf, a, b);
    const fi = Math.floor(sr * 0.04), fo = Math.floor(sr * 0.12);
    for (let k = 0; k < fi && k < main.length; k++) main[k] *= k / fi;
    for (let k = 0; k < fo && k < main.length; k++) main[main.length - 1 - k] *= k / fo;
    // جملة النهاية بصوتك (من Google Vids)
    let cta = null;
    const ctaOn = Settings.get().reelCtaOn !== false;          // خيار: جملة «الفيديو كامل تحت» في نهاية الريل
    const cb = ctaOn ? await Store.getBlob('reel-cta').catch(() => null) : null;
    if (cb) { try { const cbuf = await Player.audioCtx().decodeAudioData(await cb.arrayBuffer()); cta = mono(cbuf, 0, cbuf.duration); if (cbuf.sampleRate !== sr) cta = resample(cta, cbuf.sampleRate, sr); } catch {} }
    const gap = ctaOn ? Math.floor(sr * 0.35) : 0, ctaLen = !ctaOn ? 0 : cta ? cta.length : Math.floor(sr * 2.4), tail = Math.floor(sr * (ctaOn ? 0.6 : 0.25));
    const out = Player.audioCtx().createBuffer(1, main.length + gap + ctaLen + tail, sr), o = out.getChannelData(0);
    o.set(main, 0); if (cta) o.set(cta, main.length + gap);
    // توقيت الكلمات من الصوت نفسه (فترات الكلام الفعلية)، فتظهر الكتابة مع الكلام بدون تأخير
    const range = App.scenes.slice(p.start, p.end + 1);
    // المزامنة الدقيقة (Whisper) إن وُجدت، وإلا التقدير من الصوت
    const words = Sync.wordsIn(range, a, b) || Align.fromData(main, sr, range.map(sc => sc.text).join(' '));
    // بداية كل مشهد = لحظة نطق أول كلمة فيه
    const sceneTimes = []; let wi = 0;
    range.forEach((sc, k) => {
      const n = sc.text.split(/\s+/).filter(Boolean).length, first = words[wi], last = words[Math.min(words.length - 1, wi + n - 1)];
      sceneTimes.push({ sc, t0: k === 0 ? 0 : (first ? first.t0 - 0.1 : 0), t1: last ? last.t1 : main.length / sr });
      wi += n;
    });
    sceneTimes.forEach((x, k) => { if (sceneTimes[k + 1]) x.t1 = sceneTimes[k + 1].t0; else x.t1 = main.length / sr; });
    return { buf: out, words, dur: out.duration, ctaAt: ctaOn ? (main.length + gap * 0.5) / sr : Infinity, sceneTimes };
  }
  function resample(d, from, to) { const k = from / to, n = Math.floor(d.length / k), r = new Float32Array(n); for (let i = 0; i < n; i++) r[i] = d[Math.min(d.length - 1, Math.round(i * k))]; return r; }

  /* ---------- اللقطات: لقطة مناسبة لكل جملة ---------- */
  const rkind = () => Settings.get().reelKind || 'mix';
  const manual = () => Settings.get().reelManual === true;
  async function gatherShots(sceneTimes, onP) {
    // كل مشهد طويل (> 6 ثوانٍ) يُقسم للقطتين حتى لا يملّ المشاهد
    const slots = [];
    sceneTimes.forEach(x => { const d = x.t1 - x.t0; if (d <= 0.2) return; if (d > 6) { slots.push({ ...x, t1: x.t0 + d / 2 }, { ...x, t0: x.t0 + d / 2, second: true }); } else slots.push(x); });
    const used = new Set(), finder = makeFinder({ orientation: 'portrait', minDim: 720 });
    // لقطات Flow أو المعرض المضافة يدوياً تأخذ أول الأماكن
    for (let i = 0; i < st.flow.length && i < slots.length; i++) { const b = await Store.getBlob(st.flow[i]).catch(() => null); if (b) slots[i].blob = b, slots[i].type = b.type.startsWith('image') ? 'image' : 'video'; }
    // اختيار يدوي: اللقطات تبقى فارغة لتختارها أنت من المعرض
    if (manual()) { for (const s of slots) if (s.blob) s.el = await Media.element(s.blob, s.type).catch(() => null); return slots; }
    const need = slots.filter(s => !s.blob);
    let lists = await Promise.all(need.map(async (s, n) => ({ sc: { id: 'r', text: s.sc.text, kw: s.sc.kw, kind: rkind(), rej: [] }, cands: await finder.candidates({ text: s.sc.text, kw: s.sc.kw, kind: rkind(), rej: [] }, { need: 3, exclude: used, kind: rkind(), idx: n }).catch(() => []) })));
    if (useVision() && lists.length) { try { const ord = await visualCheck(lists); lists = lists.map((l, i) => ({ ...l, cands: ord[i].length ? [...ord[i], ...l.cands.filter(c => !ord[i].includes(c))] : l.cands.slice(0, 0) })); } catch {} }
    let k = 0;
    for (let i = 0; i < need.length; i++) {
      onP?.(k++ / need.length);
      const s = need[i]; s.cands = lists[i]?.cands || []; s.ci = 0;
      for (const it of s.cands.filter(c => !used.has(c.uid)).slice(0, 3)) {
        try { let urls = it.urls; if (it.resolve) urls = [...(await it.resolve()), ...urls]; s.blob = await Media.fetchBlob(urls); s.type = it.type; used.add(it.uid); s.ci = s.cands.indexOf(it); break; } catch {}
      }
      // احتياطي: لقطة نفس المشهد من الفيديو الأساسي (مطابقة للكلام)
      if (!s.blob && s.sc.blobKey) { s.blob = await Store.getBlob(s.sc.blobKey).catch(() => null); s.type = s.sc.asset?.type; s.off = (s.sc.offset || 0) + (s.second ? 3 : 0.5); }
    }
    for (const s of slots) if (s.blob) s.el = await Media.element(s.blob, s.type).catch(() => null);
    // أي فراغ: يأخذ لقطة المكان السابق
    slots.forEach((s, i) => { if (!s.el) { const pv = slots.slice(0, i).reverse().find(x => x.el) || slots.find(x => x.el); if (pv) Object.assign(s, { el: pv.el, type: pv.type, off: (pv.off || 0) + 2 }); } });
    return slots.filter(s => s.el);
  }

  /* ---------- الرسم ---------- */
  function cover(g, el, zoom, panX, panY) {
    const ew = el.videoWidth || el.naturalWidth, eh = el.videoHeight || el.naturalHeight; if (!ew) return false;
    const k = Math.max(W / ew, H / eh) * zoom, dw = ew * k, dh = eh * k;
    g.drawImage(el, (W - dw) / 2 + panX * (dw - W) / 2, (H - dh) / 2 + panY * (dh - H) / 2, dw, dh);
    return true;
  }
  function strokeFill(g, text, x, y, fs, fill, lw = 0.2) { g.lineJoin = 'round'; g.lineWidth = fs * lw; g.strokeStyle = 'rgba(0,0,0,.9)'; g.strokeText(text, x, y); g.fillStyle = fill; g.fillText(text, x, y); }

  const playing = new Set();
  function syncShot(s, local) {
    if (s.type !== 'video' || !s.el) return;
    const rate = Player.rate; if (s.el.playbackRate !== rate) try { s.el.playbackRate = rate; } catch {}
    if (!playing.has(s)) { try { s.el.currentTime = ((s.off || 0.4) + Math.max(0, local)) % Math.max(1, (s.el.duration || 5) - 0.2); } catch {} s.el.play().catch(() => {}); playing.add(s); }
  }
  function stopOthers(keep) { playing.forEach(s => { if (!keep.includes(s)) { s.el.pause(); playing.delete(s); } }); }

  function drawShot(g, s, i, t) {
    if (!s.el) return;
    const d = s.t1 - s.t0, p = (t - s.t0) / Math.max(0.5, d);
    const punch = Channel.cur.montage === 'strong' && t - s.t0 < 0.3 ? 0.1 * Math.pow(1 - (t - s.t0) / 0.3, 2) : 0;
    const zoom = 1.06 + 0.07 * easeIO(p) + punch, dir = i % 2 ? 1 : -1;
    g.save(); g.filter = 'saturate(1.18) contrast(1.06)';
    cover(g, s.el, zoom, dir * (p - 0.5) * 0.25, 0);
    g.restore();
  }

  function frame(t) {
    const g = Renderer.canvas.getContext('2d'), accent = Channel.cur.accent, strongM = Channel.cur.montage === 'strong';
    g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
    const shots = st.shots, end = st.ctaAt;
    // اللقطة الحالية (آخر لقطة تستمر خلف بطاقة النهاية)
    let i = shots.findIndex(s => t < s.t1); if (i < 0) i = shots.length - 1;
    const s = shots[i], nx = shots[i + 1], X = strongM ? 0 : 0.4;
    const keep = [s]; syncShot(s, t - s.t0);
    drawShot(g, s, i, t);
    if (strongM && i > 0 && t - s.t0 < 0.1) { g.fillStyle = `rgba(255,255,255,${0.5 * (1 - (t - s.t0) / 0.1)})`; g.fillRect(0, 0, W, H); }
    if (nx && t > nx.t0 - X && t < end) {                      // انتقال ناعم (تلاشي)
      keep.push(nx); syncShot(nx, t - nx.t0);
      g.save(); g.globalAlpha = easeIO((t - (nx.t0 - X)) / X); drawShot(g, nx, i + 1, t); g.restore();
    }
    stopOthers(keep);
    // الغلاف في أول جزء صغير من الريل (يمكن اختياره صورةً مصغرة في يوتيوب)
    if (st.cover && t < COVER_T) { g.drawImage(st.cover, 0, 0, W, H); return; }
    // تظليل خفيف لقراءة النص
    let gr = g.createLinearGradient(0, H * 0.55, 0, H); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,.55)'); g.fillStyle = gr; g.fillRect(0, H * 0.55, W, H * 0.45);
    gr = g.createLinearGradient(0, 0, 0, H * 0.25); gr.addColorStop(0, 'rgba(0,0,0,.35)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(0, 0, W, H * 0.25);
    g.direction = 'rtl'; g.textAlign = 'center'; g.textBaseline = 'middle';

    // عنوان الخطّاف (بعد الغلاف إن وُجد)
    if (t < 2.8 && st.hook) {
      const a = t < 0.35 ? ease(t / 0.35) : t > 2.4 ? Math.max(0, (2.8 - t) / 0.4) : 1;
      g.save(); g.globalAlpha = a; g.translate(W / 2, H * 0.2 + (1 - a) * -30);
      let fs = 104; g.font = FONT(fs); while (g.measureText(st.hook).width > W * 0.82 && fs > 56) { fs -= 4; g.font = FONT(fs); }
      const w = g.measureText(st.hook).width + 72, h = fs * 1.3;
      g.shadowColor = 'rgba(0,0,0,.45)'; g.shadowBlur = 26; g.fillStyle = accent;
      g.beginPath(); g.roundRect ? g.roundRect(-w / 2, -h / 2, w, h, 26) : g.rect(-w / 2, -h / 2, w, h); g.fill();
      g.shadowColor = 'transparent'; g.fillStyle = accent === '#FFD23F' ? '#111' : '#fff'; g.fillText(st.hook, 0, fs * 0.05);
      g.restore();
    }

    // ترجمة هادئة: حتى 4 كلمات، الكلمة المنطوقة بلون مميز
    if (t < end - 0.1) {
      let wi = st.words.findIndex(w => t < w.t1);
      // أثناء الوقفات: لا تظهر الجملة التالية قبل نطقها
      if (wi >= 0 && t < st.words[wi].t0 - 0.1) wi = wi > 0 && t - st.words[wi - 1].t1 < 0.35 ? wi - 1 : -1;
      if (wi >= 0) {
        const g0 = Math.floor(wi / 4) * 4, grp = st.words.slice(g0, g0 + 4);
        const fs = 78; g.font = CAP(fs);
        const sp = 22, widths = grp.map(w => g.measureText(w.w).width), total = widths.reduce((a, b) => a + b, 0) + sp * (grp.length - 1);
        let x = W / 2 + Math.min(total, W * 0.9) / 2; const y = H * 0.74;
        const groupAge = t - grp[0].t0, ga = Math.min(1, groupAge / 0.18);
        grp.forEach((w, k) => {
          const cx = x - widths[k] / 2, on = g0 + k === wi;
          g.save(); g.globalAlpha = ga; g.translate(cx, y + (1 - ga) * 14);
          strokeFill(g, w.w, 0, 0, fs, on ? accent : '#fff', 0.18);
          g.restore();
          x -= widths[k] + sp;
        });
      }
    }

    // النهاية: «الفيديو كامل تحت» + سهم
    if (t >= end) {
      const q = ease((t - end) / 0.45);
      g.fillStyle = `rgba(0,0,0,${0.5 * q})`; g.fillRect(0, 0, W, H);
      g.save(); g.globalAlpha = q; g.translate(W / 2, H * 0.42 + (1 - q) * 40);
      const lines = splitTwo(st.cta);
      let fs = 104; g.font = FONT(fs); while (Math.max(...lines.map(l => g.measureText(l).width)) > W * 0.86 && fs > 56) { fs -= 4; g.font = FONT(fs); }
      lines.forEach((l, k) => strokeFill(g, l, 0, (k - (lines.length - 1) / 2) * fs * 1.3, fs, k === lines.length - 1 ? accent : '#fff', 0.16));
      g.restore();
      const bob = Math.sin((t - end) * 6) * 22, ax = W / 2, ay = H * 0.6 + bob;
      g.save(); g.globalAlpha = q; g.fillStyle = accent; g.strokeStyle = 'rgba(0,0,0,.85)'; g.lineWidth = 8; g.lineJoin = 'round';
      g.beginPath(); g.moveTo(ax - 26, ay - 110); g.lineTo(ax + 26, ay - 110); g.lineTo(ax + 26, ay); g.lineTo(ax + 72, ay); g.lineTo(ax, ay + 90); g.lineTo(ax - 72, ay); g.lineTo(ax - 26, ay); g.closePath();
      g.stroke(); g.fill(); g.restore();
    }
  }

  function splitTwo(t) { const w = t.split(/\s+/); if (w.length < 4) return [t]; const m = Math.ceil(w.length / 2); return [w.slice(0, m).join(' '), w.slice(m).join(' ')]; }

  /* ---------- الصنع: 1) تجهيز المشاهد للمراجعة  2) التصدير ---------- */
  async function prepare() {
    if (st.busy) return;
    if (!App.buf || !App.scenes.length) return toast('جهّز الفيديو الأساسي أولاً', 'err');
    const box = $('#shProgress'), btn = $('#btnShort'); st.busy = true; btn.disabled = true;
    try {
      setProgress(box, 0.03, 'اختيار أقوى مقطع من تعليقك…');
      const p = await ensurePlan();
      const from = parseInt($('#rlFrom')?.value) - 1, to = parseInt($('#rlTo')?.value) - 1;
      if (from >= 0 && to >= from && to < App.scenes.length) { p.start = from; p.end = to; Store.set('reel-plan', p).catch(() => {}); }
      const a = await buildAudio(p);
      st.audio = a; st.dur = a.dur; st.words = a.words; st.ctaAt = a.ctaAt;
      st.hook = ($('#rlHook').value || p.hook || '').trim(); st.cta = Settings.get().reelCtaText || p.cta;
      setProgress(box, 0.2, 'لقطة مناسبة لكل جملة…');
      st.shots = await gatherShots(a.sceneTimes, f => setProgress(box, 0.2 + f * 0.75, `تجهيز لقطات الريل ${Math.round(f * 100)}%`));
      if (!st.shots.length) throw new Error('لم أجد لقطات للريل. اجلب لقطات الفيديو الأساسي أولاً');
      await renderShots(); saveShots();
      $('#rlShotsBox').hidden = false; $('#rlShotsBox').scrollIntoView({ behavior: 'smooth', block: 'start' });
      toast('راجع لقطات الريل ثم اضغط «صدّر الريل»');
    } catch (e) { toast(e.message, 'err', 7000); }
    finally { box.hidden = true; st.busy = false; btn.disabled = false; }
  }

  const EMPTY = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="180" height="320"><rect width="180" height="320" fill="#1b2230"/><text x="90" y="165" fill="#9ab" font-size="22" text-anchor="middle" font-family="sans-serif">اختر لقطة</text></svg>');
  const shotThumb = async s => {
    if (!s.el) return EMPTY;
    if (s.type !== 'video') return s.el.src;
    try { if (s.el.readyState < 2) await new Promise(r => { s.el.onloadeddata = r; setTimeout(r, 3000); }); s.el.currentTime = Math.min((s.off || 0.5), (s.el.duration || 2) - 0.2); await new Promise(r => { s.el.onseeked = r; setTimeout(r, 1500); }); } catch {}
    const c = document.createElement('canvas'); c.width = 180; c.height = 320; const g = c.getContext('2d');
    const ew = s.el.videoWidth, eh = s.el.videoHeight; if (!ew) return '';
    const k = Math.max(180 / ew, 320 / eh); g.drawImage(s.el, (180 - ew * k) / 2, (320 - eh * k) / 2, ew * k, eh * k);
    return c.toDataURL('image/jpeg', 0.7);
  };
  /* لقطات الريل تُحفظ، فتبقى بعد الخروج من التطبيق ويمكن إعادة التصدير (مثلاً بعد إضافة الغلاف) */
  async function saveShots() {
    if (!st.plan || !st.shots.length) return;
    const meta = [];
    for (let i = 0; i < st.shots.length; i++) {
      const s = st.shots[i], key = 'reel-shot-' + i;
      if (s.blob && s._saved !== s.blob) { await Store.putBlob(key, s.blob).catch(() => {}); s._saved = s.blob; }
      meta.push({ key: s.blob ? key : '', type: s.type, off: s.off || 0, t0: s.t0, t1: s.t1, text: s.sc.text, kw: s.sc.kw || [], second: !!s.second });
    }
    Store.set('reel-shots', { start: st.plan.start, end: st.plan.end, shots: meta }).catch(() => {});
  }
  async function restore() {
    if (st.shots.length && st.audio) return true;
    if (!App.buf || !App.scenes.length) return false;
    const m = await Store.get('reel-shots').catch(() => null); if (!m?.shots?.length) return false;
    const p = await ensurePlan(); if (m.start !== p.start || m.end !== p.end) return false;
    const a = await buildAudio(p);
    st.audio = a; st.dur = a.dur; st.words = a.words; st.ctaAt = a.ctaAt;
    st.hook = ($('#rlHook').value || p.hook || '').trim(); st.cta = Settings.get().reelCtaText || p.cta;
    st.shots = [];
    for (const x of m.shots) {
      const b = x.key ? await Store.getBlob(x.key).catch(() => null) : null;
      st.shots.push({ ...x, sc: { text: x.text, kw: x.kw }, blob: b, _saved: b, el: b ? await Media.element(b, x.type).catch(() => null) : null });
    }
    await renderShots(); $('#rlShotsBox').hidden = false;
    return true;
  }
  /* بعد إضافة الغلاف: يُعاد تصدير الريل تلقائياً بنفس اللقطات */
  async function coverChanged() {
    if (Settings.get().coverInReel === false || st.busy) return;
    const out = await Store.getBlob('reel-out').catch(() => null);
    if (!out && !st.shots.length) { toast('الغلاف جاهز، وسيوضع في أول الريل عند تصديره'); return; }
    if (!(await restore())) { toast('الغلاف جاهز. اضغط «جهّز مشاهد الريل» ثم «صدّر الريل» ليدخل في الريل', 'err', 7000); return; }
    toast('أُضيف الغلاف · يُعاد تصدير الريل بنفس اللقطات…', '', 5000);
    await exportReel();
  }
  async function renderShots() {
    const box = $('#rlShots'); box.innerHTML = '';
    for (let i = 0; i < st.shots.length; i++) {
      const s = st.shots[i], el = document.createElement('div'); el.className = 'rl-shot';
      el.innerHTML = `<img alt="" src="${esc(await shotThumb(s))}"><p>${esc(s.sc.text)}</p>
        <button class="btn ${s.el ? 'ghost' : 'primary'}" data-pick="${i}" type="button">من المعرض</button>${manual() ? '' : `<button class="btn ghost" data-next="${i}" type="button">لقطة أخرى</button>`}`;
      box.appendChild(el);
    }
  }
  async function setShot(i, blob, type) {
    const s = st.shots[i], el = await Media.element(blob, type);
    s.blob = blob; s.type = type; s.el = el; s.off = 0.3;
    const card = $('#rlShots').children[i]; if (card) { card.querySelector('img').src = await shotThumb(s); const b = card.querySelector('[data-pick]'); if (b) b.className = 'btn ghost'; }
    saveShots();
  }
  /* اختيار عدة لقطات من المعرض مرة واحدة: تملأ الأماكن الفارغة بالترتيب */
  async function pickMany() {
    let files = [];
    if (NATIVE) { const f = await pickFromGallery('any').catch(() => null); if (f) files = [f]; }
    else files = await new Promise(r => { const i = document.createElement('input'); i.type = 'file'; i.multiple = true; i.accept = 'video/*,image/*'; i.onchange = () => r([...i.files]); i.click(); });
    let k = 0;
    for (const f of files) {
      let i = st.shots.findIndex(s => !s.el); if (i < 0) i = k % st.shots.length;
      await setShot(i, f, f.type.startsWith('image') ? 'image' : 'video'); k++;
    }
    if (files.length) toast(`أُضيفت ${files.length} لقطة`);
  }
  async function nextShot(i, btn) {
    const s = st.shots[i]; btn.disabled = true; btn.textContent = '…';
    try {
      if (!s.cands?.length) s.cands = await makeFinder({ orientation: 'portrait', minDim: 720 }).candidates({ text: s.sc.text, kw: s.sc.kw, kind: rkind(), rej: [] }, { need: 6, kind: rkind(), idx: i }).catch(() => []);
      for (let k = 1; k <= s.cands.length; k++) {
        const it = s.cands[((s.ci || 0) + k) % s.cands.length];
        try { let urls = it.urls; if (it.resolve) urls = [...(await it.resolve()), ...urls]; const b = await Media.fetchBlob(urls); s.ci = s.cands.indexOf(it); await setShot(i, b, it.type); return; } catch {}
      }
      toast('لا توجد لقطات أخرى لهذه الجملة، اختر من المعرض', 'err');
    } finally { btn.disabled = false; btn.textContent = 'لقطة أخرى'; }
  }

  async function exportReel() {
    if (!st.busy && (!st.shots.length || !st.audio)) await restore().catch(() => false);
    if (st.busy || !st.shots.length || !st.audio) return toast('جهّز مشاهد الريل أولاً', 'err');
    const empty = st.shots.filter(s => !s.el).length;
    if (empty === st.shots.length) return toast('اختر لقطة واحدة على الأقل من المعرض', 'err');
    // الأماكن الفارغة تأخذ اللقطة السابقة
    st.shots.forEach((s, i) => { if (!s.el) { const pv = st.shots.slice(0, i).reverse().find(x => x.el) || st.shots.find(x => x.el); Object.assign(s, { el: pv.el, type: pv.type, blob: pv.blob, off: (pv.off || 0) + 2 }); } });
    if (empty) { renderShots(); saveShots(); toast(`${empty} لقطة فارغة أخذت اللقطة السابقة`); }
    st.cover = Settings.get().coverInReel !== false ? await Cover.compose().catch(() => null) : null;
    const box = $('#shProgress'), btn = $('#btnReelExport'), a = st.audio; st.busy = true; btn.disabled = true;
    try {
      for (const s of st.shots) if (s.type === 'video' && s.el) await new Promise(r => { if (s.el.readyState >= 2) r(); else { s.el.oncanplay = r; setTimeout(r, 4000); } });
      try { await document.fonts.load(FONT(100)); await document.fonts.load(CAP(78)); } catch {}
      st.hook = ($('#rlHook').value || st.plan?.hook || '').trim();
      setProgress(box, 0.02, 'مونتاج الريل وتصديره (9:16)…');
      const cv = Renderer.canvas, ow = cv.width, oh = cv.height; Renderer.size(W, H); playing.clear();
      const blob = await new Promise((res, rej) => {
        Player.start({
          buf: a.buf, scenes: [], record: true, frame, hasVideo: t => st.shots.some(x => x.type === 'video' && t >= x.t0 - 1 && t < x.t1 + 0.5),
          prep: f => setProgress(box, 0.02, `تجهيز الصوت ${Math.round(f * 100)}%`),
          tick: t => setProgress(box, t / a.dur, `تصدير الريل ${Math.round(t / a.dur * 100)}%`),
          end: (b, err) => { Renderer.size(ow, oh); b && b.size ? res(b) : rej(new Error('فشل تصدير الريل' + (err?.message ? ': ' + err.message : ''))); },
        }).catch(e => { Renderer.size(ow, oh); rej(e); });
      });
      playing.forEach(s => { s.el.pause(); try { s.el.playbackRate = 1; } catch {} }); playing.clear();
      await Store.putBlob('reel-out', blob).catch(() => {});
      showReel(blob);
      toast(`الريل جاهز · ${Math.round(a.dur)} ثانية. اضغط «حفظ في المعرض» لتنزيله`);
    } catch (e) { toast(e.message, 'err', 7000); }
    finally { box.hidden = true; st.busy = false; btn.disabled = false; }
  }
  const showReel = blob => resultBox($('#shResult'), blob, `${safeName()}-reel`, 'الريل جاهز', { auto: false });
  const make = prepare;

  /* ---------- لقطات من Google Flow أو المعرض (اختياري) ---------- */
  async function flowShots() {
    if (!App.scenes.length) return toast('جهّز الفيديو الأساسي أولاً', 'err');
    const p = await ensurePlan(), sc = App.scenes[p.start + st.flow.length] || App.scenes[p.start];
    const subject = sc.kw.filter(w => /^[a-z ]+$/i.test(w)).join(', ') || 'chickens on a farm';
    const prompt = `Cinematic vertical 9:16 video, 8 seconds, photorealistic. ${subject}, ${Channel.cur.setting}, matching this narration: "${sc.text.slice(0, 160)}". Smooth slow camera push-in, natural golden-hour light, shallow depth of field, vivid but natural colors, 1080x1920, no text, no watermark.`;
    if (!(await Capture.prepare())) return;
    Capture.start({ kind: 'video', label: `لقطة ${st.flow.length + 1} من Google Flow`, action: 'reelflow', onFound: async f => addClip(f) });
    await Capture.copyOpen(prompt, 'flow');
    toast('نُسخ وصف اللقطة (فيديو عمودي 9:16). اصنعها في Flow ونزّلها', '', 8000);
  }
  async function addClip(f) { const key = 'reel-flow-' + uid(); await Store.putBlob(key, f); st.flow.push(key); saveFlow(); renderPlan(); toast('أُضيفت اللقطة للريل'); }
  const saveFlow = () => Store.set('reel-flow', st.flow).catch(() => {});
  async function clearFlow() { for (const k of st.flow) await Store.delBlob(k).catch(() => {}); st.flow = []; saveFlow(); renderPlan(); }
  async function addFromGallery() {
    const f = NATIVE ? await pickFromGallery('any').catch(() => null) : await new Promise(r => { const i = document.createElement('input'); i.type = 'file'; i.accept = 'video/*,image/*'; i.onchange = () => r(i.files[0] || null); i.click(); });
    if (f) addClip(f);
  }

  async function enter() {
    try { st.flow = (await Store.get('reel-flow')) || []; } catch {}
    // الريل المصدَّر سابقاً يبقى حتى بعد الخروج من التطبيق
    if ($('#shResult').hidden) { try { const b = await Store.getBlob('reel-out'); if (b && b.size) showReel(b); } catch {} }
    if (App.scenes.length) ensurePlan().then(() => { if (!st.shots.length) restore().catch(() => {}); }).catch(() => {}); else renderPlan();
  }
  async function reset() { Store.set('reel-shots', null).catch(() => {}); st.plan = null; st.shots = []; st.audio = null; $('#rlShotsBox').hidden = true; $('#shResult').hidden = true; Store.delBlob('reel-out').catch(() => {}); await clearFlow(); Store.set('reel-plan', null).catch(() => {}); if ($('#rlHook')) $('#rlHook').value = ''; renderPlan(); }

  function bind() {
    Capture.register('reelflow', f => { if (App.view !== 'publish') go('publish'); addClip(f); });
    $('#btnShort').onclick = prepare;
    $('#btnReelExport').onclick = exportReel;
    $('#rlShots').onclick = async e => {
      const n = e.target.closest('[data-next]'), pk = e.target.closest('[data-pick]');
      if (n) nextShot(+n.dataset.next, n);
      if (pk) {
        const f = NATIVE ? await pickFromGallery('any').catch(() => null) : await new Promise(r => { const i = document.createElement('input'); i.type = 'file'; i.accept = 'video/*,image/*'; i.onchange = () => r(i.files[0] || null); i.click(); });
        if (f) setShot(+pk.dataset.pick, f, f.type.startsWith('image') ? 'image' : 'video');
      }
    };
    $('#btnReelFlow').onclick = flowShots;
    $('#rlPickMany').onclick = pickMany;
    const setKind = v => { Settings.set({ reelKind: v }); $$('#rlKind button').forEach(b => b.classList.toggle('on', b.dataset.v === v)); };
    setKind(rkind());
    $('#rlKind').onclick = e => { const b = e.target.closest('[data-v]'); if (b) setKind(b.dataset.v); };
    $('#rlCtaOn').checked = Settings.get().reelCtaOn !== false;
    $('#rlCtaOn').onchange = e => { Settings.set({ reelCtaOn: e.target.checked }); toast(e.target.checked ? 'الريل ينتهي بجملة «الفيديو كامل تحت»' : 'الريل بدون جملة النهاية. صدّره من جديد'); };
    $('#rlManual').checked = manual();
    $('#rlManual').onchange = e => { Settings.set({ reelManual: e.target.checked }); toast(e.target.checked ? 'اضغط «جهّز مشاهد الريل» ثم اختر لقطة لكل جملة من معرضك' : 'التطبيق يقترح لقطات الريل'); };
    $('#btnReelGallery').onclick = addFromGallery;
    $('#btnReelFlowClear').onclick = clearFlow;
    $('#btnReelReplan').onclick = async () => { $('#rlHook').value = ''; await ensurePlan(true); toast('اختير مقطع آخر للريل'); };
  }

  return { make, enter, reset, bind, addClip, coverChanged, exportReel, get plan() { return st.plan; } };
})();
