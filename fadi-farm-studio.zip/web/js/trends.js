/* Fadi — ترندات قناة مجرى: مواضيع جديدة من Google Trends وGoogle News وويكيبيديا وReddit،
   ثم كتابة سكريبت جاهز بالعربية بـ Gemini */
'use strict';

const Trends = (() => {
  const REG = {
    dz: { label: 'الجزائر', trends: ['DZ'], news: 'https://news.google.com/rss?hl=ar&gl=DZ&ceid=DZ:ar' },
    arab: { label: 'العالم العربي', trends: ['SA', 'EG', 'MA', 'AE'], news: 'https://news.google.com/rss?hl=ar&gl=EG&ceid=EG:ar' },
    world: { label: 'العالم', trends: ['US', 'FR', 'GB'], news: 'https://news.google.com/rss/headlines/section/topic/WORLD?hl=ar&gl=DZ&ceid=DZ:ar' },
    sport: { label: 'رياضة', trends: [], news: 'https://news.google.com/rss/headlines/section/topic/SPORTS?hl=ar&gl=DZ&ceid=DZ:ar' },
    tech: { label: 'تقنية', trends: [], news: 'https://news.google.com/rss/headlines/section/topic/TECHNOLOGY?hl=ar&gl=DZ&ceid=DZ:ar' },
  };
  const FLAG = { DZ: '🇩🇿', SA: '🇸🇦', EG: '🇪🇬', MA: '🇲🇦', AE: '🇦🇪', US: '🇺🇸', FR: '🇫🇷', GB: '🇬🇧' };
  const st = { reg: 'dz', items: [], busy: false };

  async function openLink(url) {
    if (NATIVE) { try { await capCall('FadiNative', 'open', { url, newTab: true }); return; } catch {} }
    window.open(url, '_blank', 'noopener');
  }
  /* معرّف ثابت لكل رابط (نفس الدالة في سكربت النسخ على GitHub) */
  const fid = u => { let h = 5381; for (let i = 0; i < u.length; i++) h = ((h * 33) ^ u.charCodeAt(i)) >>> 0; return h.toString(16); };
  async function getText(url) {
    if (NATIVE) {
      try { const r = await capCall('FadiNative', 'fetchText', { url }); if (r && r.status < 400) return r.data; } catch {}
    }
    // الآيفون والحاسوب: نسخة محدّثة كل ساعة على نفس موقع التطبيق (GitHub) لتجاوز قيود المتصفح
    try { const m = await fetch(`data/feeds/${fid(url)}.txt`, { cache: 'no-cache' }); if (m.ok) { const t = await m.text(); if (t.length > 50) return t; } } catch {}
    const r = await fetch(url); if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.text();
  }
  const xml = t => new DOMParser().parseFromString(t, 'text/xml');
  const tx = (el, sel) => el.getElementsByTagName(sel)[0]?.textContent?.trim() || '';
  const clean = s => String(s).replace(/<[^>]+>/g, ' ').replace(/&nbsp;|&amp;/g, ' ').replace(/\s+/g, ' ').trim();

  async function googleTrends(geo) {
    const d = xml(await getText(`https://trends.google.com/trending/rss?geo=${geo}`));
    return [...d.getElementsByTagName('item')].slice(0, 12).map(it => ({
      src: 'Google Trends ' + (FLAG[geo] || geo), title: tx(it, 'title'), traffic: tx(it, 'ht:approx_traffic'),
      pic: tx(it, 'ht:picture'), date: tx(it, 'pubDate'),
      news: [...it.getElementsByTagName('ht:news_item')].slice(0, 3).map(n => ({ t: clean(tx(n, 'ht:news_item_title')), u: tx(n, 'ht:news_item_url'), s: tx(n, 'ht:news_item_source') })),
    }));
  }
  async function googleNews(url) {
    const d = xml(await getText(url));
    return [...d.getElementsByTagName('item')].slice(0, 15).map(it => {
      const t = tx(it, 'title'), s = tx(it, 'source');
      return { src: 'Google News', title: s ? t.replace(new RegExp('\\s*-\\s*' + s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '$'), '') : t, traffic: '', pic: '', date: tx(it, 'pubDate'), news: [{ t, u: tx(it, 'link'), s }] };
    });
  }
  async function wikiMostRead() {
    const dt = new Date(Date.now() - 864e5), p = n => String(n).padStart(2, '0');
    const j = JSON.parse(await getText(`https://ar.wikipedia.org/api/rest_v1/feed/featured/${dt.getUTCFullYear()}/${p(dt.getUTCMonth() + 1)}/${p(dt.getUTCDate())}`));
    return (j.mostread?.articles || []).filter(a => !/^(الصفحة_الرئيسية|خاص:)/.test(a.title)).slice(0, 8).map(a => ({
      src: 'ويكيبيديا (الأكثر قراءة)', title: a.normalizedtitle || a.title, traffic: a.views ? a.views.toLocaleString('ar') + ' قراءة' : '', pic: a.thumbnail?.source || '', date: '',
      news: [{ t: clean(a.extract || '').slice(0, 200), u: a.content_urls?.mobile?.page || '', s: 'Wikipedia' }],
    }));
  }
  async function reddit(sub) {
    const j = JSON.parse(await getText(`https://www.reddit.com/r/${sub}/hot.json?limit=10`));
    return (j.data?.children || []).filter(c => !c.data.stickied).slice(0, 6).map(c => ({ src: 'Reddit r/' + sub, title: c.data.title, traffic: (c.data.ups || 0) + ' تفاعل', pic: '', date: '', news: [{ t: c.data.title, u: 'https://www.reddit.com' + c.data.permalink, s: 'Reddit' }] }));
  }

  async function load() {
    if (st.busy) return; st.busy = true;
    const R = REG[st.reg], box = $('#trList');
    box.innerHTML = '<p class="hint">جاري جلب الترندات…</p>';
    const jobs = [...R.trends.map(g => googleTrends(g)), googleNews(R.news)];
    if (st.reg === 'dz') { jobs.push(wikiMostRead(), reddit('algeria')); }
    if (st.reg === 'world') jobs.push(reddit('worldnews'));
    const res = await Promise.allSettled(jobs);
    const seen = new Set(), out = [];
    res.forEach(r => r.status === 'fulfilled' && r.value.forEach(it => { const k = it.title.toLowerCase().slice(0, 40); if (it.title && !seen.has(k)) { seen.add(k); out.push(it); } }));
    st.items = out.slice(0, 60); st.busy = false;
    persist();
    render();
    ideas();
    if (!out.length) box.innerHTML = `<p class="hint">تعذّر جلب الترندات (${NATIVE ? 'تحقق من الإنترنت' : 'في المتصفح بعض المصادر محجوبة، تعمل كاملة داخل التطبيق'}).</p>`;
  }

  const persist = () => { try { localStorage.setItem(Channel.key('ff.trends'), JSON.stringify({ reg: st.reg, at: Date.now(), items: st.items })); } catch {} };
  /* فكرة الموضوع بالعربية في سطر واحد (بدل العناوين الأجنبية والمقالات) */
  async function ideas() {
    const todo = st.items.map((it, i) => ({ it, i })).filter(x => !x.it.idea);
    if (!todo.length || typeof LLM === 'undefined' || !LLM.available().length) return;
    try {
      for (let k = 0; k < todo.length; k += 30) {
        const part = todo.slice(k, k + 30);
        const r = await AI.call([{ text: `For each trending topic below, write in Arabic (simple, clear) the core idea of the story for a YouTube video: "idea" = one short headline-like sentence (max 12 words) that explains what the topic is about, translated to Arabic if needed. No source names, no URLs.
Return JSON: {"items":[{"i":0,"idea":""}]}
${part.map(x => `${x.i}: ${x.it.title} | ${x.it.news.map(n => n.t).filter(Boolean).slice(0, 2).join(' / ')}`).join('\n')}` }]);
        (r.items || []).forEach(o => { const it = st.items[+o.i]; if (it && o.idea) it.idea = String(o.idea).trim(); });
        persist(); render();
      }
    } catch {}
  }

  function render() {
    const box = $('#trList'); box.innerHTML = '';
    st.items.forEach((it, i) => {
      const el = document.createElement('div'); el.className = 'trend';
      el.innerHTML = `${it.pic ? `<img src="${esc(it.pic)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : '<span class="trend-dot"></span>'}
        <div class="trend-body"><b>${esc(it.idea || it.title)}</b><small>${it.idea ? esc(it.title) + ' · ' : ''}${it.traffic ? esc(it.traffic) : ''}</small></div>
        <div class="trend-act"><button class="btn primary sm" data-w="${i}" type="button">اكتب السكريبت</button></div>`;
      box.appendChild(el);
    });
  }

  function write(i) {
    const it = st.items[i]; if (!it) return;
    const details = [`Trending source: ${it.src}${it.traffic ? ' (' + it.traffic + ')' : ''}`, ...it.news.map(n => `- ${n.t}${n.s ? ' (' + n.s + ')' : ''}`)].join('\n');
    Script.open({ topic: it.idea || it.title, details: `Original trending title: ${it.title}\n` + details, search: true });
  }

  function enter() {
    const p = $('#trendsPanel'); if (!p) return;
    p.hidden = !Channel.cur.trends;
    if (p.hidden) return;
    if (!st.items.length) {
      try { const c = JSON.parse(localStorage.getItem(Channel.key('ff.trends')) || 'null'); if (c?.items?.length) { st.reg = c.reg; st.items = c.items; } } catch {}   // تبقى حتى تضغط «تحديث»
      $$('#trReg button').forEach(b => b.classList.toggle('on', b.dataset.r === st.reg));
      if (st.items.length) { render(); ideas(); } else load();
    }
  }

  function bind() {
    const seg = $('#trReg'); if (!seg) return;
    seg.innerHTML = Object.entries(REG).map(([k, v]) => `<button type="button" data-r="${k}"${k === st.reg ? ' class="on"' : ''}>${v.label}</button>`).join('');
    seg.onclick = e => { const b = e.target.closest('[data-r]'); if (!b) return; st.reg = b.dataset.r; $$('#trReg button').forEach(x => x.classList.toggle('on', x === b)); st.items = []; load(); };
    $('#trRefresh').onclick = () => { st.items = []; load(); };
    $('#trList').onclick = e => {
      const w = e.target.closest('[data-w]'), o = e.target.closest('[data-o]');
      if (w) write(+w.dataset.w);
      if (o) openLink(st.items[+o.dataset.o].news[0].u);
    };
    $('#trOwn').onclick = () => { const t = $('#trTopic').value.trim(); if (!t) return toast('اكتب الموضوع أولاً', 'err'); Script.open({ topic: t, search: true }); };
  }
  const FEEDS = () => [...new Set(Object.values(REG).flatMap(r => [...r.trends.map(g => `https://trends.google.com/trending/rss?geo=${g}`), r.news]).concat(['https://www.reddit.com/r/algeria/hot.json?limit=10', 'https://www.reddit.com/r/worldnews/hot.json?limit=10']))];
  return { enter, bind, load, fid, FEEDS };
})();
