/* Fadi Farm — مصادر الصور والفيديو.
   كل مزوّد يُرجع عناصر بشكل موحّد:
   { uid, provider, type:'video'|'image', title, thumb, urls:[...], resolve?:async()=>urls,
     width, height, duration, creator, creatorUrl, license, licenseUrl, pageUrl, onUse?:fn } */
'use strict';

class ProviderError extends Error {
  constructor(msg, code) { super(msg); this.code = code; }
}

/* يحوّل رد الهاتف/الحاسوب إلى شكل Response مبسّط */
const fakeRes = (status, text) => ({ status, ok: status >= 200 && status < 300, json: async () => JSON.parse(text) });
async function getJSON(url, opts = {}, label = '') {
  let r;
  try { r = await fetch(url, opts); }
  catch {
    // المتصفح منع الاتصال (CORS): في تطبيق أندرويد والحاسوب نطلبه من الجهاز مباشرة
    try {
      if (typeof NATIVE !== 'undefined' && NATIVE) { const x = await Http.request(url, { headers: opts.headers || {}, timeout: 15000 }); r = fakeRes(x.status, x.data); }
      else if (window.fadiDesktop?.get) { const x = await window.fadiDesktop.get(url, opts.headers || {}); if (x.status) r = fakeRes(x.status, x.data); }
    } catch {}
    if (!r) throw new ProviderError(`${label}: تعذّر الاتصال (تحقق من الإنترنت)`, 'net');
  }
  if ((r.status === 401 || r.status === 403) && !opts.keyless) throw new ProviderError(`${label}: المفتاح غير صالح أو غير مفعّل`, 'key');
  if (r.status === 401 || r.status === 403) throw new ProviderError(`${label}: الخادم رفض الطلب مؤقتاً (${r.status})، جرّب لاحقاً`, 'http');
  if (r.status === 429) throw new ProviderError(`${label}: تجاوزت حدّ الطلبات، انتظر قليلاً`, 'rate');
  if (!r.ok) throw new ProviderError(`${label}: خطأ من الخادم (${r.status})`, 'http');
  try { return await r.json(); } catch { throw new ProviderError(`${label}: ردّ غير مفهوم`, 'parse'); }
}

let metDown = 0;
const qs = o => Object.entries(o).filter(([, v]) => v !== undefined && v !== '').map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&');
const stripHtml = h => (h || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
const https = u => (u || '').replace(/^http:\/\//, 'https://');

/* orientation: 'landscape' | 'portrait' | 'square' ; minDim: البعد الأصغر المطلوب للتصدير */

const PROVIDERS = {
  pexels: {
    name: 'Pexels', needsKey: true, kinds: ['video', 'image'],
    keyUrl: 'https://www.pexels.com/api/new/',
    note: 'فيديوهات وصور عالية الجودة، ترخيص Pexels يسمح بالاستخدام التجاري.',
    async search(q, kind, { key, orientation, minDim }) {
      const h = { headers: { Authorization: key } };
      if (kind === 'video') {
        const d = await getJSON(`https://api.pexels.com/videos/search?${qs({ query: q, per_page: 20, orientation, size: minDim >= 1000 ? 'medium' : undefined })}`, h, 'Pexels');
        return (d.videos || []).map(v => {
          const files = (v.video_files || []).filter(f => f.link && /mp4/.test(f.file_type || 'mp4'))
            .sort((a, b) => Math.min(a.width, a.height) - Math.min(b.width, b.height));
          const fit = files.filter(f => Math.min(f.width, f.height) >= minDim * 0.9);
          const ordered = [...fit, ...files.filter(f => !fit.includes(f)).reverse()].map(f => f.link);
          return {
            uid: 'pexels-v' + v.id, provider: 'pexels', type: 'video', title: (v.url || '').split('/').filter(Boolean).pop()?.replace(/-\d+$/, '').replace(/-/g, ' ') || 'Pexels',
            thumb: v.image, urls: ordered, width: v.width, height: v.height, duration: v.duration,
            creator: v.user?.name || '', creatorUrl: v.user?.url || '', license: 'Pexels License', licenseUrl: 'https://www.pexels.com/license/', pageUrl: v.url,
          };
        });
      }
      const d = await getJSON(`https://api.pexels.com/v1/search?${qs({ query: q, per_page: 24, orientation })}`, h, 'Pexels');
      return (d.photos || []).map(p => ({
        uid: 'pexels-i' + p.id, provider: 'pexels', type: 'image', title: p.alt || 'Pexels',
        thumb: p.src?.medium, urls: [p.src?.large2x, p.src?.original].filter(Boolean), width: p.width, height: p.height,
        creator: p.photographer, creatorUrl: p.photographer_url, license: 'Pexels License', licenseUrl: 'https://www.pexels.com/license/', pageUrl: p.url,
      }));
    },
  },

  pixabay: {
    name: 'Pixabay', needsKey: true, kinds: ['video', 'image'],
    keyUrl: 'https://pixabay.com/api/docs/',
    note: 'مكتبة كبيرة من الفيديو والصور، ترخيص Pixabay يسمح بالاستخدام التجاري.',
    async search(q, kind, { key, orientation, minDim }) {
      const base = { key, q: q.slice(0, 100), per_page: 24, safesearch: 'true' };
      if (kind === 'video') {
        const d = await getJSON(`https://pixabay.com/api/videos/?${qs(base)}`, {}, 'Pixabay');
        return (d.hits || []).map(v => {
          const sizes = ['tiny', 'small', 'medium', 'large'].map(k => v.videos?.[k]).filter(x => x && x.url);
          const fit = sizes.filter(x => Math.min(x.width, x.height) >= minDim * 0.9);
          const ordered = [...fit, ...sizes.filter(x => !fit.includes(x)).reverse()];
          const big = sizes[sizes.length - 1] || {};
          return {
            uid: 'pixabay-v' + v.id, provider: 'pixabay', type: 'video', title: v.tags || 'Pixabay',
            thumb: v.videos?.small?.thumbnail || v.videos?.tiny?.thumbnail || v.videos?.medium?.thumbnail,
            urls: ordered.map(x => x.url), width: big.width, height: big.height, duration: v.duration,
            creator: v.user || '', creatorUrl: v.user_id ? `https://pixabay.com/users/${v.user}-${v.user_id}/` : '',
            license: 'Pixabay Content License', licenseUrl: 'https://pixabay.com/service/license-summary/', pageUrl: v.pageURL,
          };
        });
      }
      const o = { landscape: 'horizontal', portrait: 'vertical' }[orientation];
      const d = await getJSON(`https://pixabay.com/api/?${qs({ ...base, image_type: 'photo', orientation: o })}`, {}, 'Pixabay');
      return (d.hits || []).map(p => ({
        uid: 'pixabay-i' + p.id, provider: 'pixabay', type: 'image', title: p.tags || 'Pixabay',
        thumb: p.webformatURL, urls: [p.largeImageURL, p.webformatURL].filter(Boolean), width: p.imageWidth, height: p.imageHeight,
        creator: p.user, creatorUrl: `https://pixabay.com/users/${p.user}-${p.user_id}/`,
        license: 'Pixabay Content License', licenseUrl: 'https://pixabay.com/service/license-summary/', pageUrl: p.pageURL,
      }));
    },
  },

  wikimedia: {
    name: 'Wikimedia Commons', needsKey: false, kinds: ['video', 'image'],
    keyUrl: '',
    note: 'محتوى حرّ بتراخيص Creative Commons أو ملكية عامة. يجب ذكر المؤلف حسب الترخيص.',
    async search(q, kind) {
      const filter = kind === 'video' ? 'filemime:video/webm' : 'filetype:bitmap';
      const d = await getJSON(`https://commons.wikimedia.org/w/api.php?${qs({
        action: 'query', format: 'json', origin: '*', generator: 'search', gsrsearch: `${q} ${filter}`, gsrnamespace: 6, gsrlimit: 24,
        prop: 'imageinfo', iiprop: 'url|size|mime|extmetadata', iiurlwidth: 480,
        iiextmetadatafilter: 'LicenseShortName|LicenseUrl|Artist|ObjectName',
      })}`, {}, 'Wikimedia');
      const pages = Object.values(d.query?.pages || {}).sort((a, b) => (a.index || 0) - (b.index || 0));
      return pages.map(p => {
        const ii = p.imageinfo?.[0]; if (!ii) return null;
        const m = ii.extmetadata || {};
        const isVid = /^video\//.test(ii.mime || '');
        if (kind === 'video' && !isVid) return null;
        let urls;
        if (isVid) {
          const tr = ii.url.replace('/wikipedia/commons/', '/wikipedia/commons/transcoded/');
          const name = ii.url.split('/').pop();
          urls = [`${tr}/${name}.720p.vp9.webm`, `${tr}/${name}.480p.vp9.webm`, ii.url];
        } else {
          urls = ii.width > 2000 && ii.thumburl ? [ii.thumburl.replace(/\/\d+px-/, '/1920px-'), ii.url] : [ii.url];
        }
        return {
          uid: 'wiki-' + p.pageid, provider: 'wikimedia', type: isVid ? 'video' : 'image',
          title: stripHtml(m.ObjectName?.value) || p.title.replace(/^File:/, '').replace(/\.[a-z0-9]+$/i, ''),
          thumb: ii.thumburl || ii.url, urls, width: ii.width, height: ii.height,
          creator: stripHtml(m.Artist?.value), creatorUrl: '', license: stripHtml(m.LicenseShortName?.value) || 'راجع صفحة الملف',
          licenseUrl: m.LicenseUrl?.value || '', pageUrl: ii.descriptionurl,
        };
      }).filter(Boolean);
    },
  },

  nasa: {
    name: 'NASA Image & Video Library', needsKey: false, kinds: ['video', 'image'],
    keyUrl: '',
    note: 'مواد NASA غالباً غير محمية بحقوق النشر، مع منع استخدام شعار NASA للإيحاء بالرعاية.',
    async search(q, kind) {
      const d = await getJSON(`https://images-api.nasa.gov/search?${qs({ q, media_type: kind, page_size: 24 })}`, {}, 'NASA');
      return (d.collection?.items || []).map(it => {
        const m = it.data?.[0] || {};
        return {
          uid: 'nasa-' + m.nasa_id, provider: 'nasa', type: kind, title: m.title || m.nasa_id,
          thumb: https(it.links?.[0]?.href || ''), urls: [],
          async resolve() {
            const list = (await getJSON(https(it.href), {}, 'NASA')).map(https);
            const pref = kind === 'video' ? ['~medium.mp4', '~mobile.mp4', '~large.mp4', '~orig.mp4', '.mp4'] : ['~large.jpg', '~medium.jpg', '~orig.jpg', '.jpg', '.png'];
            const out = [];
            pref.forEach(s => list.forEach(u => { if (u.toLowerCase().endsWith(s) && !out.includes(u)) out.push(u); }));
            return out;
          },
          creator: m.photographer || m.secondary_creator || m.center || 'NASA', creatorUrl: '',
          license: 'NASA Media Usage Guidelines', licenseUrl: 'https://www.nasa.gov/nasa-brand-center/images-and-media/',
          pageUrl: `https://images.nasa.gov/details/${encodeURIComponent(m.nasa_id)}`,
        };
      });
    },
  },

  archive: {
    name: 'Internet Archive', needsKey: false, kinds: ['video', 'image'],
    keyUrl: '',
    note: 'أرشيف ضخم من الأفلام القديمة والملكية العامة. التراخيص تختلف من ملف لآخر، راجع الصفحة.',
    async search(q, kind) {
      const mt = kind === 'video' ? 'movies' : 'image';
      const url = `https://archive.org/advancedsearch.php?${qs({ q: `(${q}) AND mediatype:(${mt})`, rows: 24, output: 'json', 'sort[]': 'downloads desc' })}&fl[]=identifier&fl[]=title&fl[]=creator&fl[]=licenseurl&fl[]=subject`;
      const d = await getJSON(url, {}, 'Internet Archive');
      return (d.response?.docs || []).map(doc => {
        const id = doc.identifier;
        const lic = doc.licenseurl || '';
        return {
          uid: 'ia-' + id, provider: 'archive', type: kind, title: [].concat(doc.title || id)[0], tags: [].concat(doc.subject || []).join(' '),
          thumb: `https://archive.org/services/img/${encodeURIComponent(id)}`, urls: [],
          async resolve() {
            const meta = await getJSON(`https://archive.org/metadata/${encodeURIComponent(id)}`, {}, 'Internet Archive');
            const files = meta.files || [];
            let pick;
            if (kind === 'video') {
              const mp4 = files.filter(f => /\.mp4$/i.test(f.name));
              pick = [...mp4.filter(f => /h\.264/i.test(f.format || '')), ...mp4.filter(f => !/h\.264/i.test(f.format || '')).sort((a, b) => (+a.size || 0) - (+b.size || 0))];
            } else {
              pick = files.filter(f => /\.(jpe?g|png)$/i.test(f.name) && !/thumb/i.test(f.name) && (+f.size || 0) < 15e6).sort((a, b) => (+b.size || 0) - (+a.size || 0));
            }
            return pick.slice(0, 3).map(f => `https://archive.org/download/${encodeURIComponent(id)}/${f.name.split('/').map(encodeURIComponent).join('/')}`);
          },
          creator: [].concat(doc.creator || '')[0], creatorUrl: '',
          license: lic ? (/publicdomain/.test(lic) ? 'Public Domain' : lic.replace(/^https?:\/\/creativecommons\.org\/licenses\//, 'CC ').replace(/\/$/, '')) : 'غير محدد، راجع الصفحة',
          licenseUrl: lic, pageUrl: `https://archive.org/details/${encodeURIComponent(id)}`,
        };
      });
    },
  },

  openverse: {
    name: 'Openverse', needsKey: false, kinds: ['image'],
    keyUrl: '',
    note: 'محرّك بحث في ملايين الصور بتراخيص مفتوحة (Flickr وغيرها). يُعرض فقط ما يسمح بالاستخدام التجاري.',
    async search(q, kind, { orientation }) {
      const ar = { landscape: 'wide', portrait: 'tall', square: 'square' }[orientation];
      // بدون مفتاح: Openverse يسمح بـ 20 نتيجة كحد أقصى في الطلب
      const d = await getJSON(`https://api.openverse.org/v1/images/?${qs({ q, page_size: 20, license_type: 'commercial', aspect_ratio: ar, mature: 'false' })}`, { keyless: true }, 'Openverse');
      return (d.results || []).map(r => ({
        uid: 'ov-' + r.id, provider: 'openverse', type: 'image', title: r.title || 'Openverse', tags: (r.tags || []).map(t => t.name).join(' '),
        thumb: r.thumbnail, urls: [r.url, r.thumbnail].filter(Boolean), width: r.width, height: r.height,
        creator: r.creator || '', creatorUrl: r.creator_url || '',
        license: r.license === 'cc0' ? 'CC0' : r.license === 'pdm' ? 'Public Domain Mark' : `CC ${String(r.license).toUpperCase()} ${r.license_version || ''}`.trim(),
        licenseUrl: r.license_url || '', pageUrl: r.foreign_landing_url || '',
      }));
    },
  },

  unsplash: {
    name: 'Unsplash', needsKey: true, kinds: ['image'],
    keyUrl: 'https://unsplash.com/oauth/applications',
    note: 'صور فوتوغرافية احترافية. استخدم Access Key. يُطلب ذكر المصوّر.',
    async search(q, kind, { key, orientation }) {
      const o = { landscape: 'landscape', portrait: 'portrait', square: 'squarish' }[orientation];
      const d = await getJSON(`https://api.unsplash.com/search/photos?${qs({ query: q, per_page: 24, orientation: o, content_filter: 'high' })}`, { headers: { Authorization: `Client-ID ${key}`, 'Accept-Version': 'v1' } }, 'Unsplash');
      return (d.results || []).map(p => ({
        uid: 'us-' + p.id, provider: 'unsplash', type: 'image', title: p.alt_description || p.description || 'Unsplash', tags: (p.tags || []).map(t => t.title).join(' '),
        thumb: p.urls?.small, urls: [p.urls?.raw ? `${p.urls.raw}&w=1920&q=85&fm=jpg` : p.urls?.regular, p.urls?.regular].filter(Boolean),
        width: p.width, height: p.height, creator: p.user?.name, creatorUrl: p.user?.links?.html ? `${p.user.links.html}?utm_source=fadi_farm&utm_medium=referral` : '',
        license: 'Unsplash License', licenseUrl: 'https://unsplash.com/license', pageUrl: p.links?.html,
        onUse() { if (p.links?.download_location) fetch(p.links.download_location, { headers: { Authorization: `Client-ID ${key}` } }).catch(() => {}); },
      }));
    },
  },

  inaturalist: {
    name: 'iNaturalist', needsKey: false, kinds: ['image'],
    keyUrl: '',
    note: 'ملايين الصور الحقيقية للحيوانات والطيور بأنواعها، بتراخيص Creative Commons. ممتاز للدجاج والبط والرومي.',
    async search(q) {
      const d = await getJSON(`https://api.inaturalist.org/v1/observations?${qs({ q, photos: 'true', photo_license: 'cc0,cc-by,cc-by-sa', per_page: 30, order_by: 'votes', locale: 'en' })}`, {}, 'iNaturalist');
      const out = [];
      (d.results || []).forEach(o => (o.photos || []).slice(0, 1).forEach(ph => {
        const base = (ph.url || '').replace(/square\.(jpe?g|png)/i, '');
        if (!base) return;
        const ext = ((ph.url || '').match(/square\.(jpe?g|png)/i) || [, 'jpg'])[1];
        out.push({
          uid: 'inat-' + ph.id, provider: 'inaturalist', type: 'image', title: o.taxon?.preferred_common_name || o.taxon?.name || o.species_guess || 'iNaturalist', tags: [o.taxon?.name, o.taxon?.iconic_taxon_name, o.species_guess, 'animal'].filter(Boolean).join(' '),
          thumb: `${base}medium.${ext}`, urls: [`${base}large.${ext}`, `${base}original.${ext}`, `${base}medium.${ext}`],
          width: ph.original_dimensions?.width, height: ph.original_dimensions?.height,
          creator: o.user?.name || o.user?.login || '', creatorUrl: o.user?.login ? `https://www.inaturalist.org/people/${o.user.login}` : '',
          license: String(ph.license_code || '').toUpperCase().replace(/^CC-/, 'CC ').replace(/-/g, '-'), licenseUrl: '', pageUrl: o.uri || '',
        });
      }));
      return out;
    },
  },

  flickr: {
    name: 'Flickr', needsKey: true, kinds: ['image'],
    keyUrl: 'https://www.flickr.com/services/apps/create/apply/',
    note: 'ملايين صور المزارع والحيوانات بتراخيص تسمح بالاستخدام التجاري.',
    async search(q, kind, { key, orientation }) {
      const d = await getJSON(`https://api.flickr.com/services/rest/?${qs({
        method: 'flickr.photos.search', api_key: key, text: q, license: '4,5,7,8,9,10', media: 'photos', content_types: 0, safe_search: 1,
        sort: 'relevance', per_page: 30, extras: 'url_l,url_c,url_m,owner_name,license,tags', format: 'json', nojsoncallback: 1,
        orientation: { landscape: 'landscape', portrait: 'portrait', square: 'square' }[orientation],
      })}`, {}, 'Flickr');
      if (d.stat === 'fail') throw new ProviderError('Flickr: ' + (d.code === 100 ? 'المفتاح غير صالح' : d.message), d.code === 100 ? 'key' : 'http');
      const L = { 4: 'CC BY 2.0', 5: 'CC BY-SA 2.0', 7: 'No known copyright', 8: 'US Government Work', 9: 'CC0', 10: 'Public Domain Mark' };
      return (d.photos?.photo || []).filter(p => p.url_l || p.url_c).map(p => ({
        uid: 'flickr-' + p.id, provider: 'flickr', type: 'image', title: p.title || 'Flickr', tags: p.tags || '',
        thumb: p.url_m || p.url_c, urls: [p.url_l, p.url_c].filter(Boolean), width: +p.width_l || +p.width_c, height: +p.height_l || +p.height_c,
        creator: p.ownername || '', creatorUrl: `https://www.flickr.com/people/${p.owner}/`,
        license: L[p.license] || 'CC', licenseUrl: '', pageUrl: `https://www.flickr.com/photos/${p.owner}/${p.id}`,
      }));
    },
  },

  europeana: {
    name: 'Europeana', needsKey: false, optionalKey: true, kinds: ['image', 'video'],
    keyUrl: 'https://pro.europeana.eu/page/get-api',
    note: 'أرشيف المتاحف الأوروبية: صور وأفلام قديمة للريف والمزارع بتراخيص مفتوحة. يعمل بدون مفتاح.',
    async search(q, kind, { key }) {
      const d = await getJSON(`https://api.europeana.eu/record/v2/search.json?${qs({ wskey: key || 'api2demo', query: q, media: 'true', reusability: 'open', rows: 30, qf: `TYPE:${kind === 'video' ? 'VIDEO' : 'IMAGE'}`, profile: 'rich' })}`, {}, 'Europeana');
      return (d.items || []).map(it => {
        const media = [].concat(it.edmIsShownBy || []);
        if (kind === 'video' && !media.some(u => /\.(mp4|webm)(\?|$)/i.test(u))) return null;
        return {
          uid: 'eu-' + it.id, provider: 'europeana', type: kind, title: [].concat(it.title || 'Europeana')[0],
          thumb: [].concat(it.edmPreview || [])[0] || '', urls: kind === 'video' ? media.filter(u => /\.(mp4|webm)(\?|$)/i.test(u)) : [...media, ...[].concat(it.edmPreview || [])],
          creator: [].concat(it.dcCreator || it.dataProvider || '')[0], creatorUrl: '',
          license: ([].concat(it.rights || [])[0] || '').replace(/^https?:\/\/creativecommons\.org\/(licenses|publicdomain)\//, 'CC ').replace(/\/$/, '') || 'راجع الصفحة',
          licenseUrl: [].concat(it.rights || [])[0] || '', pageUrl: it.guid || '',
        };
      }).filter(Boolean);
    },
  },

  wikipedia: {
    name: 'Wikipedia (صور المقالات)', needsKey: false, kinds: ['image'],
    note: 'الصورة الرئيسية لمقالات ويكيبيديا عن الموضوع (أشخاص، أماكن، أحداث، سلالات الحيوانات) بترخيص حر فقط.',
    async search(q) {
      const langs = Channel.id === 'majra' ? ['ar', 'en'] : ['en'];
      const all = await Promise.all(langs.map(async l => {
        const d = await getJSON(`https://${l}.wikipedia.org/w/api.php?${qs({ action: 'query', generator: 'search', gsrsearch: q, gsrlimit: 12, prop: 'pageimages|info', inprop: 'url', piprop: 'original|thumbnail', pithumbsize: 400, pilicense: 'free', format: 'json', origin: '*' })}`, {}, 'Wikipedia');
        return Object.values(d.query?.pages || {}).sort((a, b) => (a.index || 0) - (b.index || 0)).filter(p => p.original?.source && !/\.svg$/i.test(p.original.source)).map(p => ({
          uid: `wp-${l}-${p.pageid}`, provider: 'wikipedia', type: 'image', title: p.title, thumb: p.thumbnail?.source || p.original.source,
          urls: [p.original.source], width: p.original.width, height: p.original.height,
          creator: 'Wikimedia Commons', license: 'ترخيص حر (Wikimedia Commons)', licenseUrl: 'https://commons.wikimedia.org/wiki/Commons:Licensing', pageUrl: p.fullurl,
        }));
      }));
      return all.flat();
    },
  },

  loc: {
    name: 'Library of Congress', needsKey: false, kinds: ['image'],
    note: 'أرشيف مكتبة الكونغرس: صور تاريخية وأغلبها ملكية عامة (راجع الحقوق في صفحة كل صورة).',
    async search(q) {
      const d = await getJSONX(`https://www.loc.gov/photos/?${qs({ q, fo: 'json', c: 30, fa: 'online-format:image' })}`, 'Library of Congress');
      return (d.results || []).filter(r => (r.image_url || []).length).map(r => {
        const imgs = r.image_url.map(u => https(u.split('#')[0]));
        return {
          uid: 'loc-' + (r.id || r.url), provider: 'loc', type: 'image', title: String(r.title || 'LoC').slice(0, 120), thumb: imgs[0], urls: [imgs[imgs.length - 1], imgs[Math.floor(imgs.length / 2)]].filter(Boolean),
          creator: 'Library of Congress', license: (r.rights_advisory || ['راجع الحقوق'])[0]?.toString().slice(0, 60) || 'Public domain', licenseUrl: 'https://www.loc.gov/legal/', pageUrl: r.url || r.id,
        };
      });
    },
  },

  /* ---------- مصادر إضافية عامة (لكل أنواع المحتوى: صحة، تاريخ، فن، علوم…) ---------- */
  wellcome: {
    name: 'Wellcome Collection (صحة وطب)', needsKey: false, kinds: ['image'],
    note: 'أرشيف طبي وصحي ضخم: صور الطب والجسم والأمراض والتاريخ الطبي، أغلبها بترخيص حر.',
    async search(q) {
      const d = await getJSONX(`https://api.wellcomecollection.org/catalogue/v2/images?${qs({ query: q, pageSize: 24 })}`, 'Wellcome');
      return (d.results || []).map(r => {
        const base = String(r.thumbnail?.url || '').replace(/\/info\.json$/, ''); if (!base) return null;
        const lic = r.locations?.[0]?.license;
        return { uid: 'wc-' + r.id, provider: 'wellcome', type: 'image', title: r.source?.title || 'Wellcome', thumb: base + '/full/400,/0/default.jpg', urls: [base + '/full/!1600,1600/0/default.jpg', base + '/full/800,/0/default.jpg'],
          creator: 'Wellcome Collection', license: lic?.label || 'راجع الترخيص', licenseUrl: lic?.url || '', pageUrl: `https://wellcomecollection.org/works/${r.source?.id || ''}` };
      }).filter(Boolean);
    },
  },
  openi: {
    name: 'Open-i (صور طبية)', needsKey: false, kinds: ['image'],
    note: 'صور طبية وعلمية من المكتبة الوطنية للطب الأمريكية (NLM). راجع ترخيص كل صورة.',
    async search(q) {
      const d = await getJSONX(`https://openi.nlm.nih.gov/api/search?${qs({ query: q, m: 1, n: 24 })}`, 'Open-i');
      return (d.list || []).filter(x => x.imgLarge).map((x, i) => ({ uid: 'oi-' + (x.uid || i), provider: 'openi', type: 'image', title: x.image?.caption?.slice(0, 120) || x.title || 'Open-i',
        thumb: 'https://openi.nlm.nih.gov' + (x.imgThumb || x.imgLarge), urls: ['https://openi.nlm.nih.gov' + x.imgLarge], creator: x.journal_title || 'NLM', license: x.license_type || 'راجع الترخيص', licenseUrl: x.license_url || '', pageUrl: x.pmc_url || '' }));
    },
  },
  met: {
    name: 'The Met Museum', needsKey: false, kinds: ['image'],
    note: 'متحف المتروبوليتان: صور أعمال فنية وتاريخية بملكية عامة (حضارات، تاريخ، تراث).',
    async search(q) {
      if (metDown > Date.now()) return [];
      let d;
      try { d = await getJSON(`https://collectionapi.metmuseum.org/public/collection/v1/search?${qs({ q, hasImages: 'true' })}`, { keyless: true }, 'The Met'); }
      catch (e) { if (/410|404/.test(e.message)) { metDown = Date.now() + 864e5; return []; } throw e; }   // الخدمة متوقفة: نتخطاها يوماً كاملاً
      const ids = (d.objectIDs || []).slice(0, 10);
      const objs = await Promise.all(ids.map(id => getJSON(`https://collectionapi.metmuseum.org/public/collection/v1/objects/${id}`, {}, 'The Met').catch(() => null)));
      return objs.filter(o => o && o.isPublicDomain && o.primaryImage).map(o => ({ uid: 'met-' + o.objectID, provider: 'met', type: 'image', title: o.title, tags: [o.culture, o.period, o.objectName].filter(Boolean).join(' '),
        thumb: o.primaryImageSmall || o.primaryImage, urls: [o.primaryImage, o.primaryImageSmall].filter(Boolean), creator: o.artistDisplayName || 'The Met', license: 'Public Domain (CC0)', licenseUrl: 'https://www.metmuseum.org/about-the-met/policies-and-documents/open-access', pageUrl: o.objectURL }));
    },
  },
  aic: {
    name: 'Art Institute of Chicago', needsKey: false, kinds: ['image'],
    note: 'معهد شيكاغو للفنون: آلاف الأعمال بملكية عامة.',
    async search(q) {
      const d = await getJSON(`https://api.artic.edu/api/v1/artworks/search?${qs({ q, limit: 24, fields: 'id,title,image_id,is_public_domain,artist_title' })}`, {}, 'AIC');
      return (d.data || []).filter(a => a.image_id && a.is_public_domain).map(a => ({ uid: 'aic-' + a.id, provider: 'aic', type: 'image', title: a.title,
        thumb: `https://www.artic.edu/iiif/2/${a.image_id}/full/400,/0/default.jpg`, urls: [`https://www.artic.edu/iiif/2/${a.image_id}/full/1686,/0/default.jpg`, `https://www.artic.edu/iiif/2/${a.image_id}/full/843,/0/default.jpg`],
        creator: a.artist_title || 'Art Institute of Chicago', license: 'CC0', licenseUrl: 'https://www.artic.edu/open-access', pageUrl: `https://www.artic.edu/artworks/${a.id}` }));
    },
  },
  cma: {
    name: 'Cleveland Museum of Art', needsKey: false, kinds: ['image'],
    note: 'متحف كليفلاند: أعمال فنية وتاريخية بترخيص CC0.',
    async search(q) {
      const d = await getJSON(`https://openaccess-api.clevelandart.org/api/artworks/?${qs({ q, has_image: 1, cc0: 1, limit: 24 })}`, {}, 'Cleveland');
      return (d.data || []).filter(a => a.images?.web?.url).map(a => ({ uid: 'cma-' + a.id, provider: 'cma', type: 'image', title: a.title, tags: [a.culture?.join?.(' '), a.type].filter(Boolean).join(' '),
        thumb: a.images.web.url, urls: [a.images.print?.url, a.images.web.url].filter(Boolean), creator: 'Cleveland Museum of Art', license: 'CC0', licenseUrl: 'https://www.clevelandart.org/open-access', pageUrl: a.url }));
    },
  },
  smithsonian: {
    name: 'Smithsonian Open Access', needsKey: false, optionalKey: true, kinds: ['image'],
    keyUrl: 'https://api.data.gov/signup/',
    note: 'ملايين الصور من متاحف سميثسونيان (علوم، طبيعة، تاريخ). يعمل بدون مفتاح بحد صغير، ومع مفتاح api.data.gov المجاني بلا قيود تقريباً.',
    async search(q, kind, { key }) {
      const d = await getJSON(`https://api.si.edu/openaccess/api/v1.0/search?${qs({ q: q + ' AND online_media_type:Images', rows: 24, api_key: key || 'DEMO_KEY' })}`, {}, 'Smithsonian');
      return (d.response?.rows || []).map(r => { const m = r.content?.descriptiveNonRepeating?.online_media?.media?.find(x => x.type === 'Images'); if (!m?.content) return null;
        return { uid: 'si-' + r.id, provider: 'smithsonian', type: 'image', title: r.title, thumb: m.thumbnail || m.content, urls: [m.content], creator: r.unitCode || 'Smithsonian', license: m.usage?.access === 'CC0' ? 'CC0' : 'راجع الترخيص', licenseUrl: 'https://www.si.edu/openaccess', pageUrl: r.content?.descriptiveNonRepeating?.record_link || '' }; }).filter(Boolean);
    },
  },
  rijks: {
    name: 'Rijksmuseum', needsKey: true, kinds: ['image'],
    keyUrl: 'https://data.rijksmuseum.nl/object-metadata/api/',
    note: 'متحف ريكس الهولندي: لوحات وصور تاريخية عالية الدقة بملكية عامة.',
    async search(q, kind, { key }) {
      const d = await getJSON(`https://www.rijksmuseum.nl/api/en/collection?${qs({ key, q, imgonly: 'true', ps: 24 })}`, {}, 'Rijksmuseum');
      return (d.artObjects || []).filter(a => a.webImage?.url).map(a => ({ uid: 'rijks-' + a.objectNumber, provider: 'rijks', type: 'image', title: a.title, thumb: a.headerImage?.url || a.webImage.url, urls: [a.webImage.url],
        creator: a.principalOrFirstMaker || 'Rijksmuseum', license: 'Public Domain', licenseUrl: 'https://www.rijksmuseum.nl/en/research/conduct-research/data/policy', pageUrl: a.links?.web || '' }));
    },
  },
  dpla: {
    name: 'DPLA (المكتبة الرقمية الأمريكية)', needsKey: true, kinds: ['image'],
    keyUrl: 'https://pro.dp.la/developers/api-codex',
    note: 'تجمع ملايين الصور من مكتبات ومتاحف وأرشيفات. راجع ترخيص كل صورة.',
    async search(q, kind, { key }) {
      const d = await getJSON(`https://api.dp.la/v2/items?${qs({ q, api_key: key, page_size: 24, 'sourceResource.type': 'image' })}`, {}, 'DPLA');
      return (d.docs || []).filter(x => x.object).map(x => ({ uid: 'dpla-' + x.id, provider: 'dpla', type: 'image', title: [].concat(x.sourceResource?.title || 'DPLA')[0], thumb: x.object, urls: [x.object],
        creator: x.dataProvider?.name || x.provider?.name || 'DPLA', license: [].concat(x.rights || 'راجع الترخيص')[0], licenseUrl: '', pageUrl: x.isShownAt || '' }));
    },
  },
  coverr: {
    name: 'Coverr (فيديوهات)', needsKey: true, kinds: ['video'],
    keyUrl: 'https://coverr.co/developers',
    note: 'فيديوهات مجانية عالية الجودة للاستخدام التجاري.',
    async search(q, kind, { key }) {
      const d = await getJSON(`https://api.coverr.co/videos?${qs({ query: q, page_size: 20, urls: 'true', api_key: key })}`, {}, 'Coverr');
      return (d.hits || []).filter(v => v.urls?.mp4).map(v => ({ uid: 'cv-' + v.id, provider: 'coverr', type: 'video', title: v.title, tags: (v.tags || []).join(' '), thumb: v.poster || v.thumbnail, urls: [v.urls.mp4_download || v.urls.mp4, v.urls.mp4].filter(Boolean),
        duration: v.duration, creator: 'Coverr', license: 'Coverr License', licenseUrl: 'https://coverr.co/license', pageUrl: `https://coverr.co/videos/${v.slug || v.id}` }));
    },
  },
  giphy: {
    name: 'GIPHY (لقطات متحركة)', needsKey: true, kinds: ['video'],
    keyUrl: 'https://developers.giphy.com/dashboard/',
    note: 'لقطات متحركة قصيرة للمحتوى الترفيهي (تُستعمل كفيديو MP4). راجع شروط GIPHY.',
    async search(q, kind, { key }) {
      const d = await getJSON(`https://api.giphy.com/v1/gifs/search?${qs({ api_key: key, q, limit: 20, rating: 'g' })}`, {}, 'GIPHY');
      return (d.data || []).filter(g => g.images?.original?.mp4).map(g => ({ uid: 'gif-' + g.id, provider: 'giphy', type: 'video', title: g.title || 'GIPHY', thumb: g.images.fixed_width_still?.url || g.images.original_still?.url, urls: [g.images.original.mp4],
        creator: g.username || 'GIPHY', license: 'GIPHY Terms', licenseUrl: 'https://giphy.com/terms', pageUrl: g.url }));
    },
  },
};

/* JSON عبر الطبقة الأصلية في تطبيق الهاتف (بدون قيود CORS)، وإلا fetch عادي */
async function getJSONX(url, label) {
  if (typeof NATIVE !== 'undefined' && NATIVE) {
    try { const r = await capCall('FadiNative', 'fetchText', { url }); if (r && r.status < 400) return JSON.parse(r.data); } catch {}
  }
  return getJSON(url, {}, label);
}

/* البحث في كل المصادر المفعّلة، مع ترتيب النتائج بالتناوب حسب الأولوية */
async function searchProviders(q, kind, { only, orientation, minDim } = {}) {
  const s = Settings.get();
  const list = s.providers.filter(p => p.on && PROVIDERS[p.id].kinds.includes(kind) && (!only || only === p.id));
  const status = {};
  const results = await Promise.all(list.map(async p => {
    const P = PROVIDERS[p.id];
    if (P.needsKey && !s.keys[p.id]) { status[p.id] = 'يحتاج مفتاح API'; return []; }
    try {
      const r = await P.search(q, kind, { key: s.keys[p.id], orientation, minDim });
      status[p.id] = r.length ? `${r.length} نتيجة` : 'لا نتائج';
      return r;
    } catch (e) { status[p.id] = e.message; return []; }
  }));
  const merged = [], max = Math.max(0, ...results.map(r => r.length));
  for (let i = 0; i < max; i++) results.forEach(r => r[i] && merged.push(r[i]));
  return { items: merged, byProvider: list.map((p, i) => ({ id: p.id, items: results[i] })), status };
}

/* اختبار مفتاح مزوّد */
async function testProvider(id) {
  const s = Settings.get(), P = PROVIDERS[id];
  if (P.needsKey && !s.keys[id]) throw new ProviderError('أدخل المفتاح أولاً', 'key');
  const r = await P.search('farm', P.kinds[0], { key: s.keys[id], orientation: 'landscape', minDim: 720 });
  return r.length;
}
