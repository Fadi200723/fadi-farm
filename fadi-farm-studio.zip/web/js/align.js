/* Fadi — مزامنة النص مع الصوت: يكتشف فترات الكلام الفعلية في الصوت (ويتجاهل الصمت)،
   ثم يوزّع الكلمات على زمن الكلام فقط، فتظهر الكتابة مع الصوت بدون تأخير */
'use strict';

const Align = (() => {
  const cache = new Map();

  function mono(buf, a, b) {
    const sr = buf.sampleRate, i0 = Math.max(0, Math.floor(a * sr)), i1 = Math.min(buf.length, Math.floor(b * sr)), o = new Float32Array(Math.max(0, i1 - i0));
    for (let c = 0; c < buf.numberOfChannels; c++) { const d = buf.getChannelData(c); for (let k = i0; k < i1; k++) o[k - i0] += d[k] / buf.numberOfChannels; }
    return o;
  }

  /* صوت أحادي مخفَّض إلى ~16kHz (أسرع وأخف على الذاكرة للصوت الطويل) */
  function mono16(data, sr) {
    const k = Math.max(1, Math.round(sr / 16000)); if (k === 1) return { data, sr };
    const n = Math.floor(data.length / k), o = new Float32Array(n);
    for (let i = 0; i < n; i++) { let a = 0; for (let j = 0; j < k; j++) a += data[i * k + j]; o[i] = a / k; }
    return { data: o, sr: sr / k };
  }
  function monoBuf(buf, a = 0, b = buf.duration) { return mono16(mono(buf, a, b), buf.sampleRate); }

  /* فترات الكلام [{a,b}] بالثواني داخل المقطع */
  function voiced(data, sr) {
    const hop = Math.round(sr * 0.02), n = Math.floor(data.length / hop);
    if (!n) return [];
    const rms = new Float32Array(n);
    for (let i = 0; i < n; i++) { let e = 0; for (let k = i * hop; k < (i + 1) * hop; k += 2) e += data[k] * data[k]; rms[i] = Math.sqrt(e / (hop / 2)); }
    const sorted = Array.from(rms).sort((x, y) => x - y), floor = sorted[Math.floor(n * 0.1)] || 0, speech = sorted[Math.floor(n * 0.6)] || 0.05;
    const thr = Math.max(0.006, floor * 2.5, speech * 0.12);
    let on = Array.from(rms, v => v >= thr);
    // سدّ الفجوات القصيرة داخل الكلمات (< 140ms) وحذف النبضات القصيرة (< 60ms)
    const fill = (arr, val, maxLen) => { let i = 0; while (i < arr.length) { if (arr[i] === val) { let j = i; while (j < arr.length && arr[j] === val) j++; if (j - i <= maxLen && i > 0 && j < arr.length) for (let k = i; k < j; k++) arr[k] = !val; i = j; } else i++; } };
    fill(on, false, 7); fill(on, true, 3);
    const out = []; let s = -1;
    for (let i = 0; i <= n; i++) {
      if (i < n && on[i]) { if (s < 0) s = i; }
      else if (s >= 0) { out.push({ a: s * hop / sr, b: i * hop / sr }); s = -1; }
    }
    return out;
  }

  /* توقيت الكلمات داخل بيانات صوت: [{w, t0, t1}] بالثواني من بداية البيانات */
  function fromData(data, sr, text) {
    const words = String(text).split(/\s+/).filter(Boolean);
    if (!words.length) return [];
    let segs = voiced(data, sr);
    const len = data.length / sr;
    if (!segs.length) segs = [{ a: 0, b: len }];
    const V = segs.reduce((x, s) => x + (s.b - s.a), 0) || len;
    // وزن الكلمة: عدد حروفها + وقفة صغيرة بعد علامات الترقيم
    const wts = words.map(w => w.replace(/[^\p{L}\p{N}]/gu, '').length + 1.2 + (/[.!؟?…،,:]$/.test(w) ? 1.5 : 0));
    const W = wts.reduce((x, y) => x + y, 0);
    const at = v => { let acc = 0; for (const s of segs) { const d = s.b - s.a; if (v <= acc + d + 1e-6) return s.a + (v - acc); acc += d; } return segs[segs.length - 1].b; };
    // حدود الجمل ← أطول وقفات الكلام القريبة من موضعها المتوقع
    const ends = []; words.forEach((w, i) => { if (/[.!؟?…]$/.test(w) && i < words.length - 1) ends.push(i); });
    const gaps = []; let acc = 0;
    segs.forEach((s, i) => { acc += s.b - s.a; if (i < segs.length - 1 && segs[i + 1].a - s.b >= 0.22) gaps.push({ pos: acc, len: segs[i + 1].a - s.b }); });
    const cum = []; wts.reduce((a, x, i) => (cum[i] = a + x), 0);
    const cumAt = i => i < 0 ? 0 : cum[i];
    // تصحيح الانجراف: يُقدَّر موضع كل نهاية جملة من آخر حدّ مؤكد، لا من بداية الصوت
    const bounds = []; let gi = 0, pw = -1, pp = 0;
    ends.forEach(e => {
      const E = pp + (cumAt(e) - cumAt(pw)) / Math.max(1e-6, W - cumAt(pw)) * (V - pp);
      const tol = Math.max(0.8, Math.min(5, (E - pp) * 0.4));
      let best = -1, bd = 1e9;
      for (let k = gi; k < gaps.length && gaps[k].pos <= E + tol; k++) {
        const dist = Math.abs(gaps[k].pos - E); if (dist > tol || gaps[k].pos <= pp + 0.15) continue;
        const dd = dist - Math.min(0.45, gaps[k].len * 0.6);
        if (dd < bd) { bd = dd; best = k; }
      }
      if (best >= 0) { bounds.push({ word: e, pos: gaps[best].pos }); gi = best + 1; pw = e; pp = gaps[best].pos; }
    });
    // توزيع الكلمات داخل كل جملة على زمن كلامها
    const out = []; let w0 = 0, p0 = 0;
    [...bounds, { word: words.length - 1, pos: V }].forEach(b => {
      const ids = []; for (let i = w0; i <= b.word; i++) ids.push(i);
      const sw = ids.reduce((x, i) => x + wts[i], 0) || 1, span = Math.max(0.01, b.pos - p0);
      let c = 0;
      ids.forEach(i => { const t0 = at(p0 + c / sw * span + 2e-3); c += wts[i]; out.push({ w: words[i], t0, t1: at(p0 + c / sw * span) }); });
      w0 = b.word + 1; p0 = b.pos;
    });
    return out;
  }

  /* توقيت كلمات نص داخل جزء من صوت المشروع (بالثواني المطلقة) */
  function words(buf, a, b, text) {
    const k = `${a.toFixed(2)}|${b.toFixed(2)}|${text.length}|${buf.length}`;
    if (cache.has(k)) return cache.get(k);
    const m = monoBuf(buf, a, b), r = fromData(m.data, m.sr, text).map(x => ({ w: x.w, t0: x.t0 + a, t1: x.t1 + a }));
    if (cache.size > 400) cache.clear();
    cache.set(k, r);
    return r;
  }

  const norm = x => x.replace(/[^\p{L}\p{N}]/gu, '').replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي');
  /* أفضل جملة في قائمة كلمات (بأزمنة مطلقة) تطابق نص المؤثر ← {at, dur} نسبةً لبداية المشهد */
  function pick(ws, sceneStart, d, fxText, anchor) {
    if (!ws.length) return { at: 0.25, dur: Math.min(4.5, d) };
    const W = ws.map(w => norm(w.w)), sentEnd = i => { for (let k = i; k < ws.length; k++) if (/[.!؟?…]$/.test(ws[k].w)) return k; return ws.length - 1; };
    // تظهر الجملة لحظة نطق أول كلمة مطابقة (وليس قبلها)
    const fin = (i0, i1) => {
      const t0 = ws[i0].t0 - sceneStart, t1 = ws[Math.max(i1, sentEnd(i0))].t1 - sceneStart, at = Math.max(0, t0 + 0.02);
      return { at, dur: Math.min(Math.max(2.6, t1 - t0 + 1.0), Math.max(2.6, d - at + 0.4)) };
    };
    // 1) مطابقة دقيقة: أطول سلسلة كلمات متتالية من «المرساة» أو نص المؤثر داخل كلام المشهد
    for (const src of [anchor, fxText]) {
      const A = String(src || '').split(/\s+/).map(norm).filter(w => w.length > 1); if (A.length < 2) continue;
      let best = null;
      for (let i = 0; i < W.length; i++) for (let j = 0; j < A.length; j++) {
        let n = 0; while (i + n < W.length && j + n < A.length && W[i + n] === A[j + n]) n++;
        // عند التساوي نفضّل التطابق الذي يبدأ من أول كلمة في المرساة (أدق لحظة)
        if (n >= 2 && (!best || n > best.n || (n === best.n && j === 0 && best.j !== 0))) best = { i, n, j };
      }
      if (best && best.n >= Math.min(3, A.length)) return fin(best.i, best.i + best.n - 1);
    }
    // 2) الجملة الأقرب (أكثر كلمات مشتركة)، وتظهر لحظة نطق أول كلمة مهمة مشتركة فيها
    const target = new Set([...String(fxText).split(/\s+/), ...String(anchor || '').split(/\s+/)].map(norm).filter(w => w.length > 2));
    const sents = []; let st = 0;
    ws.forEach((w, i) => { if (/[.!؟?…]$/.test(w.w) || i === ws.length - 1) { sents.push([st, i]); st = i + 1; } });
    let best = sents[0], bs = -1;
    sents.forEach(([a, b]) => { let sc = 0; for (let i = a; i <= b; i++) if (target.has(W[i])) sc++; sc /= Math.sqrt(b - a + 1); if (sc > bs) { bs = sc; best = [a, b]; } });
    let first = best[0]; for (let i = best[0]; i <= best[1]; i++) if (target.has(W[i])) { first = i; break; }
    return fin(first, best[1]);
  }
  /* مطابقة دقيقة فقط (المرساة أو نص المؤثر) ← {i0, i1} أو null */
  function locate(ws, fxText, anchor) {
    const W = ws.map(w => norm(w.w));
    for (const src of [anchor, fxText]) {
      const A = String(src || '').split(/\s+/).map(norm).filter(w => w.length > 1); if (A.length < 2) continue;
      let best = null;
      for (let i = 0; i < W.length; i++) for (let j = 0; j < A.length; j++) {
        let n = 0; while (i + n < W.length && j + n < A.length && W[i + n] === A[j + n]) n++;
        if (n >= 2 && (!best || n > best.n || (n === best.n && j === 0 && best.j !== 0))) best = { i, n, j };
      }
      if (best && best.n >= Math.min(3, A.length)) return { i0: best.i, i1: best.i + best.n - 1 };
    }
    return null;
  }
  /* مطابقة مرنة (اختلاف الإملاء في اللهجات): أطول سلسلة كلمات متشابهة ≥ 72% ← {i0, i1, j} */
  function lev(a, b) {
    if (a === b) return 1; if (!a || !b) return 0;
    const m = a.length, n = b.length; let prev = Array.from({ length: n + 1 }, (_, j) => j);
    for (let i = 1; i <= m; i++) { const cur = [i]; for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); prev = cur; }
    return 1 - prev[n] / Math.max(m, n);
  }
  const strip = w => norm(w).replace(/^(وال|بال|فال|كال|لل|ال|و)/, '');
  function locateFuzzy(ws, phrase) {
    const A = String(phrase || '').split(/\s+/).map(strip).filter(w => w.length > 1); if (A.length < 2) return null;
    const W = ws.map(w => strip(w.w)); let best = null;
    for (let i = 0; i < W.length; i++) for (let j = 0; j < A.length; j++) {
      let n = 0; while (i + n < W.length && j + n < A.length && lev(W[i + n], A[j + n]) >= 0.72) n++;
      if (n >= 2 && (!best || n > best.n || (n === best.n && j < best.j))) best = { i0: i, i1: i + n - 1, n, j };
    }
    return best && best.n >= Math.min(3, A.length) ? best : null;
  }
  /* زمن ظهور جملة معيّنة داخل مشهد */
  function phrase(buf, sceneStart, d, sceneText, fxText) { return pick(words(buf, sceneStart, sceneStart + d, sceneText), sceneStart, d, fxText); }
  /* كلمات المشهد المحفوظة من المزامنة الشاملة (أدق)، وإلا تحليل المشهد وحده */
  function sceneWords(s, start, buf) {
    const ws = String(s.text).split(/\s+/).filter(Boolean);
    if (s.wt && s.wtk === s.text && s.wt.length === ws.length) return ws.map((w, i) => ({ w, t0: s.wt[i][0], t1: s.wt[i][1] }));
    return buf ? words(buf, start, start + s.d, s.text) : [];
  }
  function forScene(s, start, fxText, buf, anchor) { return pick(sceneWords(s, start, buf), start, s.d, fxText, anchor); }

  return { voiced, fromData, words, phrase, mono, mono16, monoBuf, forScene, sceneWords, pick, locate, locateFuzzy, lev, strip };
})();
