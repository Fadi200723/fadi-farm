/* Fadi — القنوات: لكل قناة هويتها ومصادرها وأسلوب مونتاجها ومشروعها المستقل */
'use strict';

const Channel = (() => {
  /* اللهجات: لغة الكتابة + أصوات Microsoft Azure + أسلوب صوت Gemini */
  const DIALECTS = {
    eg: { name: 'المصرية', nat: 'مصري', who: 'Egyptian', lang: 'Egyptian Arabic dialect (عامية مصرية)', locale: 'ar-EG', voices: [['ar-EG-ShakirNeural', 'شاكر (رجل)'], ['ar-EG-SalmaNeural', 'سلمى (امرأة)']], gem: 'راجل مصري بيحكي باللهجة المصرية العامية' },
    ae: { name: 'الإماراتية', nat: 'إماراتي', who: 'Emirati', lang: 'Emirati Arabic dialect (اللهجة الإماراتية), natural Gulf vocabulary like "شو", "وايد", "هالشي", "زين"', locale: 'ar-AE', voices: [['ar-AE-HamdanNeural', 'حمدان (رجل)'], ['ar-AE-FatimaNeural', 'فاطمة (امرأة)']], gem: 'رجل إماراتي يتكلم باللهجة الإماراتية الخليجية' },
    ma: { name: 'المغربية', nat: 'مغربي', who: 'Moroccan', lang: 'Moroccan Arabic Darija (الدارجة المغربية) written in Arabic letters, natural words like "واش", "بزاف", "دابا", "شنو", while staying understandable to other Arabs', locale: 'ar-MA', voices: [['ar-MA-JamalNeural', 'جمال (رجل)'], ['ar-MA-MounaNeural', 'منى (امرأة)']], gem: 'رجل مغربي يتكلم بالدارجة المغربية' },
    dz: { name: 'الجزائرية', nat: 'جزائري', who: 'Algerian', lang: 'Algerian Arabic Darja (الدارجة الجزائرية) written in Arabic letters, natural words like "واش", "بزاف", "درك", "كيفاش", understandable to other Arabs', locale: 'ar-DZ', voices: [['ar-DZ-IsmaelNeural', 'إسماعيل (رجل)'], ['ar-DZ-AminaNeural', 'أمينة (امرأة)']], gem: 'رجل جزائري يتكلم بالدارجة الجزائرية' },
    sa: { name: 'السعودية', nat: 'سعودي', who: 'Saudi', lang: 'Saudi Arabic dialect (اللهجة السعودية النجدية/الحجازية) with natural words like "وش", "مرة", "زين", "يا شباب"', locale: 'ar-SA', voices: [['ar-SA-HamedNeural', 'حامد (رجل)'], ['ar-SA-ZariyahNeural', 'زارية (امرأة)']], gem: 'رجل سعودي يتكلم باللهجة السعودية' },
    kw: { name: 'الكويتية', nat: 'كويتي', who: 'Kuwaiti', lang: 'Kuwaiti Arabic dialect (اللهجة الكويتية)', locale: 'ar-KW', voices: [['ar-KW-FahedNeural', 'فهد (رجل)'], ['ar-KW-NouraNeural', 'نورة (امرأة)']], gem: 'رجل كويتي يتكلم باللهجة الكويتية' },
    qa: { name: 'القطرية', nat: 'قطري', who: 'Qatari', lang: 'Qatari Arabic dialect (اللهجة القطرية)', locale: 'ar-QA', voices: [['ar-QA-MoazNeural', 'معاذ (رجل)'], ['ar-QA-AmalNeural', 'أمل (امرأة)']], gem: 'رجل قطري يتكلم باللهجة القطرية' },
    bh: { name: 'البحرينية', nat: 'بحريني', who: 'Bahraini', lang: 'Bahraini Arabic dialect (اللهجة البحرينية)', locale: 'ar-BH', voices: [['ar-BH-AliNeural', 'علي (رجل)'], ['ar-BH-LailaNeural', 'ليلى (امرأة)']], gem: 'رجل بحريني يتكلم باللهجة البحرينية' },
    om: { name: 'العُمانية', nat: 'عُماني', who: 'Omani', lang: 'Omani Arabic dialect (اللهجة العمانية)', locale: 'ar-OM', voices: [['ar-OM-AbdullahNeural', 'عبدالله (رجل)'], ['ar-OM-AyshaNeural', 'عائشة (امرأة)']], gem: 'رجل عماني يتكلم باللهجة العمانية' },
    ye: { name: 'اليمنية', nat: 'يمني', who: 'Yemeni', lang: 'Yemeni Arabic dialect (اللهجة اليمنية)', locale: 'ar-YE', voices: [['ar-YE-SalehNeural', 'صالح (رجل)'], ['ar-YE-MaryamNeural', 'مريم (امرأة)']], gem: 'رجل يمني يتكلم باللهجة اليمنية' },
    iq: { name: 'العراقية', nat: 'عراقي', who: 'Iraqi', lang: 'Iraqi Arabic dialect (اللهجة العراقية) with words like "شكو", "هواية", "زين", "اكو"', locale: 'ar-IQ', voices: [['ar-IQ-BasselNeural', 'باسل (رجل)'], ['ar-IQ-RanaNeural', 'رنا (امرأة)']], gem: 'رجل عراقي يتكلم باللهجة العراقية' },
    sy: { name: 'السورية', nat: 'سوري', who: 'Syrian', lang: 'Syrian Levantine Arabic (اللهجة الشامية السورية) with words like "شو", "كتير", "هلق", "منيح"', locale: 'ar-SY', voices: [['ar-SY-LaithNeural', 'ليث (رجل)'], ['ar-SY-AmanyNeural', 'أماني (امرأة)']], gem: 'رجل سوري يتكلم باللهجة الشامية' },
    lb: { name: 'اللبنانية', nat: 'لبناني', who: 'Lebanese', lang: 'Lebanese Arabic dialect (اللهجة اللبنانية)', locale: 'ar-LB', voices: [['ar-LB-RamiNeural', 'رامي (رجل)'], ['ar-LB-LaylaNeural', 'ليلى (امرأة)']], gem: 'رجل لبناني يتكلم باللهجة اللبنانية' },
    jo: { name: 'الأردنية', nat: 'أردني', who: 'Jordanian', lang: 'Jordanian Arabic dialect (اللهجة الأردنية)', locale: 'ar-JO', voices: [['ar-JO-TaimNeural', 'تيم (رجل)'], ['ar-JO-SanaNeural', 'سناء (امرأة)']], gem: 'رجل أردني يتكلم باللهجة الأردنية' },
    ps: { name: 'الفلسطينية', nat: 'فلسطيني', who: 'Palestinian', lang: 'Palestinian Arabic dialect (اللهجة الفلسطينية)', locale: 'ar-JO', voices: [['ar-JO-TaimNeural', 'تيم (رجل)'], ['ar-JO-SanaNeural', 'سناء (امرأة)']], gem: 'رجل فلسطيني يتكلم باللهجة الفلسطينية' },
    tn: { name: 'التونسية', nat: 'تونسي', who: 'Tunisian', lang: 'Tunisian Arabic Derja (الدارجة التونسية) written in Arabic letters, understandable to other Arabs', locale: 'ar-TN', voices: [['ar-TN-HediNeural', 'الهادي (رجل)'], ['ar-TN-ReemNeural', 'ريم (امرأة)']], gem: 'رجل تونسي يتكلم بالدارجة التونسية' },
    ly: { name: 'الليبية', nat: 'ليبي', who: 'Libyan', lang: 'Libyan Arabic dialect (اللهجة الليبية)', locale: 'ar-LY', voices: [['ar-LY-OmarNeural', 'عمر (رجل)'], ['ar-LY-ImanNeural', 'إيمان (امرأة)']], gem: 'رجل ليبي يتكلم باللهجة الليبية' },
    sd: { name: 'السودانية', nat: 'سوداني', who: 'Sudanese', lang: 'Sudanese Arabic dialect (اللهجة السودانية)', locale: 'ar-SA', voices: [['ar-SA-HamedNeural', 'حامد (رجل)'], ['ar-SA-ZariyahNeural', 'زارية (امرأة)']], gem: 'رجل سوداني يتكلم باللهجة السودانية' },
    mr: { name: 'الموريتانية (الحسانية)', nat: 'موريتاني', who: 'Mauritanian', lang: 'Mauritanian Hassaniya Arabic (الحسانية) kept understandable to other Arabs', locale: 'ar-MA', voices: [['ar-MA-JamalNeural', 'جمال (رجل)'], ['ar-MA-MounaNeural', 'منى (امرأة)']], gem: 'رجل موريتاني يتكلم بالحسانية' },
    white: { name: 'العامية البيضاء (يفهمها الجميع)', nat: 'عربي', who: 'Arab', lang: 'a simple "white" colloquial Arabic that every Arab understands (اللهجة البيضاء): everyday spoken Arabic close to Modern Standard Arabic, avoiding words that belong to only one country, warm and natural', locale: 'ar-SA', voices: [['ar-SA-HamedNeural', 'حامد (رجل)'], ['ar-SA-ZariyahNeural', 'زارية (امرأة)']], gem: 'رجل عربي يتكلم بعامية بيضاء بسيطة يفهمها كل العرب' },
    msa: { name: 'الفصحى', nat: 'عربي', who: 'Arab', lang: 'simple, lively Modern Standard Arabic (فصحى مبسطة)', locale: 'ar-SA', voices: [['ar-SA-HamedNeural', 'حامد (رجل)'], ['ar-SA-ZariyahNeural', 'زارية (امرأة)']], gem: 'مذيع عربي يتكلم بالفصحى المبسطة' },
    /* ---------- لغات أخرى: اللهجة تتبع اللغة ---------- */
    'fr-fr': { lg: 'fr', name: 'فرنسية فرنسا', nat: 'فرنسي', who: 'French', lang: 'natural spoken French from France (français courant)', locale: 'fr-FR', voices: [['fr-FR-HenriNeural', 'Henri (رجل)'], ['fr-FR-DeniseNeural', 'Denise (امرأة)']], gem: 'A French man speaking natural, lively French' },
    'fr-ca': { lg: 'fr', name: 'فرنسية كندا (كيبيك)', nat: 'كندي', who: 'Québécois', lang: 'natural Québec French (français québécois), understandable to all French speakers', locale: 'fr-CA', voices: [['fr-CA-AntoineNeural', 'Antoine (رجل)'], ['fr-CA-SylvieNeural', 'Sylvie (امرأة)']], gem: 'A Québécois man speaking natural Canadian French' },
    'fr-be': { lg: 'fr', name: 'فرنسية بلجيكا', nat: 'بلجيكي', who: 'Belgian', lang: 'natural Belgian French', locale: 'fr-BE', voices: [['fr-BE-GerardNeural', 'Gérard (رجل)'], ['fr-BE-CharlineNeural', 'Charline (امرأة)']], gem: 'A Belgian man speaking natural French' },
    'fr-ma': { lg: 'fr', name: 'فرنسية المغرب العربي', nat: 'مغاربي', who: 'North African', lang: 'clear spoken French as used in the Maghreb (Algeria, Morocco, Tunisia), simple and understandable to all French speakers', locale: 'fr-FR', voices: [['fr-FR-HenriNeural', 'Henri (رجل)'], ['fr-FR-DeniseNeural', 'Denise (امرأة)']], gem: 'A North African man speaking clear, warm French' },
    'en-us': { lg: 'en', name: 'إنجليزية أمريكية', nat: 'أمريكي', who: 'American', lang: 'natural conversational American English', locale: 'en-US', voices: [['en-US-GuyNeural', 'Guy (رجل)'], ['en-US-JennyNeural', 'Jenny (امرأة)']], gem: 'An American man speaking natural, energetic English' },
    'en-gb': { lg: 'en', name: 'إنجليزية بريطانية', nat: 'بريطاني', who: 'British', lang: 'natural conversational British English', locale: 'en-GB', voices: [['en-GB-RyanNeural', 'Ryan (رجل)'], ['en-GB-SoniaNeural', 'Sonia (امرأة)']], gem: 'A British man speaking natural English' },
    'en-au': { lg: 'en', name: 'إنجليزية أسترالية', nat: 'أسترالي', who: 'Australian', lang: 'natural Australian English', locale: 'en-AU', voices: [['en-AU-WilliamNeural', 'William (رجل)'], ['en-AU-NatashaNeural', 'Natasha (امرأة)']], gem: 'An Australian man speaking natural English' },
    'en-in': { lg: 'en', name: 'إنجليزية هندية', nat: 'هندي', who: 'Indian', lang: 'clear Indian English', locale: 'en-IN', voices: [['en-IN-PrabhatNeural', 'Prabhat (رجل)'], ['en-IN-NeerjaNeural', 'Neerja (امرأة)']], gem: 'An Indian man speaking clear English' },
    'es-es': { lg: 'es', name: 'إسبانية إسبانيا', nat: 'إسباني', who: 'Spanish', lang: 'natural Castilian Spanish', locale: 'es-ES', voices: [['es-ES-AlvaroNeural', 'Álvaro (رجل)'], ['es-ES-ElviraNeural', 'Elvira (امرأة)']], gem: 'A Spanish man speaking natural Spanish' },
    'es-mx': { lg: 'es', name: 'إسبانية لاتينية (المكسيك)', nat: 'مكسيكي', who: 'Mexican', lang: 'natural Latin American Spanish (Mexico)', locale: 'es-MX', voices: [['es-MX-JorgeNeural', 'Jorge (رجل)'], ['es-MX-DaliaNeural', 'Dalia (امرأة)']], gem: 'A Mexican man speaking natural Latin American Spanish' },
    'de-de': { lg: 'de', name: 'الألمانية', nat: 'ألماني', who: 'German', lang: 'natural spoken German', locale: 'de-DE', voices: [['de-DE-ConradNeural', 'Conrad (رجل)'], ['de-DE-KatjaNeural', 'Katja (امرأة)']], gem: 'A German man speaking natural German' },
    'it-it': { lg: 'it', name: 'الإيطالية', nat: 'إيطالي', who: 'Italian', lang: 'natural spoken Italian', locale: 'it-IT', voices: [['it-IT-DiegoNeural', 'Diego (رجل)'], ['it-IT-ElsaNeural', 'Elsa (امرأة)']], gem: 'An Italian man speaking natural Italian' },
    'pt-br': { lg: 'pt', name: 'برتغالية البرازيل', nat: 'برازيلي', who: 'Brazilian', lang: 'natural Brazilian Portuguese', locale: 'pt-BR', voices: [['pt-BR-AntonioNeural', 'Antônio (رجل)'], ['pt-BR-FranciscaNeural', 'Francisca (امرأة)']], gem: 'A Brazilian man speaking natural Portuguese' },
    'pt-pt': { lg: 'pt', name: 'برتغالية البرتغال', nat: 'برتغالي', who: 'Portuguese', lang: 'natural European Portuguese', locale: 'pt-PT', voices: [['pt-PT-DuarteNeural', 'Duarte (رجل)'], ['pt-PT-RaquelNeural', 'Raquel (امرأة)']], gem: 'A Portuguese man speaking natural Portuguese' },
    'tr-tr': { lg: 'tr', name: 'التركية', nat: 'تركي', who: 'Turkish', lang: 'natural spoken Turkish', locale: 'tr-TR', voices: [['tr-TR-AhmetNeural', 'Ahmet (رجل)'], ['tr-TR-EmelNeural', 'Emel (امرأة)']], gem: 'A Turkish man speaking natural Turkish' },
    'ru-ru': { lg: 'ru', name: 'الروسية', nat: 'روسي', who: 'Russian', lang: 'natural spoken Russian', locale: 'ru-RU', voices: [['ru-RU-DmitryNeural', 'Dmitry (رجل)'], ['ru-RU-SvetlanaNeural', 'Svetlana (امرأة)']], gem: 'A Russian man speaking natural Russian' },
    'hi-in': { lg: 'hi', name: 'الهندية', nat: 'هندي', who: 'Indian', lang: 'natural conversational Hindi', locale: 'hi-IN', voices: [['hi-IN-MadhurNeural', 'Madhur (رجل)'], ['hi-IN-SwaraNeural', 'Swara (امرأة)']], gem: 'An Indian man speaking natural Hindi' },
    'ur-pk': { lg: 'ur', name: 'الأردية', nat: 'باكستاني', who: 'Pakistani', lang: 'natural conversational Urdu', locale: 'ur-PK', voices: [['ur-PK-AsadNeural', 'Asad (رجل)'], ['ur-PK-UzmaNeural', 'Uzma (امرأة)']], gem: 'A Pakistani man speaking natural Urdu' },
    'fa-ir': { lg: 'fa', name: 'الفارسية', nat: 'إيراني', who: 'Iranian', lang: 'natural conversational Persian (Farsi)', locale: 'fa-IR', voices: [['fa-IR-FaridNeural', 'Farid (رجل)'], ['fa-IR-DilaraNeural', 'Dilara (امرأة)']], gem: 'An Iranian man speaking natural Persian' },
    'id-id': { lg: 'id', name: 'الإندونيسية', nat: 'إندونيسي', who: 'Indonesian', lang: 'natural spoken Indonesian', locale: 'id-ID', voices: [['id-ID-ArdiNeural', 'Ardi (رجل)'], ['id-ID-GadisNeural', 'Gadis (امرأة)']], gem: 'An Indonesian man speaking natural Indonesian' },
    'zh-cn': { lg: 'zh', name: 'الصينية', nat: 'صيني', who: 'Chinese', lang: 'natural spoken Mandarin Chinese (simplified characters)', locale: 'zh-CN', voices: [['zh-CN-YunxiNeural', 'Yunxi (رجل)'], ['zh-CN-XiaoxiaoNeural', 'Xiaoxiao (امرأة)']], gem: 'A Chinese man speaking natural Mandarin' },
    'ja-jp': { lg: 'ja', name: 'اليابانية', nat: 'ياباني', who: 'Japanese', lang: 'natural spoken Japanese', locale: 'ja-JP', voices: [['ja-JP-KeitaNeural', 'Keita (رجل)'], ['ja-JP-NanamiNeural', 'Nanami (امرأة)']], gem: 'A Japanese man speaking natural Japanese' },
  };
  /* اللغات: كل قناة لها لغة، واللهجات المعروضة تتبعها */
  const LANGS = {
    ar: { name: 'العربية', en: 'Arabic', rtl: true },
    fr: { name: 'الفرنسية (Français)', en: 'French' },
    en: { name: 'الإنجليزية (English)', en: 'English' },
    es: { name: 'الإسبانية (Español)', en: 'Spanish' },
    de: { name: 'الألمانية (Deutsch)', en: 'German' },
    it: { name: 'الإيطالية (Italiano)', en: 'Italian' },
    pt: { name: 'البرتغالية (Português)', en: 'Portuguese' },
    tr: { name: 'التركية (Türkçe)', en: 'Turkish' },
    ru: { name: 'الروسية (Русский)', en: 'Russian' },
    hi: { name: 'الهندية (हिन्दी)', en: 'Hindi' },
    ur: { name: 'الأردية (اردو)', en: 'Urdu', rtl: true },
    fa: { name: 'الفارسية (فارسی)', en: 'Persian', rtl: true },
    id: { name: 'الإندونيسية (Indonesia)', en: 'Indonesian' },
    zh: { name: 'الصينية (中文)', en: 'Chinese' },
    ja: { name: 'اليابانية (日本語)', en: 'Japanese' },
  };
  const lgOf = k => DIALECTS[k]?.lg || 'ar';
  /* نصوص ثابتة تظهر داخل الفيديو (الاشتراك، التعليقات…) بلغة القناة */
  const UI = {
    'اشترك': { en: 'SUBSCRIBE', fr: "S'ABONNER", es: 'SUSCRÍBETE', de: 'ABONNIEREN', it: 'ISCRIVITI', pt: 'INSCREVA-SE', tr: 'ABONE OL', ru: 'ПОДПИСАТЬСЯ', id: 'SUBSCRIBE' },
    'تم الاشتراك ✓': { en: 'SUBSCRIBED ✓', fr: 'ABONNÉ ✓', es: 'SUSCRITO ✓', de: 'ABONNIERT ✓', it: 'ISCRITTO ✓', pt: 'INSCRITO ✓', tr: 'ABONE OLUNDU ✓', ru: 'ВЫ ПОДПИСАНЫ ✓' },
    'فعّل الجرس': { en: 'Turn on the bell', fr: 'Active la cloche', es: 'Activa la campana', de: 'Glocke aktivieren', it: 'Attiva la campanella', pt: 'Ative o sininho', tr: 'Bildirimleri aç', ru: 'Включи колокольчик' },
    'اكتب رأيك في التعليقات 👇': { en: 'Tell us in the comments 👇', fr: 'Dis-nous en commentaire 👇', es: 'Dínoslo en los comentarios 👇', de: 'Schreib es in die Kommentare 👇', it: 'Scrivilo nei commenti 👇', pt: 'Conta nos comentários 👇', tr: 'Yorumlara yaz 👇', ru: 'Напиши в комментариях 👇' },
    'التعليقات': { en: 'Comments', fr: 'Commentaires', es: 'Comentarios', de: 'Kommentare', it: 'Commenti', pt: 'Comentários', tr: 'Yorumlar', ru: 'Комментарии' },
    'أنت': { en: 'You', fr: 'Toi', es: 'Tú', de: 'Du', it: 'Tu', pt: 'Você', tr: 'Sen', ru: 'Вы' },
    '@أنت · الآن': { en: '@you · now', fr: '@toi · maintenant', es: '@tú · ahora', de: '@du · jetzt', it: '@tu · ora', pt: '@você · agora', tr: '@sen · şimdi', ru: '@вы · сейчас' },
    'لايك': { en: 'LIKE', fr: "J'AIME", es: 'ME GUSTA', de: 'LIKE', it: 'MI PIACE', pt: 'CURTIR', tr: 'BEĞEN', ru: 'ЛАЙК' },
    '؟': { en: '?', fr: '?' },
  };
  const dialectsOf = lg => Object.keys(DIALECTS).filter(k => lgOf(k) === lg);
  /* شخصية المقدّم: تغيّر طريقة السكريبت كلها ({who} الجنسية بالإنجليزية، {nat} بالعربية، {name} الاسم) */
  const PERSONAS = {
    none: { name: 'مقدّم القناة (بدون تعريف)', en: '' },
    journalist: { name: 'صحفي / مراسل', en: 'The narrator is a {who} journalist named "{name}". In the first two lines he introduces himself in the chosen dialect, e.g. "أنا {name}، صحفي {nat}…" (adapt to the dialect), then reports like a field journalist: what he checked, the sources, the numbers, people\'s reactions, in a careful and credible tone.' },
    tourist: { name: 'سائح / زائر', en: 'The narrator is a {who} tourist named "{name}" visiting the place of the story. In the first lines he introduces himself, e.g. "أنا {name}، سائح {nat}…" (adapt to the dialect), then tells in first person, travel-vlog style, what he sees, hears, tastes and feels there, and compares it with his own country. Keep facts accurate; personal impressions are his.' },
    local: { name: 'ابن البلد / شاهد', en: 'The narrator is "{name}", a local person from the place where the story happens, speaking in the chosen dialect. He introduces himself in the first lines and explains the story as an insider who knows the people, customs and details.' },
    expert: { name: 'خبير / مختص', en: 'The narrator is "{name}", a {who} specialist in the topic. He introduces himself and his specialty in the first lines (e.g. "أنا {name}، مختص في…"), explains the causes and the details clearly and gives practical advice.' },
    storyteller: { name: 'حكواتي (راوي قصص)', en: 'The narrator is "{name}", a {who} storyteller. He introduces himself briefly and tells the topic as a gripping cinematic story with suspense, characters and twists, while keeping facts accurate.' },
    doctor: { name: 'طبيب', en: 'The narrator is "Dr. {name}", a {who} medical doctor. He introduces himself in the first lines (e.g. "أنا الدكتور {name}…"), explains health topics with accurate, evidence-based and safe information in simple words, never gives dangerous advice, and reminds viewers to consult their own doctor.' },
    teacher: { name: 'معلّم / شارح', en: 'The narrator is "{name}", a {who} teacher who explains step by step with simple examples, analogies and quick summaries, like a great lesson.' },
    chef: { name: 'طبّاخ / شيف', en: 'The narrator is "Chef {name}", a {who} chef. He introduces himself, talks about ingredients, taste, smells and kitchen secrets with passion and gives clear practical steps.' },
    tech: { name: 'مراجع تقنية', en: 'The narrator is "{name}", a {who} tech reviewer. He introduces himself and explains devices, apps and technology with honest pros and cons, comparisons and clear recommendations.' },
    sports: { name: 'معلّق رياضي', en: 'The narrator is "{name}", a {who} sports commentator with an exciting, energetic commentator voice, numbers, records and dramatic moments.' },
    historian: { name: 'مؤرخ / راوي تاريخ', en: 'The narrator is "{name}", a {who} historian who tells history accurately like a documentary: dates, places, people and turning points, with suspense.' },
    documentary: { name: 'راوي وثائقي', en: 'The narrator is a calm, deep documentary narrator (no self-introduction needed) in the style of big nature/history documentaries: cinematic, precise, emotional.' },
    coach: { name: 'مدرّب تحفيزي', en: 'The narrator is "{name}", a {who} motivational coach who speaks with energy and empathy, gives practical steps and pushes the viewer to act.' },
    comedian: { name: 'كوميدي ساخر', en: 'The narrator is "{name}", a {who} funny presenter who explains the topic with light, respectful humor, jokes and funny comparisons while keeping the facts correct.' },
    kids: { name: 'مقدّم للأطفال', en: 'The narrator is "{name}", a friendly presenter for children: very simple words, short sentences, questions to the kids, fun and educational, 100% child-safe.' },
    reviewer: { name: 'مراجع منتجات', en: 'The narrator is "{name}", a {who} product reviewer who tests things honestly: price, quality, pros, cons and who it is good for.' },
    business: { name: 'محلل أعمال واقتصاد', en: 'The narrator is "{name}", a {who} business and economy analyst who explains markets, prices and money topics with numbers and context, and reminds that it is not financial advice.' },
    gamer: { name: 'لاعب / مراجع ألعاب', en: 'The narrator is "{name}", a {who} gamer with gamer energy, tips, secrets and reactions.' },
    traveler: { name: 'رحّالة', en: 'The narrator is "{name}", a {who} traveler who explores places: history, food, prices, people and tips for visitors, in first person.' },
    scientist: { name: 'عالِم / مبسّط علوم', en: 'The narrator is "{name}", a {who} science communicator who explains science accurately with amazing facts and simple analogies.' },
    breeder: { name: 'مربّي / فلاح خبير', en: 'The narrator is "{name}", an experienced {who} farmer and breeder who raises these animals himself. He introduces himself in the first lines (e.g. "أنا {name}، مربّي…"), and shares practical field experience ("من تجربتي…"), real mistakes and tips.' },
    vet: { name: 'طبيب بيطري', en: 'The narrator is "{name}", a {who} veterinarian. He introduces himself in the first lines (e.g. "أنا الدكتور {name}، طبيب بيطري…"), gives medically sound, safe advice, explains symptoms and prevention, and reminds viewers to consult a vet for serious cases.' },
    investigator: { name: 'محقّق / باحث في الألغاز', en: 'The narrator is "{name}", a {who} investigator who tells mysteries, crimes and unsolved cases step by step like a detective, with suspense, evidence and timeline, without gore.' },
    psychologist: { name: 'أخصائي نفسي', en: 'The narrator is "{name}", a {who} psychologist who explains feelings, behavior and relationships with empathy, real examples and practical advice, without diagnosing anyone.' },
    nutritionist: { name: 'أخصائي تغذية', en: 'The narrator is "{name}", a {who} nutritionist who explains food, diets and healthy habits with science, simple numbers and practical tips.' },
    pharmacist: { name: 'صيدلي', en: 'The narrator is "Dr. {name}", a {who} pharmacist who explains medicines, side effects and safe use clearly, always advising to consult a doctor.' },
    lawyer: { name: 'محامٍ / مستشار قانوني', en: 'The narrator is "{name}", a {who} lawyer who explains laws, rights and procedures simply, with real cases and clear steps.' },
    imam: { name: 'شيخ / داعية', en: 'The narrator is "Sheikh {name}", a {who} Islamic preacher who speaks with calm wisdom, Quran and authentic hadith (only well-known authentic ones), stories of the prophets and companions, and practical lessons.' },
    mechanic: { name: 'خبير سيارات / ميكانيكي', en: 'The narrator is "{name}", a {who} car expert who explains cars, faults, maintenance and buying tips with practical experience.' },
    grandpa: { name: 'الجدّ الحكيم (حكايات)', en: 'The narrator is "{name}", a warm {who} grandfather telling stories and life lessons in a cozy, wise and emotional way.' },
    entrepreneur: { name: 'رائد أعمال', en: 'The narrator is "{name}", a {who} entrepreneur who shares business ideas, success and failure stories, money lessons and practical steps.' },
    fitness: { name: 'مدرّب رياضي', en: 'The narrator is "Coach {name}", a {who} fitness coach who explains training, health and motivation with clear practical routines.' },
    farmer: { name: 'مهندس زراعي', en: 'The narrator is "{name}", a {who} agricultural engineer who explains planting, soil, irrigation and crops scientifically and practically.' },
    reporter: { name: 'مراسل ميداني', en: 'The narrator is "{name}", a {who} field reporter speaking as if on location, describing what he sees, interviews and facts.' },
  };
  const LIST = {
    farm: {
      id: 'farm', name: 'Fadi Farm', logo: 'icons/farm-logo.png', tile: 'icons/farm-logo.png',
      accent: '#FFD23F', theme: '#2f6b3a',
      context: 'قناة Fadi Farm: الزراعة، الحيوانات، الحياة الريفية',
      niche: 'a family-friendly YouTube channel about farm animals (chickens, ducks, turkeys, goats, rabbits) and rural life in Egypt',
      lang: 'Egyptian Arabic dialect (عامية مصرية)',
      visual: 'farm animals, farming or rural life',
      examples: '"goat grazing hillside", "farmer planting seedlings", "sunrise over wheat field"',
      setting: 'a rural Egyptian farm (mud-brick coop, straw, green fields)',
      montage: 'calm', topicFilter: true,
      providers: ['pexels', 'pixabay', 'wikimedia', 'inaturalist', 'wikipedia', 'openverse', 'flickr', 'unsplash', 'europeana', 'archive', 'loc', 'nasa'],
      providersOff: ['nasa', 'loc'],
      cta: 'ولو عايز تعرف الحكاية كاملة، الفيديو كامل تحت. ادخل شوفه دلوقتي!',
      yt: '@fadifarm',
      dialects: ['eg', 'ae', 'ma', 'dz', 'msa', 'white', 'sa', 'kw', 'qa', 'bh', 'om', 'ye', 'iq', 'sy', 'lb', 'jo', 'ps', 'tn', 'ly', 'sd', 'mr'],   // القديمة أولاً ثم كل اللهجات
      personas: ['none', 'breeder', 'vet', 'expert', 'storyteller', 'tourist', 'farmer', 'grandpa', 'documentary', 'teacher', 'kids', 'nutritionist'],
      voice: 'a warm, funny and passionate {who} storyteller who loves animals, talks to the viewer like a close friend ("يا جماعة", "بصوا بقى"), mixes useful facts with surprising stories and emotional moments',
      scriptRules: 'practical, accurate and safe animal-care information; surprising facts; small stories and real-life examples; tips the viewer can apply at home',
      ideaCats: { pets: 'الحيوانات الأليفة', farm: 'حيوانات المزرعة', wild: 'حيوانات غريبة ومدهشة', all: 'كل الأفكار' },
      ideaFocus: { pets: '(cats, dogs, rabbits, parrots, budgies, hamsters, turtles, fish, pet chickens and ducks: care, behavior, funny facts, mistakes owners make, breeds, health signs)' },
      ideaDefault: 'pets',
    },
    majra: {
      id: 'majra', name: 'مجرى', logo: 'icons/majra-overlay.png', tile: 'icons/majra-tile.jpg',
      accent: '#2E8BFF', theme: '#0a1530',
      context: 'قناة مجرى: محتوى صحفي بلهجة مصرية عن الجزائر والعالم: أحداث، عادات وتقاليد لافتة، قضايا البلد، الأسعار والمعيشة، والترندات',
      niche: 'an Arabic journalism YouTube channel that tells Arab audiences about Algeria and the world: current events, striking customs and traditions, social issues inside the country, prices of products and cost of living, unusual stories and fresh trends',
      lang: 'Egyptian Arabic dialect (عامية مصرية)',
      visual: 'the news topic itself: its place, people, objects, events or atmosphere',
      examples: '"Algiers city skyline", "football stadium crowd", "smartphone close up", "breaking news studio", "stock market screen"',
      setting: 'a dramatic cinematic news setting related to the topic',
      montage: 'strong', topicFilter: false,
      providers: ['pexels', 'pixabay', 'wikipedia', 'wikimedia', 'openverse', 'flickr', 'unsplash', 'archive', 'loc', 'europeana', 'nasa', 'inaturalist'],
      providersOff: ['inaturalist'],
      cta: 'والقصة الكاملة في الفيديو تحت. ادخل شوفها دلوقتي!',
      yt: '',
      ideaCats: { algeria: 'أحداث وقضايا الجزائر', customs: 'عادات وتقاليد لافتة', prices: 'الأسعار والمعيشة', world: 'الجزائر والعالم', trends: 'من الترندات', all: 'كل الأفكار' },
      ideaDefault: 'algeria',
      ideaFocus: {
        algeria: '(what Algerians are talking about now: decisions, laws, scandals, achievements, viral stories, controversies, explained simply for Egyptians)',
        customs: '(surprising Algerian traditions: weddings, food, Ramadan, Eid, clothing, regions like Kabylie, Sahara, Oran, Constantine; compare with Egypt)',
        prices: '(real current prices in Algeria: food, cars, rent, gold, fuel, salaries, the dinar, compared with Egypt; use fresh numbers from search and say where they come from)',
        world: '(how world events affect Algeria, Algeria-Egypt relations and comparisons, Algerians abroad, big international stories)',
        trends: '(build strong angles from the current trending searches listed above)',
      },
      dialects: ['eg', 'ae', 'ma', 'dz', 'msa', 'white', 'sa', 'kw', 'qa', 'bh', 'om', 'ye', 'iq', 'sy', 'lb', 'jo', 'ps', 'tn', 'ly', 'sd', 'mr'],   // القديمة أولاً ثم كل اللهجات
      personas: ['none', 'journalist', 'tourist', 'local', 'expert', 'storyteller', 'reporter', 'investigator', 'historian', 'traveler', 'business', 'documentary', 'lawyer', 'comedian'],
      voice: 'a sharp {who} journalist and storyteller who explains Algeria and the world like a gripping investigation: dramatic pauses, strong hooks, comparisons with the viewer\'s own country, "استنى استنى… لسه ما قلتلكش أغرب حاجة", while staying factual and respectful',
      scriptRules: 'journalistic, factual and respectful of Algerians; explain what happened, the background, numbers and prices with their source, people\'s reactions, comparisons with other Arab countries and what might happen next; never invent numbers, names or quotes; say "حسب التقارير" when unsure',
    },
  };
  /* ---------- القنوات المضافة من المستخدم: عامة لأي محتوى، بكل الأدوات واللهجات والأساليب ---------- */
  const ALL_PERSONAS = Object.keys(PERSONAS);
  const GENERAL_PROVIDERS = ['pexels', 'pixabay', 'wikimedia', 'wikipedia', 'openverse', 'unsplash', 'flickr', 'archive', 'coverr', 'wellcome', 'openi', 'smithsonian', 'met', 'aic', 'cma', 'loc', 'europeana', 'nasa', 'inaturalist', 'rijks', 'dpla', 'giphy'];
  function custom(c) {
    const lg = c.lang || lgOf(c.dialect), all = dialectsOf(LANGS[lg] ? lg : 'ar');
    const ds = [...new Set([c.dialect, ...all])].filter(x => DIALECTS[x] && lgOf(x) === lg);
    if (!ds.length) ds.push(all[0] || 'eg');
    const P = c.profile || {};
    // المقدّمون مرتّبون حسب محتوى القناة (من التحليل)، والباقي بعدهم
    const ps = [...new Set(['none', ...(P.personas || []).filter(x => PERSONAS[x]), ...ALL_PERSONAS])];
    const base = {
      id: c.id, name: c.name, logo: c.logo || 'icons/icon-512.png', tile: c.logo || 'icons/icon-512.png', custom: true, trends: true,
      accent: c.accent || '#8B5CF6', theme: '#120d24',
      context: `قناة ${c.name}: ${c.desc || ''}`,
      niche: `a YouTube channel named "${c.name}" about: ${c.desc || 'general topics'}`,
      lang: DIALECTS[ds[0]].lang,
      visual: 'the exact real subject of each sentence: its real place, objects, actions, men or animals and atmosphere',
      examples: '"doctor explaining x-ray", "fresh vegetables on wooden table", "city street at night", "man typing on laptop", "mountain road aerial"',
      setting: 'a cinematic setting that exactly fits the topic',
      montage: c.montage || 'calm', topicFilter: false,
      providers: GENERAL_PROVIDERS, providersOff: ['nasa', 'inaturalist', 'met', 'aic', 'cma', 'rijks', 'dpla', 'giphy', 'openi', 'europeana'],
      cta: lg === 'ar' ? 'والفيديو الكامل على القناة!' : lg === 'fr' ? 'La vidéo complète est juste en dessous !' : lg === 'en' ? 'Watch the full video below!' : 'Full video below!', langCode: lg,
      yt: c.yt || '',
      dialects: ds, personas: ['none', ...ALL_PERSONAS.filter(x => x !== 'none')],
      voice: 'an engaging {who} YouTube presenter who explains the topic clearly with energy, short stories, examples and a friendly tone',
      scriptRules: 'accurate, useful and engaging content about the topic; clear explanation, real examples, surprising facts and practical takeaways; never invent facts, numbers, names or quotes',
      ideaCats: { trend: 'رائج الآن', howto: 'شرح وتعليم', stories: 'قصص وتجارب', lists: 'قوائم وأرقام', myths: 'خرافات وحقائق', all: 'كل الأفكار' },
      ideaFocus: { trend: '(what people search and talk about right now in this niche)', howto: '(practical step-by-step explainers and tutorials)', stories: '(real stories, experiences and case studies)', lists: '(top 5/10 lists, comparisons and numbers)', myths: '(common myths vs scientific truth)' },
      ideaDefault: 'all',
    };
    if (!c.profile) return base;
    // تحليل القناة: يجعل الأفكار والسكريبتات والصور مناسبة لمحتواها بالضبط
    return Object.assign(base, {
      niche: P.niche || base.niche,
      context: `قناة ${c.name}: ${c.desc || ''}${P.audience ? ' · الجمهور: ' + P.audience : ''}`,
      visual: P.visual || base.visual, examples: P.examples || base.examples, setting: P.setting || base.setting,
      voice: P.voice || base.voice, scriptRules: P.scriptRules || base.scriptRules,
      ideaCats: P.ideaCats && Object.keys(P.ideaCats).length ? { ...P.ideaCats, all: 'كل الأفكار' } : base.ideaCats,
      ideaFocus: P.ideaFocus || base.ideaFocus, topics: P.topics || [], audience: P.audience || '', style: P.style || '',
      personas: ps,
    });
  }
  let customs = [];
  try { customs = JSON.parse(localStorage.getItem('ff.channels') || '[]') || []; } catch {}
  customs.forEach(c => { if (c?.id && !LIST[c.id]) LIST[c.id] = custom(c); });
  LIST.majra.trends = true;
  /* قناتاك الأساسيتان: اسم وصورة تختارهما أنت (بدون حذف) */
  const ORIG = { farm: { name: LIST.farm.name, tile: LIST.farm.tile, logo: LIST.farm.logo }, majra: { name: LIST.majra.name, tile: LIST.majra.tile } };
  let over = {}; try { over = JSON.parse(localStorage.getItem('ff.chOverride') || '{}') || {}; } catch {}
  const applyOver = () => ['farm', 'majra'].forEach(k => {
    const o = over[k] || {}, L = LIST[k];
    L.name = o.name || ORIG[k].name; L.tile = o.img || ORIG[k].tile;
    if (k === 'farm') L.logo = o.img || ORIG.farm.logo;      // مجرى: لوغو الفيديو يبقى كما هو
  });
  applyOver();
  const saveCustoms = () => { try { localStorage.setItem('ff.channels', JSON.stringify(customs)); } catch { throw new Error('لا توجد مساحة كافية لحفظ القناة (صغّر الصورة)'); } };

  let id = 'farm';
  try { id = localStorage.getItem('ff.channel') || 'farm'; } catch {}
  if (!LIST[id]) id = 'farm';
  /* اللهجة المختارة لهذه القناة */
  const dialectId = () => { let d = ''; try { d = Settings.get().dialect || ''; } catch {} const ok = LIST[id].dialects || ['eg']; return ok.includes(d) ? d : ok[0]; };
  return {
    LIST, DIALECTS, PERSONAS,
    /* وصف شخصية المقدّم للسكريبت */
    persona(id, name) {
      const p = PERSONAS[id]; if (!p || !p.en) return '';
      const d = DIALECTS[dialectId()];
      let noName = false; try { noName = Settings.get().noName === true; } catch {}
      if (noName) {   // بدون اسم: يقدّم دوره فقط ولا يُذكر أي اسم في الفيديو
        return p.en.replace(/(named |called )?"(Dr\. |Chef |Sheikh |Coach )?\{name\}"(, )?/g, '').replace(/\(e\.g\.[^)]*\{name\}[^)]*\)/g, '').replace(/\{name\}/g, '').replace(/\{who\}/g, d.who).replace(/\{nat\}/g, d.nat)
          + ' IMPORTANT: the narrator has NO name. Never say, invent or use any personal name for him; if he introduces himself, he mentions only his role (e.g. "أنا صحفي" / "كطبيب").';
      }
      return p.en.replace(/\{who\}/g, d.who).replace(/\{nat\}/g, d.nat).replace(/\{name\}/g, name || 'فادي');
    },
    LANGS, dialectsOf, lgOf,
    get lg() { return lgOf(dialectId()); },
    get rtl() { return !!LANGS[lgOf(dialectId())]?.rtl; },
    get dir() { return LANGS[lgOf(dialectId())]?.rtl ? 'rtl' : 'ltr'; },
    get langEn() { return LANGS[lgOf(dialectId())]?.en || 'Arabic'; },
    /* يكيّف أي وصف (prompt) للغة القناة: كل نص للمشاهد بلغة القناة وليس بالعربية */
    loc(p) {
      const lg = lgOf(dialectId()); if (lg === 'ar' || typeof p !== 'string' || p.startsWith('IMPORTANT LANGUAGE RULE')) return p;
      const L = LANGS[lg].en;
      return `IMPORTANT LANGUAGE RULE: this channel is in ${L} (${DIALECTS[dialectId()].lang}). Every text meant for viewers (titles, scripts, narration, captions, on-screen texts, thumbnail texts, descriptions, chapters, hashtags) must be written in ${L}, never in Arabic. Ignore any Arabic examples below and produce their ${L} equivalent.\n\n` + p.replace(/\bArabic\b/g, L);
    },
    /* وصف الصور (Flow): نفس الوصف لكن الكتابة على الصورة بلغة القناة */
    loc0(p) { const lg = lgOf(dialectId()); return lg === 'ar' || typeof p !== 'string' ? p : p.replace(/\bArabic\b/g, LANGS[lg].en).replace(/\b(Lalezar|Cairo Black)\b/g, 'Anton'); },
    t(ar) { const lg = lgOf(dialectId()); if (lg === 'ar') return ar; const m = UI[ar]; return m ? (m[lg] || m.en || (ar === '؟' ? '?' : ar)) : ar; },
    get dialect() { return DIALECTS[dialectId()]; },
    get dialectId() { return dialectId(); },
    get lang() { return DIALECTS[dialectId()].lang; },
    get voice() { return (LIST[id].voice || '').replace(/\{who\}/g, DIALECTS[dialectId()].who); },
    get id() { return id; },
    get cur() { return LIST[id]; },
    /* مفتاح تخزين محلي خاص بالقناة (قناة المزرعة تحتفظ بالمفاتيح القديمة كما هي) */
    key(k) { return id === 'farm' ? k : `${k}.${id}`; },
    set(n) { id = LIST[n] ? n : 'farm'; try { localStorage.setItem('ff.channel', id); } catch {} },
    get customs() { return customs.slice(); },
    /* تعديل اسم وصورة Fadi Farm أو مجرى؛ name/img فارغ = الأصلي */
    setBuiltin(k, { name, img }) {
      over[k] = { name: (name || '').trim(), img: img || '' };
      if (!over[k].name && !over[k].img) delete over[k];
      try { localStorage.setItem('ff.chOverride', JSON.stringify(over)); } catch { throw new Error('الصورة كبيرة جداً، اختر صورة أصغر'); }
      applyOver();
    },
    builtin(k) { return { ...(over[k] || {}), origName: ORIG[k].name, origImg: ORIG[k].tile }; },
    /* إضافة/تعديل قناة: {name, desc, logo(dataURL), accent, dialect, montage, yt} */
    saveCustom(c) {
      const isNew = !c.id; if (isNew) c.id = 'c' + Date.now().toString(36);
      const i = customs.findIndex(x => x.id === c.id);
      if (i >= 0) customs[i] = { ...customs[i], ...c }; else customs.push(c);
      saveCustoms(); LIST[c.id] = custom(customs.find(x => x.id === c.id));
      return c.id;
    },
    removeCustom(cid) {
      customs = customs.filter(x => x.id !== cid); saveCustoms(); delete LIST[cid];
      try { Object.keys(localStorage).filter(k => k.endsWith('.' + cid)).forEach(k => localStorage.removeItem(k)); } catch {}
      if (id === cid) { id = 'farm'; try { localStorage.setItem('ff.channel', 'farm'); } catch {} }
    },
  };
})();
