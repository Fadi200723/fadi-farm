/* Fadi — القنوات: لكل قناة هويتها ومصادرها وأسلوب مونتاجها ومشروعها المستقل */
'use strict';

const Channel = (() => {
  /* اللهجات: لغة الكتابة + أصوات Microsoft Azure + أسلوب صوت Gemini */
  const DIALECTS = {
    eg: { name: 'المصرية', nat: 'مصري', who: 'Egyptian', lang: 'Egyptian Arabic dialect (عامية مصرية)', locale: 'ar-EG', voices: [['ar-EG-ShakirNeural', 'شاكر (رجل)'], ['ar-EG-SalmaNeural', 'سلمى (امرأة)']], gem: 'راجل مصري بيحكي باللهجة المصرية العامية' },
    ae: { name: 'الإماراتية', nat: 'إماراتي', who: 'Emirati', lang: 'Emirati Arabic dialect (اللهجة الإماراتية), natural Gulf vocabulary like "شو", "وايد", "هالشي", "زين"', locale: 'ar-AE', voices: [['ar-AE-HamdanNeural', 'حمدان (رجل)'], ['ar-AE-FatimaNeural', 'فاطمة (امرأة)']], gem: 'رجل إماراتي يتكلم باللهجة الإماراتية الخليجية' },
    ma: { name: 'المغربية', nat: 'مغربي', who: 'Moroccan', lang: 'Moroccan Arabic Darija (الدارجة المغربية) written in Arabic letters, natural words like "واش", "بزاف", "دابا", "شنو", while staying understandable to other Arabs', locale: 'ar-MA', voices: [['ar-MA-JamalNeural', 'جمال (رجل)'], ['ar-MA-MounaNeural', 'منى (امرأة)']], gem: 'رجل مغربي يتكلم بالدارجة المغربية' },
    dz: { name: 'الجزائرية', nat: 'جزائري', who: 'Algerian', lang: 'Algerian Arabic Darja (الدارجة الجزائرية) written in Arabic letters, natural words like "واش", "بزاف", "درك", "كيفاش", understandable to other Arabs', locale: 'ar-DZ', voices: [['ar-DZ-IsmaelNeural', 'إسماعيل (رجل)'], ['ar-DZ-AminaNeural', 'أمينة (امرأة)']], gem: 'رجل جزائري يتكلم بالدارجة الجزائرية' },
    msa: { name: 'الفصحى', nat: 'عربي', who: 'Arab', lang: 'simple, lively Modern Standard Arabic (فصحى مبسطة)', locale: 'ar-SA', voices: [['ar-SA-HamedNeural', 'حامد (رجل)'], ['ar-SA-ZariyahNeural', 'زارية (امرأة)']], gem: 'مذيع عربي يتكلم بالفصحى المبسطة' },
  };
  /* شخصية المقدّم: تغيّر طريقة السكريبت كلها ({who} الجنسية بالإنجليزية، {nat} بالعربية، {name} الاسم) */
  const PERSONAS = {
    none: { name: 'مقدّم القناة (بدون تعريف)', en: '' },
    journalist: { name: 'صحفي / مراسل', en: 'The narrator is a {who} journalist named "{name}". In the first two lines he introduces himself in the chosen dialect, e.g. "أنا {name}، صحفي {nat}…" (adapt to the dialect), then reports like a field journalist: what he checked, the sources, the numbers, people\'s reactions, in a careful and credible tone.' },
    tourist: { name: 'سائح / زائر', en: 'The narrator is a {who} tourist named "{name}" visiting the place of the story. In the first lines he introduces himself, e.g. "أنا {name}، سائح {nat}…" (adapt to the dialect), then tells in first person, travel-vlog style, what he sees, hears, tastes and feels there, and compares it with his own country. Keep facts accurate; personal impressions are his.' },
    local: { name: 'ابن البلد / شاهد', en: 'The narrator is "{name}", a local person from the place where the story happens, speaking in the chosen dialect. He introduces himself in the first lines and explains the story as an insider who knows the people, customs and details.' },
    expert: { name: 'خبير / مختص', en: 'The narrator is "{name}", a {who} specialist in the topic. He introduces himself and his specialty in the first lines (e.g. "أنا {name}، مختص في…"), explains the causes and the details clearly and gives practical advice.' },
    storyteller: { name: 'حكواتي (راوي قصص)', en: 'The narrator is "{name}", a {who} storyteller. He introduces himself briefly and tells the topic as a gripping cinematic story with suspense, characters and twists, while keeping facts accurate.' },
    breeder: { name: 'مربّي / فلاح خبير', en: 'The narrator is "{name}", an experienced {who} farmer and breeder who raises these animals himself. He introduces himself in the first lines (e.g. "أنا {name}، مربّي…"), and shares practical field experience ("من تجربتي…"), real mistakes and tips.' },
    vet: { name: 'طبيب بيطري', en: 'The narrator is "{name}", a {who} veterinarian. He introduces himself in the first lines (e.g. "أنا الدكتور {name}، طبيب بيطري…"), gives medically sound, safe advice, explains symptoms and prevention, and reminds viewers to consult a vet for serious cases.' },
  };
  const LIST = {
    farm: {
      id: 'farm', name: 'Fadi Farm', logo: 'icons/farm-logo.png', tile: 'icons/farm-logo.png',
      accent: '#FFD23F', theme: '#2f6b3a',
      context: 'قناة Fadi Farm: الزراعة، الحيوانات، الحياة الريفية',
      niche: 'a family-friendly YouTube channel about farm animals (chickens, ducks, turkeys, goats, rabbits) and rural life in Egypt',
      lang: 'Egyptian Arabic dialect (عامية مصرية)',
      visual: 'farm animals, farming or rural life',
      examples: '"goat grazing hillside", "farmer planting seedlings", "sunrise over wheat field"',
      setting: 'a rural Egyptian farm (mud-brick coop, straw, green fields)',
      montage: 'calm', topicFilter: true,
      providers: ['pexels', 'pixabay', 'wikimedia', 'inaturalist', 'wikipedia', 'openverse', 'flickr', 'unsplash', 'europeana', 'archive', 'loc', 'nasa'],
      providersOff: ['nasa', 'loc'],
      cta: 'ولو عايز تعرف الحكاية كاملة، الفيديو كامل تحت. ادخل شوفه دلوقتي!',
      yt: '@fadifarm',
      dialects: ['eg', 'ae', 'ma', 'dz', 'msa'],
      personas: ['none', 'breeder', 'vet', 'expert', 'storyteller', 'tourist'],
      voice: 'a warm, funny and passionate {who} storyteller who loves animals, talks to the viewer like a close friend ("يا جماعة", "بصوا بقى"), mixes useful facts with surprising stories and emotional moments',
      scriptRules: 'practical, accurate and safe animal-care information; surprising facts; small stories and real-life examples; tips the viewer can apply at home',
      ideaCats: { pets: 'الحيوانات الأليفة', farm: 'حيوانات المزرعة', wild: 'حيوانات غريبة ومدهشة', all: 'كل الأفكار' },
      ideaFocus: { pets: '(cats, dogs, rabbits, parrots, budgies, hamsters, turtles, fish, pet chickens and ducks: care, behavior, funny facts, mistakes owners make, breeds, health signs)' },
      ideaDefault: 'pets',
    },
    majra: {
      id: 'majra', name: 'مجرى', logo: 'icons/majra-overlay.png', tile: 'icons/majra-tile.jpg',
      accent: '#2E8BFF', theme: '#0a1530',
      context: 'قناة مجرى: محتوى صحفي بلهجة مصرية عن الجزائر والعالم: أحداث، عادات وتقاليد لافتة، قضايا البلد، الأسعار والمعيشة، والترندات',
      niche: 'an Arabic journalism YouTube channel that tells Arab audiences about Algeria and the world: current events, striking customs and traditions, social issues inside the country, prices of products and cost of living, unusual stories and fresh trends',
      lang: 'Egyptian Arabic dialect (عامية مصرية)',
      visual: 'the news topic itself: its place, people, objects, events or atmosphere',
      examples: '"Algiers city skyline", "football stadium crowd", "smartphone close up", "breaking news studio", "stock market screen"',
      setting: 'a dramatic cinematic news setting related to the topic',
      montage: 'strong', topicFilter: false,
      providers: ['pexels', 'pixabay', 'wikipedia', 'wikimedia', 'openverse', 'flickr', 'unsplash', 'archive', 'loc', 'europeana', 'nasa', 'inaturalist'],
      providersOff: ['inaturalist'],
      cta: 'والقصة الكاملة في الفيديو تحت. ادخل شوفها دلوقتي!',
      yt: '',
      ideaCats: { algeria: 'أحداث وقضايا الجزائر', customs: 'عادات وتقاليد لافتة', prices: 'الأسعار والمعيشة', world: 'الجزائر والعالم', trends: 'من الترندات', all: 'كل الأفكار' },
      ideaDefault: 'algeria',
      ideaFocus: {
        algeria: '(what Algerians are talking about now: decisions, laws, scandals, achievements, viral stories, controversies, explained simply for Egyptians)',
        customs: '(surprising Algerian traditions: weddings, food, Ramadan, Eid, clothing, regions like Kabylie, Sahara, Oran, Constantine; compare with Egypt)',
        prices: '(real current prices in Algeria: food, cars, rent, gold, fuel, salaries, the dinar, compared with Egypt; use fresh numbers from search and say where they come from)',
        world: '(how world events affect Algeria, Algeria-Egypt relations and comparisons, Algerians abroad, big international stories)',
        trends: '(build strong angles from the current trending searches listed above)',
      },
      dialects: ['eg', 'ae', 'ma', 'dz', 'msa'],
      personas: ['none', 'journalist', 'tourist', 'local', 'expert', 'storyteller'],
      voice: 'a sharp {who} journalist and storyteller who explains Algeria and the world like a gripping investigation: dramatic pauses, strong hooks, comparisons with the viewer\'s own country, "استنى استنى… لسه ما قلتلكش أغرب حاجة", while staying factual and respectful',
      scriptRules: 'journalistic, factual and respectful of Algerians; explain what happened, the background, numbers and prices with their source, people\'s reactions, comparisons with other Arab countries and what might happen next; never invent numbers, names or quotes; say "حسب التقارير" when unsure',
    },
  };
  let id = 'farm';
  try { id = localStorage.getItem('ff.channel') || 'farm'; } catch {}
  if (!LIST[id]) id = 'farm';
  /* اللهجة المختارة لهذه القناة */
  const dialectId = () => { let d = ''; try { d = Settings.get().dialect || ''; } catch {} const ok = LIST[id].dialects || ['eg']; return ok.includes(d) ? d : ok[0]; };
  return {
    LIST, DIALECTS, PERSONAS,
    /* وصف شخصية المقدّم للسكريبت */
    persona(id, name) {
      const p = PERSONAS[id]; if (!p || !p.en) return '';
      const d = DIALECTS[dialectId()];
      return p.en.replace(/\{who\}/g, d.who).replace(/\{nat\}/g, d.nat).replace(/\{name\}/g, name || 'فادي');
    },
    get dialect() { return DIALECTS[dialectId()]; },
    get dialectId() { return dialectId(); },
    get lang() { return DIALECTS[dialectId()].lang; },
    get voice() { return (LIST[id].voice || '').replace(/\{who\}/g, DIALECTS[dialectId()].who); },
    get id() { return id; },
    get cur() { return LIST[id]; },
    /* مفتاح تخزين محلي خاص بالقناة (قناة المزرعة تحتفظ بالمفاتيح القديمة كما هي) */
    key(k) { return id === 'farm' ? k : `${k}.${id}`; },
    set(n) { id = LIST[n] ? n : 'farm'; try { localStorage.setItem('ff.channel', id); } catch {} },
  };
})();
