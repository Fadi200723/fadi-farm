/* Fadi — مزامنة دقيقة للكتابة مع الصوت (مثل CapCut): التعرّف على الكلام بـ Whisper يعطي وقت كل كلمة بالضبط،
   ثم نطابق كلمات السكريبت مع الكلمات المسموعة، فتظهر كل كلمة لحظة نطقها وتبدأ المشاهد مع أول كلمة فيها.
   يعمل بمفتاح Groq (مجاني) أو ChatGPT (OpenAI). */
'use strict';

const Sync = (() => {
  const ENGINES = {
    groq: { name: 'Groq Whisper', url: 'https://api.groq.com/openai/v1/audio/transcriptions', models: ['whisper-large-v3-turbo', 'whisper-large-v3'] },
    openai: { name: 'ChatGPT Whisper', url: 'https://api.openai.com/v1/audio/transcriptions', models: ['whisper-1'] },
  };
  const order = () => {
    const k = Settings.get().keys, pref = Settings.get().aiPref;
    let o = ['groq', 'openai'].filter(x => k[x]?.trim());
    if (pref === 'openai' && o.includes('openai')) o = ['openai', ...o.filter(x => x !== 'openai')];
    return o;
  };
  const available = () => order().length > 0;

  /* ---------- الصوت: مقاطع WAV أحادية 16kHz مقطوعة عند الصمت (≤ 5 دقائق لكل مقطع) ---------- */
  function wav16(f32, sr) {
    const n = f32.length, buf = new ArrayBuffer(44 + n * 2), v = new DataView(buf);
    const W = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
    W(0, 'RIFF'); v.setUint32(4, 36 + n * 2, true); W(8, 'WAVE'); W(12, 'fmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
    v.setUint32(24, sr, true); v.setUint32(28, sr * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); W(36, 'data'); v.setUint32(40, n * 2, true);
    for (let i = 0; i < n; i++) { const x = Math.max(-1, Math.min(1, f32[i])); v.setInt16(44 + i * 2, x < 0 ? x * 0x8000 : x * 0x7fff, true); }
    return new Uint8Array(buf);
  }
  function chunks(buf, maxSec = 300) {
    const m = Align.monoBuf(buf), sr = m.sr, data = m.data, len = data.length / sr;
    const cuts = [0];
    while (len - cuts[cuts.length - 1] > maxSec) {
      const target = cuts[cuts.length - 1] + maxSec - 20, a = Math.floor(target * sr), seg = data.subarray(a, Math.min(data.length, a + 40 * sr));
      const gaps = Align.voiced(seg, sr); let cut = target + 20;
      for (let i = 0; i < gaps.length - 1; i++) { const g0 = gaps[i].b, g1 = gaps[i + 1].a; if (g1 - g0 > 0.25) { cut = target + (g0 + g1) / 2; break; } }
      cuts.push(cut);
    }
    cuts.push(len);
    return cuts.slice(0, -1).map((a, i) => ({ a, b: cuts[i + 1], bytes: wav16(data.subarray(Math.floor(a * sr), Math.floor(cuts[i + 1] * sr)), sr) }));
  }

  /* ---------- الإرسال (multipart) ---------- */
  function multipart(fields, file) {
    const bd = '----fadi' + Math.random().toString(36).slice(2), enc = new TextEncoder(), parts = [];
    for (const [k, v] of fields) parts.push(enc.encode(`--${bd}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`));
    parts.push(enc.encode(`--${bd}\r\nContent-Disposition: form-data; name="file"; filename="audio.wav"\r\nContent-Type: audio/wav\r\n\r\n`), file, enc.encode(`\r\n--${bd}--\r\n`));
    const total = parts.reduce((a, p) => a + p.length, 0), out = new Uint8Array(total); let o = 0;
    for (const p of parts) { out.set(p, o); o += p.length; }
    return { body: out, type: 'multipart/form-data; boundary=' + bd };
  }
  const b64 = u8 => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };
  async function post(url, key, mp, signal) {
    const headers = { Authorization: 'Bearer ' + key, 'Content-Type': mp.type };
    try {
      const r = await fetch(url, { method: 'POST', headers, body: mp.body, signal });
      return { status: r.status, text: await r.text() };
    } catch (e) {
      if (signal?.aborted) throw e;
      if (!NATIVE) throw new Error('تعذّر الاتصال بخدمة التعرّف على الكلام');
      const r = await capCall('FadiNative', 'httpRequest', { url, method: 'POST', headers, bodyBase64: b64(mp.body), timeout: 300000 });
      return { status: r.status, text: r.data };
    }
  }
  async function transcribe(id, ch, prompt, signal) {
    const E = ENGINES[id], key = Settings.get().keys[id].trim();
    let last = '';
    for (const model of E.models) {
      const mp = multipart([['model', model], ['language', 'ar'], ['response_format', 'verbose_json'], ['timestamp_granularities[]', 'word'], ['temperature', '0'], ['prompt', prompt]], ch.bytes);
      for (let a = 0; a < 3; a++) {
        const r = await post(E.url, key, mp, signal);
        if (r.status === 200) {
          const d = JSON.parse(r.text);
          const ws = (d.words || []).map(w => ({ w: String(w.word || '').trim(), t0: ch.a + (+w.start || 0), t1: ch.a + (+w.end || 0) })).filter(w => w.w);
          if (ws.length) return ws;
          last = 'لم يُرجع توقيت الكلمات'; break;
        }
        let msg = ''; try { msg = JSON.parse(r.text).error?.message || ''; } catch {}
        last = `${E.name} (${r.status}) ${msg}`.slice(0, 180);
        if (r.status === 401 || r.status === 403) throw new Error(`مفتاح ${id === 'groq' ? 'Groq' : 'ChatGPT'} غير صالح`);
        if (r.status === 429 || r.status >= 500) { await new Promise(res => setTimeout(res, 8000 * (a + 1))); continue; }
        break;
      }
    }
    throw new Error(last || E.name + ': تعذّرت المزامنة');
  }

  /* ---------- المطابقة: كلمات السكريبت ↔ الكلمات المسموعة ---------- */
  const norm = x => String(x).replace(/[ً-ْـ]/g, '').replace(/[^\p{L}\p{N}]/gu, '').replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').replace(/^(وال|بال|فال|كال|لل|ال)/, '').toLowerCase();
  function sim(a, b) {
    if (!a || !b) return 0; if (a === b) return 1;
    const m = a.length, n = b.length; if (Math.abs(m - n) > Math.max(m, n) * 0.6) return 0;
    let prev = Array.from({ length: n + 1 }, (_, j) => j);
    for (let i = 1; i <= m; i++) { const cur = [i]; for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); prev = cur; }
    return 1 - prev[n] / Math.max(m, n);
  }
  /* محاذاة شريطية (Needleman-Wunsch حول القطر) ← لكل كلمة من السكريبت رقم الكلمة المسموعة أو -1 */
  function alignSeq(S, T) {
    const n = S.length, m = T.length, band = Math.max(80, Math.min(320, Math.round(Math.max(n, m) * 0.05))), G = -0.5;
    const center = i => Math.round(i * m / Math.max(1, n));
    const lo = i => Math.max(0, center(i) - band), hi = i => Math.min(m, center(i) + band);
    const score = [], dir = [];
    for (let i = 0; i <= n; i++) {
      const L = lo(i), H = hi(i), row = new Float32Array(H - L + 1).fill(-1e9), d = new Uint8Array(H - L + 1);
      for (let j = L; j <= H; j++) {
        if (i === 0) { row[j - L] = j * G; d[j - L] = 2; continue; }
        const P = score[i - 1], PL = lo(i - 1), get = jj => (jj >= PL && jj <= hi(i - 1)) ? P[jj - PL] : -1e9;
        let best = get(j) + G, bd = 1;                                      // كلمة من السكريبت لم تُسمع
        if (j > 0) { const s = sim(S[i - 1], T[j - 1]), v = get(j - 1) + (s >= 0.5 ? 2 * s : -1); if (v > best) { best = v; bd = 0; } }
        if (j > L) { const v = row[j - 1 - L] + G; if (v > best) { best = v; bd = 2; } }   // كلمة مسموعة زائدة
        row[j - L] = best; d[j - L] = bd;
      }
      score.push(row); dir.push(d);
    }
    const map = new Array(n).fill(-1); let i = n, j = Math.min(m, hi(n));
    while (i > 0 && j >= 0) {
      const L = lo(i); if (j < L || j > hi(i)) { j = Math.max(L, Math.min(hi(i), j)); }
      const d = dir[i][j - L];
      if (d === 0) { if (sim(S[i - 1], T[j - 1]) >= 0.5) map[i - 1] = j - 1; i--; j--; }
      else if (d === 1) i--;
      else j--;
    }
    return map;
  }

  /* ---------- التشغيل ---------- */
  let running = null;
  async function run({ quiet = false, onProgress, signal } = {}) {
    if (!App.buf || !App.scenes.length) throw new Error('جهّز الصوت والمشاهد أولاً');
    const ids = order(); if (!ids.length) throw new Error('أضف مفتاح Groq (مجاني) أو ChatGPT في الإعدادات للمزامنة الدقيقة');
    if (running) return running;
    running = (async () => {
      const parts = chunks(App.buf);
      const script = App.scenes.map(s => s.text).join(' '), sw = script.split(/\s+/).filter(Boolean);
      let heard = [], err = null;
      for (const id of ids) {
        try {
          heard = [];
          for (let k = 0; k < parts.length; k++) {
            onProgress?.(k / parts.length, `التعرّف على الكلام ${k + 1}/${parts.length}`);
            // تلميح للإملاء: جزء السكريبت المتوقع في هذا المقطع
            const at = Math.floor(sw.length * parts[k].a / App.buf.duration), hint = sw.slice(at, at + 60).join(' ');
            heard.push(...await transcribe(id, parts[k], hint, signal));
          }
          err = null; break;
        } catch (e) { if (signal?.aborted) throw e; err = e; }
      }
      if (err) throw err;
      onProgress?.(0.95, 'مطابقة الكلمات مع السكريبت');
      const S = sw.map(norm), T = heard.map(h => norm(h.w)), map = alignSeq(S, T);
      // أوقات كل كلمة من السكريبت؛ الكلمات غير المسموعة تُقدَّر بين جارتيها حسب طولها
      const tm = sw.map((_, i) => map[i] >= 0 ? [heard[map[i]].t0, heard[map[i]].t1] : null);
      const matched = tm.filter(Boolean).length;
      if (matched < sw.length * 0.35) throw new Error(`تطابق ضعيف (${matched} من ${sw.length} كلمة). تأكد أن الصوت هو نفس النص`);
      for (let i = 0; i < tm.length; i++) {
        if (tm[i]) continue;
        let a = i - 1; while (a >= 0 && !tm[a]) a--;
        let b = i; while (b < tm.length && !tm[b]) b++;
        const t0 = a >= 0 ? tm[a][1] : Math.max(0, (tm[b]?.[0] ?? 0) - 0.4 * (b - i)), t1 = b < tm.length ? tm[b][0] : Math.min(App.buf.duration, t0 + 0.4 * (b - a));
        const ids2 = []; for (let k = a + 1; k < b; k++) ids2.push(k);
        const L = ids2.reduce((x, k) => x + sw[k].length + 1, 0) || 1; let c = 0;
        ids2.forEach(k => { const s0 = t0 + (t1 - t0) * c / L; c += sw[k].length + 1; tm[k] = [s0, t0 + (t1 - t0) * c / L]; });
      }
      // كل مشهد: كلماته بأوقاتها + يبدأ لحظة نطق أول كلمة فيه
      let wi = 0; const total = App.buf.duration, starts = [];
      App.scenes.forEach(sc => {
        const n = sc.text.split(/\s+/).filter(Boolean).length;
        sc.wt = tm.slice(wi, wi + n).map(([a, b]) => [+a.toFixed(3), +Math.max(a + 0.05, b).toFixed(3)]); sc.wtk = sc.text;
        starts.push(n ? Math.max(0, tm[wi][0] - 0.08) : null); wi += n;
      });
      starts[0] = 0;
      for (let k = 1; k < starts.length; k++) if (starts[k] == null || starts[k] < starts[k - 1] + 0.5) starts[k] = starts[k - 1] + 0.5;
      App.scenes.forEach((sc, k) => { sc.d = Math.max(0.5, (k + 1 < starts.length ? starts[k + 1] : total) - starts[k]); });
      const sum = App.scenes.reduce((a, x) => a + x.d, 0); App.scenes[App.scenes.length - 1].d += total - sum;
      App.exactSync = { at: Date.now(), matched, words: sw.length };
      return { matched, words: sw.length };
    })();
    try { return await running; } finally { running = null; }
  }

  /* أوقات الكلمات بين a وb (للريل) إذا كانت المزامنة الدقيقة جاهزة */
  function wordsIn(scenes, a, b) {
    if (!scenes.every(s => s.wt && s.wtk === s.text)) return null;
    return scenes.flatMap(s => s.text.split(/\s+/).filter(Boolean).map((w, i) => ({ w, t0: s.wt[i][0] - a, t1: s.wt[i][1] - a }))).filter(w => w.t1 > 0 && w.t0 < b - a);
  }

  return { run, available, wordsIn, alignSeq, norm, get busy() { return !!running; } };
})();
