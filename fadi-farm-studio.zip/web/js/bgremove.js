/* Swift — إزالة خلفية الشعار: مفتاح لوني (مثل Chroma Key في CapCut) بالضغط على لون الخلفية،
   أو إزالة تلقائية (تكتشف لون الخلفية من أطراف الصورة وتزيله من الخارج فقط حتى لا تُمسح ألوان داخل الشعار).
   النتيجة تُعرض فوق مربعات الشفافية، ولا تُحفظ إلا بعد «تأكيد». */
'use strict';

const BgRemove = (() => {
  let src = null, W = 0, H = 0, orig = null, mask = null, key = null, mode = '', res = null;
  const $q = s => document.querySelector(s);

  function load(url) {
    return new Promise((ok, no) => {
      const im = new Image(); im.crossOrigin = 'anonymous';
      im.onload = () => {
        const m = 640, k = Math.min(1, m / Math.max(im.width, im.height));
        W = Math.max(1, Math.round(im.width * k)); H = Math.max(1, Math.round(im.height * k));
        const c = document.createElement('canvas'); c.width = W; c.height = H;
        const g = c.getContext('2d', { willReadFrequently: true }); g.drawImage(im, 0, 0, W, H);
        try { orig = g.getImageData(0, 0, W, H); } catch { return no(new Error('تعذّرت قراءة الصورة')); }
        ok();
      };
      im.onerror = () => no(new Error('تعذّر فتح الصورة'));
      im.src = url;
    });
  }

  const dist = (d, i, c) => { const r = d[i] - c[0], g = d[i + 1] - c[1], b = d[i + 2] - c[2]; return Math.sqrt(r * r * 0.9 + g * g * 1.2 + b * b * 0.9); };

  /* الألوان الأكثر تكراراً في أطراف الصورة (لون الخلفية) */
  function borderColors() {
    const d = orig.data, hist = new Map(), add = (x, y) => { const i = (y * W + x) * 4; if (d[i + 3] < 30) return; const k = (d[i] >> 4) << 8 | (d[i + 1] >> 4) << 4 | (d[i + 2] >> 4); const h = hist.get(k) || { n: 0, r: 0, g: 0, b: 0 }; h.n++; h.r += d[i]; h.g += d[i + 1]; h.b += d[i + 2]; hist.set(k, h); };
    for (let x = 0; x < W; x++) { add(x, 0); add(x, 1); add(x, H - 1); add(x, H - 2); }
    for (let y = 0; y < H; y++) { add(0, y); add(1, y); add(W - 1, y); add(W - 2, y); }
    const total = [...hist.values()].reduce((a, h) => a + h.n, 0) || 1;
    return [...hist.values()].sort((a, b) => b.n - a.n).filter(h => h.n / total > 0.08).slice(0, 3).map(h => [h.r / h.n, h.g / h.n, h.b / h.n]);
  }

  /* تلقائي: تعبئة من الأطراف للبكسلات القريبة من لون الخلفية فقط (المتصلة بالحافة) */
  function autoMask(tol) {
    const d = orig.data, cols = borderColors(), m = new Float32Array(W * H).fill(1);
    if (!cols.length) return m;
    const near = i => { let best = 1e9; for (const c of cols) best = Math.min(best, dist(d, i * 4, c)); return d[i * 4 + 3] < 30 ? 0 : best; };
    const seen = new Uint8Array(W * H), stack = [];
    const push = p => { if (!seen[p]) { seen[p] = 1; stack.push(p); } };
    for (let x = 0; x < W; x++) { push(x); push((H - 1) * W + x); }
    for (let y = 0; y < H; y++) { push(y * W); push(y * W + W - 1); }
    while (stack.length) {
      const p = stack.pop(), dd = near(p);
      if (dd > tol * 1.6) continue;
      m[p] = dd < tol ? 0 : (dd - tol) / (tol * 0.6);
      const x = p % W, y = (p / W) | 0;
      if (x > 0) push(p - 1); if (x < W - 1) push(p + 1); if (y > 0) push(p - W); if (y < H - 1) push(p + W);
    }
    return m;
  }

  /* مفتاح لوني: كل البكسلات القريبة من اللون المختار في كل الصورة */
  function keyMask(c, tol, soft) {
    const d = orig.data, m = new Float32Array(W * H);
    for (let p = 0; p < W * H; p++) { const dd = dist(d, p * 4, c); m[p] = dd < tol ? 0 : dd < tol + soft ? (dd - tol) / soft : 1; }
    return m;
  }

  /* تنعيم الحواف قليلاً حتى لا تظهر حواف مسننة */
  function feather(m, r) {
    if (r < 1) return m;
    const o = new Float32Array(m.length);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      let s = 0, n = 0;
      for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) { const xx = x + dx, yy = y + dy; if (xx >= 0 && yy >= 0 && xx < W && yy < H) { s += m[yy * W + xx]; n++; } }
      o[y * W + x] = Math.min(m[y * W + x], s / n + 0.25);   // لا يعيد الخلفية، يلين الحافة فقط
    }
    return o;
  }

  function render() {
    const cv = $q('#bgCv'); cv.width = W; cv.height = H;
    const g = cv.getContext('2d'), out = new ImageData(W, H), d = orig.data, o = out.data;
    for (let p = 0; p < W * H; p++) { const i = p * 4; o[i] = d[i]; o[i + 1] = d[i + 1]; o[i + 2] = d[i + 2]; o[i + 3] = mask ? Math.round(d[i + 3] * Math.max(0, Math.min(1, mask[p]))) : d[i + 3]; }
    g.putImageData(out, 0, 0);
    // يقص الأطراف الفارغة بعد الإزالة (الشعار يأخذ حجمه الحقيقي في الفيديو)
    $q('#bgInfo').textContent = !mask ? 'اضغط على لون الخلفية في الصورة (مفتاح لوني)، أو اختر «إزالة تلقائية».'
      : mode === 'auto' ? 'إزالة تلقائية: حُذفت الخلفية المتصلة بأطراف الصورة. عدّل القوة إن لزم ثم أكّد.'
      : 'مفتاح لوني: حُذف اللون المختار من كل الصورة. عدّل القوة والنعومة ثم أكّد.';
    $q('#bgOk').disabled = !mask;
  }

  function recompute() {
    const tol = +$q('#bgTol').value, soft = +$q('#bgSoft').value;
    if (mode === 'auto') mask = feather(autoMask(tol), soft > 15 ? 1 : 0);
    else if (mode === 'key' && key) mask = feather(keyMask(key, tol, soft), 0);
    else mask = null;
    render();
  }

  function trimmed() {
    const cv = $q('#bgCv'), g = cv.getContext('2d'), d = g.getImageData(0, 0, W, H).data;
    let x0 = W, y0 = H, x1 = -1, y1 = -1;
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (d[(y * W + x) * 4 + 3] > 12) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    if (x1 < 0) return null;
    const pad = 4; x0 = Math.max(0, x0 - pad); y0 = Math.max(0, y0 - pad); x1 = Math.min(W - 1, x1 + pad); y1 = Math.min(H - 1, y1 + pad);
    const w = x1 - x0 + 1, h = y1 - y0 + 1, k = Math.min(1, 512 / Math.max(w, h));
    const c = document.createElement('canvas'); c.width = Math.round(w * k); c.height = Math.round(h * k);
    c.getContext('2d').drawImage(cv, x0, y0, w, h, 0, 0, c.width, c.height);
    return c.toDataURL('image/png');
  }

  /* يفتح الأداة لصورة (dataURL أو رابط) ويرجع الشعار الجديد بعد التأكيد، أو null */
  async function open(url) {
    src = url; mask = null; key = null; mode = '';
    await load(url);
    const d = $q('#bgDlg');
    $q('#bgTol').value = 42; $q('#bgSoft').value = 18; $q('#bgSwatch').style.background = 'transparent';
    render();
    const cv = $q('#bgCv');
    cv.onclick = e => {
      const r = cv.getBoundingClientRect(), x = Math.floor((e.clientX - r.left) / r.width * W), y = Math.floor((e.clientY - r.top) / r.height * H);
      const i = (Math.max(0, Math.min(H - 1, y)) * W + Math.max(0, Math.min(W - 1, x))) * 4, dd = orig.data;
      key = [dd[i], dd[i + 1], dd[i + 2]]; mode = 'key';
      $q('#bgSwatch').style.background = `rgb(${key.join(',')})`;
      recompute();
    };
    $q('#bgAuto').onclick = () => { mode = 'auto'; recompute(); };
    $q('#bgReset').onclick = () => { mode = ''; key = null; mask = null; $q('#bgSwatch').style.background = 'transparent'; render(); };
    $q('#bgTol').oninput = $q('#bgSoft').oninput = () => mode && recompute();
    $q('#bgBgDark').onclick = () => $q('#bgStage').classList.toggle('dark');
    return new Promise(res => {
      d.onclose = () => res(d.returnValue === 'ok' ? trimmed() : null);
      d.returnValue = ''; d.showModal();
    });
  }
  return { open };
})();
