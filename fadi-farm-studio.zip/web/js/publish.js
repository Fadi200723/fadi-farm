/* Fadi Farm — النشر: شورت تشويقي، صورة مصغرة، عنوان ووصف يوتيوب */
'use strict';

const Publish = (() => {
  const st = { promo: null, shortBuf: null, shortScenes: [], thumbScene: 0, thumbColor: '#FFD43B', busy: false, shortBlob: null };

  const usableScenes = () => App.scenes.map((s, i) => ({ s, i })).filter(x => x.s.blobKey);

  async function loadPromo() {
    try { st.promo = await Store.get('promo'); } catch {}
  }
  const savePromo = () => Store.set('promo', st.promo).catch(() => {});

  /* ---------- العنوان والوصف ---------- */
  /* فصول يوتيوب: 00:00 أولاً، ولا يقل الفصل عن 10 ثوانٍ */
  function chaptersText(p) {
    const ch = (p.chapters || []).filter(c => App.scenes[c.scene]);
    if (ch.length < 3) return '';
    const { st: starts } = Renderer.timeline(App.scenes), total = App.buf?.duration || 0;
    const ts = x => { x = Math.floor(x); const h = Math.floor(x / 3600), m = Math.floor(x % 3600 / 60), s = x % 60; return (h ? h + ':' + String(m).padStart(2, '0') : String(m).padStart(2, '0')) + ':' + String(s).padStart(2, '0'); };
    const list = []; let last = -99;
    ch.sort((a, b) => a.scene - b.scene).forEach((c, i) => { const t = i === 0 ? 0 : starts[c.scene]; if (t - last >= 10 && (!total || total - t >= 10)) { list.push(`${ts(t)} ${c.title}`); last = t; } });
    if (!list.length || !list[0].startsWith('00:00')) list.unshift('00:00 المقدمة');
    return list.length >= 3 ? 'فصول الفيديو:\n' + list.join('\n') : '';
  }

  function fullDescription(p) {
    const parts = [p.description.trim()];
    const ch = chaptersText(p); if (ch) parts.push(ch);
    if (p.tags?.length) parts.push(p.tags.join(' '));
    return parts.join('\n\n');
  }

  function renderMeta() {
    const p = st.promo, box = $('#ytMeta');
    if (!p) { box.innerHTML = `<p class="muted">${Settings.get().keys.gemini ? 'اضغط «اقترح» ليكتب Gemini عنواناً ووصفاً احترافياً.' : 'أضف مفتاح Gemini ليكتب لك العنوان والوصف.'}</p>`; return; }
    if (!$('#thumbTitle').value) $('#thumbTitle').value = p.thumbTitle;
    const row = (label, val, id, hint = '') => `<div class="meta-row"><div class="meta-head"><b>${label}</b><button class="btn ghost sm" data-copy="${id}" type="button">نسخ</button></div>${hint ? `<span class="muted small">${hint}</span>` : ''}<p id="${id}">${esc(val)}</p></div>`;
    box.innerHTML =
      row('العنوان', p.ytTitle, 'mTitle', `${p.ytTitle.length} / 100 حرف`) +
      row('الوصف', fullDescription(p), 'mDesc', 'وصف SEO + فصول الفيديو + الهاشتاقات. الصقه كما هو في يوتيوب') +
      (p.keywords?.length ? row('الكلمات المفتاحية (خانة العلامات في يوتيوب)', p.keywords.join(', '), 'mKw', `${p.keywords.join(', ').length} / 500 حرف`) : '') +
      row('الهاشتاقات', p.tags.join(' '), 'mTags');
  }


  /* بديل بدون Gemini: عنوان ووصف وهاشتاقات من نص الفيديو */
  function localPromo() {
    const all = App.scenes.map(x => x.text).join(' '), sents = all.split(/(?<=[.!؟?])\s+/).filter(Boolean);
    const q = sents.find(x => /[؟?]$/.test(x)), title = (App.projName || q || sents[0] || 'فيديو جديد').slice(0, 68);
    const en = [...new Set(App.scenes.flatMap(x => x.kw).filter(w => /^[a-z ]+$/i.test(w)))].slice(0, 6);
    const tags = ['#فادي_فارم', '#تربية_الدواجن', '#الفراخ_البلدي', '#Fadi_Farm', '#مزرعة', '#الريف_المصري', ...en.map(w => '#' + w.replace(/\s+/g, '_'))].slice(0, 12);
    const bullets = App.scenes.filter(s => s.fx).slice(0, 5).map(s => '✅ ' + s.fx.text);
    const n = App.scenes.length, chapters = [0, Math.floor(n * 0.25), Math.floor(n * 0.5), Math.floor(n * 0.75)].filter((v, i, a) => a.indexOf(v) === i).map((sc, i) => ({ scene: sc, title: i === 0 ? 'المقدمة' : App.scenes[sc].text.split(/\s+/).slice(0, 5).join(' ') }));
    const description = [
      `${title} | ${sents[0] || ''}`,
      `في الفيديو ده من قناة فادي فارم بنتكلم عن ${title} بالتفصيل وبطريقة عملية، عشان تقدر تطبّق الكلام ده في مزرعتك أو في بيتك. ${sents.slice(1, 3).join(' ')}`,
      bullets.length ? 'في الفيديو ده هتعرف:\n' + bullets.join('\n') : '',
      'لو الفيديو عجبك اعمل لايك واشترك في القناة وفعّل الجرس 🔔 عشان يوصلك كل جديد عن تربية الدواجن والحيوانات. ولو عندك سؤال اكتبه في التعليقات.',
    ].filter(Boolean).join('\n\n');
    const keywords = [title, 'تربية الفراخ البلدي', 'تربية الدواجن', 'مزرعة دواجن', 'علف الفراخ', 'فادي فارم', ...en].slice(0, 15);
    return { teaser: '', teaserScenes: [], thumbTitle: title.split(/\s+/).slice(0, 4).join(' '), thumbHighlight: '', thumbLayout: / ولا /.test(title) ? 'vs' : 'hero', thumbScene: 0, thumbPrompt: '', thumbPhrase: '',
      ytTitle: title, description, chapters, keywords, tags };
  }


  async function suggest() {
    if (!Settings.get().keys.gemini) return toast('أضف مفتاح Gemini أولاً', 'err');
    if (!App.scenes.length) return toast('لا توجد مشاهد بعد', 'err');
    const b = $('#btnPromo'); b.disabled = true; b.textContent = 'جارٍ الكتابة…';
    try {
      st.promo = await AI.promo(App.scenes.map(x => x.text)); savePromo();
      $('#thumbTitle').value = st.promo.thumbTitle; $('#thumbHi').value = st.promo.thumbHighlight || '';
      Thumb.reset(); renderMeta(); Thumb.enter(st.promo);
    } catch (e) {
      toast('Gemini: ' + e.message + '. كتبت عنواناً ووصفاً تلقائياً، عدّلهما كما تحب', 'err', 7000);
      st.promo = localPromo(); savePromo(); renderMeta(); Thumb.enter(st.promo);
    }
    b.disabled = false; b.textContent = 'اقترح بـ Gemini';
  }

  function enter() {
    const ready = App.buf && App.scenes.length;
    $('#pubEmpty').hidden = !!ready;
    $$('#v-publish .panel').forEach(p => p.hidden = !ready);
    if (!ready) return;
    renderMeta();
    if (!st.promo && Settings.get().keys.gemini) suggest(); else Thumb.enter(st.promo);
    Reel.enter();
  }

  function bind() {
    Reel.bind();
    $('#btnPromo').onclick = suggest;
    Thumb.bind();
    $('#ytMeta').addEventListener('click', async e => {
      const b = e.target.closest('[data-copy]'); if (!b) return;
      try { await navigator.clipboard.writeText($('#' + b.dataset.copy).textContent); toast('نُسخ'); } catch { toast('تعذّر النسخ', 'err'); }
    });
  }

  function reset() { st.promo = null; st.shortBlob = null; Thumb.reset(); Reel.reset(); Store.set('promo', null).catch(() => {}); }

  return { enter, bind, loadPromo, reset };
})();
