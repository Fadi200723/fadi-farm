/* Fadi Farm — النشر: شورت تشويقي، صورة مصغرة، عنوان ووصف يوتيوب */
'use strict';

const Publish = (() => {
  const st = { promo: null, shortBuf: null, shortScenes: [], thumbScene: 0, thumbColor: '#FFD43B', busy: false, shortBlob: null };

  const usableScenes = () => App.scenes.map((s, i) => ({ s, i })).filter(x => x.s.blobKey);

  async function loadPromo() {
    try { st.promo = await Store.get('promo'); } catch {}
  }
  const savePromo = () => Store.set('promo', st.promo).catch(() => {});

  /* ---------- العنوان والوصف ---------- */
  function renderMeta() {
    const p = st.promo, box = $('#ytMeta');
    if (!p) { box.innerHTML = `<p class="muted">${Settings.get().keys.gemini ? 'اضغط «اقترح» ليكتب Gemini عنواناً ووصفاً وهاشتاقات.' : 'أضف مفتاح Gemini ليكتب لك العنوان والوصف.'}</p>`; return; }
    if (!$('#thumbTitle').value) $('#thumbTitle').value = p.thumbTitle;
    const row = (label, val, id) => `<div class="meta-row"><div class="meta-head"><b>${label}</b><button class="btn ghost sm" data-copy="${id}" type="button">نسخ</button></div><p id="${id}">${esc(val)}</p></div>`;
    box.innerHTML = row('العنوان', p.ytTitle, 'mTitle') + row('الوصف', p.description + (creditsText() ? '\n\n' + creditsText() : ''), 'mDesc') + row('الهاشتاقات', p.tags.join(' '), 'mTags');
  }

  async function suggest() {
    if (!Settings.get().keys.gemini) return toast('أضف مفتاح Gemini أولاً', 'err');
    if (!App.scenes.length) return toast('لا توجد مشاهد بعد', 'err');
    const b = $('#btnPromo'); b.disabled = true; b.textContent = 'جارٍ الكتابة…';
    try {
      st.promo = await AI.promo(App.scenes.map(x => x.text)); savePromo();
      $('#thumbTitle').value = st.promo.thumbTitle; $('#thumbHi').value = st.promo.thumbHighlight || '';
      Thumb.reset(); renderMeta(); Thumb.enter(st.promo);
    } catch (e) { toast(e.message, 'err'); Thumb.enter(st.promo); }
    b.disabled = false; b.textContent = 'اقترح بـ Gemini';
  }

  function enter() {
    const ready = App.buf && App.scenes.length;
    $('#pubEmpty').hidden = !!ready;
    $$('#v-publish .panel').forEach(p => p.hidden = !ready);
    if (!ready) return;
    renderMeta();
    if (!st.promo && Settings.get().keys.gemini) suggest(); else Thumb.enter(st.promo);
    Reel.enter();
  }

  function bind() {
    Reel.bind();
    $('#btnPromo').onclick = suggest;
    Thumb.bind();
    $('#ytMeta').addEventListener('click', async e => {
      const b = e.target.closest('[data-copy]'); if (!b) return;
      try { await navigator.clipboard.writeText($('#' + b.dataset.copy).textContent); toast('نُسخ'); } catch { toast('تعذّر النسخ', 'err'); }
    });
  }

  function reset() { st.promo = null; st.shortBlob = null; Thumb.reset(); Reel.reset(); Store.set('promo', null).catch(() => {}); }

  return { enter, bind, loadPromo, reset };
})();
