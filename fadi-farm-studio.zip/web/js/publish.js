/* Fadi Farm — النشر: شورت تشويقي، صورة مصغرة، عنوان ووصف يوتيوب */
'use strict';

const Publish = (() => {
  const st = { promo: null, shortBuf: null, shortScenes: [], thumbScene: 0, thumbColor: '#FFD43B', busy: false, shortBlob: null };

  const usableScenes = () => App.scenes.map((s, i) => ({ s, i })).filter(x => x.s.blobKey);

  async function loadPromo() {
    try { st.promo = await Store.get('promo'); } catch {}
  }
  const savePromo = () => Store.set('promo', st.promo).catch(() => {});

  /* ---------- الشورت ---------- */
  function sliceBuffer(buf, from, to) {
    const ctx = Player.audioCtx(), sr = buf.sampleRate, a = Math.floor(from * sr), b = Math.min(buf.length, Math.floor(to * sr));
    const out = ctx.createBuffer(1, Math.max(1, b - a), sr), o = out.getChannelData(0), src = buf.getChannelData(0);
    o.set(src.subarray(a, b));
    const fade = Math.min(o.length, Math.floor(sr * 0.4));
    for (let i = 0; i < fade; i++) o[o.length - 1 - i] *= i / fade;
    return out;
  }

  function buildShortScenes(text, dur, pick) {
    const words = text.split(/\s+/).filter(Boolean);
    const n = Math.max(1, Math.min(pick.length, 5));
    const per = Math.ceil(words.length / n), out = [];
    for (let k = 0; k < n; k++) {
      const t = words.slice(k * per, (k + 1) * per).join(' ');
      if (!t) continue;
      const src = App.scenes[pick[k]] || usableScenes()[k % Math.max(1, usableScenes().length)]?.s;
      out.push({ id: 'sh' + k, text: t, d: 1, kw: [], kind: 'video', asset: src?.asset || null, blobKey: src?.blobKey || null, el: null, type: '', offset: (src?.offset || 0) + 1.5 });
    }
    const L = out.reduce((a, x) => a + x.text.length, 0) || 1;
    out.forEach(x => x.d = dur * x.text.length / L);
    return out;
  }

  async function makeShort() {
    if (st.busy) return;
    if (!App.buf || !App.scenes.length) return toast('جهّز الفيديو الأساسي أولاً (الصوت والمشاهد)', 'err');
    if (!usableScenes().length) return toast('اجلب لقطات للمشاهد أولاً', 'err');
    const box = $('#shProgress'); st.busy = true; $('#btnShort').disabled = true;
    try {
      const s = Settings.get();
      let text, buf, pick;
      if (s.keys.gemini) {
        setProgress(box, 0.1, 'Gemini يكتب سكربت تشويقي…');
        if (!st.promo) { st.promo = await AI.promo(App.scenes.map(x => x.text)); savePromo(); renderMeta(); }
        text = $('#shText').value.trim() || st.promo.teaser;
        $('#shText').value = text;
        setProgress(box, 0.4, 'تسجيل صوت الشورت بلهجة مصرية…');
        buf = (await TTS.speak(text, { pace: 'fast' })).buffer;
        pick = st.promo.teaserScenes.filter(i => App.scenes[i]?.blobKey);
      }
      if (!buf) {
        // بدون Gemini: أول 14 ثانية من الفيديو الأساسي
        buf = sliceBuffer(App.buf, 0, Math.min(14, App.buf.duration));
        let a = 0; text = App.scenes.filter(x => { const ok = a < 14; a += x.d; return ok; }).map(x => x.text).join(' ');
      }
      if (!pick || !pick.length) pick = usableScenes().slice(0, 4).map(x => x.i);
      text = text + ' — الفيديو كامل على القناة';
      st.shortBuf = buf;
      st.shortScenes = buildShortScenes(text, buf.duration, pick);
      for (const x of st.shortScenes) {
        await Live.ensure(x);
        if (x.el && x.type === 'video') await new Promise(r => { if (x.el.readyState >= 2) r(); else { x.el.oncanplay = r; setTimeout(r, 4000); } });
      }
      setProgress(box, 0.6, 'تصدير الشورت (عمودي 9:16)…');
      const blob = await renderVideo(buf, st.shortScenes, 1080, 1920, (f, txt) => setProgress(box, 0.6 + f * 0.4, txt || `تصدير الشورت ${Math.round(f * 100)}%`));
      st.shortBlob = blob;
      showVideo('#shResult', blob, `${safeName()}-short`);
      toast(`الشورت جاهز · ${buf.duration.toFixed(0)} ثانية`);
    } catch (e) { toast(e.message, 'err', 6000); }
    finally { box.hidden = true; st.busy = false; $('#btnShort').disabled = false; }
  }

  /* يصدّر مشاهد مستقلة بأبعاد مؤقتة ثم يعيد اللوحة كما كانت */
  function renderVideo(buf, scenes, w, h, onP) {
    const cv = Renderer.canvas, ow = cv.width, oh = cv.height;
    Renderer.size(w, h);
    return new Promise((res, rej) => {
      Player.start({
        buf, scenes, record: true,
        prep: f => onP?.(0, `تجهيز الصوت ${Math.round(f * 100)}%`),
        tick: t => onP?.(t / buf.duration),
        end: (blob, err) => { Renderer.size(ow, oh); blob && blob.size ? res(blob) : rej(new Error('فشل تصدير الشورت' + (err?.message ? ': ' + err.message : ''))); },
      }).catch(e => { Renderer.size(ow, oh); rej(e); });
    });
  }

  function showVideo(sel, blob, base) { resultBox($(sel), blob, base, 'الشورت جاهز'); }

  /* ---------- العنوان والوصف ---------- */
  function renderMeta() {
    const p = st.promo, box = $('#ytMeta');
    if (!p) { box.innerHTML = `<p class="muted">${Settings.get().keys.gemini ? 'اضغط «اقترح» ليكتب Gemini عنواناً ووصفاً وهاشتاقات.' : 'أضف مفتاح Gemini ليكتب لك العنوان والوصف.'}</p>`; return; }
    if (!$('#thumbTitle').value) $('#thumbTitle').value = p.thumbTitle;
    if (!$('#shText').value) $('#shText').value = p.teaser;
    const row = (label, val, id) => `<div class="meta-row"><div class="meta-head"><b>${label}</b><button class="btn ghost sm" data-copy="${id}" type="button">نسخ</button></div><p id="${id}">${esc(val)}</p></div>`;
    box.innerHTML = row('العنوان', p.ytTitle, 'mTitle') + row('الوصف', p.description + (creditsText() ? '\n\n' + creditsText() : ''), 'mDesc') + row('الهاشتاقات', p.tags.join(' '), 'mTags');
  }

  async function suggest() {
    if (!Settings.get().keys.gemini) return toast('أضف مفتاح Gemini أولاً', 'err');
    if (!App.scenes.length) return toast('لا توجد مشاهد بعد', 'err');
    const b = $('#btnPromo'); b.disabled = true; b.textContent = 'جارٍ الكتابة…';
    try {
      st.promo = await AI.promo(App.scenes.map(x => x.text)); savePromo();
      $('#thumbTitle').value = st.promo.thumbTitle; $('#thumbHi').value = st.promo.thumbHighlight || ''; $('#shText').value = st.promo.teaser;
      Thumb.reset(); renderMeta(); Thumb.enter(st.promo);
    } catch (e) { toast(e.message, 'err'); Thumb.enter(st.promo); }
    b.disabled = false; b.textContent = 'اقترح بـ Gemini';
  }

  function enter() {
    const ready = App.buf && App.scenes.length;
    $('#pubEmpty').hidden = !!ready;
    $$('#v-publish .panel').forEach(p => p.hidden = !ready);
    if (!ready) return;
    renderMeta();
    if (!st.promo && Settings.get().keys.gemini) suggest(); else Thumb.enter(st.promo);
  }

  function bind() {
    $('#btnShort').onclick = makeShort;
    $('#btnPromo').onclick = suggest;
    Thumb.bind();
    $('#ytMeta').addEventListener('click', async e => {
      const b = e.target.closest('[data-copy]'); if (!b) return;
      try { await navigator.clipboard.writeText($('#' + b.dataset.copy).textContent); toast('نُسخ'); } catch { toast('تعذّر النسخ', 'err'); }
    });
  }

  function reset() { st.promo = null; st.shortBlob = null; Thumb.reset(); Store.set('promo', null).catch(() => {}); }

  return { enter, bind, loadPromo, reset };
})();
