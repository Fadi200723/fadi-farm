/* Fadi Farm — النشر: شورت تشويقي، صورة مصغرة، عنوان ووصف يوتيوب */
'use strict';

const Publish = (() => {
  const st = { promo: null, shortBuf: null, shortScenes: [], thumbScene: 0, thumbColor: '#FFD43B', busy: false, shortBlob: null };

  const usableScenes = () => App.scenes.map((s, i) => ({ s, i })).filter(x => x.s.blobKey);

  async function loadPromo() {
    try { st.promo = await Store.get('promo'); } catch {}
  }
  const savePromo = () => Store.set('promo', st.promo).catch(() => {});

  /* ---------- الشورت ---------- */
  function sliceBuffer(buf, from, to) {
    const ctx = Player.audioCtx(), sr = buf.sampleRate, a = Math.floor(from * sr), b = Math.min(buf.length, Math.floor(to * sr));
    const out = ctx.createBuffer(1, Math.max(1, b - a), sr), o = out.getChannelData(0), src = buf.getChannelData(0);
    o.set(src.subarray(a, b));
    const fade = Math.min(o.length, Math.floor(sr * 0.4));
    for (let i = 0; i < fade; i++) o[o.length - 1 - i] *= i / fade;
    return out;
  }

  function buildShortScenes(text, dur, pick) {
    const words = text.split(/\s+/).filter(Boolean);
    const n = Math.max(1, Math.min(pick.length, 5));
    const per = Math.ceil(words.length / n), out = [];
    for (let k = 0; k < n; k++) {
      const t = words.slice(k * per, (k + 1) * per).join(' ');
      if (!t) continue;
      const src = App.scenes[pick[k]] || usableScenes()[k % Math.max(1, usableScenes().length)]?.s;
      out.push({ id: 'sh' + k, text: t, d: 1, kw: [], kind: 'video', asset: src?.asset || null, blobKey: src?.blobKey || null, el: null, type: '', offset: (src?.offset || 0) + 1.5 });
    }
    const L = out.reduce((a, x) => a + x.text.length, 0) || 1;
    out.forEach(x => x.d = dur * x.text.length / L);
    return out;
  }

  async function makeShort() {
    if (st.busy) return;
    if (!App.buf || !App.scenes.length) return toast('جهّز الفيديو الأساسي أولاً (الصوت والمشاهد)', 'err');
    if (!usableScenes().length) return toast('اجلب لقطات للمشاهد أولاً', 'err');
    const box = $('#shProgress'); st.busy = true; $('#btnShort').disabled = true;
    try {
      const s = Settings.get();
      let text, buf, pick;
      if (s.keys.gemini) {
        setProgress(box, 0.1, 'Gemini يكتب سكربت تشويقي…');
        if (!st.promo) { st.promo = await AI.promo(App.scenes.map(x => x.text)); savePromo(); renderMeta(); }
        text = $('#shText').value.trim() || st.promo.teaser;
        $('#shText').value = text;
        setProgress(box, 0.4, 'تسجيل صوت الشورت بلهجة مصرية…');
        buf = (await TTS.speak(text, { pace: 'fast' })).buffer;
        pick = st.promo.teaserScenes.filter(i => App.scenes[i]?.blobKey);
      }
      if (!buf) {
        // بدون Gemini: أول 14 ثانية من الفيديو الأساسي
        buf = sliceBuffer(App.buf, 0, Math.min(14, App.buf.duration));
        let a = 0; text = App.scenes.filter(x => { const ok = a < 14; a += x.d; return ok; }).map(x => x.text).join(' ');
      }
      if (!pick || !pick.length) pick = usableScenes().slice(0, 4).map(x => x.i);
      text = text + ' — الفيديو كامل على القناة';
      st.shortBuf = buf;
      st.shortScenes = buildShortScenes(text, buf.duration, pick);
      await Promise.all(st.shortScenes.map(x => Live.ensure(x)));
      setProgress(box, 0.6, 'تصدير الشورت (عمودي 9:16)…');
      const blob = await renderVideo(buf, st.shortScenes, 1080, 1920, f => setProgress(box, 0.6 + f * 0.4, `تصدير الشورت ${Math.round(f * 100)}%`));
      st.shortBlob = blob;
      showVideo('#shResult', blob, `${safeName()}-short`);
      toast(`الشورت جاهز · ${buf.duration.toFixed(0)} ثانية`);
    } catch (e) { toast(e.message, 'err', 6000); }
    finally { box.hidden = true; st.busy = false; $('#btnShort').disabled = false; }
  }

  /* يصدّر مشاهد مستقلة بأبعاد مؤقتة ثم يعيد اللوحة كما كانت */
  function renderVideo(buf, scenes, w, h, onP) {
    const cv = Renderer.canvas, ow = cv.width, oh = cv.height;
    Renderer.size(w, h);
    return new Promise((res, rej) => {
      Player.start({
        buf, scenes, record: true,
        tick: t => onP?.(t / buf.duration),
        end: blob => { Renderer.size(ow, oh); blob && blob.size ? res(blob) : rej(new Error('فشل التصدير')); },
      }).catch(e => { Renderer.size(ow, oh); rej(e); });
    });
  }

  function showVideo(sel, blob, base) {
    const ext = blob.type.includes('mp4') ? 'mp4' : 'webm', name = `${base}.${ext}`, url = URL.createObjectURL(blob);
    const R = $(sel); R.hidden = false;
    R.innerHTML = `<video src="${url}" controls playsinline></video>
      <div class="actions"><button class="btn primary" data-save type="button">${NATIVE ? 'حفظ في الهاتف' : 'تنزيل'}</button><button class="btn" data-share type="button">مشاركة</button></div>`;
    R.querySelector('[data-save]').onclick = () => saveFile(blob, name).catch(e => toast(e.message, 'err'));
    R.querySelector('[data-share]').onclick = async () => {
      if (NATIVE) return saveFile(blob, name, { share: true }).catch(() => {});
      try { await navigator.share({ files: [new File([blob], name, { type: blob.type })] }); } catch { saveFile(blob, name); }
    };
  }

  /* ---------- الصورة المصغرة ---------- */
  async function frameOf(scene) {
    const b = await Store.getBlob(scene.blobKey);
    if (!b) return null;
    const el = await Media.element(b, scene.asset.type);
    if (scene.asset.type === 'video') {
      await new Promise(r => { el.onseeked = r; try { el.currentTime = Math.min((el.duration || 2) * 0.35, 4); } catch { r(); } setTimeout(r, 2500); });
    }
    return el;
  }

  async function drawThumb() {
    const cv = $('#thumbCv'), g = cv.getContext('2d'), W = cv.width, H = cv.height;
    const list = usableScenes();
    g.fillStyle = '#1b130a'; g.fillRect(0, 0, W, H);
    if (list.length) {
      const sc = list[((st.thumbScene % list.length) + list.length) % list.length].s;
      try {
        const el = await frameOf(sc);
        if (el) {
          const ew = el.videoWidth || el.naturalWidth, eh = el.videoHeight || el.naturalHeight, k = Math.max(W / ew, H / eh) * 1.04;
          g.filter = 'saturate(1.25) contrast(1.08)';
          g.drawImage(el, (W - ew * k) / 2, (H - eh * k) / 2, ew * k, eh * k);
          g.filter = 'none';
          URL.revokeObjectURL(el.src);
        }
      } catch {}
    }
    // تظليل لقراءة النص
    const gr = g.createLinearGradient(W, 0, W * 0.25, 0);
    gr.addColorStop(0, 'rgba(0,0,0,.78)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr; g.fillRect(0, 0, W, H);
    const vg = g.createRadialGradient(W / 2, H / 2, H * 0.3, W / 2, H / 2, W * 0.75);
    vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,.45)');
    g.fillStyle = vg; g.fillRect(0, 0, W, H);

    // العنوان
    const title = ($('#thumbTitle').value || st.promo?.thumbTitle || App.projName || 'Fadi Farm').trim();
    const words = title.split(/\s+/);
    const lines = words.length > 2 ? [words.slice(0, Math.ceil(words.length / 2)).join(' '), words.slice(Math.ceil(words.length / 2)).join(' ')] : [title];
    let fs = H * (lines.length > 1 ? 0.19 : 0.23);
    g.direction = 'rtl'; g.textAlign = 'right'; g.textBaseline = 'middle';
    const font = n => `900 ${n}px "Lalezar", "IBM Plex Sans Arabic", sans-serif`;
    g.font = font(fs);
    while (Math.max(...lines.map(l => g.measureText(l).width)) > W * 0.62 && fs > 40) { fs -= 4; g.font = font(fs); }
    const x = W * 0.95, y0 = H * 0.5 - (lines.length - 1) * fs * 0.6;
    lines.forEach((l, i) => {
      const y = y0 + i * fs * 1.2;
      g.lineJoin = 'round'; g.lineWidth = fs * 0.16; g.strokeStyle = '#000'; g.strokeText(l, x, y);
      g.fillStyle = i === 0 ? st.thumbColor : '#ffffff'; g.fillText(l, x, y);
    });
    // شريط سفلي بلون مميز
    g.fillStyle = st.thumbColor; g.fillRect(W * 0.55, y0 + (lines.length - 1) * fs * 1.2 + fs * 0.7, W * 0.4, H * 0.018);
    // الشعار
    const logo = new Image(); logo.src = 'icons/logo.png';
    await new Promise(r => { if (logo.complete) r(); else { logo.onload = r; logo.onerror = r; } });
    if (logo.naturalWidth) { const lw = W * 0.2, lh = lw * logo.naturalHeight / logo.naturalWidth; g.drawImage(logo, W * 0.03, H * 0.04, lw, lh); }
  }

  function saveThumb(share) {
    $('#thumbCv').toBlob(b => { if (b) saveFile(b, `${safeName()}-thumbnail.jpg`, { share }).catch(e => toast(e.message, 'err')); }, 'image/jpeg', 0.92);
  }

  /* ---------- العنوان والوصف ---------- */
  function renderMeta() {
    const p = st.promo, box = $('#ytMeta');
    if (!p) { box.innerHTML = `<p class="muted">${Settings.get().keys.gemini ? 'اضغط «اقترح» ليكتب Gemini عنواناً ووصفاً وهاشتاقات.' : 'أضف مفتاح Gemini ليكتب لك العنوان والوصف.'}</p>`; return; }
    if (!$('#thumbTitle').value) $('#thumbTitle').value = p.thumbTitle;
    if (!$('#shText').value) $('#shText').value = p.teaser;
    const row = (label, val, id) => `<div class="meta-row"><div class="meta-head"><b>${label}</b><button class="btn ghost sm" data-copy="${id}" type="button">نسخ</button></div><p id="${id}">${esc(val)}</p></div>`;
    box.innerHTML = row('العنوان', p.ytTitle, 'mTitle') + row('الوصف', p.description + (creditsText() ? '\n\n' + creditsText() : ''), 'mDesc') + row('الهاشتاقات', p.tags.join(' '), 'mTags');
  }

  async function suggest() {
    if (!Settings.get().keys.gemini) return toast('أضف مفتاح Gemini أولاً', 'err');
    if (!App.scenes.length) return toast('لا توجد مشاهد بعد', 'err');
    const b = $('#btnPromo'); b.disabled = true; b.textContent = 'جارٍ الكتابة…';
    try {
      st.promo = await AI.promo(App.scenes.map(x => x.text)); savePromo();
      $('#thumbTitle').value = st.promo.thumbTitle; $('#shText').value = st.promo.teaser;
      const list = usableScenes(), k = list.findIndex(x => x.i === st.promo.thumbScene);
      if (k >= 0) st.thumbScene = k;
      renderMeta(); drawThumb();
    } catch (e) { toast(e.message, 'err'); }
    b.disabled = false; b.textContent = 'اقترح بـ Gemini';
  }

  function enter() {
    const ready = App.buf && App.scenes.length;
    $('#pubEmpty').hidden = !!ready;
    $$('#v-publish .panel').forEach(p => p.hidden = !ready);
    if (!ready) return;
    renderMeta(); drawThumb();
  }

  function bind() {
    $('#btnShort').onclick = makeShort;
    $('#btnPromo').onclick = suggest;
    $('#thumbPrev').onclick = () => { st.thumbScene--; drawThumb(); };
    $('#thumbNext').onclick = () => { st.thumbScene++; drawThumb(); };
    $('#thumbTitle').addEventListener('input', () => { clearTimeout(st.t); st.t = setTimeout(drawThumb, 250); });
    $('#thumbColors').addEventListener('click', e => { const c = e.target.closest('[data-c]'); if (!c) return; st.thumbColor = c.dataset.c; $$('#thumbColors [data-c]').forEach(x => x.classList.toggle('on', x === c)); drawThumb(); });
    $('#thumbSave').onclick = () => saveThumb(false);
    $('#thumbShare').onclick = () => saveThumb(true);
    $('#ytMeta').addEventListener('click', async e => {
      const b = e.target.closest('[data-copy]'); if (!b) return;
      try { await navigator.clipboard.writeText($('#' + b.dataset.copy).textContent); toast('نُسخ'); } catch { toast('تعذّر النسخ', 'err'); }
    });
  }

  function reset() { st.promo = null; st.shortBlob = null; Store.set('promo', null).catch(() => {}); }

  return { enter, bind, loadPromo, reset };
})();
