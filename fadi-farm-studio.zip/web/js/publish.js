/* Fadi Farm — النشر: شورت تشويقي، صورة مصغرة، عنوان ووصف يوتيوب */
'use strict';

const Publish = (() => {
  const st = { promo: null, shortBuf: null, shortScenes: [], thumbScene: 0, thumbColor: '#FFD43B', busy: false, shortBlob: null };

  const usableScenes = () => App.scenes.map((s, i) => ({ s, i })).filter(x => x.s.blobKey);

  async function loadPromo() {
    try { st.promo = await Store.get('promo'); } catch {}
  }
  const savePromo = () => Store.set('promo', st.promo).catch(() => {});

  /* ---------- العنوان والوصف ---------- */
  /* فصول يوتيوب: 00:00 أولاً، ولا يقل الفصل عن 10 ثوانٍ */
  function chaptersText(p) {
    const ch = (p.chapters || []).filter(c => App.scenes[c.scene]);
    if (ch.length < 3) return '';
    const { st: starts } = Renderer.timeline(App.scenes), total = App.buf?.duration || 0;
    const ts = x => { x = Math.floor(x); const h = Math.floor(x / 3600), m = Math.floor(x % 3600 / 60), s = x % 60; return (h ? h + ':' + String(m).padStart(2, '0') : String(m).padStart(2, '0')) + ':' + String(s).padStart(2, '0'); };
    const list = []; let last = -99;
    ch.sort((a, b) => a.scene - b.scene).forEach((c, i) => { const t = i === 0 ? 0 : starts[c.scene]; if (t - last >= 10 && (!total || total - t >= 10)) { list.push(`${ts(t)} ${c.title}`); last = t; } });
    if (!list.length || !list[0].startsWith('00:00')) list.unshift('00:00 المقدمة');
    return list.length >= 3 ? 'فصول الفيديو:\n' + list.join('\n') : '';
  }

  function fullDescription(p) {
    const parts = [p.description.trim()];
    const ch = chaptersText(p); if (ch) parts.push(ch);
    if (p.tags?.length) parts.push(p.tags.join(' '));
    return parts.join('\n\n');
  }

  function renderMeta() {
    const p = st.promo, box = $('#ytMeta');
    if (!p) { box.innerHTML = `<p class="muted">${Settings.get().keys.gemini ? 'اضغط «اقترح» ليكتب Gemini عنواناً ووصفاً احترافياً.' : 'أضف مفتاح Gemini ليكتب لك العنوان والوصف.'}</p>`; return; }
    if (!$('#thumbTitle').value) $('#thumbTitle').value = p.thumbTitle;
    const row = (label, val, id, hint = '') => `<div class="meta-row"><div class="meta-head"><b>${label}</b><button class="btn ghost sm" data-copy="${id}" type="button">نسخ</button></div>${hint ? `<span class="muted small">${hint}</span>` : ''}<p id="${id}">${esc(val)}</p></div>`;
    box.innerHTML =
      titlesBox(p) +
      row('الوصف + الكلمات المفتاحية + الهاشتاقات', allText(p), 'mAll', 'زر واحد ينسخ كل شيء معاً. الصقه كما هو في خانة الوصف في يوتيوب');
  }
  /* 5 عناوين مقترحة: اختر واحداً أو عدّله، ثم انسخه وحده */
  function titlesBox(p) {
    const list = (p.titles?.length ? p.titles : [p.ytTitle]).slice(0, 5);
    return `<div class="meta-row"><div class="meta-head"><b>العنوان (5 اقتراحات، اختر وعدّل)</b><button class="btn ghost sm" data-copy="mTitle" type="button">نسخ العنوان</button></div>
      <div class="titles">${list.map((t, i) => `<label class="title-opt"><input type="radio" name="ytT" value="${i}" ${t === p.ytTitle ? 'checked' : ''}><span>${esc(t)}</span></label>`).join('')}</div>
      <input id="mTitleEdit" type="text" value="${esc(p.ytTitle)}" maxlength="100"><span class="muted small" id="mTitleLen">${p.ytTitle.length} / 100 حرف</span>
      <p id="mTitle" hidden>${esc(p.ytTitle)}</p>
      <div class="actions"><button class="btn ghost sm" id="btnMoreTitles" type="button">اقترح 5 عناوين أخرى</button></div></div>`;
  }
  async function moreTitles(b) {
    const p = st.promo; if (!p) return;
    b.disabled = true; b.textContent = 'يقترح…';
    try {
      const r = await AI.call([{ text: `You write YouTube titles for ${Channel.cur.niche}. Video narration: ${App.scenes.map(x => x.text).join(' ').slice(0, 2500)}
Current titles (do not repeat): ${(p.titles || []).join(' | ')}
Write 5 NEW strong, SEO-optimized, click-worthy titles in ${Channel.lang}, each under 70 characters, main search keyword first, different angles (question, number, shocking fact, how-to, story), no emojis, no lies.
Return JSON: {"titles":["","","","",""]}` }]);
      const t = (r.titles || []).map(x => String(x).trim()).filter(Boolean).slice(0, 5);
      if (!t.length) throw new Error('لم تصل عناوين');
      p.titles = t; savePromo(); renderMeta();
    } catch (e) { toast(e.message, 'err'); }
    finally { b.disabled = false; b.textContent = 'اقترح 5 عناوين أخرى'; }
  }
  function setTitle(t) { const p = st.promo; p.ytTitle = t.slice(0, 100); $('#mTitle').textContent = p.ytTitle; $('#mTitleLen').textContent = `${p.ytTitle.length} / 100 حرف`; savePromo(); }

  function allText(p) {
    const parts = [p.description.trim()];
    const ch = chaptersText(p); if (ch) parts.push(ch);
    if (p.keywords?.length) parts.push('الكلمات المفتاحية: ' + p.keywords.join('، '));
    if (p.tags?.length) parts.push(p.tags.join(' '));
    return parts.join('\n\n');
  }

  function localTitles(title, all) {
    const q = (all.match(/[^.!؟?]*[؟?]/) || [''])[0].trim().slice(0, 68);
    const t = title.replace(/[؟?!.]+$/, '');
    return [...new Set([title, q, `${t} | كل اللي لازم تعرفه`, `الحقيقة الكاملة عن ${t}`, `${t}… مش هتصدق اللي حصل!`].filter(x => x && x.length > 5).map(x => x.slice(0, 95)))].slice(0, 5);
  }
  /* بديل بدون Gemini: عنوان ووصف وهاشتاقات من نص الفيديو */
  function localPromo() {
    const all = App.scenes.map(x => x.text).join(' '), sents = all.split(/(?<=[.!؟?])\s+/).filter(Boolean);
    const q = sents.find(x => /[؟?]$/.test(x)), title = (App.projName || q || sents[0] || 'فيديو جديد').slice(0, 68);
    const en = [...new Set(App.scenes.flatMap(x => x.kw).filter(w => /^[a-z ]+$/i.test(w)))].slice(0, 6);
    const farm = Channel.id === 'farm';
    const tags = [...(farm ? ['#فادي_فارم', '#تربية_الدواجن', '#الفراخ_البلدي', '#Fadi_Farm', '#مزرعة', '#الريف_المصري'] : ['#مجرى', '#الجزائر', '#أخبار_الجزائر', '#ترند', '#Majra', '#الجزائر_ومصر']), ...en.map(w => '#' + w.replace(/\s+/g, '_'))].slice(0, 12);
    const bullets = App.scenes.filter(s => s.fx).slice(0, 5).map(s => '✅ ' + s.fx.text);
    const n = App.scenes.length, chapters = [0, Math.floor(n * 0.25), Math.floor(n * 0.5), Math.floor(n * 0.75)].filter((v, i, a) => a.indexOf(v) === i).map((sc, i) => ({ scene: sc, title: i === 0 ? 'المقدمة' : App.scenes[sc].text.split(/\s+/).slice(0, 5).join(' ') }));
    const description = [
      `${title} | ${sents[0] || ''}`,
      farm ? `في الفيديو ده من قناة فادي فارم بنتكلم عن ${title} بالتفصيل وبطريقة عملية، عشان تقدر تطبّق الكلام ده في مزرعتك أو في بيتك. ${sents.slice(1, 3).join(' ')}` : `في الفيديو ده من قناة مجرى بنحكيلك قصة ${title} من الأول للآخر: إيه اللي حصل، وليه الناس بتتكلم عنه، وإيه اللي جاي. ${sents.slice(1, 3).join(' ')}`,
      bullets.length ? 'في الفيديو ده هتعرف:\n' + bullets.join('\n') : '',
      `لو الفيديو عجبك اعمل لايك واشترك في القناة وفعّل الجرس 🔔 عشان يوصلك كل جديد ${farm ? 'عن تربية الدواجن والحيوانات' : 'عن الجزائر والعالم'}. ولو عندك سؤال اكتبه في التعليقات.`,
    ].filter(Boolean).join('\n\n');
    const keywords = [title, ...(farm ? ['تربية الفراخ البلدي', 'تربية الدواجن', 'مزرعة دواجن', 'علف الفراخ', 'فادي فارم'] : ['الجزائر', 'أخبار الجزائر', 'الجزائر اليوم', 'ترند الجزائر', 'قناة مجرى']), ...en].slice(0, 15);
    return { teaser: '', teaserScenes: [], thumbTitle: title.split(/\s+/).slice(0, 4).join(' '), thumbHighlight: '', thumbLayout: / ولا /.test(title) ? 'vs' : 'hero', thumbScene: 0, thumbPrompt: '', thumbPhrase: '',
      ytTitle: title, titles: localTitles(title, all), description, chapters, keywords, tags };
  }


  async function suggest() {
    if (!Settings.get().keys.gemini) return toast('أضف مفتاح Gemini أولاً', 'err');
    if (!App.scenes.length) return toast('لا توجد مشاهد بعد', 'err');
    const b = $('#btnPromo'); b.disabled = true; b.textContent = 'جارٍ الكتابة…';
    try {
      st.promo = await AI.promo(App.scenes.map(x => x.text)); savePromo();
      $('#thumbTitle').value = st.promo.thumbTitle; $('#thumbHi').value = st.promo.thumbHighlight || '';
      Thumb.reset(); renderMeta(); Thumb.enter(st.promo); Cover.show();
    } catch (e) {
      toast('Gemini: ' + e.message + '. كتبت عنواناً ووصفاً تلقائياً، عدّلهما كما تحب', 'err', 7000);
      st.promo = localPromo(); savePromo(); renderMeta(); Thumb.enter(st.promo); Cover.show();
    }
    b.disabled = false; b.textContent = 'اقترح بـ Gemini';
  }

  function enter() {
    const ready = App.buf && App.scenes.length;
    $('#pubEmpty').hidden = !!ready;
    $$('#v-publish .panel').forEach(p => p.hidden = !ready);
    if (!ready) return;
    renderMeta();
    if (!st.promo && Settings.get().keys.gemini) suggest(); else Thumb.enter(st.promo); Cover.show();
    Reel.enter();
    Cover.enter();
  }

  function bind() {
    Reel.bind();
    Cover.bind();
    $('#btnPromo').onclick = suggest;
    Thumb.bind();
    $('#ytMeta').addEventListener('change', e => { if (e.target.name === 'ytT') { const t = (st.promo.titles || [])[+e.target.value]; if (t) { $('#mTitleEdit').value = t; setTitle(t); } } });
    $('#ytMeta').addEventListener('input', e => { if (e.target.id === 'mTitleEdit') setTitle(e.target.value); });
    $('#ytMeta').addEventListener('click', async e => {
      if (e.target.id === 'btnMoreTitles') return moreTitles(e.target);
      const b = e.target.closest('[data-copy]'); if (!b) return;
      if (await copyText($('#' + b.dataset.copy).textContent)) toast(b.dataset.copy === 'mTitle' ? 'نُسخ العنوان' : 'نُسخ الوصف والكلمات المفتاحية والهاشتاقات'); else toast('تعذّر النسخ', 'err');
    });
  }

  function reset() { st.promo = null; st.shortBlob = null; Thumb.reset(); Reel.reset(); Cover.reset(); Store.set('promo', null).catch(() => {}); }

  return { enter, bind, loadPromo, reset, get promo() { return st.promo; } };
})();
