-- Swift — نظام الحسابات والموافقة (Supabase / Postgres)
-- يُنفَّذ مرة واحدة من: Supabase → SQL Editor → New query → الصق الملف → Run
-- لا يحتوي على أي كلمة سر أو مفتاح سري.

create extension if not exists pgcrypto;

-- بريد المالك (ليس سراً). يُستعمل لتحديد دور المالك على الخادم فقط.
create or replace function public.owner_email() returns text language sql immutable as $$ select 'fadisalmi05@gmail.com'::text $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  role text not null default 'user' check (role in ('user','owner')),
  status text not null default 'pending' check (status in ('pending','active','rejected','suspended','banned')),
  device_id text,                -- الجهاز المعتمد (جهاز واحد لكل حساب)
  pending_device text,           -- جهاز جديد ينتظر موافقة المالك
  device_label text,
  pending_label text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  last_seen timestamptz
);

create table if not exists public.audit_log (
  id bigserial primary key,
  at timestamptz not null default now(),
  actor uuid,
  target uuid,
  action text not null,
  detail jsonb
);

-- ========== إشعارات المالك (بدون أي سر في قاعدة البيانات) ==========
-- الدالة notify-owner تقرأ الحالة الحقيقية من الجدول بنفسها وترسل مرة واحدة فقط لكل حدث،
-- فلا يمكن لأحد استعمالها لإرسال رسائل مزيفة أو متكررة.
alter table public.profiles add column if not exists notified_signup boolean not null default false;
alter table public.profiles add column if not exists notified_device text;
create extension if not exists pg_net with schema extensions;

create or replace function public.ping_owner_now(p_id uuid) returns void language plpgsql security definer set search_path = public, extensions as $$
begin
  perform net.http_post(
    url := 'https://__PROJECT_REF__.supabase.co/functions/v1/notify-owner',
    body := jsonb_build_object('id', p_id),
    headers := '{"Content-Type":"application/json"}'::jsonb);
end $$;
revoke all on function public.ping_owner_now(uuid) from public, anon, authenticated;
create or replace function public.ping_owner() returns trigger language plpgsql security definer set search_path = public, extensions as $$
begin
  if new.role <> 'owner' and new.pending_device is not null and new.pending_device is distinct from old.pending_device then
    perform public.ping_owner_now(new.id);
  end if;
  return new;
end $$;
drop trigger if exists profiles_ping_owner on public.profiles;
create trigger profiles_ping_owner after update of pending_device on public.profiles for each row execute function public.ping_owner();

create or replace function public.is_owner() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles p join auth.users u on u.id = p.id
                 where p.id = auth.uid() and p.role = 'owner' and p.status = 'active'
                   and lower(u.email) = owner_email() and u.email_confirmed_at is not null)
$$;

alter table public.profiles enable row level security;
alter table public.audit_log enable row level security;

-- القراءة فقط: المستخدم يرى سطره، والمالك يرى الكل. لا كتابة مباشرة من التطبيق أبداً (كل التعديلات عبر الدوال بالأسفل).
drop policy if exists "own row" on public.profiles;
create policy "own row" on public.profiles for select using (auth.uid() = id);
drop policy if exists "owner reads all" on public.profiles;
create policy "owner reads all" on public.profiles for select using (public.is_owner());
drop policy if exists "owner reads log" on public.audit_log;
create policy "owner reads log" on public.audit_log for select using (public.is_owner());
grant usage on schema public to authenticated;
grant select on public.profiles, public.audit_log to authenticated;
revoke all on public.profiles, public.audit_log from anon;
revoke insert, update, delete on public.profiles from anon, authenticated;
revoke insert, update, delete on public.audit_log from anon, authenticated;

-- عند إنشاء حساب: سطر «قيد المراجعة». حساب المالك وحده يصبح مالكاً (بعد تأكيد البريد).
create or replace function public.on_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, role, status)
  values (new.id, lower(new.email),
          case when lower(new.email) = owner_email() then 'owner' else 'user' end,
          case when lower(new.email) = owner_email() then 'active' else 'pending' end)
  on conflict (id) do nothing;
  insert into public.audit_log (target, action, detail) values (new.id, 'signup', jsonb_build_object('email', lower(new.email)));
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.on_new_user();

-- يُستدعى عند كل فتح للتطبيق (وكل بضع دقائق): يرجع الحالة الحقيقية من الخادم ويربط الجهاز.
create or replace function public.my_access(p_device text, p_label text default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare r public.profiles; confirmed boolean;
begin
  if auth.uid() is null then return jsonb_build_object('status', 'signed_out'); end if;
  select (email_confirmed_at is not null) into confirmed from auth.users where id = auth.uid();
  if not coalesce(confirmed, false) then return jsonb_build_object('status', 'unverified'); end if;
  select * into r from public.profiles where id = auth.uid();
  if not found then return jsonb_build_object('status', 'pending'); end if;
  update public.profiles set last_seen = now() where id = r.id;
  if r.status = 'pending' and not coalesce(r.notified_signup, false) then perform public.ping_owner_now(r.id); end if;   -- إشعار المالك بعد تأكيد البريد فقط
  if r.status <> 'active' then return jsonb_build_object('status', r.status, 'role', r.role); end if;
  -- المالك لا يُقفل بجهاز (لا أحد غيره يستطيع الموافقة)، حسابه محمي بكلمة السر
  if r.role = 'owner' then return jsonb_build_object('status', 'active', 'role', r.role, 'email', r.email); end if;
  if coalesce(p_device, '') = '' then return jsonb_build_object('status', 'device_pending', 'role', r.role); end if;
  if r.device_id is null then
    update public.profiles set device_id = p_device, device_label = p_label, updated_at = now() where id = r.id;
    insert into public.audit_log (actor, target, action, detail) values (r.id, r.id, 'device_bound', jsonb_build_object('label', p_label));
  elsif r.device_id <> p_device then
    if r.pending_device is distinct from p_device then
      update public.profiles set pending_device = p_device, pending_label = p_label, updated_at = now() where id = r.id;
      insert into public.audit_log (actor, target, action, detail) values (r.id, r.id, 'device_change_request', jsonb_build_object('label', p_label));
    end if;
    return jsonb_build_object('status', 'device_pending', 'role', r.role);
  end if;
  return jsonb_build_object('status', 'active', 'role', r.role, 'email', r.email);
end $$;

-- إجراءات المالك فقط (التحقق على الخادم وليس في الواجهة)
create or replace function public.admin_set_status(p_user uuid, p_status text) returns void
language plpgsql security definer set search_path = public, auth as $$
begin
  if not public.is_owner() then raise exception 'not allowed'; end if;
  if p_status not in ('pending','active','rejected','suspended','banned') then raise exception 'bad status'; end if;
  if exists (select 1 from public.profiles where id = p_user and role = 'owner') then raise exception 'cannot change owner'; end if;
  update public.profiles set status = p_status, updated_at = now() where id = p_user;
  if p_status in ('rejected','suspended','banned') then
    delete from auth.refresh_tokens where user_id::text = p_user::text;   -- إنهاء الجلسات فوراً
    delete from auth.sessions where user_id = p_user;
  end if;
  insert into public.audit_log (actor, target, action, detail) values (auth.uid(), p_user, 'status', jsonb_build_object('to', p_status));
end $$;

drop function if exists public.admin_device(uuid, boolean);
create or replace function public.admin_device(p_user uuid, p_approve boolean, p_device text default null) returns void
language plpgsql security definer set search_path = public, auth as $$
begin
  if not public.is_owner() then raise exception 'not allowed'; end if;
  -- الموافقة على الجهاز الظاهر للمالك تحديداً (إذا طلب جهاز آخر في الأثناء لا يُعتمد بالخطأ)
  if p_device is not null and p_device <> '' and not exists (select 1 from public.profiles where id = p_user and pending_device = p_device) then
    raise exception 'الطلب تغيّر، حدّث القائمة';
  end if;
  if p_approve then
    update public.profiles set device_id = pending_device, device_label = pending_label, pending_device = null, pending_label = null, updated_at = now() where id = p_user and pending_device is not null;
    delete from auth.refresh_tokens where user_id::text = p_user::text;   -- الجهاز القديم يُسجَّل خروجه
    delete from auth.sessions where user_id = p_user;
  else
    update public.profiles set pending_device = null, pending_label = null, updated_at = now() where id = p_user;
  end if;
  insert into public.audit_log (actor, target, action, detail) values (auth.uid(), p_user, 'device', jsonb_build_object('approved', p_approve));
end $$;

-- فك ربط الجهاز (مثلاً إذا ضاع الهاتف) — يرتبط الحساب بأول جهاز يدخل بعدها
create or replace function public.admin_reset_device(p_user uuid) returns void
language plpgsql security definer set search_path = public, auth as $$
begin
  if not public.is_owner() then raise exception 'not allowed'; end if;
  update public.profiles set device_id = null, device_label = null, pending_device = null, pending_label = null, updated_at = now() where id = p_user;
  delete from auth.refresh_tokens where user_id::text = p_user::text;
  delete from auth.sessions where user_id = p_user;
  insert into public.audit_log (actor, target, action) values (auth.uid(), p_user, 'device_reset');
end $$;

revoke all on function public.admin_set_status(uuid, text), public.admin_device(uuid, boolean, text), public.admin_reset_device(uuid), public.my_access(text, text) from public, anon;
grant execute on function public.admin_set_status(uuid, text), public.admin_device(uuid, boolean, text), public.admin_reset_device(uuid), public.my_access(text, text), public.is_owner() to authenticated;

