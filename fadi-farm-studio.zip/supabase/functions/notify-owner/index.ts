// Swift — يرسل بريداً للمالك عند تسجيل حساب جديد أو طلب تغيير جهاز.
// يُستدعى من Database Webhook (جدول profiles: Insert + Update).
// الأسرار (تُضاف في Supabase → Edge Functions → Secrets، وليس في GitHub):
//   RESEND_API_KEY, OWNER_EMAIL, WEBHOOK_SECRET, MAIL_FROM (مثلاً: Swift <onboarding@resend.dev>), APP_URL
// لا يحتوي البريد على أي رابط قبول تلقائي: الموافقة فقط من لوحة المالك داخل التطبيق بعد تسجيل الدخول.
Deno.serve(async (req) => {
  if (req.headers.get("x-webhook-secret") !== Deno.env.get("WEBHOOK_SECRET")) return new Response("forbidden", { status: 403 });
  const body = await req.json().catch(() => null);
  const rec = body?.record, old = body?.old_record;
  if (!rec) return new Response("ok");
  let subject = "", text = "";
  if (body.type === "INSERT" && rec.role !== "owner") {
    subject = "Swift: طلب حساب جديد";
    text = `طلب حساب جديد في Swift\nالبريد: ${rec.email}\nالوقت: ${rec.created_at}\n\nللقبول أو الرفض افتح التطبيق وسجّل الدخول بحساب المالك ثم «الطلبات».\n${Deno.env.get("APP_URL") ?? ""}`;
  } else if (body.type === "UPDATE" && rec.pending_device && rec.pending_device !== old?.pending_device) {
    subject = "Swift: طلب تغيير جهاز";
    text = `الحساب ${rec.email} يطلب الدخول من جهاز جديد (${rec.pending_label ?? "غير معروف"}).\nللموافقة أو الرفض افتح «الطلبات» في حساب المالك.`;
  } else return new Response("ok");
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${Deno.env.get("RESEND_API_KEY")}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from: Deno.env.get("MAIL_FROM") ?? "Swift <onboarding@resend.dev>", to: [Deno.env.get("OWNER_EMAIL")], subject, text }),
  });
  return new Response(r.ok ? "sent" : "mail failed", { status: r.ok ? 200 : 502 });
});
