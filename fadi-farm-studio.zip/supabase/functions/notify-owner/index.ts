// Swift — يرسل بريداً للمالك عند طلب حساب جديد أو طلب تغيير جهاز.
// يُستدعى من مشغّل قاعدة البيانات بمعرّف الحساب فقط، ثم يقرأ الحالة الحقيقية من الجدول بمفتاح الخدمة
// (متوفر تلقائياً داخل Supabase)، ويرسل مرة واحدة لكل حدث. لا روابط قبول في البريد.
// السر الوحيد: RESEND_API_KEY (يُضاف في Supabase → Edge Functions → Secrets). اختياري: OWNER_EMAIL, APP_URL, MAIL_FROM
import { createClient } from "jsr:@supabase/supabase-js@2";

Deno.serve(async (req) => {
  const { id } = await req.json().catch(() => ({}));
  if (!id || !/^[0-9a-f-]{36}$/i.test(id)) return new Response("bad", { status: 400 });
  const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const { data: u } = await db.from("profiles").select("*").eq("id", id).maybeSingle();
  if (!u || u.role === "owner") return new Response("skip");
  let subject = "", text = "", mark: Record<string, unknown> = {};
  const app = Deno.env.get("APP_URL") ?? "https://fadi200723.github.io/fadi-farm/";
  if (!u.notified_signup && u.status === "pending") {
    subject = "Swift: طلب حساب جديد";
    text = `طلب حساب جديد في Swift\nالبريد: ${u.email}\nالوقت: ${u.created_at}\n\nللقبول أو الرفض افتح التطبيق بحساب المالك ثم «الطلبات».\n${app}`;
    mark = { notified_signup: true };
  } else if (u.pending_device && u.pending_device !== u.notified_device) {
    subject = "Swift: طلب تغيير جهاز";
    text = `الحساب ${u.email} يطلب الدخول من جهاز جديد (${u.pending_label ?? "غير معروف"}).\nللموافقة أو الرفض افتح «الطلبات» في حساب المالك.\n${app}`;
    mark = { notified_device: u.pending_device };
  } else return new Response("nothing");
  // ينظّف المفتاح من أي مسافة أو حرف غير مرئي قد يُلصق معه
  const key = (Deno.env.get("RESEND_API_KEY") ?? "").replace(/[^\x21-\x7e]/g, "");
  if (!key) return new Response("missing RESEND_API_KEY", { status: 500 });
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from: Deno.env.get("MAIL_FROM") ?? "Swift <onboarding@resend.dev>", to: [Deno.env.get("OWNER_EMAIL") ?? "fadisalmi05@gmail.com"], subject, text }),
  });
  if (!r.ok) return new Response("mail failed: " + (await r.text()).slice(0, 200), { status: 502 });
  await db.from("profiles").update(mark).eq("id", id);
  return new Response("sent");
});
