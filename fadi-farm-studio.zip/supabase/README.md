# Swift — تفعيل نظام الحسابات (يفعله صاحب التطبيق بنفسه)

ما دام `web/js/auth-config.js` فارغاً، يعمل التطبيق كما هو بدون تسجيل دخول.

1. أنشئ مشروعاً مجانياً على supabase.com.
2. SQL Editor ← الصق `schema.sql` ← Run.
3. Authentication ← Providers ← Email: فعّل Confirm email.
   Authentication ← URL Configuration: Site URL = https://fadi200723.github.io/fadi-farm/ وأضفه إلى Redirect URLs.
4. سجّل في التطبيق بالبريد fadisalmi05@gmail.com وبكلمة سر قوية تختارها أنت (لا تُكتب في أي ملف)، ثم أكّد البريد. يصبح هذا الحساب «المالك» تلقائياً من الخادم.
5. إشعارات البريد للمالك: أنشئ حساباً في resend.com وانسخ API key. ثم في Supabase ← Edge Functions:
   انشر `functions/notify-owner`، وأضف في Secrets القيم: RESEND_API_KEY و OWNER_EMAIL و WEBHOOK_SECRET (نص عشوائي طويل) و APP_URL.
   ثم Database ← Webhooks ← جدول profiles (Insert و Update) ← الدالة notify-owner مع الترويسة x-webhook-secret = نفس WEBHOOK_SECRET.
6. ضع Project URL و anon (publishable) key فقط في `web/js/auth-config.js`. هذان عامّان بطبيعتهما. لا تضع service_role ولا مفتاح Resend في GitHub أبداً.
