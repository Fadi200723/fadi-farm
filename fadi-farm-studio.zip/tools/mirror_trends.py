"""ينسخ مصادر الترندات (RSS/JSON) إلى web/data/feeds كل ساعة، ليقرأها التطبيق على الآيفون والحاسوب بدون قيود المتصفح."""
import json, os, sys, time, urllib.request

def fid(u):
    h = 5381
    for ch in u:
        h = ((h * 33) ^ ord(ch)) & 0xFFFFFFFF
    return format(h, 'x')

root = sys.argv[1] if len(sys.argv) > 1 else 'web'
urls = json.load(open(os.path.join(root, 'data', 'feeds.json')))
out = os.path.join(root, 'data', 'feeds'); os.makedirs(out, exist_ok=True)
ok = 0
for u in urls:
    try:
        req = urllib.request.Request(u, headers={'User-Agent': 'Mozilla/5.0 (FadiTrendsMirror)', 'Accept-Language': 'ar,en;q=0.8'})
        data = urllib.request.urlopen(req, timeout=25).read()
        if len(data) > 50:
            open(os.path.join(out, fid(u) + '.txt'), 'wb').write(data); ok += 1
    except Exception as e:
        print('skip', u, e)
    time.sleep(0.5)
json.dump({'at': int(time.time()), 'ok': ok}, open(os.path.join(root, 'data', 'mirror.json'), 'w'))
print('mirrored', ok, 'of', len(urls))
